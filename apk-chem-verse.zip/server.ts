import express from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { generateDiagnosticSetWithGemini } from './server/diagnosticGenerator';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Initialize Google GenAI client
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Helper to construct structured prompt that guarantees standard cards and optional lightweight mode
function buildTutorPrompt(studentName: string, grade: string, isLightweight: boolean): string {
  if (isLightweight) {
    return `Kamu adalah Kak Kimi, Tutor Kimia SMA Indonesia untuk ${studentName} (${grade}).
MODE: ULTRA-RINGAN & RESPON KILAT (Sangat Padat, Hemat Token, Hemat Kuota & CPU).

ATURAN WAJIB & FORMAT JAWABAN:
1. Berikan petunjuk bertahap (clue) tanpa membocorkan jawaban akhir secara langsung. Total jawaban maksimal 110 kata.
2. Gunakan HANYA format blok terstruktur persis berikut tanpa teks pengantar:
🎯 **Inti Jawaban:** [1-2 kalimat konsep kunci atau clue utama]
📐 **Langkah Penyelesaian:**
1. [Langkah 1: Rumus kunci / identifikasi variabel]
2. [Langkah 2: Substitusi angka & perbandingan mol / stoikiometri]
3. [Langkah 3: Arah penarikan kesimpulan]
💡 **Catatan/Tips:** [1 trik cepat atau shortcut kimia]
❓ **Cek Pemahaman:** [1 pertanyaan reflektif singkat]
🔊 **Narasi Suara:**
> "[1 kalimat pendek, hangat, dan memotivasi untuk dibacakan suara TTS]"

3. Tulis rumus kimia dengan notasi IUPAC (misal H₂SO₄, [OH⁻], 25°C).`;
  }

  return `Kamu adalah Kak Kimi, Tutor Kimia SMA Indonesia yang sabar, hangat, dan terpercaya untuk ${studentName} (${grade}).
ATURAN UTAMA:
1. JANGAN PERNAH memberikan jawaban akhir langsung. Berikan petunjuk bertahap (scaffolding clue) agar siswa menemukan pemahamannya sendiri.
2. Format jawaban WAJIB terstruktur rapi dengan tag-tag berikut:
🎯 **Inti Jawaban:** [Konsep esensial dan arah penyelesaian soal]
📐 **Langkah Penyelesaian:**
1. [Langkah 1: Identifikasi variabel diketahui & rumus dasar]
2. [Langkah 2: Konversi satuan / penyetaraan reaksi / perbandingan mol]
3. [Langkah 3: Perhitungan atau penalaran bertahap]
💡 **Catatan/Tips:** [Tips trik menghafal rumus / aplikasi ilmiah]
❓ **Cek Pemahaman:** [Pertanyaan reflektif untuk mengecek pemahaman siswa]
🔊 **Narasi Suara:**
> "[1-2 kalimat narasi ramah, jelas, dan menyemangati untuk dibacakan suara TTS]"

3. Gunakan notasi kimia IUPAC yang rapi dan benar.`;
}

// Dedicated Contextual Chat endpoint for "Tanya Kak Kimi"
app.post('/api/kimi/chat', async (req, res) => {
  try {
    const { message, history = [], topicTitle = 'Materi Kimia', topicContent = '', isLightweight = false } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Pesan pertanyaan tidak boleh kosong.' });
    }

    const cleanTitle = String(topicTitle).trim();
    const cleanContent = String(topicContent).trim();

    const modeDirective = isLightweight
      ? `MODE RINGAN & CEPAT: Jawab langsung to-the-point maksimal 3 kalimat padat. Tanpa basa-basi berlebih.`
      : `Berikan penjelasan yang mudah dipahami, gunakan analogi sehari-hari jika relevan, dan berikan rumus kimia atau contoh konkret jika membantu.`;

    const systemInstruction = `Kamu adalah Kak Kimi, kakak tingkat yang ramah, hangat, dan suportif dalam belajar kimia.
Siswa saat ini sedang membaca materi tentang "${cleanTitle}".
${modeDirective}

Berikut adalah teks materi yang sedang dibaca siswa:
"""
${cleanContent || 'Materi kimia SMA.'}
"""

ATURAN KETAT KAK KIMI:
1. Jawab pertanyaan siswa HANYA berdasarkan materi yang sedang dibaca ini.
2. Gunakan sapaan akrab dan bersahabat seperti kakak tingkat (panggil diri "Kak Kimi" dan sapa siswa dengan ramah).
3. Jika siswa bertanya di luar materi yang sedang dibaca ini, ingatkan dengan sopan dan kembalikan fokus ke materi ini. Contoh: "Wah pertanyaan menarik! Tapi saat ini kita sedang fokus mendalami materi ${cleanTitle} ya. Yuk kita bahas hal yang berkaitan dengan topik ini dulu agar pemahamanmu makin mantap!"
4. Pastikan notasi kimia IUPAC benar.`;

    const contents: any[] = [];
    if (Array.isArray(history)) {
      for (const item of history.slice(-6)) {
        if (item.role === 'user' || item.role === 'model') {
          contents.push({
            role: item.role,
            parts: [{ text: item.text }],
          });
        }
      }
    }

    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    let reply = '';
    const modelsToTry = isLightweight
      ? ['gemini-3.1-flash-lite', 'gemini-3.8-flash']
      : ['gemini-3.8-flash', 'gemini-3.1-flash-lite'];

    for (const modelName of modelsToTry) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents,
          config: {
            systemInstruction,
            temperature: isLightweight ? 0.3 : 0.6,
            maxOutputTokens: isLightweight ? 380 : 700,
          },
        });
        if (response.text) {
          reply = response.text;
          break;
        }
      } catch (err: any) {
        console.warn(`Kak Kimi fallback attempt for ${modelName}:`, err?.message);
      }
    }

    if (!reply) {
      reply = `Halo! Kak Kimi di sini. Terkait materi **${cleanTitle}**, mari kita perhatikan kembali konsep utamanya. Ada bagian spesifik yang ingin kamu tanyakan lebih detail?`;
    }

    res.json({ success: true, reply });
  } catch (error: any) {
    console.error('Kak Kimi API Error:', error);
    res.status(500).json({
      error: 'Terjadi kendala pada Kak Kimi. Silakan ulangi pertanyaanmu ya!',
      reply: 'Maaf ya, Kak Kimi sedang ada sedikit gangguan koneksi. Coba tanyakan sekali lagi pertanyaannya!',
    });
  }
});

// Chat endpoint for Gemini Chemistry Tutor (Supports Text + Image OCR + Mode Ringan)
app.post('/api/tutor/chat', async (req, res) => {
  try {
    const {
      message,
      history = [],
      studentName = 'Siswa',
      grade = 'SMA',
      systemPrompt,
      image,
      isLightweight = false,
    } = req.body;

    if ((!message || typeof message !== 'string') && !image) {
      return res.status(400).json({ error: 'Pesan atau gambar tidak boleh kosong.' });
    }

    const systemInstruction = systemPrompt || buildTutorPrompt(studentName, grade, Boolean(isLightweight));

    // Format chat history
    const contents: any[] = [];
    if (Array.isArray(history)) {
      // For lightweight mode, use shorter history to save tokens and latency
      const maxHistory = isLightweight ? 4 : 8;
      for (const item of history.slice(-maxHistory)) {
        if (item.role === 'user' || item.role === 'model') {
          contents.push({
            role: item.role,
            parts: [{ text: item.text }],
          });
        }
      }
    }

    const userParts: any[] = [];

    // 1. UPLOAD FOTO SOAL (OCR + AI SOLVER)
    if (image && image.data) {
      let pureBase64 = String(image.data);
      let detectedMime = image.mimeType || 'image/jpeg';
      if (pureBase64.includes(';base64,')) {
        const split = pureBase64.split(';base64,');
        detectedMime = split[0].replace('data:', '') || detectedMime;
        pureBase64 = split[1];
      }

      userParts.push({
        inlineData: {
          mimeType: detectedMime,
          data: pureBase64,
        },
      });
    }

    const defaultPrompt = isLightweight
      ? 'Baca teks soal dari gambar ini. Berikan petunjuk pengerjaan super ringkas sesuai format terstruktur.'
      : 'Baca teks soal dari gambar ini. Jangan berikan jawaban akhir, tapi berikan langkah-langkah atau petunjuk pengerjaannya.';
    const promptText = message || defaultPrompt;
    userParts.push({ text: promptText });

    contents.push({
      role: 'user',
      parts: userParts,
    });

    const modelsToTry = isLightweight
      ? ['gemini-3.1-flash-lite', 'gemini-3.8-flash']
      : ['gemini-3.8-flash', 'gemini-3.1-flash-lite'];
    let replyText = '';
    let lastError: any = null;

    for (const modelName of modelsToTry) {
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents,
            config: {
              systemInstruction,
              temperature: isLightweight ? 0.3 : 0.6,
              maxOutputTokens: isLightweight ? 450 : 850,
            },
          });
          if (response.text) {
            replyText = response.text;
            break;
          }
        } catch (err: any) {
          lastError = err;
          if (attempt === 0) {
            await new Promise((resolve) => setTimeout(resolve, 500));
          }
        }
      }
      if (replyText) break;
    }

    if (!replyText) {
      console.warn('Gemini temporary high demand spike:', lastError?.message);
      replyText = `🎯 **Inti Jawaban:** Halo ${studentName}! Pertanyaanmu telah dicatat oleh Kak Kimi.\n\n📐 **Langkah Penyelesaian:**\n1. Amati persamaan reaksi atau variabel soal yang tertera.\n2. Tentukan rumus atau hukum kimia dasar yang relevan.\n3. Masukkan angka yang diketahui ke dalam persamaan.\n\n💡 **Catatan/Tips:** Perhatikan koefisien reaksi dan konversi satuan mol.\n❓ **Cek Pemahaman:** Apakah kamu sudah mengidentifikasi zat reaktan dan produknya?\n\n🔊 **Narasi Suara:**\n> "Hai, Kak Kimi di sini. Coba periksa variabel yang diketahui dan masukkan ke rumus dasarnya ya. Kamu pasti bisa!"`;
    }

    // Extract spoken narrative from reply text if available
    let spokenText = '';
    const voiceIdx = replyText.indexOf('🔊');
    if (voiceIdx !== -1) {
      const voiceSubstring = replyText.slice(voiceIdx);
      const quoteMatch = voiceSubstring.match(/["“]([^"”]+)["”]/);
      if (quoteMatch && quoteMatch[1]) {
        spokenText = quoteMatch[1].trim();
      } else {
        const lines = voiceSubstring.split('\n').filter((l) => l.trim().startsWith('>'));
        if (lines.length > 0) {
          spokenText = lines.map((l) => l.replace(/^>\s*/, '').replace(/["“”]/g, '')).join(' ').trim();
        }
      }
    }

    if (!spokenText) {
      spokenText = replyText
        .replace(/🎯|📐|✅|💡|❓|🔊|\*\*|__|```[\s\S]*?```/g, '')
        .replace(/\n+/g, ' ')
        .slice(0, 240);
    }

    res.json({ reply: replyText, spokenText });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    res.json({
      reply: '🎯 **Inti Jawaban:** Terjadi kendala saat menganalisis soal.\n\n📐 **Langkah Penyelesaian:**\n1. Pastikan gambar cukup terang dan jelas terbaca.\n2. Kirim ulang pertanyaan atau foto.\n\n💡 **Catatan/Tips:** Format gambar JPEG atau PNG resolusi sedang bekerja paling cepat.\n\n🔊 **Narasi Suara:**\n> "Maaf, terjadi kendala koneksi singkat. Silakan kirimkan kembali pertanyaanmu ya!"',
      spokenText: 'Terjadi kendala saat menganalisis soal. Silakan unggah kembali ya!',
    });
  }
});

// 2. GENERATOR KUIS INSTAN (TEXT-TO-QUIZ)
app.post('/api/quiz/generate', async (req, res) => {
  try {
    const { text, isLightweight = true } = req.body;
    if (!text || typeof text !== 'string' || text.trim().length < 10) {
      return res.status(400).json({ error: 'Teks materi kimia minimal 10 karakter.' });
    }

    const systemInstruction = `Kamu adalah pembuat soal kimia SMA. Buatkan 5 soal pilihan ganda (A-E) berdasarkan teks berikut. Soal harus padat, jelas, dan menguji konsep kunci. Kembalikan HASIL HANYA dalam format JSON array dengan struktur: [{ "soal": "...", "pilihan": {"A": "...", "B": "...", "C": "...", "D": "...", "E": "..."}, "jawaban_benar": "A" }]. Tanpa teks pembuka atau penutup.`;

    const modelToUse = isLightweight ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash';
    let response: any;
    try {
      response = await ai.models.generateContent({
        model: modelToUse,
        contents: [
          {
            role: 'user',
            parts: [{ text: `Teks materi:\n\n${text}` }],
          },
        ],
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.3,
          maxOutputTokens: 1100,
        },
      });
    } catch (primaryErr) {
      response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          {
            role: 'user',
            parts: [{ text: `Teks materi:\n\n${text}` }],
          },
        ],
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.3,
          maxOutputTokens: 1100,
        },
      });
    }

    const rawOutput = response.text || '';
    const cleaned = rawOutput.replace(/```json\n?|\n?```/g, '').trim();
    const parsed = JSON.parse(cleaned);

    if (!Array.isArray(parsed) || parsed.length === 0) {
      throw new Error('Hasil respon bukan berupa array kuis JSON.');
    }

    return res.json({ success: true, questions: parsed });
  } catch (error: any) {
    console.error('Text-to-Quiz generator error:', error);
    return res.status(500).json({
      error: error?.message || 'Gagal menghasilkan kuis dari teks materi kimia.',
    });
  }
});

// 3. NOTEBOOK RINGKASAN OTOMATIS (AI NOTES SUMMARY + Mode Ringan)
app.post('/api/notes/summarize', async (req, res) => {
  try {
    const { materiTeks, topicTitle, isLightweight = true } = req.body;
    if (!materiTeks || typeof materiTeks !== 'string' || materiTeks.trim().length === 0) {
      return res.status(400).json({ error: 'Teks materi kimia tidak boleh kosong.' });
    }

    const userPrompt = `Buatkan rangkuman materi kimia berikut dalam bentuk 3 poin penting. Gunakan format HTML (gunakan tag <ul> dan <li>) agar rapi. Jangan berikan teks pengantar.\n\nTeks materi (${topicTitle || 'Kimia'}):\n${materiTeks}`;

    const modelToUse = isLightweight ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash';
    let response: any;
    try {
      response = await ai.models.generateContent({
        model: modelToUse,
        contents: userPrompt,
        config: {
          temperature: 0.3,
          maxOutputTokens: 500,
        },
      });
    } catch (err) {
      response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: userPrompt,
        config: {
          temperature: 0.3,
          maxOutputTokens: 500,
        },
      });
    }

    let summaryHtml = response.text || '';
    // Clean code fences if any
    summaryHtml = summaryHtml.replace(/^```html\n?|^```\n?/i, '').replace(/\n?```$/i, '').trim();

    // Fallback if empty or formatting issue
    if (!summaryHtml.includes('<li') && !summaryHtml.includes('<ul')) {
      const items = summaryHtml.split('\n').filter((l: string) => l.trim().length > 0).slice(0, 3);
      summaryHtml = `<ul>${items.map((it: string) => `<li>${it.replace(/^[-*•0-9.]+\s*/, '')}</li>`).join('')}</ul>`;
    }

    res.json({ success: true, summaryHtml });
  } catch (error: any) {
    console.error('AI Notes summarization error:', error);
    res.status(500).json({
      error: error?.message || 'Gagal membuat rangkuman materi kimia otomatis.',
      summaryHtml: `<ul><li>Konsep fundamental materi kimia mencakup hukum kekekalan materi dan interaksi ikatan antar partikel.</li><li>Perhitungan kuantitatif stoikiometri menghubungkan perbandingan mol zat reaktan dengan produk reaksi.</li><li>Aplikasi konsep kimia bermanfaat dalam menjaga kelestarian lingkungan dan proses industri modern.</li></ul>`,
    });
  }
});

// Dynamic 5-Question Prerequisite Diagnostic Generator endpoint
app.post('/api/diagnostic/generate', async (req, res) => {
  try {
    const { materiId, topicName, topik, previousSetIds = [] } = req.body;
    const query = topik || topicName || materiId;
    if (!query || typeof query !== 'string') {
      return res.status(400).json({ error: 'Topik materi atau materiId diperlukan.' });
    }

    const diagnosticSet = await generateDiagnosticSetWithGemini(
      ai,
      query,
      previousSetIds
    );

    res.json(diagnosticSet);
  } catch (error: any) {
    console.error('Error generating diagnostic set:', error);
    res.status(500).json({ error: 'Gagal membuat soal asesmen kesiapan belajar.', details: error?.message });
  }
});

// Diagnostic Topics & Prerequisites Catalog endpoint
app.get('/api/diagnostic/topics', async (_req, res) => {
  try {
    const { PREREQUISITE_CATALOG } = await import('./server/diagnosticGenerator.ts');
    res.json({ topics: PREREQUISITE_CATALOG });
  } catch (err: any) {
    res.status(500).json({ error: 'Gagal memuat katalog topik diagnostik.' });
  }
});

// Learning Activity Tracker Beacon Endpoint (Supports navigator.sendBeacon during pagehide/beforeunload)
app.post('/api/activity/beacon', (req, res) => {
  try {
    const data = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    // Log beacon payload for monitoring
    if (data && data.student_id) {
      console.log(`[Activity Beacon] Student: ${data.student_id} | Type: ${data.type} | Duration: ${data.duration_sec}s | Ref: ${data.ref_title}`);
    }
    res.status(200).json({ ok: true, received: true });
  } catch (err) {
    res.status(200).json({ ok: true });
  }
});

// Text-to-Speech endpoint using Gemini TTS for voice responses
app.post('/api/tutor/tts', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Teks tidak boleh kosong.' });
    }

    // Limit text length for TTS to prevent excessive processing
    const cleanText = text.slice(0, 450);

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: cleanText,
              speechMetadata: {
                style: 'Sabar, ramah, hangat, guru kimia Indonesia',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      res.json({ audio: base64Audio });
    } else {
      res.status(500).json({ error: 'Gagal membuat audio suara tutor.' });
    }
  } catch (error: any) {
    console.warn('Gemini TTS error (will fallback to browser speech):', error?.message);
    res.status(500).json({ error: 'TTS unavailable', fallback: true });
  }
});

// Dedicated AI Command endpoint for Teachers (with strict temperature 0)
app.post('/api/ai-command/parse', async (req, res) => {
  try {
    const { prompt, context, daftarKelas, daftarBab, daftarMateri, filePayload } = req.body;
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ error: 'Perintah guru tidak boleh kosong.' });
    }

    const daftarKelasStr = daftarKelas || 'Kelas 10, Kelas 11, Kelas 12';
    const daftarBabStr = daftarBab || '- [ID: "bab_01_atom"] Bab 1: Struktur Atom & Tabel Periodik (Kelas 10)\n- [ID: "bab_02_ikatan"] Bab 2: Ikatan Kimia & Bentuk Molekul (Kelas 10)\n- [ID: "bab_03_stoikiometri"] Bab 3: Stoikiometri & Konsep Mol (Kelas 10)\n- [ID: "bab_04_termokimia"] Bab 1: Termokimia & Perubahan Entalpi (Kelas 11)\n- [ID: "bab_05_laju"] Bab 2: Laju Reaksi & Faktor Pengaruh (Kelas 11)';
    const daftarMateriStr = daftarMateri || '- [ID: "mat_01"] "Hakikat Ilmu Kimia & Sifat Materi" (Bab: bab_01_atom)\n- [ID: "mat_02_ikatan"] "Ikatan Kimia" (Bab: bab_02_ikatan)';

    const fileInstruction = filePayload?.name
      ? `\n\nPENTING: Guru telah melampirkan file referensi ("${filePayload.name}"). Anda WAJIB membuat materi/soal 100% berdasarkan isi file ini. Jangan berhalusinasi.`
      : '';

    const systemInstruction = `Anda adalah mesin eksekusi AI Command untuk platform Chemverse. Anda BUKAN penulis kreatif. Anda hanya boleh mengeksekusi perintah guru secara LITERAL dan 100% AKURAT. 

ATURAN KETAT (PELANGGARAN TIDAK DAPAT DITOLERANSI):
1. JANGAN BERHALUSINASI. Jika guru meminta soal tentang "Struktur Atom", buatlah HANYA soal tentang Struktur Atom. Jangan pernah menggantinya dengan topik lain (seperti ikatan kovalen).
2. PATUHI JUMLAH. Jika guru meminta "5 soal", hasilkan TEPAT 5 soal. Bukan 4, bukan 6.
3. JIKA DATA KURANG. Jika guru meminta menambahkan file PDF/Word/PPT/Foto tapi tidak memberikan URL-nya, gunakan format placeholder: [URL_FILE_PDF_DARI_GURU]. Jangan mengarang URL.
4. FORMAT GAMES & LINK. Jika guru meminta menambah games atau link, gunakan operasi "add_game" atau "add_materi" dengan attachmentType "link".
5. MENIMPA / MENGGANTI KONTEN LAMA (SMART OVERWRITE):
   - Jika guru memerintahkan untuk MENGGANTI, MENIMPA, ATAU MEMPERBARUI konten yang sudah ada (misal: 'Ganti materi bab 1 dengan PDF ini', 'Timpa materi Ikatan Kimia di bab 2 kelas 10 dengan ringkasan ini'), gunakan operasi 'update_materi' dan gunakan ID materi lama yang sesuai dari STATE.
   - Isi parameter 'targetId' dan 'id' dengan ID materi lama yang sesuai dari STATE.
   - Isi parameter 'targetTitle' dengan judul materi lama yang ditimpa (misal: "Ikatan Kimia").
   - Isi parameter 'replaceStrategy': "overwrite" (atau "append" jika diminta menggabungkan).
   - Jika melibatkan file upload (PDF/Word/dll.), isi 'attachmentType' ("pdf"|"word"|"ppt"|"foto"|"link") dan 'attachmentUrl' (gunakan format [URL_FILE_PDF_DARI_GURU] jika URL belum tersedia).
   - Pastikan menyertakan judul materi lama yang ditimpa di dalam ringkasan rencana ("summary") dan "preview" agar guru tahu persis materi apa yang akan hilang/digantikan (misal: "Menimpa materi 'Ikatan Kimia' di Bab 2 dengan ringkasan PDF baru").
   - Naikkan status impact risk ke "high" atau "critical" jika melibatkan file upload atau penimpaan materi penting.
6. MENYISIPKAN KONTEN BARU (SMART PLACEMENT):
   - Jika guru memerintahkan untuk menambahkan ke bagian tertentu, gunakan operasi 'add_materi' dengan babId yang tepat.
   - Pastikan 'babId' cocok dengan ID Bab dari DATA STATE saat ini.
7. TATA LETAK & DESAIN INTERAKTIF (CUSTOM DESIGN & INTERACTIVE LAYOUT):
   - Jika guru meminta materi dibuat seperti buku yang bisa dibalik (flipbook), set layoutType menjadi 'flipbook' dan pecah isi materi ke dalam array contentPages (tiap halaman maksimal 2-3 paragraf).
   - Jika guru meminta materi dibuat seperti PPT/Slide, set layoutType menjadi 'presentation' dan pecah ke contentPages.
   - Jika guru mengunggah PDF dan ingin menampilkannya langsung, set layoutType menjadi 'pdf_viewer'.
   - Jika tidak diminta khusus, default layoutType adalah 'standard'.
8. JIKA PERINTAH TIDAK JELAS. Jika guru mengetik hal yang tidak masuk akal atau ambigu, JANGAN mengeksekusi. Isi field "clarification" dengan pertanyaan balik ke guru, dan kosongkan "operations".${fileInstruction}

DATA STATE SAAT INI:
- Daftar Kelas: ${daftarKelasStr}
- Daftar Bab:
${daftarBabStr}
- Daftar Materi Saat Ini:
${daftarMateriStr}

OUTPUT HARUS BERUPA JSON VALID SESUAI SKEMA:
{
  "summary": "string",
  "clarification": "string (opsional jika ambigu)",
  "operations": [
    {
      "op": "add_soal" | "update_soal" | "delete_soal" | "add_materi" | "update_materi" | "delete_materi" | "add_game" | "add_pengumuman",
      "params": {
        // update_materi: { targetId, id, targetTitle, babId, judul, isi, deskripsi, layoutType: ("standard"|"flipbook"|"presentation"|"pdf_viewer"), contentPages: string[], replaceStrategy: "overwrite"|"append", attachmentUrl, attachmentType, linkUrl }
        // update_soal: { targetId, id, replaceStrategy: "overwrite"|"append", pertanyaan, jawaban, ... }
        // add_materi: { babId, judul, isi, deskripsi, layoutType: ("standard"|"flipbook"|"presentation"|"pdf_viewer"), contentPages: string[], attachmentUrl, attachmentType: ("pdf"|"word"|"ppt"|"foto"|"link"), linkUrl }
        // add_soal: { babId, pertanyaan, pilihan: { A, B, C, D }, jawaban, pembahasan, tingkatKesulitan }
        // add_game: { babId, judul, tipeGame, deskripsi, linkUrl }
        // add_pengumuman: { judul, isi, targetKelas }
        // delete_*: { id, babId }
      },
      "preview": "string",
      "detail": "string"
    }
  ],
  "impact": {
    "added": number,
    "updated": number,
    "deleted": number,
    "risk": "low" | "medium" | "high" | "critical"
  }
}`;

    const contextBab = context?.selectedBab || 'bab_01_atom';
    const contextGrade = context?.selectedGrade || '10';

    const userParts: any[] = [];
    if (filePayload && filePayload.data) {
      if (filePayload.mimeType && filePayload.mimeType.startsWith('text/')) {
        let textContent = '';
        try {
          textContent = Buffer.from(filePayload.data, 'base64').toString('utf-8');
        } catch {
          textContent = filePayload.data;
        }
        userParts.push({ text: `[DOKUMEN LAMPIRAN GURU: ${filePayload.name}]\n${textContent}` });
      } else {
        userParts.push({
          inlineData: {
            mimeType: filePayload.mimeType || 'application/pdf',
            data: filePayload.data,
          },
        });
      }
    }

    userParts.push({
      text: `Konteks Bab aktif: ${contextBab}, Kelas: ${contextGrade}.\nPerintah Guru: "${prompt}"`,
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          role: 'user',
          parts: userParts,
        },
      ],
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        temperature: 0,
      },
    });

    const responseText = response.text?.trim() || '';
    const cleaned = responseText.replace(/```json\n?|\n?```/g, '').trim();
    const parsed = JSON.parse(cleaned);

    if (filePayload?.name) {
      parsed.attachedFileName = filePayload.name;
    }

    return res.json({ success: true, plan: parsed });
  } catch (error: any) {
    console.error('AI Command parse error on server:', error);
    return res.status(500).json({ error: error?.message || 'Gagal memproses perintah AI.' });
  }
});


// Mount Vite or static files
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ChemiVerse SMA server running on port ${PORT}`);
  });
}

startServer();
