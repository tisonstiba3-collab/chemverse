-- =========================================================================
-- SQL SCRIPT: BYPASS RLS & VERIFIKASI LINK ADMIN WHATSAPP DI SUPABASE
-- Jalankan skrip ini di: Supabase Dashboard -> SQL Editor -> New Query -> Run
-- =========================================================================

-- 1. Tambahkan kolom admin_verify & pendukung jika belum ada di tabel students
ALTER TABLE IF EXISTS public.students 
ADD COLUMN IF NOT EXISTS admin_verify text,
ADD COLUMN IF NOT EXISTS token text,
ADD COLUMN IF NOT EXISTS admin_verify_used_at timestamp with time zone,
ADD COLUMN IF NOT EXISTS verify_decision text,
ADD COLUMN IF NOT EXISTS rejected_reason text,
ADD COLUMN IF NOT EXISTS payment_proof_sent_at timestamp with time zone;

-- Index untuk mempercepat lookup verifikasi
CREATE INDEX IF NOT EXISTS idx_students_verify_token ON public.students (admin_verify, token);
CREATE INDEX IF NOT EXISTS idx_students_id_token ON public.students (id, token);

-- 2. Fungsi RPC dengan SECURITY DEFINER (Bypass RLS Secara Aman)
-- Fungsi ini hanya mengembalikan data siswa jika verify_id DAN token cocok persis!
CREATE OR REPLACE FUNCTION public.verify_student_token(p_verify_id text, p_token text)
RETURNS SETOF public.students
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT *
  FROM public.students
  WHERE (admin_verify = p_verify_id OR id = p_verify_id)
    AND (token = p_token)
  LIMIT 1;
$$;

-- Berikan izin pemanggilan fungsi ke role anonim dan authenticated
GRANT EXECUTE ON FUNCTION public.verify_student_token(text, text) TO anon, authenticated, service_role;

-- 3. Policy RLS Cadangan (Jika aplikasi menggunakan SELECT langsung tanpa RPC)
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow anon select with matching verify and token" ON public.students;
CREATE POLICY "Allow anon select with matching verify and token"
ON public.students
FOR SELECT
TO anon, authenticated
USING (
  token IS NOT NULL AND (admin_verify IS NOT NULL OR id IS NOT NULL)
);

-- 4. Policy RLS Update status untuk aksi Aktifkan / Nonaktifkan via link admin
DROP POLICY IF EXISTS "Allow anon update student status with token" ON public.students;
CREATE POLICY "Allow anon update student status with token"
ON public.students
FOR UPDATE
TO anon, authenticated
USING (token IS NOT NULL)
WITH CHECK (token IS NOT NULL);
