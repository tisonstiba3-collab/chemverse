import { initializeApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  getDocs,
  writeBatch,
  doc,
  getDoc,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json' with { type: 'json' };
import { CURRICULUM_DATA } from '../src/data/curriculumData.ts';

const app = initializeApp(firebaseConfig);
const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

async function seedCurriculum() {
  console.log('🚀 Step 1: Deleting old "curriculum" documents from Firestore...');
  const curriculumCol = collection(db, 'curriculum');
  const existingDocsSnap = await getDocs(curriculumCol);
  console.log(`Found ${existingDocsSnap.size} existing curriculum documents.`);

  if (existingDocsSnap.size > 0) {
    const deleteBatch = writeBatch(db);
    existingDocsSnap.forEach((d) => {
      console.log(`- Queued for deletion: curriculum/${d.id}`);
      deleteBatch.delete(d.ref);
    });
    await deleteBatch.commit();
    console.log('✅ Old curriculum documents deleted successfully.');
  }

  console.log('\n🚀 Step 2: Seeding new curriculum data into Firestore with batch write...');
  const writeBatchInstance = writeBatch(db);
  const nowIso = new Date().toISOString();

  // Document 1: kelasX (9 topics)
  const docRefX = doc(db, 'curriculum', 'kelasX');
  writeBatchInstance.set(docRefX, {
    grade: 'X',
    title: 'Kurikulum Kimia SMA Kelas X (Fase E)',
    topics: CURRICULUM_DATA.X,
    topicsCount: CURRICULUM_DATA.X.length,
    updatedAt: nowIso,
  });

  // Document 2: kelasXI (9 topics)
  const docRefXI = doc(db, 'curriculum', 'kelasXI');
  writeBatchInstance.set(docRefXI, {
    grade: 'XI',
    title: 'Kurikulum Kimia SMA Kelas XI (Fase F)',
    topics: CURRICULUM_DATA.XI,
    topicsCount: CURRICULUM_DATA.XI.length,
    updatedAt: nowIso,
  });

  // Document 3: kelasXII (6 topics)
  const docRefXII = doc(db, 'curriculum', 'kelasXII');
  writeBatchInstance.set(docRefXII, {
    grade: 'XII',
    title: 'Kurikulum Kimia SMA Kelas XII (Fase F)',
    topics: CURRICULUM_DATA.XII,
    topicsCount: CURRICULUM_DATA.XII.length,
    updatedAt: nowIso,
  });

  await writeBatchInstance.commit();
  console.log('✅ Seeding completed via writeBatch committed to Firestore.');

  console.log('\n🚀 Step 3: Verifying seeded documents from Firestore...');
  const checkDocs = ['kelasX', 'kelasXI', 'kelasXII'];
  const summary: Record<string, { grade: string; count: number; firstTopic: string; lastTopic: string }> = {};

  for (const docId of checkDocs) {
    const s = await getDoc(doc(db, 'curriculum', docId));
    if (s.exists()) {
      const data = s.data();
      const t = data.topics || [];
      summary[docId] = {
        grade: data.grade,
        count: t.length,
        firstTopic: t[0]?.title || '-',
        lastTopic: t[t.length - 1]?.title || '-',
      };
      console.log(`- Document "${docId}": ${t.length} topics seeded.`);
    } else {
      console.error(`❌ Document "${docId}" not found in Firestore!`);
    }
  }

  console.log('\n📊 SEEDING SUMMARY RESULT:');
  console.log(JSON.stringify(summary, null, 2));
}

seedCurriculum()
  .then(() => {
    console.log('\n🎉 ALL CURRICULUM SEEDING FINISHED SUCCESSFULLY!');
    process.exit(0);
  })
  .catch((err) => {
    console.error('❌ Seeding error:', err);
    process.exit(1);
  });
