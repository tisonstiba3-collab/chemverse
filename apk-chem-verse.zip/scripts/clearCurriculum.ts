import { initializeApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  getDocs,
  writeBatch,
  doc,
  setDoc,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json' with { type: 'json' };

const app = initializeApp(firebaseConfig);
const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

async function clearCurriculum() {
  console.log('🧹 Menghapus seluruh materi lama dari koleksi "curriculum" di Firestore...');
  const curriculumCol = collection(db, 'curriculum');
  const existingDocsSnap = await getDocs(curriculumCol);

  if (existingDocsSnap.size > 0) {
    const batch = writeBatch(db);
    existingDocsSnap.forEach((d) => {
      console.log(`- Menghapus dokumen: curriculum/${d.id}`);
      batch.delete(d.ref);
    });
    await batch.commit();
    console.log('✅ Seluruh dokumen materi lama di Firestore telah berhasil dihapus.');
  } else {
    console.log('ℹ️ Koleksi "curriculum" sudah kosong.');
  }

  // Buat dokumen kosong siap diisi ulang untuk kelasX, kelasXI, dan kelasXII
  const nowIso = new Date().toISOString();
  const resetBatch = writeBatch(db);

  resetBatch.set(doc(db, 'curriculum', 'kelasX'), {
    grade: 'X',
    title: 'Kurikulum Kimia SMA Kelas X',
    topics: [],
    topicsCount: 0,
    updatedAt: nowIso,
  });

  resetBatch.set(doc(db, 'curriculum', 'kelasXI'), {
    grade: 'XI',
    title: 'Kurikulum Kimia SMA Kelas XI',
    topics: [],
    topicsCount: 0,
    updatedAt: nowIso,
  });

  resetBatch.set(doc(db, 'curriculum', 'kelasXII'), {
    grade: 'XII',
    title: 'Kurikulum Kimia SMA Kelas XII',
    topics: [],
    topicsCount: 0,
    updatedAt: nowIso,
  });

  await resetBatch.commit();
  console.log('✅ Dokumen kelasX, kelasXI, kelasXII telah direset menjadi kosong (0 topik), siap disusun ulang.');
}

clearCurriculum()
  .then(() => {
    console.log('🎉 PEMBERSIHAN MATERI SELESAI!');
    process.exit(0);
  })
  .catch((err) => {
    console.error('❌ Gagal membersihkan materi:', err);
    process.exit(1);
  });
