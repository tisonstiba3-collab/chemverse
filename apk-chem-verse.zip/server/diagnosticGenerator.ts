import { GoogleGenAI } from '@google/genai';
import {
  DiagnosticQuestionType,
  MatchingItem,
  DiagnosticQuestion,
  DiagnosticSet,
} from '../src/types/chemistry';
import {
  KAMUS_PRASYARAT,
  DAFTAR_TOPIK_PRASYARAT,
  cariPrasyaratTopik,
  buildPrerequisiteCheckPrompt,
  formatKesiapanAnalysis,
  getProceduralPrerequisiteSet,
  PROCEDURAL_PREREQUISITE_SETS,
  PrasyaratMapping,
} from '../src/data/kamusPrasyarat';

export type { DiagnosticQuestionType, MatchingItem, DiagnosticQuestion, DiagnosticSet };
export { KAMUS_PRASYARAT, DAFTAR_TOPIK_PRASYARAT, cariPrasyaratTopik };

export interface PrerequisiteCatalogItem {
  code: string;
  name: string;
  grade: 'X' | 'XI' | 'XII';
  prasyarat: string[];
  aliases: string[];
  prerequisiteSummary?: string;
}

// Katalog Topik Prasyarat untuk kompatibilitas tampilan
export const PREREQUISITE_CATALOG: PrerequisiteCatalogItem[] = DAFTAR_TOPIK_PRASYARAT.map((item) => ({
  code: item.code,
  name: item.topik,
  grade: item.grade,
  prasyarat: [KAMUS_PRASYARAT[item.topik] || 'Materi Prasyarat'],
  aliases: [
    item.topik.toLowerCase(),
    item.topik.toLowerCase().replace(/\s+/g, '-'),
    item.code.toLowerCase(),
  ],
  prerequisiteSummary: KAMUS_PRASYARAT[item.topik],
}));

/**
 * Resolves a topic title, query, code or alias into the exact catalog item with prerequisite info.
 */
export function resolveMateri(queryOrCode: string): PrerequisiteCatalogItem {
  const mapping = cariPrasyaratTopik(queryOrCode);
  const foundInCatalog = PREREQUISITE_CATALOG.find(
    (c) => c.name.toLowerCase() === mapping.topik.toLowerCase()
  );

  if (foundInCatalog) return foundInCatalog;

  return {
    code: 'X.02',
    name: mapping.topik,
    grade: mapping.grade,
    prasyarat: [mapping.prasyarat],
    aliases: [mapping.topik.toLowerCase()],
    prerequisiteSummary: mapping.prasyarat,
  };
}

/**
 * Calls Gemini API with strict instructions:
 * "Siswa ingin mempelajari materi [Topik Pilihan]. Namun, buatkan 5 soal pilihan ganda (A-E) yang HANYA menguji materi prasyarat berikut: [Materi Prasyarat dari Kamus]. DILARANG membuat soal tentang [Topik Pilihan]."
 *
 * If Gemini has high latency or temporary spike, seamlessly falls back to procedural generator.
 */
export async function generateDiagnosticSetWithGemini(
  ai: GoogleGenAI,
  topicQueryOrCode: string,
  _previousSetIds: string[] = []
): Promise<DiagnosticSet> {
  const mapping = cariPrasyaratTopik(topicQueryOrCode);
  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
  const randomSalt = Math.random().toString(36).substring(2, 6);
  const setId = `diag_${mapping.topik.replace(/\s+/g, '_').toLowerCase()}_${dateStr}_${randomSalt}`;

  const { systemInstruction, userPrompt } = buildPrerequisiteCheckPrompt(
    mapping.topik,
    mapping.prasyarat
  );

  const callGemini = async (): Promise<DiagnosticSet | null> => {
    const modelsToTry = ['gemini-3.1-flash-lite', 'gemini-3.8-flash'];
    for (const modelName of modelsToTry) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: userPrompt,
          config: {
            systemInstruction,
            responseMimeType: 'application/json',
            temperature: 0.3,
            maxOutputTokens: 1250,
          },
        });

        const text = response.text?.trim() || '';
        if (!text) continue;

        const cleanJson = text.replace(/^```json/i, '').replace(/```$/i, '').trim();
        const parsed: any = JSON.parse(cleanJson);

      const rawQuestions = parsed.soal || parsed.questions;
      if (rawQuestions && Array.isArray(rawQuestions) && rawQuestions.length >= 5) {
        const validatedQuestions: DiagnosticQuestion[] = rawQuestions.slice(0, 5).map((q: any, idx: number) => {
          // Normalize options A, B, C, D, E
          let opsiMap: Record<string, string> = {};
          if (q.opsi && typeof q.opsi === 'object' && !Array.isArray(q.opsi)) {
            opsiMap = q.opsi;
          } else if (Array.isArray(q.opsi)) {
            ['A', 'B', 'C', 'D', 'E'].forEach((letter, i) => {
              opsiMap[letter] = String(q.opsi[i] || `Pilihan ${letter}`);
            });
          } else if (q.pilihan && typeof q.pilihan === 'object') {
            opsiMap = q.pilihan;
          } else {
            opsiMap = {
              A: 'Pilihan A',
              B: 'Pilihan B',
              C: 'Pilihan C',
              D: 'Pilihan D',
              E: 'Pilihan E',
            };
          }

          let keyStr = String(q.kunci || q.jawaban_benar || q.jawabanBenar || 'A')
            .trim()
            .toUpperCase();
          if (!['A', 'B', 'C', 'D', 'E'].includes(keyStr)) {
            keyStr = 'A';
          }

          const levelNum = (idx < 2 ? 1 : idx < 4 ? 2 : 3) as 1 | 2 | 3;
          const levelLabel =
            levelNum === 1
              ? 'Level 1: Konsep Dasar Prasyarat'
              : levelNum === 2
              ? 'Level 2: Penerapan & Analisis Prasyarat'
              : 'Level 3: HOTS / Penalaran Prasyarat';

          return {
            id: `q${idx + 1}`,
            nomor: idx + 1,
            level: levelNum,
            levelLabel,
            tipe: 'PG',
            bloom: idx < 2 ? 'C2' : idx < 4 ? 'C3' : 'C4',
            indikator: q.indikator || `Menguji materi prasyarat: ${mapping.prasyarat}`,
            soal: q.soal || q.pertanyaan || `Soal nomor ${idx + 1}`,
            opsi: opsiMap,
            kunci: keyStr,
            pembahasan:
              q.pembahasan ||
              q.penjelasan ||
              `Jawaban yang tepat adalah opsi ${keyStr}. Penjelasan didasarkan pada materi prasyarat: ${mapping.prasyarat}.`,
            prasyaratTerkait: mapping.prasyarat,
          };
        });

        return {
          materi_id: mapping.topik,
          materi_nama: mapping.topik,
          kelas: mapping.grade,
          prasyarat: [mapping.prasyarat],
          judul_tes: `Asesmen Kesiapan Belajar untuk: ${mapping.topik}`,
          set_id: setId,
          level_kesulitan: 'pilihan-ganda-prasyarat',
          threshold: 70,
          soal: validatedQuestions,
          metadata: {
            generated_at: now.toISOString(),
            model_used: modelName,
          },
        };
      }
    } catch (err: any) {
      console.warn(`Gemini prerequisite test attempt for ${modelName} failed:`, err?.message);
    }
  }
  return null;
};

  const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 5000));

  try {
    const result = await Promise.race([callGemini(), timeoutPromise]);
    if (result) {
      return result;
    }
  } catch (err) {
    console.warn('Race error during diagnostic generation:', err);
  }

  // Fallback to procedural generator tailored specifically to the prerequisite dictionary
  console.info(`Using verified procedural prerequisite set for ${mapping.topik}`);
  return getProceduralPrerequisiteSet(mapping.topik, setId);
}

/**
 * Procedural Dynamic Diagnostic Generator for 5 Prerequisite Questions.
 */
export function generateProceduralAdaptive5QuestionSet(
  catalogItem: PrerequisiteCatalogItem | { name?: string; topik?: string },
  setId: string
): DiagnosticSet {
  const topicName = ('name' in catalogItem && catalogItem.name) ? catalogItem.name : (catalogItem as any).topik || 'Struktur Atom';
  return getProceduralPrerequisiteSet(topicName, setId);
}

/**
 * Evaluates student answers, calculates percentage score, and synthesizes the exact analysis:
 * "Kesiapan Anda: [Persentase]%". Jika di bawah 70%, beri saran:
 * "Silakan pelajari kembali materi prasyarat [Materi Prasyarat] sebelum masuk ke [Topik Pilihan]."
 */
export function evaluateDiagnosticAnswers(
  diagnosticSet: DiagnosticSet,
  userAnswers: Record<string, any>
) {
  let totalCorrect = 0;
  const questions = diagnosticSet.soal || [];

  let level1Correct = 0;
  let level1Total = 0;
  let level2Correct = 0;
  let level2Total = 0;
  let level3Correct = 0;
  let level3Total = 0;

  const missedConcepts: string[] = [];

  questions.forEach((q) => {
    const userAns = userAnswers[q.id];
    let isCorrect = false;

    if (q.tipe === 'PG') {
      isCorrect =
        typeof userAns === 'string' &&
        userAns.trim().toUpperCase() === String(q.kunci).trim().toUpperCase();
    } else if (q.tipe === 'BS') {
      if (q.statements && Array.isArray(q.statements)) {
        if (typeof userAns === 'object' && userAns !== null && !Array.isArray(userAns)) {
          isCorrect = q.statements.every((st) => userAns[st.id] === st.kunci);
        } else if (typeof userAns === 'string') {
          isCorrect = userAns.trim().toUpperCase() === String(q.kunci).trim().toUpperCase();
        }
      } else {
        isCorrect =
          typeof userAns === 'string' &&
          userAns.trim().toUpperCase() === String(q.kunci).trim().toUpperCase();
      }
    } else if (q.tipe === 'PGK') {
      const correctKeys = Array.isArray(q.kunci) ? [...q.kunci].sort() : [];
      const userKeys = Array.isArray(userAns) ? [...userAns].sort() : [];
      isCorrect =
        correctKeys.length === userKeys.length &&
        correctKeys.every((val, i) => val === userKeys[i]);
    } else if (q.tipe === 'MENJODOHKAN') {
      const correctMap = (q.kunci as Record<string, string>) || {};
      const userMap = (userAns as Record<string, string>) || {};
      const keys = Object.keys(correctMap);
      isCorrect =
        keys.length > 0 && keys.every((k) => userMap[k] === correctMap[k]);
    }

    if (q.level === 1) {
      level1Total++;
      if (isCorrect) level1Correct++;
    } else if (q.level === 2) {
      level2Total++;
      if (isCorrect) level2Correct++;
    } else if (q.level === 3) {
      level3Total++;
      if (isCorrect) level3Correct++;
    }

    if (isCorrect) {
      totalCorrect++;
    } else {
      if (q.prasyaratTerkait && !missedConcepts.includes(q.prasyaratTerkait)) {
        missedConcepts.push(q.prasyaratTerkait);
      }
    }
  });

  const totalQuestions = questions.length || 5;
  const rawScore = Math.round((totalCorrect / totalQuestions) * 100);
  const passed = rawScore >= (diagnosticSet.threshold || 70);

  const l1Percent = level1Total > 0 ? Math.round((level1Correct / level1Total) * 100) : 0;
  const l2Percent = level2Total > 0 ? Math.round((level2Correct / level2Total) * 100) : 0;
  const l3Percent = level3Total > 0 ? Math.round((level3Correct / level3Total) * 100) : 0;

  const primaryPrereq =
    diagnosticSet.prasyarat?.[0] ||
    KAMUS_PRASYARAT[diagnosticSet.materi_nama] ||
    'materi prasyarat';

  // Analysis strictly adhering to rule #4:
  // "Kesiapan Anda: [Persentase]%". Jika di bawah 70%, beri saran:
  // "Silakan pelajari kembali materi prasyarat [Materi Prasyarat] sebelum masuk ke [Topik Pilihan]."
  const analysisObj = formatKesiapanAnalysis(
    rawScore,
    diagnosticSet.materi_nama,
    primaryPrereq
  );

  const analysisFeedback = `${analysisObj.kesiapanText}. ${analysisObj.saranText}`;

  return {
    score: rawScore,
    passed,
    totalCorrect,
    totalQuestions,
    levelBreakdown: {
      level1: { correct: level1Correct, total: level1Total, percent: l1Percent },
      level2: { correct: level2Correct, total: level2Total, percent: l2Percent },
      level3: { correct: level3Correct, total: level3Total, percent: l3Percent },
    },
    missedPrasyarat: missedConcepts.length > 0 ? missedConcepts : [primaryPrereq],
    analysisFeedback,
    kesiapanText: analysisObj.kesiapanText,
    saranText: analysisObj.saranText,
  };
}
