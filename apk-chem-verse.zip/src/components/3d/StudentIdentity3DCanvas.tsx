import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float } from '@react-three/drei';
import * as THREE from 'three';
import { isWebGLAvailable } from './webglUtils';
import WebGLErrorBoundary from './WebGLErrorBoundary';

interface AtomVisualProps {
  isHovered?: boolean;
  role?: 'siswa' | 'guru';
}

function AtomVisual({ isHovered = false, role = 'siswa' }: AtomVisualProps) {
  const coreRef = useRef<THREE.Mesh>(null);
  const ring1Ref = useRef<THREE.Group>(null);
  const ring2Ref = useRef<THREE.Group>(null);
  const ring3Ref = useRef<THREE.Group>(null);
  const electron1Ref = useRef<THREE.Mesh>(null);
  const electron2Ref = useRef<THREE.Mesh>(null);
  const electron3Ref = useRef<THREE.Mesh>(null);

  const coreColor = role === 'guru' ? '#818cf8' : '#22d3ee';
  const emissiveColor = role === 'guru' ? '#4f46e5' : '#0891b2';
  const ringColor = role === 'guru' ? '#a5b4fc' : '#38bdf8';

  useFrame((state, delta) => {
    const time = state.clock.getElapsedTime();
    const speed = isHovered ? 2.2 : 1.0;

    if (coreRef.current) {
      coreRef.current.rotation.y += delta * 0.8 * speed;
      const pulse = Math.sin(time * 3) * 0.08 + 1;
      coreRef.current.scale.set(pulse, pulse, pulse);
    }

    if (ring1Ref.current) {
      ring1Ref.current.rotation.x = Math.PI / 3;
      ring1Ref.current.rotation.y += delta * 1.4 * speed;
    }
    if (ring2Ref.current) {
      ring2Ref.current.rotation.x = -Math.PI / 3;
      ring2Ref.current.rotation.z += delta * 1.2 * speed;
    }
    if (ring3Ref.current) {
      ring3Ref.current.rotation.y = Math.PI / 4;
      ring3Ref.current.rotation.x += delta * 1.6 * speed;
    }

    // Position electrons along orbits
    if (electron1Ref.current) {
      const angle = time * 2.5 * speed;
      electron1Ref.current.position.set(Math.cos(angle) * 1.3, Math.sin(angle) * 1.3, 0);
    }
    if (electron2Ref.current) {
      const angle = time * 2.1 * speed + 1.5;
      electron2Ref.current.position.set(Math.cos(angle) * 1.3, Math.sin(angle) * 1.3, 0);
    }
    if (electron3Ref.current) {
      const angle = time * 2.8 * speed + 3.0;
      electron3Ref.current.position.set(Math.cos(angle) * 1.3, Math.sin(angle) * 1.3, 0);
    }
  });

  return (
    <Float speed={2.5} rotationIntensity={0.8} floatIntensity={0.6}>
      <group>
        {/* Glowing Central Nucleus */}
        <mesh ref={coreRef}>
          <sphereGeometry args={[0.55, 32, 32]} />
          <meshStandardMaterial
            color={coreColor}
            emissive={emissiveColor}
            emissiveIntensity={isHovered ? 0.9 : 0.55}
            roughness={0.2}
            metalness={0.7}
          />
        </mesh>

        {/* Orbit Ring 1 */}
        <group ref={ring1Ref}>
          <mesh>
            <torusGeometry args={[1.3, 0.025, 16, 64]} />
            <meshStandardMaterial color={ringColor} opacity={0.65} transparent roughness={0.3} />
          </mesh>
          <mesh ref={electron1Ref}>
            <sphereGeometry args={[0.13, 16, 16]} />
            <meshStandardMaterial color="#ffffff" emissive="#38bdf8" emissiveIntensity={1.2} />
          </mesh>
        </group>

        {/* Orbit Ring 2 */}
        <group ref={ring2Ref}>
          <mesh>
            <torusGeometry args={[1.3, 0.025, 16, 64]} />
            <meshStandardMaterial color={ringColor} opacity={0.65} transparent roughness={0.3} />
          </mesh>
          <mesh ref={electron2Ref}>
            <sphereGeometry args={[0.13, 16, 16]} />
            <meshStandardMaterial color="#ffffff" emissive="#a855f7" emissiveIntensity={1.2} />
          </mesh>
        </group>

        {/* Orbit Ring 3 */}
        <group ref={ring3Ref}>
          <mesh>
            <torusGeometry args={[1.3, 0.025, 16, 64]} />
            <meshStandardMaterial color={ringColor} opacity={0.65} transparent roughness={0.3} />
          </mesh>
          <mesh ref={electron3Ref}>
            <sphereGeometry args={[0.13, 16, 16]} />
            <meshStandardMaterial color="#ffffff" emissive="#34d399" emissiveIntensity={1.2} />
          </mesh>
        </group>
      </group>
    </Float>
  );
}

function Atom2DFallback({ isHovered = false, role = 'siswa' }: AtomVisualProps) {
  const isGuru = role === 'guru';
  const primaryColor = isGuru ? '#818cf8' : '#22d3ee';
  const secondaryColor = isGuru ? '#a855f7' : '#06b6d4';

  return (
    <div className="w-full h-full flex items-center justify-center relative select-none">
      <div className={`relative w-28 h-28 flex items-center justify-center transition-transform duration-500 ${isHovered ? 'scale-110' : 'scale-100'}`}>
        {/* Glow backdrop */}
        <div
          className="absolute inset-0 rounded-full blur-xl opacity-40 animate-pulse"
          style={{ backgroundColor: primaryColor }}
        />

        {/* Orbit Ring 1 */}
        <div
          className="absolute inset-1 rounded-full border border-cyan-400/40 animate-spin"
          style={{ animationDuration: isHovered ? '3s' : '7s', transform: 'rotateX(65deg) rotateY(20deg)' }}
        >
          <div className="w-2 h-2 rounded-full bg-cyan-300 shadow-[0_0_8px_#22d3ee] absolute -top-1 left-1/2 -translate-x-1/2" />
        </div>

        {/* Orbit Ring 2 */}
        <div
          className="absolute inset-1 rounded-full border border-violet-400/40 animate-spin"
          style={{ animationDuration: isHovered ? '4s' : '9s', animationDirection: 'reverse', transform: 'rotateX(-65deg) rotateY(-20deg)' }}
        >
          <div className="w-2 h-2 rounded-full bg-violet-300 shadow-[0_0_8px_#a78bfa] absolute -bottom-1 left-1/2 -translate-x-1/2" />
        </div>

        {/* Orbit Ring 3 */}
        <div
          className="absolute inset-2 rounded-full border border-emerald-400/40 animate-spin"
          style={{ animationDuration: isHovered ? '2.5s' : '6s', transform: 'rotateY(75deg)' }}
        >
          <div className="w-2 h-2 rounded-full bg-emerald-300 shadow-[0_0_8px_#34d399] absolute top-1/2 -left-1 -translate-y-1/2" />
        </div>

        {/* Core Glowing Nucleus */}
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center shadow-lg relative z-10 transition-transform duration-300"
          style={{
            background: `radial-gradient(circle at 35% 35%, #ffffff 0%, ${primaryColor} 45%, ${secondaryColor} 100%)`,
            boxShadow: `0 0 20px ${primaryColor}99`,
          }}
        >
          <span className="text-white font-black text-xs drop-shadow font-mono">
            {isGuru ? 'GR' : '⚛'}
          </span>
        </div>
      </div>
    </div>
  );
}

export default function StudentIdentity3DCanvas({
  isHovered = false,
  role = 'siswa',
}: {
  isHovered?: boolean;
  role?: 'siswa' | 'guru';
}) {
  if (!isWebGLAvailable()) {
    return <Atom2DFallback isHovered={isHovered} role={role} />;
  }

  return (
    <WebGLErrorBoundary fallback={<Atom2DFallback isHovered={isHovered} role={role} />}>
      <div className="w-full h-full relative cursor-grab active:cursor-grabbing">
        <Canvas
          camera={{ position: [0, 0, 3.8], fov: 45 }}
          gl={{ antialias: true, alpha: true, powerPreference: 'low-power' }}
          dpr={[1, 1.5]}
        >
          <ambientLight intensity={0.8} />
          <directionalLight position={[5, 5, 5]} intensity={1.5} />
          <pointLight position={[-4, -4, -2]} intensity={0.8} color="#22d3ee" />
          <AtomVisual isHovered={isHovered} role={role} />
        </Canvas>
      </div>
    </WebGLErrorBoundary>
  );
}
