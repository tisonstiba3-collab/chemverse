import React, { useRef, Suspense, lazy } from 'react';
import { MoleculeData } from '../../types/chemistry';
import { useInViewport } from './useInViewport';
import CanvasShimmerSkeleton from './CanvasShimmerSkeleton';
import { isWebGLAvailable } from './webglUtils';
import WebGLErrorBoundary from './WebGLErrorBoundary';

// Code-split Three.js Canvas via React.lazy
const LazyMoleculeViewerCanvas = lazy(() => import('./MoleculeViewerCanvas'));

interface MoleculeViewer3DProps {
  molecule: MoleculeData;
  autoRotate?: boolean;
  showElectronCloud?: boolean;
}

function Molecule2DFallback({ molecule }: { molecule: MoleculeData }) {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center relative select-none p-6">
      <div className="relative w-48 h-48 rounded-full border border-cyan-400/20 bg-slate-900/60 backdrop-blur flex items-center justify-center shadow-[0_0_30px_rgba(34,211,238,0.15)]">
        {/* Glowing orbital ring */}
        <div
          className="absolute inset-2 rounded-full border border-dashed border-cyan-400/30 animate-spin"
          style={{ animationDuration: '20s' }}
        />

        {/* Molecular formula badge */}
        <div className="text-center z-10 px-4">
          <div className="text-3xl font-black font-mono text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-sky-200 to-purple-300 tracking-wider">
            {molecule.chemicalFormula || molecule.name}
          </div>
          <div className="text-xs font-semibold text-slate-300 mt-1 max-w-[140px] truncate">
            {molecule.name}
          </div>
          <div className="text-[10px] font-mono text-cyan-400 mt-2 px-2.5 py-0.5 rounded-full bg-cyan-950/60 border border-cyan-500/30 inline-block">
            {molecule.atoms.length} Atom • Model 2D
          </div>
        </div>

        {/* Orbiting atoms */}
        {molecule.atoms.slice(0, 4).map((atom, idx) => {
          const angles = [0, 90, 180, 270];
          const angle = (angles[idx] * Math.PI) / 180;
          const r = 74;
          const x = Math.cos(angle) * r;
          const y = Math.sin(angle) * r;
          return (
            <div
              key={idx}
              className="absolute w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold font-mono text-white shadow-md border border-white/20"
              style={{
                backgroundColor: atom.color || '#22d3ee',
                transform: `translate(${x}px, ${y}px)`,
              }}
            >
              {atom.element}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function MoleculeViewer3D({
  molecule,
  autoRotate = true,
  showElectronCloud = true,
}: MoleculeViewer3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInViewport = useInViewport(containerRef, 0.1);

  if (!isWebGLAvailable()) {
    return (
      <div ref={containerRef} className="w-full h-full relative">
        <Molecule2DFallback molecule={molecule} />
      </div>
    );
  }

  return (
    <div ref={containerRef} className="w-full h-full relative cursor-grab active:cursor-grabbing">
      <WebGLErrorBoundary fallback={<Molecule2DFallback molecule={molecule} />}>
        {isInViewport ? (
          <Suspense fallback={<CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-xl" />}>
            <LazyMoleculeViewerCanvas
              molecule={molecule}
              autoRotate={autoRotate}
              showElectronCloud={showElectronCloud}
            />
          </Suspense>
        ) : (
          <CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-xl" />
        )}
      </WebGLErrorBoundary>

      {/* Helpful Hint */}
      <div className="absolute bottom-3 left-4 text-xs font-mono text-slate-400 bg-slate-950/70 backdrop-blur px-2.5 py-1 rounded border border-slate-800/80 pointer-events-none">
        🖱️ Klik & geser untuk memutar • Scroll untuk zoom
      </div>
    </div>
  );
}
