import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  symbol: string;
  opacity: number;
}

const CHEMICAL_SYMBOLS = ['H₂O', 'CH₄', 'CO₂', 'C₆H₆', 'NaCl', 'H⁺', 'OH⁻', 'e⁻', 'O₂', 'NH₃'];
const COLORS = ['#22d3ee', '#a78bfa', '#34d399', '#38bdf8', '#fbbf24'];

export default function HeroMoleculeLightweightBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Create 35 lightweight particles (enough for gorgeous ambient feel without lag)
    const particleCount = Math.min(35, Math.floor((width * height) / 30000));
    const particles: Particle[] = Array.from({ length: particleCount }).map(() => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.45,
      vy: (Math.random() - 0.5) * 0.45,
      radius: Math.random() * 2 + 1.5,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      symbol: CHEMICAL_SYMBOLS[Math.floor(Math.random() * CHEMICAL_SYMBOLS.length)],
      opacity: Math.random() * 0.4 + 0.2,
    }));

    let isVisible = document.visibilityState === 'visible';
    const handleVisibility = () => {
      isVisible = document.visibilityState === 'visible';
    };
    document.addEventListener('visibilitychange', handleVisibility);

    const render = () => {
      if (!isVisible) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      ctx.clearRect(0, 0, width, height);

      // Draw subtle connecting bonds between nearby particles
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 120) {
            const alpha = (1 - dist / 120) * 0.12;
            ctx.strokeStyle = `rgba(34, 211, 238, ${alpha})`;
            ctx.lineWidth = 0.8;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      // Draw each particle and its floating formula
      for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        // Glowing nucleus
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.opacity;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();

        // Chemical formula text tag
        ctx.font = '10px monospace';
        ctx.fillStyle = '#94a3b8';
        ctx.globalAlpha = p.opacity * 0.75;
        ctx.fillText(p.symbol, p.x + 8, p.y + 3);
      }

      ctx.globalAlpha = 1.0;
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10 bg-[#070B18]">
      {/* Aurora Ambient Blobs for deep glowing neon lighting (pure CSS) */}
      <div className="absolute -top-[15%] left-[20%] w-[500px] h-[500px] rounded-full opacity-[0.14] blur-[120px] bg-cyan-500 will-change-transform animate-[auroraOne_18s_ease-in-out_infinite_alternate]" />
      <div className="absolute top-[35%] -right-[10%] w-[550px] h-[550px] rounded-full opacity-[0.12] blur-[130px] bg-violet-600 will-change-transform animate-[auroraTwo_22s_ease-in-out_infinite_alternate]" />
      <div className="absolute -bottom-[20%] left-[10%] w-[450px] h-[450px] rounded-full opacity-[0.10] blur-[120px] bg-amber-500 will-change-transform animate-[auroraThree_16s_ease-in-out_infinite_alternate]" />

      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />

      {/* Vignette overlay for cinematic depth */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(7,11,24,0.7)_100%)]" />
    </div>
  );
}
