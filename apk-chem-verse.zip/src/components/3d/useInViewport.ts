import { useState, useEffect, RefObject } from 'react';

/**
 * Hook to observe if an element is currently intersecting within the viewport.
 * Uses threshold 0.1 as specified in performance fixes.
 */
export function useInViewport(
  ref: RefObject<HTMLElement | null>,
  threshold: number = 0.1
): boolean {
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    if (typeof IntersectionObserver === 'undefined') {
      setInView(true);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        setInView(entry.isIntersecting);
      },
      {
        threshold,
        rootMargin: '100px 0px', // Pre-fetch slightly before hitting screen
      }
    );

    observer.observe(el);

    return () => {
      observer.disconnect();
    };
  }, [ref, threshold]);

  return inView;
}
