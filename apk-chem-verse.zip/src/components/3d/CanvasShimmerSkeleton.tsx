import React from 'react';

interface CanvasShimmerSkeletonProps {
  className?: string;
  rounded?: string;
}

export default function CanvasShimmerSkeleton({
  className = 'w-full h-full',
  rounded = 'rounded-2xl',
}: CanvasShimmerSkeletonProps) {
  return (
    <div
      className={`relative overflow-hidden bg-slate-900/60 border border-white/5 flex flex-col items-center justify-center ${rounded} ${className}`}
    >
      {/* Animated Shimmer Light Sweep */}
      <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.8s_infinite] bg-gradient-to-r from-transparent via-white/[0.06] to-transparent pointer-events-none" />

      {/* Orbit Indicator Placeholder */}
      <div className="relative flex items-center justify-center">
        <div className="w-12 h-12 rounded-full border border-cyan-500/30 border-t-cyan-400 animate-spin" style={{ animationDuration: '3s' }} />
        <div className="absolute w-4 h-4 rounded-full bg-cyan-400/40 shadow-[0_0_12px_rgba(34,211,238,0.5)]" />
      </div>
      <span className="text-[10px] font-mono text-slate-400 mt-2 tracking-wider">
        Memuat 3D...
      </span>
    </div>
  );
}
