import React, { useRef, Suspense, lazy } from 'react';
import { BookOpen, FlaskConical, Gamepad2, Award, TrendingUp, Sparkles, GraduationCap, Stethoscope } from 'lucide-react';
import { MenuKey } from '../../types/chemistry';
import { useInViewport } from './useInViewport';
import CanvasShimmerSkeleton from './CanvasShimmerSkeleton';
import { isWebGLAvailable } from './webglUtils';
import WebGLErrorBoundary from './WebGLErrorBoundary';

// Code-split Three.js Canvas via React.lazy
const LazyCardIconCanvas = lazy(() => import('./CardIconCanvas'));

interface CardIconProps {
  type: MenuKey;
  isHovered?: boolean;
}

function CardIcon2DFallback({ type, isHovered = false }: CardIconProps) {
  const getIconConfig = () => {
    switch (type) {
      case 'materi':
        return {
          icon: BookOpen,
          color: 'from-cyan-400 to-blue-500',
          shadow: 'rgba(34,211,238,0.3)',
          badge: 'Materi Lengkap',
        };
      case 'latihan':
        return {
          icon: FlaskConical,
          color: 'from-emerald-400 to-teal-500',
          shadow: 'rgba(52,211,153,0.3)',
          badge: 'Praktikum Soal',
        };
      case 'games':
        return {
          icon: Gamepad2,
          color: 'from-purple-400 to-indigo-500',
          shadow: 'rgba(167,139,250,0.3)',
          badge: 'Arena Kuis',
        };
      case 'tka':
        return {
          icon: Award,
          color: 'from-amber-400 to-rose-500',
          shadow: 'rgba(251,191,36,0.3)',
          badge: 'Simulasi UTBK',
        };
      case 'progres':
        return {
          icon: TrendingUp,
          color: 'from-sky-400 to-emerald-500',
          shadow: 'rgba(56,189,248,0.3)',
          badge: 'Statistik Belajar',
        };
      case 'jurnal':
        return {
          icon: Sparkles,
          color: 'from-pink-400 to-violet-500',
          shadow: 'rgba(244,114,182,0.3)',
          badge: 'Refleksi Diri',
        };
      case 'guru':
        return {
          icon: GraduationCap,
          color: 'from-indigo-400 to-cyan-500',
          shadow: 'rgba(99,102,241,0.3)',
          badge: 'Dasbor Guru',
        };
      case 'diagnostik':
        return {
          icon: Stethoscope,
          color: 'from-teal-400 to-cyan-500',
          shadow: 'rgba(45,212,191,0.3)',
          badge: 'Tes Prasyarat',
        };
      default:
        return {
          icon: Sparkles,
          color: 'from-cyan-400 to-blue-500',
          shadow: 'rgba(34,211,238,0.3)',
          badge: 'Modul Kimia',
        };
    }
  };

  const config = getIconConfig();
  const IconComponent = config.icon;

  return (
    <div className="w-full h-full flex flex-col items-center justify-center relative select-none">
      <div
        className={`w-20 h-20 rounded-2xl flex items-center justify-center relative transition-all duration-300 ${
          isHovered ? 'scale-110 shadow-lg' : 'scale-100 shadow-md'
        } bg-gradient-to-br ${config.color}`}
        style={{ boxShadow: `0 0 25px ${config.shadow}` }}
      >
        <div className="absolute inset-0 rounded-2xl bg-white/10 backdrop-blur-xs" />
        <IconComponent className="w-10 h-10 text-white relative z-10 drop-shadow" />
      </div>
      <span className="text-[10px] font-mono font-medium text-slate-300 mt-2 px-2 py-0.5 rounded-full bg-white/[0.05] border border-white/10">
        {config.badge}
      </span>
    </div>
  );
}

export default function CardIcon3D({ type, isHovered = false }: CardIconProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInViewport = useInViewport(containerRef, 0.1);

  if (!isWebGLAvailable()) {
    return (
      <div ref={containerRef} className="w-full h-36 relative">
        <CardIcon2DFallback type={type} isHovered={isHovered} />
      </div>
    );
  }

  return (
    <div ref={containerRef} className="w-full h-36 relative">
      <WebGLErrorBoundary fallback={<CardIcon2DFallback type={type} isHovered={isHovered} />}>
        {isInViewport ? (
          <Suspense fallback={<CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-xl" />}>
            <LazyCardIconCanvas type={type} isHovered={isHovered} />
          </Suspense>
        ) : (
          <CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-xl" />
        )}
      </WebGLErrorBoundary>
    </div>
  );
}
