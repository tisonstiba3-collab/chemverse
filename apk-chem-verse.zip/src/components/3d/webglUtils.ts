/**
 * WebGL Detection and Compatibility Utilities
 * Prevents WebGL context creation crashes in sandboxed or headless environments.
 */

let _cachedWebGLSupport: boolean | null = null;

export function isWebGLAvailable(): boolean {
  if (typeof window === 'undefined') return false;
  if (_cachedWebGLSupport !== null) return _cachedWebGLSupport;

  try {
    const canvas = document.createElement('canvas');
    const gl =
      canvas.getContext('webgl2') ||
      canvas.getContext('webgl') ||
      canvas.getContext('experimental-webgl');

    if (!gl) {
      _cachedWebGLSupport = false;
      return false;
    }

    // Try a simple operation to verify context is truly active and not disabled by sandbox
    const isContextLost = (gl as WebGLRenderingContext).isContextLost?.();
    if (isContextLost) {
      _cachedWebGLSupport = false;
      return false;
    }

    _cachedWebGLSupport = true;
    return true;
  } catch {
    _cachedWebGLSupport = false;
    return false;
  }
}

/**
 * Forces WebGL status override if needed
 */
export function setWebGLAvailable(supported: boolean) {
  _cachedWebGLSupport = supported;
}
