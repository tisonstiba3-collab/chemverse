import React, { useRef, useState, useMemo, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Float } from '@react-three/drei';
import * as THREE from 'three';
import { RotateCw, Eye, Sparkles, ZoomIn, Sliders } from 'lucide-react';
import { ChemistryTopic, SimulationState } from '../../types/chemistry';
import { useInViewport } from './useInViewport';
import CanvasShimmerSkeleton from './CanvasShimmerSkeleton';
import { isWebGLAvailable } from './webglUtils';
import WebGLErrorBoundary from './WebGLErrorBoundary';

interface TopicDetailViewer3DProps {
  topic: ChemistryTopic;
  simulationState?: SimulationState;
}

// Compute real-time fluid color based on pH & indicator
export function getIndicatorColor(pH: number = 7, indicatorType: string = 'universal'): string {
  if (indicatorType === 'pp') {
    return pH >= 8.3 ? '#f43f5e' : '#e0f2fe';
  }
  if (indicatorType === 'mm') {
    return pH < 5.0 ? '#ef4444' : '#eab308';
  }
  if (indicatorType === 'btb') {
    if (pH < 6.5) return '#eab308';
    if (pH <= 7.5) return '#10b981';
    return '#3b82f6';
  }
  // Universal Indicator
  if (pH <= 2.5) return '#ef4444'; // Red (Strong Acid)
  if (pH <= 4.5) return '#f97316'; // Orange (Mild Acid)
  if (pH <= 6.2) return '#eab308'; // Yellow (Weak Acid)
  if (pH <= 7.8) return '#22c55e'; // Green (Neutral)
  if (pH <= 9.5) return '#06b6d4'; // Cyan/Teal (Mild Base)
  if (pH <= 11.5) return '#3b82f6'; // Blue (Medium Base)
  return '#a855f7'; // Purple (Strong Base)
}

// Subtle Particle Field behind 3D Model
function ChemistryParticleField({ color }: { color: string }) {
  const pointsRef = useRef<THREE.Points>(null);

  const [positions, colors] = useMemo(() => {
    const count = 120;
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const baseCol = new THREE.Color(color);
    const altCol = new THREE.Color('#38bdf8');

    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 8;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 8;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 6 - 1;

      const mixed = baseCol.clone().lerp(altCol, Math.random());
      col[i * 3] = mixed.r;
      col[i * 3 + 1] = mixed.g;
      col[i * 3 + 2] = mixed.b;
    }
    return [pos, col];
  }, [color]);

  useFrame((_, delta) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y += delta * 0.05;
      pointsRef.current.rotation.x += delta * 0.02;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-color" args={[colors, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.06}
        vertexColors
        transparent
        opacity={0.65}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

// High-fidelity interactive 3D model according to topic.modelType & simulationState
function MainInteractiveModel({
  topic,
  autoRotate,
  showClouds,
  simulationState = {},
}: {
  topic: ChemistryTopic;
  autoRotate: boolean;
  showClouds: boolean;
  simulationState?: SimulationState;
}) {
  const modelGroup = useRef<THREE.Group>(null);
  const secondaryGroup = useRef<THREE.Group>(null);

  useFrame((state, delta) => {
    if (autoRotate && modelGroup.current) {
      modelGroup.current.rotation.y += delta * 0.7;
      modelGroup.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.8) * 0.1;
    }
    if (secondaryGroup.current) {
      const circuitOn = simulationState.circuitClosed !== false;
      if (circuitOn) {
        secondaryGroup.current.rotation.z += delta * 1.5;
      }
    }
  });

  const renderContent = () => {
    switch (topic.modelType) {
      case 'atom': {
        const qN = simulationState.principalQuantumN || 2;
        const scaleFactor = 1.0 + (qN - 1) * 0.25;

        return (
          <group ref={modelGroup} scale={scaleFactor}>
            {/* Multi-particle atomic nucleus */}
            <mesh>
              <sphereGeometry args={[0.55, 32, 32]} />
              <meshStandardMaterial
                color="#38bdf8"
                emissive="#0284c7"
                emissiveIntensity={0.8}
                metalness={0.7}
                roughness={0.2}
              />
            </mesh>
            {/* Clustered Protons & Neutrons */}
            {[
              [0.25, 0.2, 0.1, '#f43f5e', '#e11d48'],
              [-0.22, -0.25, 0.15, '#10b981', '#059669'],
              [-0.25, 0.22, -0.1, '#fbbf24', '#d97706'],
              [0.2, -0.2, -0.2, '#a855f7', '#7e22ce'],
            ].map(([x, y, z, col, emi], idx) => (
              <mesh key={idx} position={[Number(x), Number(y), Number(z)]}>
                <sphereGeometry args={[0.26, 20, 20]} />
                <meshStandardMaterial color={String(col)} emissive={String(emi)} emissiveIntensity={0.6} />
              </mesh>
            ))}

            {/* Electron Orbit 1 */}
            <group rotation={[Math.PI / 4, 0, 0]}>
              <mesh>
                <torusGeometry args={[1.35 * (qN / 2), 0.02, 16, 64]} />
                <meshBasicMaterial color="#38bdf8" transparent opacity={0.6} />
              </mesh>
              <mesh position={[1.35 * (qN / 2), 0, 0]}>
                <sphereGeometry args={[0.1, 16, 16]} />
                <meshStandardMaterial color="#ffffff" emissive="#38bdf8" emissiveIntensity={2.0} />
              </mesh>
            </group>

            {/* Electron Orbit 2 */}
            {qN >= 2 && (
              <group rotation={[-Math.PI / 4, Math.PI / 3, 0]}>
                <mesh>
                  <torusGeometry args={[1.65, 0.02, 16, 64]} />
                  <meshBasicMaterial color="#a78bfa" transparent opacity={0.6} />
                </mesh>
                <mesh position={[-1.65, 0, 0]}>
                  <sphereGeometry args={[0.1, 16, 16]} />
                  <meshStandardMaterial color="#ffffff" emissive="#a855f7" emissiveIntensity={2.0} />
                </mesh>
              </group>
            )}

            {/* Electron Orbit 3 */}
            {qN >= 3 && (
              <group rotation={[0, -Math.PI / 3, Math.PI / 4]}>
                <mesh>
                  <torusGeometry args={[1.95, 0.02, 16, 64]} />
                  <meshBasicMaterial color="#34d399" transparent opacity={0.6} />
                </mesh>
                <mesh position={[0, 1.95, 0]}>
                  <sphereGeometry args={[0.1, 16, 16]} />
                  <meshStandardMaterial color="#ffffff" emissive="#34d399" emissiveIntensity={2.0} />
                </mesh>
              </group>
            )}

            {/* Quantum Electron Probability Cloud */}
            {showClouds && (
              <mesh>
                <sphereGeometry args={[1.8 * (qN / 2), 32, 32]} />
                <meshStandardMaterial
                  color="#38bdf8"
                  emissive="#0284c7"
                  emissiveIntensity={0.25}
                  wireframe
                  transparent
                  opacity={0.12}
                />
              </mesh>
            )}
          </group>
        );
      }

      case 'h2o': {
        // Dynamic bond angle from simulationState (default ~104.5°)
        const angleDeg = simulationState.bondAngle ?? 104.5;
        const halfAngleRad = ((angleDeg / 2) * Math.PI) / 180;
        const bondLength = 1.15;
        const h1X = -Math.sin(halfAngleRad) * bondLength;
        const h1Y = -Math.cos(halfAngleRad) * bondLength;
        const h2X = Math.sin(halfAngleRad) * bondLength;
        const h2Y = -Math.cos(halfAngleRad) * bondLength;

        const showBonds = simulationState.showBonds !== false;
        const showPEB = (simulationState.showPEB !== false) && showClouds;

        return (
          <group ref={modelGroup} scale={1.4} position={[0, 0.1, 0]}>
            {/* Oxygen Atom (Center) */}
            <mesh position={[0, 0.2, 0]}>
              <sphereGeometry args={[0.62, 32, 32]} />
              <meshStandardMaterial
                color="#ef4444"
                emissive="#b91c1c"
                emissiveIntensity={0.6}
                roughness={0.2}
                metalness={0.4}
              />
            </mesh>

            {/* Hydrogen 1 */}
            <mesh position={[h1X, h1Y + 0.2, 0]}>
              <sphereGeometry args={[0.38, 24, 24]} />
              <meshStandardMaterial
                color="#38bdf8"
                emissive="#0284c7"
                emissiveIntensity={0.6}
                roughness={0.2}
                metalness={0.5}
              />
            </mesh>

            {/* Hydrogen 2 */}
            <mesh position={[h2X, h2Y + 0.2, 0]}>
              <sphereGeometry args={[0.38, 24, 24]} />
              <meshStandardMaterial
                color="#38bdf8"
                emissive="#0284c7"
                emissiveIntensity={0.6}
                roughness={0.2}
                metalness={0.5}
              />
            </mesh>

            {/* Covalent Bonds (Toggleable in Simulation) */}
            {showBonds && (
              <>
                <mesh
                  position={[h1X / 2, h1Y / 2 + 0.2, 0]}
                  rotation={[0, 0, Math.PI / 2 - halfAngleRad]}
                >
                  <cylinderGeometry args={[0.09, 0.09, bondLength, 16]} />
                  <meshStandardMaterial color="#cbd5e1" metalness={0.6} roughness={0.3} />
                </mesh>
                <mesh
                  position={[h2X / 2, h2Y / 2 + 0.2, 0]}
                  rotation={[0, 0, -(Math.PI / 2 - halfAngleRad)]}
                >
                  <cylinderGeometry args={[0.09, 0.09, bondLength, 16]} />
                  <meshStandardMaterial color="#cbd5e1" metalness={0.6} roughness={0.3} />
                </mesh>
              </>
            )}

            {/* 2 Lone Pair (PEB) Electron Clouds (Toggleable in Simulation) */}
            {showPEB && (
              <>
                <mesh position={[-0.42, 0.75, 0.35]}>
                  <sphereGeometry args={[0.26, 20, 20]} />
                  <meshStandardMaterial
                    color="#c084fc"
                    emissive="#9333ea"
                    emissiveIntensity={0.9}
                    transparent
                    opacity={0.65}
                  />
                </mesh>
                <mesh position={[0.42, 0.75, -0.35]}>
                  <sphereGeometry args={[0.26, 20, 20]} />
                  <meshStandardMaterial
                    color="#c084fc"
                    emissive="#9333ea"
                    emissiveIntensity={0.9}
                    transparent
                    opacity={0.65}
                  />
                </mesh>
              </>
            )}
          </group>
        );
      }

      case 'beaker': {
        // Real-time pH color based on simulation
        const currentPH = simulationState.pH ?? 7.0;
        const currentIndicator = simulationState.indicatorType || 'universal';
        const fluidColor = getIndicatorColor(currentPH, currentIndicator);

        return (
          <group ref={modelGroup} scale={1.3} position={[0, -0.2, 0]}>
            {/* Glass Beaker Body */}
            <mesh position={[0, 0.15, 0]}>
              <cylinderGeometry args={[0.85, 0.85, 1.45, 36, 1, true]} />
              <meshPhysicalMaterial
                color="#e0f2fe"
                transmission={0.88}
                roughness={0.1}
                metalness={0.15}
                ior={1.48}
                transparent
                opacity={0.7}
                side={THREE.DoubleSide}
              />
            </mesh>
            {/* Beaker Bottom */}
            <mesh position={[0, -0.58, 0]}>
              <cylinderGeometry args={[0.85, 0.85, 0.05, 36]} />
              <meshStandardMaterial color="#bae6fd" roughness={0.2} />
            </mesh>
            {/* Lip Rim */}
            <mesh position={[0, 0.88, 0]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.86, 0.045, 16, 36]} />
              <meshStandardMaterial color="#bae6fd" roughness={0.2} metalness={0.4} />
            </mesh>

            {/* Fluid Volume inside (changes color with pH live!) */}
            <mesh position={[0, -0.15, 0]}>
              <cylinderGeometry args={[0.8, 0.8, 0.85, 36]} />
              <meshStandardMaterial
                color={fluidColor}
                emissive={fluidColor}
                emissiveIntensity={0.8}
                roughness={0.2}
                transparent
                opacity={0.86}
              />
            </mesh>
            {/* Meniscus */}
            <mesh position={[0, 0.28, 0]} rotation={[-Math.PI / 2, 0, 0]}>
              <circleGeometry args={[0.8, 36]} />
              <meshStandardMaterial color={fluidColor} emissive={fluidColor} emissiveIntensity={1.0} />
            </mesh>

            {/* Effervescent Rising Gas Bubbles */}
            <group ref={secondaryGroup}>
              {[-0.3, 0.25, -0.15, 0.35, -0.05, 0.1].map((x, idx) => (
                <mesh key={idx} position={[x, -0.3 + idx * 0.15, (idx % 2 === 0 ? 0.3 : -0.3)]}>
                  <sphereGeometry args={[0.08, 16, 16]} />
                  <meshStandardMaterial
                    color="#ffffff"
                    emissive="#cffafe"
                    emissiveIntensity={1.5}
                    transparent
                    opacity={0.9}
                  />
                </mesh>
              ))}
            </group>
          </group>
        );
      }

      case 'flame': {
        const temp = simulationState.temperature ?? 300;
        const flameScale = 1.0 + (temp / 800) * 0.5;

        return (
          <group ref={modelGroup} scale={flameScale * 1.1} position={[0, -0.35, 0]}>
            {/* Outer Energetic Flame */}
            <mesh position={[0, 0.5, 0]}>
              <coneGeometry args={[0.75, 1.6, 32]} />
              <meshStandardMaterial
                color={temp > 600 ? '#f97316' : '#f59e0b'}
                emissive="#d97706"
                emissiveIntensity={1.2}
                transparent
                opacity={0.85}
              />
            </mesh>
            {/* Middle Golden Core */}
            <mesh position={[0, 0.35, 0]}>
              <coneGeometry args={[0.5, 1.2, 24]} />
              <meshStandardMaterial
                color="#fbbf24"
                emissive="#f59e0b"
                emissiveIntensity={1.5}
                transparent
                opacity={0.92}
              />
            </mesh>
            {/* Inner White Core */}
            <mesh position={[0, 0.2, 0]}>
              <coneGeometry args={[0.28, 0.75, 20]} />
              <meshStandardMaterial color="#ffffff" emissive="#fef08a" emissiveIntensity={2.0} />
            </mesh>
            {/* Hot Blue Base Sphere */}
            <mesh position={[0, -0.1, 0]}>
              <sphereGeometry args={[0.38, 24, 24]} />
              <meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={1.8} />
            </mesh>
          </group>
        );
      }

      case 'battery': {
        const isClosed = simulationState.circuitClosed !== false;

        return (
          <group ref={modelGroup} scale={1.3} position={[0, -0.1, 0]}>
            {/* Battery Cylinder */}
            <mesh position={[0, 0, 0]}>
              <cylinderGeometry args={[0.65, 0.65, 1.4, 32]} />
              <meshStandardMaterial
                color="#0f766e"
                emissive="#134e4a"
                emissiveIntensity={0.5}
                metalness={0.8}
                roughness={0.2}
              />
            </mesh>
            {/* Cathode Terminal (+) */}
            <mesh position={[0, 0.8, 0]}>
              <cylinderGeometry args={[0.25, 0.25, 0.2, 24]} />
              <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={1.2} metalness={0.9} />
            </mesh>
            {/* Anode Terminal (-) */}
            <mesh position={[0, -0.75, 0]}>
              <cylinderGeometry args={[0.66, 0.66, 0.1, 32]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.9} roughness={0.2} />
            </mesh>

            {/* External Electron Wire Circuit */}
            <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
              <torusGeometry args={[1.2, 0.02, 16, 64]} />
              <meshBasicMaterial color={isClosed ? '#38bdf8' : '#64748b'} transparent opacity={0.7} />
            </mesh>
            {/* Flowing Electron Particles (animated if circuit is closed) */}
            {isClosed && (
              <group ref={secondaryGroup}>
                <mesh position={[1.2, 0, 0]}>
                  <sphereGeometry args={[0.1, 16, 16]} />
                  <meshStandardMaterial color="#ffffff" emissive="#38bdf8" emissiveIntensity={2.5} />
                </mesh>
                <mesh position={[-1.2, 0, 0]}>
                  <sphereGeometry args={[0.1, 16, 16]} />
                  <meshStandardMaterial color="#ffffff" emissive="#22d3ee" emissiveIntensity={2.5} />
                </mesh>
              </group>
            )}
          </group>
        );
      }

      case 'organic': {
        const deloc = simulationState.delocalizationActive !== false;

        return (
          <group ref={modelGroup} scale={1.2}>
            {/* Benzene 6-Carbon Ring with Resonant Electron Cloud */}
            {Array.from({ length: 6 }).map((_, i) => {
              const angle = (i * Math.PI) / 3;
              const x = Math.cos(angle) * 0.95;
              const y = Math.sin(angle) * 0.95;
              const nextAngle = ((i + 1) * Math.PI) / 3;
              const nx = Math.cos(nextAngle) * 0.95;
              const ny = Math.sin(nextAngle) * 0.95;

              return (
                <group key={i}>
                  <mesh position={[x, y, 0]}>
                    <sphereGeometry args={[0.22, 24, 24]} />
                    <meshStandardMaterial color="#334155" metalness={0.7} roughness={0.3} />
                  </mesh>

                  <mesh position={[x * 1.5, y * 1.5, 0]}>
                    <sphereGeometry args={[0.14, 16, 16]} />
                    <meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={0.7} />
                  </mesh>

                  <mesh
                    position={[(x + nx) / 2, (y + ny) / 2, 0]}
                    rotation={[0, 0, angle + Math.PI / 6]}
                  >
                    <cylinderGeometry args={[0.07, 0.07, 0.95, 16]} />
                    <meshStandardMaterial color="#cbd5e1" metalness={0.6} />
                  </mesh>
                </group>
              );
            })}

            {/* Resonant Pi-orbital Torus (Toggleable in simulation) */}
            {deloc && (
              <>
                <mesh position={[0, 0, 0.2]}>
                  <torusGeometry args={[0.6, 0.04, 16, 48]} />
                  <meshStandardMaterial
                    color="#f43f5e"
                    emissive="#e11d48"
                    emissiveIntensity={1.2}
                    transparent
                    opacity={0.7}
                  />
                </mesh>
                <mesh position={[0, 0, -0.2]}>
                  <torusGeometry args={[0.6, 0.04, 16, 48]} />
                  <meshStandardMaterial
                    color="#f43f5e"
                    emissive="#e11d48"
                    emissiveIntensity={1.2}
                    transparent
                    opacity={0.7}
                  />
                </mesh>
              </>
            )}
          </group>
        );
      }

      case 'equilibrium': {
        return (
          <group ref={modelGroup} scale={1.3}>
            <mesh position={[-0.7, 0, 0]}>
              <sphereGeometry args={[0.45, 24, 24]} />
              <meshStandardMaterial color="#8b5cf6" emissive="#6d28d9" emissiveIntensity={0.9} />
            </mesh>
            <mesh position={[0.7, 0, 0]}>
              <sphereGeometry args={[0.45, 24, 24]} />
              <meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={0.9} />
            </mesh>

            <mesh rotation={[0, 0, Math.PI / 2]}>
              <cylinderGeometry args={[0.08, 0.08, 1.4, 16]} />
              <meshStandardMaterial color="#e2e8f0" metalness={0.7} />
            </mesh>

            <group ref={secondaryGroup}>
              <mesh rotation={[Math.PI / 3, 0, 0]}>
                <torusGeometry args={[1.2, 0.02, 16, 48]} />
                <meshBasicMaterial color="#a78bfa" transparent opacity={0.65} />
              </mesh>
              <mesh rotation={[-Math.PI / 3, 0, 0]}>
                <torusGeometry args={[1.2, 0.02, 16, 48]} />
                <meshBasicMaterial color="#38bdf8" transparent opacity={0.65} />
              </mesh>
            </group>
          </group>
        );
      }

      case 'kinetics':
      default: {
        const cat = simulationState.catalystAdded ?? false;
        const speedMultiplier = cat ? 1.5 : 1.0;

        return (
          <group ref={modelGroup} scale={1.3}>
            <mesh>
              <dodecahedronGeometry args={[0.6, 0]} />
              <meshStandardMaterial
                color="#06b6d4"
                emissive="#0891b2"
                emissiveIntensity={cat ? 1.4 : 0.8}
                metalness={0.6}
                roughness={0.2}
              />
            </mesh>
            {[
              [1.1, 0.6, 0, '#22d3ee'],
              [-1.1, -0.6, 0, '#f59e0b'],
              [0, 1.1, 0.6, '#a855f7'],
              [0, -1.1, -0.6, '#10b981'],
            ].map(([x, y, z, col], idx) => (
              <mesh key={idx} position={[Number(x) * speedMultiplier, Number(y), Number(z)]}>
                <sphereGeometry args={[0.18, 16, 16]} />
                <meshStandardMaterial color={String(col)} emissive={String(col)} emissiveIntensity={1.4} />
              </mesh>
            ))}

            <mesh rotation={[Math.PI / 4, 0, 0]}>
              <torusGeometry args={[1.35, 0.02, 16, 48]} />
              <meshBasicMaterial color="#22d3ee" transparent opacity={0.6} />
            </mesh>
          </group>
        );
      }
    }
  };

  return <>{renderContent()}</>;
}

export default function TopicDetailViewer3D({
  topic,
  simulationState,
}: TopicDetailViewer3DProps) {
  const [autoRotate, setAutoRotate] = useState(true);
  const [showClouds, setShowClouds] = useState(true);
  const controlsRef = useRef<any>(null);
  const canvasContainerRef = useRef<HTMLDivElement>(null);

  // Fix 2: Unmount 3D canvas when out of viewport (threshold 0.1)
  const isInViewport = useInViewport(canvasContainerRef, 0.1);

  const handleResetCamera = () => {
    if (controlsRef.current) {
      controlsRef.current.reset();
    }
  };

  return (
    <div className="w-full h-full min-h-[420px] lg:min-h-[580px] relative rounded-2xl overflow-hidden bg-gradient-to-b from-slate-950 via-[#070b19] to-slate-950 border border-slate-800/80 shadow-2xl flex flex-col">
      {/* Top Floating Control Bar */}
      <div className="absolute top-4 left-4 right-4 z-10 flex items-center justify-between pointer-events-none">
        {/* Model Meta Pill */}
        <div className="glass-panel px-3.5 py-1.5 rounded-xl border border-slate-700/80 flex items-center gap-2 pointer-events-auto">
          <span
            className="w-2.5 h-2.5 rounded-full animate-ping"
            style={{ backgroundColor: topic.accentColor }}
          />
          <span className="text-xs font-mono font-bold text-slate-200">
            Model 3D: {topic.title}
          </span>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={() => setAutoRotate(!autoRotate)}
            className={`p-2 rounded-xl text-xs border transition cursor-pointer flex items-center gap-1.5 ${
              autoRotate
                ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                : 'bg-slate-900/90 border-slate-750 text-slate-400'
            }`}
            title="Toggle Putaran Otomatis"
          >
            <RotateCw className={`w-3.5 h-3.5 ${autoRotate ? 'animate-spin' : ''}`} style={{ animationDuration: '6s' }} />
            <span className="hidden sm:inline font-mono text-[11px]">Rotasi</span>
          </button>

          <button
            onClick={() => setShowClouds(!showClouds)}
            className={`p-2 rounded-xl text-xs border transition cursor-pointer flex items-center gap-1.5 ${
              showClouds
                ? 'bg-purple-500/20 border-purple-500/40 text-purple-300'
                : 'bg-slate-900/90 border-slate-750 text-slate-400'
            }`}
            title="Toggle Awan Probabilitas & Medan Orbital"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden sm:inline font-mono text-[11px]">Orbital</span>
          </button>

          <button
            onClick={handleResetCamera}
            className="p-2 rounded-xl text-xs border border-slate-750 bg-slate-900/90 hover:bg-slate-800 text-slate-300 transition cursor-pointer"
            title="Reset Sudut Pandang Kamera"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 3D Canvas / 2D Visual Fallback */}
      <div ref={canvasContainerRef} className="w-full flex-1 relative flex items-center justify-center">
        {!isWebGLAvailable() ? (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center select-none">
            <div
              className="w-32 h-32 rounded-3xl flex items-center justify-center relative shadow-2xl mb-4"
              style={{
                backgroundColor: `${topic.accentColor}22`,
                border: `1px solid ${topic.accentColor}55`,
                boxShadow: `0 0 30px ${topic.accentColor}33`,
              }}
            >
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center bg-white/10 backdrop-blur">
                <Sparkles className="w-7 h-7 text-white" />
              </div>
            </div>
            <div className="text-base font-bold text-white font-mono">{topic.title}</div>
            <div className="text-xs text-slate-400 mt-1 max-w-sm line-clamp-2">{topic.description}</div>
            <div className="mt-3 px-3 py-1 rounded-full text-xs font-mono bg-cyan-950/60 border border-cyan-500/30 text-cyan-300">
              Visualisasi Materi Kimia Interaktif
            </div>
          </div>
        ) : (
          <WebGLErrorBoundary
            fallback={
              <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center select-none">
                <div
                  className="w-28 h-28 rounded-2xl flex items-center justify-center relative shadow-xl mb-3"
                  style={{
                    backgroundColor: `${topic.accentColor}22`,
                    border: `1px solid ${topic.accentColor}44`,
                  }}
                >
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div className="text-sm font-bold text-white font-mono">{topic.title}</div>
              </div>
            }
          >
            {isInViewport ? (
              <Suspense fallback={<CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-none" />}>
                <Canvas
                  camera={{ position: [0, 0, 3.8], fov: 45 }}
                  gl={{ antialias: true, alpha: true }}
                  dpr={[1, 1.5]}
                  frameloop={autoRotate ? 'always' : 'demand'}
                >
                  {/* Ambient, Directional & Soft Rim Lights */}
                  <ambientLight intensity={0.9} />
                  <directionalLight position={[4, 5, 4]} intensity={1.6} color="#ffffff" />
                  {/* Colored rim backlights for neon depth */}
                  <pointLight position={[-4, 3, -3]} intensity={2.5} color={topic.accentColor} />
                  <pointLight position={[4, -3, -3]} intensity={2.0} color="#a855f7" />
                  <pointLight position={[0, -4, 2]} intensity={1.2} color="#06b6d4" />

                  {/* Orbit Controls with dampening */}
                  <OrbitControls
                    ref={controlsRef}
                    enablePan={false}
                    enableZoom={true}
                    minDistance={2.0}
                    maxDistance={6.0}
                    dampingFactor={0.06}
                  />

                  {/* Subtle Particle Starfield */}
                  <ChemistryParticleField color={topic.accentColor} />

                  <Float speed={1.5} rotationIntensity={0.15} floatIntensity={0.25}>
                    <MainInteractiveModel
                      topic={topic}
                      autoRotate={autoRotate}
                      showClouds={showClouds}
                      simulationState={simulationState}
                    />
                  </Float>
                </Canvas>
              </Suspense>
            ) : (
              <CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-none" />
            )}
          </WebGLErrorBoundary>
        )}
      </div>

      {/* Bottom Interactive Guide Helper */}
      <div className="p-3 bg-slate-950/85 backdrop-blur-md border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
        <div className="flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>Klik & geser untuk rotasi 360° • Scroll untuk zoom</span>
        </div>
        <div className="hidden sm:block text-slate-500 text-[11px]">
          Rendering: @react-three/fiber
        </div>
      </div>
    </div>
  );
}
