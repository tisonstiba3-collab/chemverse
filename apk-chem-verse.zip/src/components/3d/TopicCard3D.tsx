import React, { useRef, useState, useEffect, Suspense, lazy } from 'react';
import { ModelType } from '../../types/chemistry';
import { useInViewport } from './useInViewport';
import CanvasShimmerSkeleton from './CanvasShimmerSkeleton';
import TopicCardLightweightVisual from '../chemistry/TopicCardLightweightVisual';
import { isWebGLAvailable } from './webglUtils';
import WebGLErrorBoundary from './WebGLErrorBoundary';

// Fix 6: Code-split Three.js Canvas via React.lazy
const LazyTopicCardCanvas = lazy(() => import('./TopicCardCanvas'));

interface TopicCard3DProps {
  modelType: string;
  accentColor?: string;
  isHovered?: boolean;
  className?: string;
  frameloop?: 'always' | 'demand' | 'never';
}

export default function TopicCard3D({
  modelType,
  accentColor = '#22d3ee',
  isHovered = false,
  className,
  frameloop = 'demand',
}: TopicCard3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  // Performance mode & mobile detection
  const [isLightweight, setIsLightweight] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('chem_perf_mode');
      if (saved) return saved === 'lightweight';
      if (typeof window !== 'undefined' && (window.innerWidth < 768 || (navigator.maxTouchPoints && navigator.maxTouchPoints > 1))) {
        return true;
      }
      return false;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    const handleModeChange = () => {
      try {
        const saved = localStorage.getItem('chem_perf_mode');
        if (saved) {
          setIsLightweight(saved === 'lightweight');
        }
      } catch {}
    };
    window.addEventListener('chem_perf_mode_change', handleModeChange);
    return () => window.removeEventListener('chem_perf_mode_change', handleModeChange);
  }, []);

  // Unmount 3D canvas when out of viewport (threshold 0.1)
  const isInViewport = useInViewport(containerRef, 0.1);

  const fallbackVisual = (
    <div className={`w-full relative overflow-hidden flex items-center justify-center ${className || 'h-44'}`}>
      <TopicCardLightweightVisual
        modelType={modelType}
        accentColor={accentColor}
        isHovered={isHovered}
      />
    </div>
  );

  // If lightweight mode, mobile, or WebGL unavailable, use 60fps SVG/CSS visual immediately
  if (isLightweight || !isWebGLAvailable()) {
    return fallbackVisual;
  }

  return (
    <WebGLErrorBoundary fallback={fallbackVisual}>
      <div
        ref={containerRef}
        className={`w-full relative overflow-hidden flex items-center justify-center ${className || 'h-44'}`}
      >
        {isInViewport ? (
          <Suspense fallback={<CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-none" />}>
            <LazyTopicCardCanvas
              modelType={modelType}
              accentColor={accentColor}
              isHovered={isHovered}
              frameloop={frameloop}
            />
          </Suspense>
        ) : (
          <CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-none" />
        )}
      </div>
    </WebGLErrorBoundary>
  );
}
