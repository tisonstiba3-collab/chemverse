import React, { useRef, useMemo, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float } from '@react-three/drei';
import * as THREE from 'three';
import HeroMoleculeLightweightBackground from './HeroMoleculeLightweightBackground';
import { isWebGLAvailable } from './webglUtils';
import WebGLErrorBoundary from './WebGLErrorBoundary';

// Single Molecule Node with glowing nucleus and orbital electron rings
function MoleculeNode({
  position,
  color,
  emissive,
  radius = 0.35,
  ringCount = 1,
  pulseSpeed = 2,
}: {
  position: [number, number, number];
  color: string;
  emissive: string;
  radius?: number;
  ringCount?: number;
  pulseSpeed?: number;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const ring1Ref = useRef<THREE.Group>(null);
  const ring2Ref = useRef<THREE.Group>(null);

  useFrame((state, delta) => {
    if (ring1Ref.current) {
      ring1Ref.current.rotation.x += delta * 1.2;
      ring1Ref.current.rotation.y += delta * 1.5;
    }
    if (ring2Ref.current) {
      ring2Ref.current.rotation.z += delta * 1.0;
      ring2Ref.current.rotation.x -= delta * 1.2;
    }
    if (meshRef.current) {
      const pulse = 1 + Math.sin(state.clock.elapsedTime * pulseSpeed) * 0.06;
      meshRef.current.scale.set(pulse, pulse, pulse);
    }
  });

  return (
    <group position={position}>
      {/* Atom core - optimized segments [radius, 14, 14] instead of [radius, 24, 24] */}
      <mesh ref={meshRef}>
        <sphereGeometry args={[radius, 14, 14]} />
        <meshStandardMaterial
          color={color}
          emissive={emissive}
          emissiveIntensity={1.4}
          roughness={0.15}
          metalness={0.4}
        />
      </mesh>

      {/* Orbiting quantum electron ring 1 - optimized geometry segments */}
      {ringCount >= 1 && (
        <group ref={ring1Ref}>
          <mesh rotation={[Math.PI / 3, Math.PI / 6, 0]}>
            <torusGeometry args={[radius * 2.2, 0.016, 8, 24]} />
            <meshBasicMaterial color={color} transparent opacity={0.6} />
          </mesh>
          <mesh position={[radius * 2.2, 0, 0]}>
            <sphereGeometry args={[0.06, 8, 8]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
        </group>
      )}

      {/* Orbiting quantum electron ring 2 */}
      {ringCount >= 2 && (
        <group ref={ring2Ref}>
          <mesh rotation={[-Math.PI / 4, 0, Math.PI / 3]}>
            <torusGeometry args={[radius * 2.4, 0.015, 8, 24]} />
            <meshBasicMaterial color="#A78BFA" transparent opacity={0.55} />
          </mesh>
          <mesh position={[-radius * 2.4, 0, 0]}>
            <sphereGeometry args={[0.055, 8, 8]} />
            <meshBasicMaterial color="#38bdf8" />
          </mesh>
        </group>
      )}
    </group>
  );
}

// Sleek glowing bond connecting two atom coordinates
function ChemicalBond({
  start,
  end,
  color = '#38bdf8',
}: {
  start: [number, number, number];
  end: [number, number, number];
  color?: string;
}) {
  const { position, quaternion, length } = useMemo(() => {
    const s = new THREE.Vector3(...start);
    const e = new THREE.Vector3(...end);
    const dir = new THREE.Vector3().subVectors(e, s);
    const len = dir.length();
    const half = new THREE.Vector3().addVectors(s, e).multiplyScalar(0.5);

    const quat = new THREE.Quaternion();
    quat.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());

    return { position: half, quaternion: quat, length: len };
  }, [start, end]);

  return (
    <mesh position={position} quaternion={quaternion}>
      <cylinderGeometry args={[0.04, 0.04, length, 8]} />
      <meshStandardMaterial
        color={color}
        emissive={color}
        emissiveIntensity={0.6}
        transparent
        opacity={0.7}
        roughness={0.2}
      />
    </mesh>
  );
}

// Benzene aromatic ring structure floating in space
function BenzeneMolecule({ position, scale = 1 }: { position: [number, number, number]; scale?: number }) {
  const groupRef = useRef<THREE.Group>(null);
  const ringRadius = 1.15 * scale;

  const vertices: [number, number, number][] = useMemo(() => {
    const pts: [number, number, number][] = [];
    for (let i = 0; i < 6; i++) {
      const angle = (i * Math.PI) / 3;
      pts.push([Math.cos(angle) * ringRadius, Math.sin(angle) * ringRadius, 0]);
    }
    return pts;
  }, [ringRadius]);

  useFrame((_, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += delta * 0.25;
      groupRef.current.rotation.x += delta * 0.15;
    }
  });

  return (
    <group ref={groupRef} position={position}>
      {/* 6 Carbon atoms on corners */}
      {vertices.map((pos, idx) => (
        <MoleculeNode
          key={`c-${idx}`}
          position={pos}
          color="#38bdf8"
          emissive="#0284c7"
          radius={0.26 * scale}
          ringCount={idx % 2 === 0 ? 1 : 0}
          pulseSpeed={1.8 + idx * 0.2}
        />
      ))}

      {/* 6 Covalent bonds connecting carbon atoms */}
      {vertices.map((pos, idx) => {
        const nextPos = vertices[(idx + 1) % 6];
        return (
          <ChemicalBond
            key={`b-${idx}`}
            start={pos}
            end={nextPos}
            color={idx % 2 === 0 ? '#38bdf8' : '#818cf8'}
          />
        );
      })}

      {/* Central aromatic delocalized electron pi-cloud ring */}
      <mesh rotation={[0, 0, 0]}>
        <torusGeometry args={[ringRadius * 0.58, 0.025 * scale, 8, 24]} />
        <meshBasicMaterial color="#22D3EE" transparent opacity={0.5} />
      </mesh>
    </group>
  );
}

// Water Molecule (H2O) with 104.5 degree bent geometry
function WaterMolecule({ position, scale = 1 }: { position: [number, number, number]; scale?: number }) {
  const groupRef = useRef<THREE.Group>(null);
  const bondLength = 1.05 * scale;
  const halfAngle = (104.5 / 2) * (Math.PI / 180);

  const h1Pos: [number, number, number] = [
    -Math.sin(halfAngle) * bondLength,
    -Math.cos(halfAngle) * bondLength,
    0,
  ];
  const h2Pos: [number, number, number] = [
    Math.sin(halfAngle) * bondLength,
    -Math.cos(halfAngle) * bondLength,
    0,
  ];

  useFrame((_, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y -= delta * 0.3;
      groupRef.current.rotation.z += delta * 0.2;
    }
  });

  return (
    <group ref={groupRef} position={position}>
      {/* Central Oxygen atom */}
      <MoleculeNode
        position={[0, 0.2 * scale, 0]}
        color="#f87171"
        emissive="#dc2626"
        radius={0.34 * scale}
        ringCount={1}
        pulseSpeed={2.2}
      />

      {/* Hydrogen 1 */}
      <MoleculeNode
        position={h1Pos}
        color="#e2e8f0"
        emissive="#94a3b8"
        radius={0.2 * scale}
        ringCount={0}
      />

      {/* Hydrogen 2 */}
      <MoleculeNode
        position={h2Pos}
        color="#e2e8f0"
        emissive="#94a3b8"
        radius={0.2 * scale}
        ringCount={0}
      />

      {/* O-H Bonds */}
      <ChemicalBond start={[0, 0.2 * scale, 0]} end={h1Pos} color="#fca5a5" />
      <ChemicalBond start={[0, 0.2 * scale, 0]} end={h2Pos} color="#fca5a5" />
    </group>
  );
}

// Methane Molecule (CH4) with tetrahedral 109.5 degree geometry
function MethaneMolecule({ position, scale = 1 }: { position: [number, number, number]; scale?: number }) {
  const groupRef = useRef<THREE.Group>(null);
  const d = 0.85 * scale;

  const hPositions: [number, number, number][] = [
    [d, d, d],
    [-d, -d, d],
    [-d, d, -d],
    [d, -d, -d],
  ];

  useFrame((_, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.x += delta * 0.22;
      groupRef.current.rotation.y += delta * 0.28;
    }
  });

  return (
    <group ref={groupRef} position={position}>
      {/* Central Carbon */}
      <MoleculeNode
        position={[0, 0, 0]}
        color="#38bdf8"
        emissive="#0284c7"
        radius={0.3 * scale}
        ringCount={1}
      />

      {/* 4 Hydrogens */}
      {hPositions.map((hPos, i) => (
        <React.Fragment key={i}>
          <MoleculeNode position={hPos} color="#f1f5f9" emissive="#cbd5e1" radius={0.18 * scale} ringCount={0} />
          <ChemicalBond start={[0, 0, 0]} end={hPos} color="#93c5fd" />
        </React.Fragment>
      ))}
    </group>
  );
}

// Floating ambient ion and electron particle cloud (optimized to 40 particles)
function BackgroundIonParticles({ count = 40 }: { count?: number }) {
  const pointsRef = useRef<THREE.Points>(null);

  const [positions, colors] = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const palette = [
      new THREE.Color('#22D3EE'),
      new THREE.Color('#A78BFA'),
      new THREE.Color('#34D399'),
      new THREE.Color('#FBBF24'),
    ];

    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 18;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 14;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 10 - 2;

      const c = palette[Math.floor(Math.random() * palette.length)];
      col[i * 3] = c.r;
      col[i * 3 + 1] = c.g;
      col[i * 3 + 2] = c.b;
    }

    return [pos, col];
  }, [count]);

  useFrame((_, delta) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y += delta * 0.04;
      pointsRef.current.rotation.x += delta * 0.02;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-color" args={[colors, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.12}
        vertexColors
        transparent
        opacity={0.65}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </points>
  );
}

// Complete 3D Chemistry Scene
function Chemistry3DScene() {
  const sceneRef = useRef<THREE.Group>(null);

  useFrame(({ mouse }) => {
    if (sceneRef.current) {
      sceneRef.current.rotation.y = THREE.MathUtils.lerp(
        sceneRef.current.rotation.y,
        mouse.x * 0.2,
        0.05
      );
      sceneRef.current.rotation.x = THREE.MathUtils.lerp(
        sceneRef.current.rotation.x,
        -mouse.y * 0.2,
        0.05
      );
    }
  });

  return (
    <group ref={sceneRef}>
      <BackgroundIonParticles count={45} />

      {/* Floating Benzene Molecule on Top Left */}
      <Float speed={1.8} rotationIntensity={0.4} floatIntensity={0.6}>
        <BenzeneMolecule position={[-3.6, 2.2, -0.5]} scale={1.15} />
      </Float>

      {/* Floating Water Molecule on Top Right */}
      <Float speed={2.0} rotationIntensity={0.5} floatIntensity={0.7}>
        <WaterMolecule position={[3.6, 2.0, 0]} scale={1.2} />
      </Float>

      {/* Floating Methane Molecule on Bottom Left */}
      <Float speed={1.8} rotationIntensity={0.35} floatIntensity={0.6}>
        <MethaneMolecule position={[-3.8, -2.2, -0.2]} scale={1.15} />
      </Float>

      {/* Central Orbiting Quantum Atom behind */}
      <Float speed={1.0} rotationIntensity={0.2} floatIntensity={0.4}>
        <group position={[0, 0, -2.5]}>
          <MoleculeNode
            position={[0, 0, 0]}
            color="#22D3EE"
            emissive="#0891b2"
            radius={0.75}
            ringCount={2}
            pulseSpeed={1.5}
          />
        </group>
      </Float>
    </group>
  );
}

interface HeroMoleculeBackgroundProps {
  forceLightweight?: boolean;
}

export default function HeroMoleculeBackground({ forceLightweight = false }: HeroMoleculeBackgroundProps) {
  const [isTabVisible, setIsTabVisible] = React.useState(true);
  const [isLightweight, setIsLightweight] = React.useState(() => {
    if (forceLightweight) return true;
    try {
      const saved = localStorage.getItem('chem_perf_mode');
      if (saved) return saved === 'lightweight';
      // Auto-detect mobile devices for silky smooth 60fps & instant response:
      if (typeof window !== 'undefined' && (window.innerWidth < 768 || (navigator.maxTouchPoints && navigator.maxTouchPoints > 1))) {
        return true;
      }
      return false;
    } catch {
      return false;
    }
  });

  React.useEffect(() => {
    if (forceLightweight) {
      setIsLightweight(true);
      return;
    }
    const handleStorageChange = () => {
      try {
        const saved = localStorage.getItem('chem_perf_mode');
        setIsLightweight(saved === 'lightweight');
      } catch {}
    };
    window.addEventListener('chem_perf_mode_change', handleStorageChange);
    return () => window.removeEventListener('chem_perf_mode_change', handleStorageChange);
  }, [forceLightweight]);

  React.useEffect(() => {
    const handleVisibilityChange = () => {
      setIsTabVisible(document.visibilityState === 'visible');
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, []);

  // If lightweight mode is active or WebGL is not supported, render ultra-fast 2D canvas
  if (isLightweight || !isWebGLAvailable()) {
    return <HeroMoleculeLightweightBackground />;
  }

  return (
    <WebGLErrorBoundary fallback={<HeroMoleculeLightweightBackground />}>
      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10 bg-[#070B18]">
        {/* Aurora Ambient Blobs for deep glowing neon lighting */}
        <div className="absolute -top-[15%] left-[20%] w-[550px] h-[550px] rounded-full opacity-[0.14] blur-[120px] bg-cyan-500 will-change-transform animate-[auroraOne_18s_ease-in-out_infinite_alternate]" />
        <div className="absolute top-[35%] -right-[10%] w-[600px] h-[600px] rounded-full opacity-[0.12] blur-[130px] bg-violet-600 will-change-transform animate-[auroraTwo_22s_ease-in-out_infinite_alternate]" />
        <div className="absolute -bottom-[20%] left-[10%] w-[500px] h-[500px] rounded-full opacity-[0.10] blur-[120px] bg-amber-500 will-change-transform animate-[auroraThree_16s_ease-in-out_infinite_alternate]" />

        {/* 3D Chemistry Moving Canvas Animation - optimized dpr and frameloop */}
        <div className="absolute inset-0">
          <Canvas
            camera={{ position: [0, 0, 7.2], fov: 50 }}
            gl={{ antialias: false, alpha: true, powerPreference: 'low-power' }}
            dpr={[1, 1]}
            frameloop={isTabVisible ? 'always' : 'never'}
          >
            <ambientLight intensity={0.7} />
            <directionalLight position={[4, 6, 4]} intensity={1.2} color="#ffffff" />
            <pointLight position={[-5, 3, 2]} intensity={2.2} color="#22D3EE" />
            <pointLight position={[5, -3, 2]} intensity={2.2} color="#A78BFA" />

            <Suspense fallback={null}>
              {isTabVisible && <Chemistry3DScene />}
            </Suspense>
          </Canvas>
        </div>

        {/* Vignette overlay for cinematic depth */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(7,11,24,0.7)_100%)]" />
      </div>
    </WebGLErrorBoundary>
  );
}
