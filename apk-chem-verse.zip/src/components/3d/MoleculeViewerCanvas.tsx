import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Html, Center } from '@react-three/drei';
import * as THREE from 'three';
import { MoleculeData } from '../../types/chemistry';

interface MoleculeViewerCanvasProps {
  molecule: MoleculeData;
  autoRotate?: boolean;
  showElectronCloud?: boolean;
}

function MoleculeStructure({ molecule, autoRotate, showElectronCloud }: MoleculeViewerCanvasProps) {
  const groupRef = useRef<THREE.Group>(null);
  const [hoveredAtomId, setHoveredAtomId] = useState<number | null>(null);

  useFrame((_, delta) => {
    if (autoRotate && groupRef.current) {
      groupRef.current.rotation.y += delta * 0.4;
    }
  });

  return (
    <group ref={groupRef}>
      {molecule.atoms.map((atom) => {
        const isHovered = hoveredAtomId === atom.id;
        return (
          <group
            key={atom.id}
            position={atom.position}
            onPointerOver={(e) => {
              e.stopPropagation();
              setHoveredAtomId(atom.id);
            }}
            onPointerOut={() => setHoveredAtomId(null)}
          >
            <mesh castShadow receiveShadow>
              <sphereGeometry args={[atom.radius * (isHovered ? 1.15 : 1.0), 32, 32]} />
              <meshStandardMaterial
                color={atom.color}
                roughness={0.25}
                metalness={0.4}
                emissive={atom.color}
                emissiveIntensity={isHovered ? 0.6 : 0.15}
              />
            </mesh>

            {showElectronCloud && (
              <mesh>
                <sphereGeometry args={[atom.radius * 1.6, 16, 16]} />
                <meshBasicMaterial
                  color={atom.color}
                  transparent
                  opacity={0.12}
                  wireframe
                />
              </mesh>
            )}

            <Html position={[0, atom.radius + 0.18, 0]} center distanceFactor={8} pointerEvents="none">
              <div className="px-1.5 py-0.5 rounded bg-slate-950/80 backdrop-blur border border-slate-700/60 text-[10px] font-mono font-bold text-slate-200 select-none shadow">
                {atom.label}
              </div>
            </Html>
          </group>
        );
      })}

      {molecule.bonds.map((bond, idx) => {
        const start = new THREE.Vector3(...bond.start);
        const end = new THREE.Vector3(...bond.end);
        const distance = start.distanceTo(end);
        const position = start.clone().add(end).multiplyScalar(0.5);

        const direction = end.clone().sub(start).normalize();
        const up = new THREE.Vector3(0, 1, 0);
        const quaternion = new THREE.Quaternion().setFromUnitVectors(up, direction);

        const isDouble = bond.type === 'double';

        return (
          <group key={idx} position={position} quaternion={quaternion}>
            {isDouble ? (
              <>
                <mesh position={[0.07, 0, 0]}>
                  <cylinderGeometry args={[0.04, 0.04, distance, 16]} />
                  <meshStandardMaterial color="#cbd5e1" metalness={0.6} roughness={0.3} />
                </mesh>
                <mesh position={[-0.07, 0, 0]}>
                  <cylinderGeometry args={[0.04, 0.04, distance, 16]} />
                  <meshStandardMaterial color="#cbd5e1" metalness={0.6} roughness={0.3} />
                </mesh>
              </>
            ) : (
              <mesh>
                <cylinderGeometry args={[0.065, 0.065, distance, 16]} />
                <meshStandardMaterial color="#e2e8f0" metalness={0.7} roughness={0.25} />
              </mesh>
            )}
          </group>
        );
      })}
    </group>
  );
}

export default function MoleculeViewerCanvas({
  molecule,
  autoRotate = true,
  showElectronCloud = true,
}: MoleculeViewerCanvasProps) {
  return (
    <Canvas
      camera={{ position: [0, 0, 4.8], fov: 45 }}
      gl={{ antialias: true, alpha: true, toneMapping: THREE.ACESFilmicToneMapping }}
      // Fix 3: Set dpr={[1, 1.5]} (strictly never full devicePixelRatio or 2)
      dpr={[1, 1.5]}
      // Fix 1: frameloop 'demand' when not rotating, or 'demand' with invalidate on orbit controls
      frameloop={autoRotate ? 'always' : 'demand'}
    >
      <ambientLight intensity={0.7} />
      <directionalLight position={[5, 8, 5]} intensity={1.5} color="#ffffff" />
      <directionalLight position={[-5, -4, -4]} intensity={0.6} color="#38bdf8" />
      <pointLight position={[0, 4, 2]} intensity={1.0} color="#38bdf8" />

      <Center>
        <MoleculeStructure
          molecule={molecule}
          autoRotate={autoRotate}
          showElectronCloud={showElectronCloud}
        />
      </Center>

      <OrbitControls
        enablePan={false}
        enableZoom={true}
        minDistance={2.5}
        maxDistance={8}
        rotateSpeed={0.8}
      />
    </Canvas>
  );
}
