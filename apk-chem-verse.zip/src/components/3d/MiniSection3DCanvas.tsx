import React, { useRef, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { AtomMiniModel, H2OMiniModel, FlameMiniModel, BatteryMiniModel, GlobeMiniModel } from './TopicCardModels';
import { isWebGLAvailable } from './webglUtils';
import WebGLErrorBoundary from './WebGLErrorBoundary';

interface MiniSection3DCanvasProps {
  animationType?: '3d-molecule' | '3d-reaction' | 'particle-system' | 'static';
  modelType?: string;
  accentColor?: string;
}

function MiniParticleCloud({ color = '#22D3EE' }: { color?: string }) {
  const pointsRef = useRef<THREE.Points>(null);
  const count = 120;

  const [positions, colors] = React.useMemo(() => {
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const c1 = new THREE.Color(color);
    const c2 = new THREE.Color('#A78BFA');

    for (let i = 0; i < count; i++) {
      const radius = 0.8 + Math.random() * 1.6;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      pos[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      pos[i * 3 + 2] = radius * Math.cos(phi);

      const chosen = i % 2 === 0 ? c1 : c2;
      col[i * 3] = chosen.r;
      col[i * 3 + 1] = chosen.g;
      col[i * 3 + 2] = chosen.b;
    }
    return [pos, col];
  }, [color]);

  useFrame((state, delta) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y += delta * 0.4;
      pointsRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.5) * 0.2;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-color" args={[colors, 3]} />
      </bufferGeometry>
      <pointsMaterial size={0.07} vertexColors transparent opacity={0.85} blending={THREE.AdditiveBlending} />
    </points>
  );
}

function MiniReactionCollisions({ color = '#10B981' }: { color?: string }) {
  const atomARef = useRef<THREE.Mesh>(null);
  const atomBRef = useRef<THREE.Mesh>(null);
  const sparkRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime * 2.8;
    const distance = Math.abs(Math.sin(t)) * 1.2;

    if (atomARef.current && atomBRef.current) {
      atomARef.current.position.x = -distance;
      atomBRef.current.position.x = distance;
    }
    if (sparkRef.current) {
      sparkRef.current.scale.setScalar(distance < 0.25 ? 1.5 : 0);
    }
  });

  return (
    <group>
      <mesh ref={atomARef} position={[-0.8, 0, 0]}>
        <sphereGeometry args={[0.3, 20, 20]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.8} />
      </mesh>
      <mesh ref={atomBRef} position={[0.8, 0, 0]}>
        <sphereGeometry args={[0.3, 20, 20]} />
        <meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={0.8} />
      </mesh>
      <mesh ref={sparkRef} position={[0, 0, 0]}>
        <sphereGeometry args={[0.25, 16, 16]} />
        <meshBasicMaterial color="#fef08a" transparent opacity={0.9} />
      </mesh>
    </group>
  );
}

function MiniSection2DFallback({
  modelType = 'atom',
  accentColor = '#22D3EE',
}: MiniSection3DCanvasProps) {
  return (
    <div className="w-full h-56 rounded-2xl bg-slate-950/70 border border-white/10 relative overflow-hidden shadow-inner flex flex-col items-center justify-center p-4">
      <div className="absolute top-2 left-3 z-10 text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/[0.06] border border-white/10 text-cyan-300">
        Simulasi Visual 2D
      </div>
      <div className="relative w-24 h-24 rounded-full border border-white/10 flex items-center justify-center">
        <div
          className="absolute inset-0 rounded-full blur-xl opacity-30 animate-pulse"
          style={{ backgroundColor: accentColor }}
        />
        <div
          className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center shadow-lg"
          style={{ backgroundColor: `${accentColor}33` }}
        >
          <span className="text-xl font-bold font-mono text-white">
            {modelType === 'h2o' ? 'H₂O' : modelType === 'flame' ? '🔥' : modelType === 'battery' ? '⚡' : '⚛'}
          </span>
        </div>
      </div>
      <span className="text-xs font-mono text-slate-400 mt-2">
        Interaksi Partikel & Molekul
      </span>
    </div>
  );
}

export default function MiniSection3DCanvas({
  animationType,
  modelType = 'atom',
  accentColor = '#22D3EE',
}: MiniSection3DCanvasProps) {
  if (!isWebGLAvailable()) {
    return <MiniSection2DFallback animationType={animationType} modelType={modelType} accentColor={accentColor} />;
  }

  return (
    <WebGLErrorBoundary fallback={<MiniSection2DFallback animationType={animationType} modelType={modelType} accentColor={accentColor} />}>
      <div className="w-full h-56 rounded-2xl bg-slate-950/70 border border-white/10 relative overflow-hidden shadow-inner">
        <div className="absolute top-2 left-3 z-10 text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/[0.06] border border-white/10 text-cyan-300">
          Interactive 3D Simulation
        </div>

        <Canvas
          camera={{ position: [0, 0, 3.2], fov: 45 }}
          gl={{ antialias: true, alpha: true }}
          dpr={[1, 1.5]}
          frameloop="demand"
        >
          <ambientLight intensity={0.9} />
          <directionalLight position={[3, 4, 3]} intensity={1.5} color="#ffffff" />
          <pointLight position={[-3, 2, -2]} intensity={2.0} color={accentColor} />

          <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={2} />

          <Suspense fallback={null}>
            <Float speed={2} rotationIntensity={0.2} floatIntensity={0.3}>
              {animationType === 'particle-system' ? (
                <MiniParticleCloud color={accentColor} />
              ) : animationType === '3d-reaction' ? (
                <MiniReactionCollisions color={accentColor} />
              ) : modelType === 'h2o' ? (
                <H2OMiniModel isHovered={false} />
              ) : modelType === 'flame' ? (
                <FlameMiniModel isHovered={false} />
              ) : modelType === 'battery' ? (
                <BatteryMiniModel isHovered={false} />
              ) : modelType === 'globe' ? (
                <GlobeMiniModel isHovered={false} />
              ) : (
                <AtomMiniModel isHovered={false} />
              )}
            </Float>
          </Suspense>
        </Canvas>
      </div>
    </WebGLErrorBoundary>
  );
}
