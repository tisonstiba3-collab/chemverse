import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

// 1. Atom with Electron Orbitals (Struktur Atom)
export function AtomMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const ring1 = useRef<THREE.Mesh>(null);
  const ring2 = useRef<THREE.Mesh>(null);
  const ring3 = useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    const speed = isHovered ? 2.4 : 0.9;
    if (group.current) {
      group.current.rotation.y += delta * speed * 0.6;
    }
    if (ring1.current) ring1.current.rotation.z += delta * speed * 1.5;
    if (ring2.current) ring2.current.rotation.x += delta * speed * 1.3;
    if (ring3.current) ring3.current.rotation.y += delta * speed * 1.4;
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0}>
      <mesh>
        <sphereGeometry args={[0.38, 24, 24]} />
        <meshStandardMaterial
          color="#38bdf8"
          emissive="#0284c7"
          emissiveIntensity={isHovered ? 1.0 : 0.6}
          roughness={0.2}
          metalness={0.6}
        />
      </mesh>
      <mesh position={[0.15, 0.12, 0]}>
        <sphereGeometry args={[0.2, 16, 16]} />
        <meshStandardMaterial color="#818cf8" emissive="#6366f1" emissiveIntensity={0.6} />
      </mesh>
      <mesh position={[-0.15, -0.1, 0.1]}>
        <sphereGeometry args={[0.2, 16, 16]} />
        <meshStandardMaterial color="#34d399" emissive="#10b981" emissiveIntensity={0.6} />
      </mesh>

      <group ref={ring1} rotation={[0, 0, Math.PI / 4]}>
        <mesh>
          <torusGeometry args={[0.95, 0.018, 16, 48]} />
          <meshBasicMaterial color="#38bdf8" transparent opacity={0.7} />
        </mesh>
        <mesh position={[0.95, 0, 0]}>
          <sphereGeometry args={[0.075, 16, 16]} />
          <meshStandardMaterial color="#f0fdf4" emissive="#22d3ee" emissiveIntensity={1.5} />
        </mesh>
      </group>

      <group ref={ring2} rotation={[Math.PI / 3, Math.PI / 4, 0]}>
        <mesh>
          <torusGeometry args={[0.98, 0.018, 16, 48]} />
          <meshBasicMaterial color="#a78bfa" transparent opacity={0.7} />
        </mesh>
        <mesh position={[-0.98, 0, 0]}>
          <sphereGeometry args={[0.075, 16, 16]} />
          <meshStandardMaterial color="#fdf4ff" emissive="#a855f7" emissiveIntensity={1.5} />
        </mesh>
      </group>

      <group ref={ring3} rotation={[-Math.PI / 3, 0, Math.PI / 6]}>
        <mesh>
          <torusGeometry args={[1.02, 0.018, 16, 48]} />
          <meshBasicMaterial color="#34d399" transparent opacity={0.7} />
        </mesh>
        <mesh position={[0, 1.02, 0]}>
          <sphereGeometry args={[0.075, 16, 16]} />
          <meshStandardMaterial color="#ecfdf5" emissive="#34d399" emissiveIntensity={1.5} />
        </mesh>
      </group>
    </group>
  );
}

// 2. Rotating H2O Molecule (Ikatan Kimia)
export function H2OMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const cloud1 = useRef<THREE.Mesh>(null);
  const cloud2 = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    const speed = isHovered ? 2.2 : 0.8;
    if (group.current) {
      group.current.rotation.y += delta * speed;
      group.current.rotation.x = Math.sin(state.clock.elapsedTime * 1.5) * 0.15;
    }
    if (cloud1.current && cloud2.current) {
      cloud1.current.rotation.z += delta * 0.8;
      cloud2.current.rotation.z -= delta * 0.8;
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0} position={[0, -0.05, 0]}>
      <mesh position={[0, 0.25, 0]}>
        <sphereGeometry args={[0.48, 32, 32]} />
        <meshStandardMaterial
          color="#ef4444"
          emissive="#b91c1c"
          emissiveIntensity={isHovered ? 0.9 : 0.5}
          roughness={0.25}
          metalness={0.4}
        />
      </mesh>
      <mesh position={[-0.75, -0.32, 0]}>
        <sphereGeometry args={[0.3, 24, 24]} />
        <meshStandardMaterial
          color="#38bdf8"
          emissive="#0284c7"
          emissiveIntensity={isHovered ? 0.8 : 0.4}
          roughness={0.25}
          metalness={0.5}
        />
      </mesh>
      <mesh position={[0.75, -0.32, 0]}>
        <sphereGeometry args={[0.3, 24, 24]} />
        <meshStandardMaterial
          color="#38bdf8"
          emissive="#0284c7"
          emissiveIntensity={isHovered ? 0.8 : 0.4}
          roughness={0.25}
          metalness={0.5}
        />
      </mesh>
      <mesh position={[-0.375, -0.035, 0]} rotation={[0, 0, Math.PI / 4]}>
        <cylinderGeometry args={[0.07, 0.07, 0.75, 16]} />
        <meshStandardMaterial color="#cbd5e1" metalness={0.7} roughness={0.3} />
      </mesh>
      <mesh position={[0.375, -0.035, 0]} rotation={[0, 0, -Math.PI / 4]}>
        <cylinderGeometry args={[0.07, 0.07, 0.75, 16]} />
        <meshStandardMaterial color="#cbd5e1" metalness={0.7} roughness={0.3} />
      </mesh>
      <mesh ref={cloud1} position={[-0.28, 0.65, 0.2]}>
        <sphereGeometry args={[0.16, 16, 16]} />
        <meshStandardMaterial
          color="#c084fc"
          emissive="#9333ea"
          emissiveIntensity={1.0}
          transparent
          opacity={0.55}
        />
      </mesh>
      <mesh ref={cloud2} position={[0.28, 0.65, -0.2]}>
        <sphereGeometry args={[0.16, 16, 16]} />
        <meshStandardMaterial
          color="#c084fc"
          emissive="#9333ea"
          emissiveIntensity={1.0}
          transparent
          opacity={0.55}
        />
      </mesh>
    </group>
  );
}

// 3. Laboratory Beaker with Bubbling Fluid (Stoikiometri / Asam-Basa)
export function BeakerMiniModel({ isHovered, color = '#10b981' }: { isHovered?: boolean; color?: string }) {
  const group = useRef<THREE.Group>(null);
  const bubbles = useRef<THREE.Group>(null);

  useFrame((state, delta) => {
    const speed = isHovered ? 2.0 : 0.7;
    if (group.current) {
      group.current.rotation.y += delta * speed;
      group.current.position.y = Math.sin(state.clock.elapsedTime * 2) * 0.06;
    }
    if (bubbles.current) {
      bubbles.current.children.forEach((child, i) => {
        child.position.y += delta * (0.5 + i * 0.25);
        if (child.position.y > 0.5) child.position.y = -0.3;
      });
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0} position={[0, -0.15, 0]}>
      <mesh position={[0, 0.1, 0]}>
        <cylinderGeometry args={[0.62, 0.62, 1.1, 32, 1, true]} />
        <meshPhysicalMaterial
          color="#e0f2fe"
          transmission={0.88}
          roughness={0.1}
          metalness={0.1}
          transparent
          opacity={0.65}
          side={THREE.DoubleSide}
        />
      </mesh>
      <mesh position={[0, -0.45, 0]}>
        <cylinderGeometry args={[0.62, 0.62, 0.04, 32]} />
        <meshStandardMaterial color="#bae6fd" roughness={0.2} />
      </mesh>
      <mesh position={[0, 0.65, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.63, 0.035, 16, 32]} />
        <meshStandardMaterial color="#bae6fd" roughness={0.2} metalness={0.4} />
      </mesh>
      <mesh position={[0, -0.15, 0]}>
        <cylinderGeometry args={[0.58, 0.58, 0.65, 32]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={isHovered ? 0.9 : 0.55}
          roughness={0.2}
          transparent
          opacity={0.85}
        />
      </mesh>
      <mesh position={[0, 0.18, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.58, 32]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.8} />
      </mesh>
      <group ref={bubbles}>
        {[-0.2, 0.15, -0.1, 0.22].map((x, idx) => (
          <mesh key={idx} position={[x, -0.2 + idx * 0.18, idx % 2 === 0 ? 0.2 : -0.2]}>
            <sphereGeometry args={[0.065, 16, 16]} />
            <meshStandardMaterial
              color="#ffffff"
              emissive="#ffffff"
              emissiveIntensity={1.2}
              transparent
              opacity={0.9}
            />
          </mesh>
        ))}
      </group>
    </group>
  );
}

// 4. Energetic Flame / Thermometric Element (Termokimia)
export function FlameMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const outerCone = useRef<THREE.Mesh>(null);
  const innerCone = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    const speed = isHovered ? 2.5 : 1.0;
    if (group.current) {
      group.current.rotation.y += delta * speed * 0.8;
      const wiggle = Math.sin(state.clock.elapsedTime * 4) * 0.05;
      group.current.position.y = wiggle;
    }
    if (outerCone.current && innerCone.current) {
      const scale = 1 + Math.sin(state.clock.elapsedTime * 6) * 0.06;
      outerCone.current.scale.set(scale, scale * 1.05, scale);
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0} position={[0, -0.25, 0]}>
      <mesh ref={outerCone} position={[0, 0.35, 0]}>
        <coneGeometry args={[0.55, 1.25, 32]} />
        <meshStandardMaterial
          color="#f59e0b"
          emissive="#d97706"
          emissiveIntensity={isHovered ? 1.2 : 0.8}
          roughness={0.2}
          transparent
          opacity={0.88}
        />
      </mesh>
      <mesh ref={innerCone} position={[0, 0.2, 0]}>
        <coneGeometry args={[0.35, 0.9, 24]} />
        <meshStandardMaterial
          color="#fef08a"
          emissive="#fde047"
          emissiveIntensity={1.5}
          roughness={0.1}
          transparent
          opacity={0.95}
        />
      </mesh>
      <mesh position={[0, -0.05, 0]}>
        <sphereGeometry args={[0.28, 24, 24]} />
        <meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={1.6} />
      </mesh>
      <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, 0.1, 0]}>
        <torusGeometry args={[0.75, 0.02, 16, 48]} />
        <meshBasicMaterial color="#fbbf24" transparent opacity={0.65} />
      </mesh>
    </group>
  );
}

// 5. Galvanic Battery / Electrochemical Redox Cell (Elektrokimia)
export function BatteryMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const ring = useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    const speed = isHovered ? 2.0 : 0.7;
    if (group.current) {
      group.current.rotation.y += delta * speed;
    }
    if (ring.current) {
      ring.current.rotation.z += delta * 1.5;
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0} position={[0, -0.05, 0]}>
      <mesh position={[0, 0, 0]}>
        <cylinderGeometry args={[0.48, 0.48, 1.1, 32]} />
        <meshStandardMaterial
          color="#0f766e"
          emissive="#134e4a"
          emissiveIntensity={isHovered ? 0.6 : 0.25}
          metalness={0.7}
          roughness={0.25}
        />
      </mesh>
      <mesh position={[0, 0.62, 0]}>
        <cylinderGeometry args={[0.18, 0.18, 0.16, 24]} />
        <meshStandardMaterial
          color="#fbbf24"
          emissive="#f59e0b"
          emissiveIntensity={1.2}
          metalness={0.9}
        />
      </mesh>
      <mesh position={[0, -0.58, 0]}>
        <cylinderGeometry args={[0.49, 0.49, 0.08, 32]} />
        <meshStandardMaterial color="#cbd5e1" metalness={0.8} roughness={0.2} />
      </mesh>
      {[-0.2, 0, 0.2].map((y, idx) => (
        <mesh key={idx} position={[0, y, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.49, 0.02, 16, 32]} />
          <meshStandardMaterial
            color="#2dd4bf"
            emissive="#14b8a6"
            emissiveIntensity={isHovered ? 1.5 : 0.9}
          />
        </mesh>
      ))}
      <group ref={ring} rotation={[Math.PI / 3, 0, 0]}>
        <mesh>
          <torusGeometry args={[0.85, 0.015, 16, 48]} />
          <meshBasicMaterial color="#38bdf8" transparent opacity={0.6} />
        </mesh>
        <mesh position={[0.85, 0, 0]}>
          <sphereGeometry args={[0.07, 16, 16]} />
          <meshStandardMaterial color="#ffffff" emissive="#38bdf8" emissiveIntensity={2.0} />
        </mesh>
      </group>
    </group>
  );
}

// 6. Equilibrium Reversible Dynamic Scales/Rings (Kesetimbangan)
export function EquilibriumMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const ring1 = useRef<THREE.Mesh>(null);
  const ring2 = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    const speed = isHovered ? 2.4 : 0.9;
    if (group.current) {
      group.current.rotation.y += delta * speed * 0.5;
      group.current.position.y = Math.sin(state.clock.elapsedTime * 2) * 0.05;
    }
    if (ring1.current && ring2.current) {
      ring1.current.rotation.z += delta * speed * 1.2;
      ring2.current.rotation.z -= delta * speed * 1.2;
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0}>
      <mesh>
        <octahedronGeometry args={[0.45, 0]} />
        <meshStandardMaterial
          color="#8b5cf6"
          emissive="#6d28d9"
          emissiveIntensity={isHovered ? 1.0 : 0.5}
          metalness={0.6}
          roughness={0.2}
        />
      </mesh>
      <group ref={ring1} rotation={[Math.PI / 4, 0, 0]}>
        <mesh>
          <torusGeometry args={[0.88, 0.02, 16, 48]} />
          <meshBasicMaterial color="#a78bfa" transparent opacity={0.7} />
        </mesh>
        <mesh position={[0.88, 0, 0]}>
          <sphereGeometry args={[0.09, 16, 16]} />
          <meshStandardMaterial color="#c4b5fd" emissive="#8b5cf6" emissiveIntensity={1.5} />
        </mesh>
      </group>
      <group ref={ring2} rotation={[-Math.PI / 4, 0, 0]}>
        <mesh>
          <torusGeometry args={[0.88, 0.02, 16, 48]} />
          <meshBasicMaterial color="#38bdf8" transparent opacity={0.7} />
        </mesh>
        <mesh position={[-0.88, 0, 0]}>
          <sphereGeometry args={[0.09, 16, 16]} />
          <meshStandardMaterial color="#bae6fd" emissive="#0284c7" emissiveIntensity={1.5} />
        </mesh>
      </group>
    </group>
  );
}

// 7. Particle Kinetics Collision Model (Laju Reaksi)
export function KineticsMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    const speed = isHovered ? 2.5 : 1.0;
    if (group.current) {
      group.current.rotation.y += delta * speed * 0.8;
      group.current.rotation.x += delta * speed * 0.4;
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0}>
      <mesh>
        <dodecahedronGeometry args={[0.42, 0]} />
        <meshStandardMaterial
          color="#06b6d4"
          emissive="#0891b2"
          emissiveIntensity={isHovered ? 1.2 : 0.6}
          roughness={0.2}
          metalness={0.5}
        />
      </mesh>
      {[
        [0.75, 0.5, 0],
        [-0.75, -0.5, 0],
        [0, 0.75, 0.5],
        [0, -0.75, -0.5],
      ].map((pos, idx) => (
        <group key={idx}>
          <mesh position={pos as [number, number, number]}>
            <sphereGeometry args={[0.16, 16, 16]} />
            <meshStandardMaterial
              color={idx % 2 === 0 ? '#22d3ee' : '#f59e0b'}
              emissive={idx % 2 === 0 ? '#06b6d4' : '#d97706'}
              emissiveIntensity={1.5}
            />
          </mesh>
        </group>
      ))}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.95, 0.02, 16, 48]} />
        <meshBasicMaterial color="#22d3ee" transparent opacity={0.6} />
      </mesh>
    </group>
  );
}

// 8. Hexagonal Benzene / Hydrocarbon Framework (Kimia Organik)
export function OrganicMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const ring = useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    const speed = isHovered ? 2.0 : 0.8;
    if (group.current) {
      group.current.rotation.y += delta * speed;
      group.current.rotation.z += delta * (speed * 0.4);
    }
    if (ring.current) {
      ring.current.rotation.z += delta * 1.4;
    }
  });

  const hexagonPoints = Array.from({ length: 6 }).map((_, i) => {
    const angle = (i * Math.PI) / 3;
    return [Math.cos(angle) * 0.68, Math.sin(angle) * 0.68, 0] as [number, number, number];
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0}>
      {hexagonPoints.map((pos, idx) => (
        <group key={idx}>
          <mesh position={pos}>
            <sphereGeometry args={[0.16, 20, 20]} />
            <meshStandardMaterial
              color="#f43f5e"
              emissive="#e11d48"
              emissiveIntensity={isHovered ? 0.9 : 0.4}
              metalness={0.6}
            />
          </mesh>
          <mesh position={[pos[0] * 1.45, pos[1] * 1.45, 0]}>
            <sphereGeometry args={[0.1, 16, 16]} />
            <meshStandardMaterial
              color="#38bdf8"
              emissive="#0284c7"
              emissiveIntensity={0.6}
            />
          </mesh>
        </group>
      ))}
      <mesh ref={ring}>
        <torusGeometry args={[0.42, 0.025, 16, 32]} />
        <meshStandardMaterial color="#fb7185" emissive="#f43f5e" emissiveIntensity={1.4} />
      </mesh>
    </group>
  );
}

// 9. Erlenmeyer Lab Flask Model
export function FlaskMiniModel({ isHovered, color = '#22d3ee' }: { isHovered?: boolean; color?: string }) {
  const group = useRef<THREE.Group>(null);
  useFrame((_, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * (isHovered ? 2.0 : 0.8);
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0} position={[0, -0.15, 0]}>
      {/* Glass Body */}
      <mesh position={[0, 0.1, 0]}>
        <cylinderGeometry args={[0.18, 0.65, 1.1, 24, 1, true]} />
        <meshPhysicalMaterial
          color="#e0f2fe"
          transmission={0.9}
          roughness={0.1}
          metalness={0.1}
          transparent
          opacity={0.65}
          side={THREE.DoubleSide}
        />
      </mesh>
      {/* Liquid Core */}
      <mesh position={[0, -0.2, 0]}>
        <coneGeometry args={[0.55, 0.6, 24]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={isHovered ? 1.0 : 0.6}
          roughness={0.2}
          transparent
          opacity={0.85}
        />
      </mesh>
      {/* Flask Lip */}
      <mesh position={[0, 0.68, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.2, 0.03, 16, 24]} />
        <meshStandardMaterial color="#bae6fd" roughness={0.2} metalness={0.4} />
      </mesh>
    </group>
  );
}

// 10. Planetary Globe with Atmosphere Ring (Pemanasan Global)
export function GlobeMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const ring = useRef<THREE.Mesh>(null);
  useFrame((_, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * (isHovered ? 2.0 : 0.7);
    }
    if (ring.current) {
      ring.current.rotation.z += delta * 1.2;
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0}>
      {/* Earth Sphere */}
      <mesh>
        <sphereGeometry args={[0.65, 32, 32]} />
        <meshStandardMaterial
          color="#0284c7"
          emissive="#0369a1"
          emissiveIntensity={isHovered ? 0.7 : 0.3}
          roughness={0.3}
          metalness={0.2}
        />
      </mesh>
      {/* Continents Embellishment */}
      <mesh position={[0.2, 0.3, 0.45]}>
        <sphereGeometry args={[0.28, 16, 16]} />
        <meshStandardMaterial color="#10b981" roughness={0.5} />
      </mesh>
      <mesh position={[-0.3, -0.2, 0.45]}>
        <sphereGeometry args={[0.24, 16, 16]} />
        <meshStandardMaterial color="#10b981" roughness={0.5} />
      </mesh>
      {/* Atmosphere Greenhouse Heat Ring */}
      <mesh ref={ring} rotation={[Math.PI / 3, 0, 0]}>
        <torusGeometry args={[0.95, 0.025, 16, 48]} />
        <meshStandardMaterial
          color="#ef4444"
          emissive="#dc2626"
          emissiveIntensity={1.8}
          transparent
          opacity={0.8}
        />
      </mesh>
    </group>
  );
}

// 11. Eco Green Leaf / Sustainability Emblem (Kimia Hijau)
export function LeafMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  useFrame((state, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * (isHovered ? 2.2 : 0.8);
      group.current.rotation.z = Math.sin(state.clock.elapsedTime * 2) * 0.1;
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0} position={[0, -0.1, 0]}>
      {/* Leaf Blade Primary */}
      <mesh rotation={[0, 0, Math.PI / 4]}>
        <boxGeometry args={[0.7, 0.7, 0.08]} />
        <meshStandardMaterial
          color="#22c55e"
          emissive="#15803d"
          emissiveIntensity={isHovered ? 0.9 : 0.5}
          roughness={0.3}
        />
      </mesh>
      {/* Leaf Stem */}
      <mesh position={[-0.35, -0.35, 0]} rotation={[0, 0, Math.PI / 4]}>
        <cylinderGeometry args={[0.04, 0.04, 0.4, 16]} />
        <meshStandardMaterial color="#166534" roughness={0.4} />
      </mesh>
      {/* Bio Water Droplet */}
      <mesh position={[0.1, 0.1, 0.1]}>
        <sphereGeometry args={[0.12, 16, 16]} />
        <meshPhysicalMaterial
          color="#38bdf8"
          transmission={0.9}
          roughness={0.1}
          metalness={0.1}
          transparent
        />
      </mesh>
    </group>
  );
}

// 12. Clock / Reaction Time Indicator
export function ClockMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const hand = useRef<THREE.Mesh>(null);
  useFrame((_, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * (isHovered ? 1.8 : 0.6);
    }
    if (hand.current) {
      hand.current.rotation.z -= delta * (isHovered ? 4.0 : 1.5);
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0}>
      <mesh>
        <cylinderGeometry args={[0.75, 0.75, 0.12, 32]} />
        <meshStandardMaterial
          color="#6366f1"
          emissive="#4338ca"
          emissiveIntensity={isHovered ? 0.8 : 0.4}
          metalness={0.6}
          roughness={0.2}
        />
      </mesh>
      <mesh position={[0, 0, 0.07]}>
        <ringGeometry args={[0.65, 0.72, 32]} />
        <meshBasicMaterial color="#a5b4fc" />
      </mesh>
      <group ref={hand} position={[0, 0, 0.08]}>
        <mesh position={[0, 0.25, 0]}>
          <boxGeometry args={[0.04, 0.5, 0.02]} />
          <meshBasicMaterial color="#f43f5e" />
        </mesh>
      </group>
    </group>
  );
}

// 13. Balance / Equilibrium Scale
export function BalanceMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const beam = useRef<THREE.Group>(null);
  useFrame((state, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * (isHovered ? 2.0 : 0.7);
    }
    if (beam.current) {
      beam.current.rotation.z = Math.sin(state.clock.elapsedTime * 2.5) * 0.18;
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0} position={[0, -0.15, 0]}>
      {/* Central Pillar */}
      <mesh position={[0, 0.4, 0]}>
        <cylinderGeometry args={[0.06, 0.09, 0.9, 16]} />
        <meshStandardMaterial color="#cbd5e1" metalness={0.8} roughness={0.2} />
      </mesh>
      {/* Base */}
      <mesh position={[0, -0.08, 0]}>
        <cylinderGeometry args={[0.4, 0.45, 0.08, 24]} />
        <meshStandardMaterial color="#94a3b8" metalness={0.8} roughness={0.2} />
      </mesh>
      {/* Pivoting Beam */}
      <group ref={beam} position={[0, 0.82, 0]}>
        <mesh>
          <boxGeometry args={[1.3, 0.05, 0.05]} />
          <meshStandardMaterial color="#fbbf24" metalness={0.7} roughness={0.2} />
        </mesh>
        {/* Left Pan */}
        <mesh position={[-0.55, -0.35, 0]}>
          <cylinderGeometry args={[0.22, 0.22, 0.04, 20]} />
          <meshStandardMaterial color="#38bdf8" metalness={0.7} roughness={0.2} />
        </mesh>
        {/* Right Pan */}
        <mesh position={[0.55, -0.35, 0]}>
          <cylinderGeometry args={[0.22, 0.22, 0.04, 20]} />
          <meshStandardMaterial color="#a78bfa" metalness={0.7} roughness={0.2} />
        </mesh>
      </group>
    </group>
  );
}

// 14. Thermometer Thermal Column
export function ThermometerMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const liquid = useRef<THREE.Mesh>(null);
  useFrame((state, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * (isHovered ? 2.0 : 0.8);
    }
    if (liquid.current) {
      const h = 0.5 + Math.sin(state.clock.elapsedTime * 3) * 0.15;
      liquid.current.scale.set(1, h, 1);
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0} position={[0, -0.1, 0]}>
      {/* Glass Tube */}
      <mesh position={[0, 0.3, 0]}>
        <cylinderGeometry args={[0.12, 0.12, 1.2, 24, 1, true]} />
        <meshPhysicalMaterial
          color="#e0f2fe"
          transmission={0.9}
          roughness={0.1}
          metalness={0.1}
          transparent
          opacity={0.6}
        />
      </mesh>
      {/* Bottom Mercury Bulb */}
      <mesh position={[0, -0.35, 0]}>
        <sphereGeometry args={[0.26, 24, 24]} />
        <meshStandardMaterial
          color="#ef4444"
          emissive="#dc2626"
          emissiveIntensity={isHovered ? 1.2 : 0.8}
        />
      </mesh>
      {/* Rising Fluid Column */}
      <mesh ref={liquid} position={[0, 0.15, 0]}>
        <cylinderGeometry args={[0.07, 0.07, 0.8, 16]} />
        <meshStandardMaterial
          color="#ef4444"
          emissive="#dc2626"
          emissiveIntensity={isHovered ? 1.2 : 0.8}
        />
      </mesh>
    </group>
  );
}

// 15. Industrial Factory / Metallurgy Chemical Processing
export function FactoryMiniModel({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  useFrame((_, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * (isHovered ? 1.8 : 0.6);
    }
  });

  return (
    <group ref={group} scale={isHovered ? 1.15 : 1.0} position={[0, -0.2, 0]}>
      {/* Factory Base Structure */}
      <mesh position={[0, 0.2, 0]}>
        <boxGeometry args={[0.9, 0.5, 0.6]} />
        <meshStandardMaterial
          color="#475569"
          metalness={0.7}
          roughness={0.3}
        />
      </mesh>
      {/* Tower 1 */}
      <mesh position={[-0.25, 0.7, 0]}>
        <cylinderGeometry args={[0.1, 0.14, 0.7, 16]} />
        <meshStandardMaterial color="#f59e0b" emissive="#d97706" emissiveIntensity={0.6} />
      </mesh>
      {/* Tower 2 */}
      <mesh position={[0.22, 0.85, 0]}>
        <cylinderGeometry args={[0.09, 0.13, 0.95, 16]} />
        <meshStandardMaterial color="#f59e0b" emissive="#d97706" emissiveIntensity={0.6} />
      </mesh>
    </group>
  );
}
