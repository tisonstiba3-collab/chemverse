import React, { useRef, Suspense, lazy } from 'react';
import { FlaskConical } from 'lucide-react';
import { useInViewport } from './useInViewport';
import CanvasShimmerSkeleton from './CanvasShimmerSkeleton';
import { isWebGLAvailable } from './webglUtils';
import WebGLErrorBoundary from './WebGLErrorBoundary';

// Code-split Three.js Canvas via React.lazy
const LazyHeroFlaskHeaderCanvas = lazy(() => import('./HeroFlaskHeaderCanvas'));

function Flask2DFallback() {
  return (
    <div className="w-full h-full flex items-center justify-center relative select-none">
      <div className="relative w-20 h-20 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-purple-600/30 border border-cyan-400/30 flex items-center justify-center shadow-[0_0_20px_rgba(34,211,238,0.25)]">
        <FlaskConical className="w-10 h-10 text-cyan-300 drop-shadow-[0_0_8px_#22d3ee] animate-pulse" />
        {/* Subtle rising bubble particles */}
        <div className="absolute w-2 h-2 rounded-full bg-cyan-400 opacity-75 animate-ping top-3 right-4" />
        <div className="absolute w-1.5 h-1.5 rounded-full bg-purple-300 opacity-60 animate-ping top-5 left-4" style={{ animationDelay: '0.8s' }} />
      </div>
    </div>
  );
}

export default function HeroFlaskHeader3D() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInViewport = useInViewport(containerRef, 0.1);

  if (!isWebGLAvailable()) {
    return (
      <div ref={containerRef} className="w-24 h-24 sm:w-28 sm:h-28 relative shrink-0">
        <Flask2DFallback />
      </div>
    );
  }

  return (
    <div ref={containerRef} className="w-24 h-24 sm:w-28 sm:h-28 relative shrink-0">
      <WebGLErrorBoundary fallback={<Flask2DFallback />}>
        {isInViewport ? (
          <Suspense fallback={<CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-2xl" />}>
            <LazyHeroFlaskHeaderCanvas />
          </Suspense>
        ) : (
          <CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-2xl" />
        )}
      </WebGLErrorBoundary>
    </div>
  );
}
