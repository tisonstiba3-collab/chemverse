import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float } from '@react-three/drei';
import * as THREE from 'three';

function FloatingFlaskModel() {
  const groupRef = useRef<THREE.Group>(null);
  const ringRef = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += delta * 0.5;
      groupRef.current.position.y = Math.sin(state.clock.elapsedTime * 1.5) * 0.05;
    }
    if (ringRef.current) {
      ringRef.current.rotation.z += delta * 0.8;
    }
  });

  return (
    <group ref={groupRef} scale={1.05} position={[0, -0.15, 0]}>
      {/* Outer Erlenmeyer Glass Flask Body */}
      <mesh position={[0, 0.45, 0]}>
        <cylinderGeometry args={[0.22, 0.22, 0.55, 32, 1, true]} />
        <meshPhysicalMaterial
          color="#e0f2fe"
          transmission={0.92}
          roughness={0.08}
          metalness={0.1}
          transparent
          opacity={0.65}
          side={THREE.DoubleSide}
        />
      </mesh>

      <mesh position={[0, -0.12, 0]}>
        <coneGeometry args={[0.78, 0.95, 32, 1, true]} />
        <meshPhysicalMaterial
          color="#e0f2fe"
          transmission={0.92}
          roughness={0.08}
          metalness={0.1}
          transparent
          opacity={0.65}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Flask Base Rim */}
      <mesh position={[0, -0.58, 0]}>
        <cylinderGeometry args={[0.78, 0.78, 0.04, 32]} />
        <meshStandardMaterial color="#bae6fd" roughness={0.2} />
      </mesh>

      {/* Flask Top Lip */}
      <mesh position={[0, 0.72, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.24, 0.035, 16, 32]} />
        <meshStandardMaterial color="#38bdf8" roughness={0.2} metalness={0.5} />
      </mesh>

      {/* Luminous Glowing Liquid with Neon Cyan Core */}
      <mesh position={[0, -0.22, 0]}>
        <coneGeometry args={[0.62, 0.68, 32]} />
        <meshStandardMaterial
          color="#22d3ee"
          emissive="#0891b2"
          emissiveIntensity={1.2}
          roughness={0.15}
          transparent
          opacity={0.85}
        />
      </mesh>

      {/* Orbiting Quantum Neon Ring */}
      <group ref={ringRef} rotation={[Math.PI / 3.5, 0, 0]}>
        <mesh>
          <torusGeometry args={[1.05, 0.018, 16, 64]} />
          <meshBasicMaterial color="#a78bfa" transparent opacity={0.7} />
        </mesh>
        <mesh position={[1.05, 0, 0]}>
          <sphereGeometry args={[0.08, 16, 16]} />
          <meshStandardMaterial
            color="#fdf4ff"
            emissive="#a78bfa"
            emissiveIntensity={2.0}
          />
        </mesh>
      </group>

      {/* Floating Sparkles inside flask */}
      <mesh position={[0.15, -0.15, 0.15]}>
        <sphereGeometry args={[0.07, 16, 16]} />
        <meshStandardMaterial
          color="#fbbf24"
          emissive="#f59e0b"
          emissiveIntensity={1.5}
        />
      </mesh>
    </group>
  );
}

export default function HeroFlaskHeaderCanvas() {
  return (
    <Canvas
      camera={{ position: [0, 0, 3.1], fov: 42 }}
      gl={{ antialias: true, alpha: true }}
      // Fix 3: Set dpr={[1, 1.5]}
      dpr={[1, 1.5]}
      // Fix 1: Frameloop demand to avoid continuous background rendering
      frameloop="demand"
    >
      <ambientLight intensity={0.9} />
      <directionalLight position={[2, 3, 4]} intensity={1.5} color="#ffffff" />
      <pointLight position={[-3, 2, -2]} intensity={2.2} color="#22d3ee" />
      <pointLight position={[3, -2, -2]} intensity={2.0} color="#a78bfa" />
      <pointLight position={[0, 3, 2]} intensity={1.0} color="#fef08a" />

      <Float speed={2.5} rotationIntensity={0.2} floatIntensity={0.35}>
        <FloatingFlaskModel />
      </Float>
    </Canvas>
  );
}
