import React from 'react';
import { Canvas } from '@react-three/fiber';
import { Float } from '@react-three/drei';
import { ModelType } from '../../types/chemistry';
import {
  AtomMiniModel,
  H2OMiniModel,
  BeakerMiniModel,
  FlameMiniModel,
  BatteryMiniModel,
  EquilibriumMiniModel,
  KineticsMiniModel,
  OrganicMiniModel,
  FlaskMiniModel,
  GlobeMiniModel,
  LeafMiniModel,
  ClockMiniModel,
  BalanceMiniModel,
  ThermometerMiniModel,
  FactoryMiniModel,
} from './TopicCardModels';

interface TopicCardCanvasProps {
  modelType: string;
  accentColor?: string;
  isHovered?: boolean;
  frameloop?: 'always' | 'demand' | 'never';
}

export default function TopicCardCanvas({
  modelType,
  accentColor = '#22d3ee',
  isHovered = false,
  frameloop = 'demand',
}: TopicCardCanvasProps) {
  const renderModel = () => {
    switch (modelType) {
      case 'atom':
        return <AtomMiniModel isHovered={isHovered} />;
      case 'h2o':
        return <H2OMiniModel isHovered={isHovered} />;
      case 'beaker':
        return <BeakerMiniModel isHovered={isHovered} color={accentColor} />;
      case 'flame':
        return <FlameMiniModel isHovered={isHovered} />;
      case 'battery':
        return <BatteryMiniModel isHovered={isHovered} />;
      case 'equilibrium':
        return <EquilibriumMiniModel isHovered={isHovered} />;
      case 'kinetics':
        return <KineticsMiniModel isHovered={isHovered} />;
      case 'organic':
        return <OrganicMiniModel isHovered={isHovered} />;
      case 'flask':
        return <FlaskMiniModel isHovered={isHovered} color={accentColor} />;
      case 'globe':
        return <GlobeMiniModel isHovered={isHovered} />;
      case 'leaf':
        return <LeafMiniModel isHovered={isHovered} />;
      case 'clock':
        return <ClockMiniModel isHovered={isHovered} />;
      case 'balance':
        return <BalanceMiniModel isHovered={isHovered} />;
      case 'thermometer':
        return <ThermometerMiniModel isHovered={isHovered} />;
      case 'factory':
        return <FactoryMiniModel isHovered={isHovered} />;
      default:
        return <AtomMiniModel isHovered={isHovered} />;
    }
  };

  return (
    <Canvas
      camera={{ position: [0, 0, 3.1], fov: 42 }}
      gl={{ antialias: true, alpha: true }}
      dpr={[1, 1.5]}
      frameloop={frameloop}
    >
      <ambientLight intensity={0.8} />
      <directionalLight position={[3, 4, 3]} intensity={1.4} color="#ffffff" />
      <pointLight position={[-3, -2, -2]} intensity={1.5} color={accentColor} />
      <pointLight position={[3, 2, 2]} intensity={1.2} color="#ffffff" />

      <Float speed={2} rotationIntensity={0.2} floatIntensity={0.3}>
        {renderModel()}
      </Float>
    </Canvas>
  );
}
