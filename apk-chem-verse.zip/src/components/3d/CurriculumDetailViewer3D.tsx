import React, { useRef, useState, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Float, Center } from '@react-three/drei';
import * as THREE from 'three';
import { RotateCw, ZoomIn, Sparkles } from 'lucide-react';
import { CurriculumTopic } from '../../types/chemistry';
import { useInViewport } from './useInViewport';
import CanvasShimmerSkeleton from './CanvasShimmerSkeleton';
import { isWebGLAvailable } from './webglUtils';
import WebGLErrorBoundary from './WebGLErrorBoundary';
import {
  AtomMiniModel,
  H2OMiniModel,
  BeakerMiniModel,
  FlameMiniModel,
  BatteryMiniModel,
  EquilibriumMiniModel,
  OrganicMiniModel,
  FlaskMiniModel,
  GlobeMiniModel,
  LeafMiniModel,
  ClockMiniModel,
  BalanceMiniModel,
  ThermometerMiniModel,
  FactoryMiniModel,
} from './TopicCardModels';

interface CurriculumDetailViewer3DProps {
  topic: CurriculumTopic;
  activeAnimationType?: '3d-molecule' | '3d-reaction' | 'particle-system' | 'static';
}

// Particle System Model for greenhouse gas / atmospheric dispersion
function AtmosphericParticleField({ color = '#22D3EE' }: { color?: string }) {
  const pointsRef = useRef<THREE.Points>(null);
  const particleCount = 280;

  const [positions, colors] = React.useMemo(() => {
    const pos = new Float32Array(particleCount * 3);
    const col = new Float32Array(particleCount * 3);
    const c1 = new THREE.Color(color);
    const c2 = new THREE.Color('#A78BFA');
    const c3 = new THREE.Color('#FBBF24');

    for (let i = 0; i < particleCount; i++) {
      const radius = 1.2 + Math.random() * 2.5;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      pos[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      pos[i * 3 + 2] = radius * Math.cos(phi);

      const chosenColor = i % 3 === 0 ? c1 : i % 3 === 1 ? c2 : c3;
      col[i * 3] = chosenColor.r;
      col[i * 3 + 1] = chosenColor.g;
      col[i * 3 + 2] = chosenColor.b;
    }
    return [pos, col];
  }, [color]);

  useFrame((state, delta) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y += delta * 0.2;
      pointsRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.4) * 0.15;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-color" args={[colors, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.065}
        vertexColors
        transparent
        opacity={0.8}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

// Reaction collision animation (atoms colliding and rebounding)
function ReactionCollisionScene({ color = '#10B981' }: { color?: string }) {
  const groupRef = useRef<THREE.Group>(null);
  const atomARef = useRef<THREE.Mesh>(null);
  const atomBRef = useRef<THREE.Mesh>(null);
  const sparkRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime * 2.5;
    const distance = Math.abs(Math.sin(t)) * 1.5;

    if (atomARef.current && atomBRef.current) {
      atomARef.current.position.x = -distance;
      atomBRef.current.position.x = distance;
    }
    if (sparkRef.current) {
      const isColliding = distance < 0.25;
      sparkRef.current.scale.setScalar(isColliding ? 1.6 : 0);
    }
    if (groupRef.current) {
      groupRef.current.rotation.y += 0.01;
    }
  });

  return (
    <group ref={groupRef}>
      <mesh ref={atomARef} position={[-1.2, 0, 0]}>
        <sphereGeometry args={[0.35, 24, 24]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.8} />
      </mesh>
      <mesh ref={atomBRef} position={[1.2, 0, 0]}>
        <sphereGeometry args={[0.35, 24, 24]} />
        <meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={0.8} />
      </mesh>
      <mesh ref={sparkRef} position={[0, 0, 0]}>
        <sphereGeometry args={[0.3, 16, 16]} />
        <meshBasicMaterial color="#fef08a" transparent opacity={0.9} />
      </mesh>
    </group>
  );
}

function MainModelRenderer({
  topic,
  isHovered,
  animationType,
}: {
  topic: CurriculumTopic;
  isHovered: boolean;
  animationType?: string;
}) {
  if (animationType === 'particle-system') {
    return (
      <group>
        <AtmosphericParticleField color={topic.fromColor} />
        {topic.modelType === 'globe' ? (
          <GlobeMiniModel isHovered={isHovered} />
        ) : (
          <AtomMiniModel isHovered={isHovered} />
        )}
      </group>
    );
  }

  if (animationType === '3d-reaction') {
    return <ReactionCollisionScene color={topic.fromColor} />;
  }

  switch (topic.modelType) {
    case 'atom':
      return <AtomMiniModel isHovered={isHovered} />;
    case 'h2o':
      return <H2OMiniModel isHovered={isHovered} />;
    case 'beaker':
      return <BeakerMiniModel isHovered={isHovered} color={topic.fromColor} />;
    case 'flame':
      return <FlameMiniModel isHovered={isHovered} />;
    case 'battery':
      return <BatteryMiniModel isHovered={isHovered} />;
    case 'equilibrium':
      return <EquilibriumMiniModel isHovered={isHovered} />;
    case 'organic':
      return <OrganicMiniModel isHovered={isHovered} />;
    case 'flask':
      return <FlaskMiniModel isHovered={isHovered} color={topic.fromColor} />;
    case 'globe':
      return (
        <group>
          <GlobeMiniModel isHovered={isHovered} />
          <AtmosphericParticleField color={topic.fromColor} />
        </group>
      );
    case 'leaf':
      return <LeafMiniModel isHovered={isHovered} />;
    case 'clock':
      return <ClockMiniModel isHovered={isHovered} />;
    case 'balance':
      return <BalanceMiniModel isHovered={isHovered} />;
    case 'thermometer':
      return <ThermometerMiniModel isHovered={isHovered} />;
    case 'factory':
      return <FactoryMiniModel isHovered={isHovered} />;
    default:
      return <AtomMiniModel isHovered={isHovered} />;
  }
}

export default function CurriculumDetailViewer3D({
  topic,
  activeAnimationType,
}: CurriculumDetailViewer3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const controlsRef = useRef<any>(null);
  const [autoRotate, setAutoRotate] = useState(true);

  // Fix 2: Unmount when out of viewport (threshold 0.1)
  const isInViewport = useInViewport(containerRef, 0.1);

  const handleReset = () => {
    if (controlsRef.current) {
      controlsRef.current.reset();
    }
  };

  return (
    <div
      ref={containerRef}
      className="w-full h-full min-h-[380px] lg:min-h-[580px] relative rounded-3xl overflow-hidden bg-white/[0.02] backdrop-blur-2xl border border-white/10 shadow-[0_8px_40px_rgba(34,211,238,0.12)] flex flex-col"
    >
      {/* Top Floating Control Bar */}
      <div className="absolute top-4 left-4 right-4 z-10 flex items-center justify-between pointer-events-none">
        <div className="px-3 py-1.5 rounded-xl bg-slate-950/70 backdrop-blur-md border border-white/10 flex items-center gap-2 pointer-events-auto">
          <span
            className="w-2.5 h-2.5 rounded-full animate-ping"
            style={{ backgroundColor: topic.fromColor }}
          />
          <span className="text-xs font-mono font-bold text-slate-200">
            Model 3D: {topic.title}
          </span>
        </div>

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={() => setAutoRotate(!autoRotate)}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono border transition-all cursor-pointer flex items-center gap-1.5 ${
              autoRotate
                ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                : 'bg-slate-950/70 border-white/10 text-slate-400'
            }`}
            title="Toggle Putaran Otomatis"
          >
            <RotateCw className={`w-3.5 h-3.5 ${autoRotate ? 'animate-spin' : ''}`} style={{ animationDuration: '6s' }} />
            <span className="hidden sm:inline">Rotasi</span>
          </button>

          <button
            onClick={handleReset}
            className="p-2 rounded-xl text-xs border border-white/10 bg-slate-950/70 hover:bg-slate-800 text-slate-300 transition-all cursor-pointer"
            title="Reset Sudut Pandang Kamera"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 3D Canvas / 2D Visual Fallback */}
      <div className="w-full flex-1 relative flex items-center justify-center">
        {!isWebGLAvailable() ? (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center select-none">
            <div
              className="w-36 h-36 rounded-3xl flex items-center justify-center relative shadow-2xl transition-transform hover:scale-105"
              style={{
                background: `radial-gradient(circle, ${topic.fromColor}33 0%, ${topic.toColor}15 100%)`,
                border: `1px solid ${topic.fromColor}40`,
                boxShadow: `0 0 35px ${topic.fromColor}33`,
              }}
            >
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center bg-white/10 backdrop-blur border border-white/20">
                <Sparkles className="w-8 h-8 text-cyan-300 animate-pulse" />
              </div>
            </div>
            <div className="text-base font-bold text-white mt-4 font-mono">{topic.title}</div>
            <div className="text-xs text-slate-400 mt-1 max-w-sm line-clamp-2">{topic.description}</div>
            <div className="mt-3 px-3 py-1 rounded-full text-xs font-mono bg-cyan-950/60 border border-cyan-500/30 text-cyan-300">
              Visualisasi Konsep Kimia SMA
            </div>
          </div>
        ) : (
          <WebGLErrorBoundary
            fallback={
              <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center select-none">
                <div
                  className="w-32 h-32 rounded-3xl flex items-center justify-center relative shadow-2xl"
                  style={{
                    background: `radial-gradient(circle, ${topic.fromColor}33 0%, ${topic.toColor}15 100%)`,
                    border: `1px solid ${topic.fromColor}40`,
                  }}
                >
                  <Sparkles className="w-8 h-8 text-cyan-300" />
                </div>
                <div className="text-sm font-bold text-white mt-3 font-mono">{topic.title}</div>
              </div>
            }
          >
            {isInViewport ? (
              <Suspense fallback={<CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-none" />}>
                <Canvas
                  camera={{ position: [0, 0, 3.6], fov: 45 }}
                  gl={{ antialias: true, alpha: true }}
                  dpr={[1, 1.5]}
                  frameloop={autoRotate ? 'always' : 'demand'}
                >
                  <ambientLight intensity={0.9} />
                  <directionalLight position={[4, 5, 4]} intensity={1.5} color="#ffffff" />
                  <pointLight position={[-4, 3, -3]} intensity={2.2} color={topic.fromColor} />
                  <pointLight position={[4, -3, -3]} intensity={1.8} color={topic.toColor} />
                  <pointLight position={[0, -3, 2]} intensity={1.0} color="#22D3EE" />

                  <OrbitControls
                    ref={controlsRef}
                    enablePan={false}
                    enableZoom={true}
                    minDistance={1.8}
                    maxDistance={6.0}
                    dampingFactor={0.06}
                  />

                  <Float speed={1.5} rotationIntensity={0.15} floatIntensity={0.25}>
                    <Center>
                      <MainModelRenderer
                        topic={topic}
                        isHovered={false}
                        animationType={activeAnimationType}
                      />
                    </Center>
                  </Float>
                </Canvas>
              </Suspense>
            ) : (
              <CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-none" />
            )}
          </WebGLErrorBoundary>
        )}
      </div>

      {/* Bottom Floating Helper */}
      <div className="p-3 bg-slate-950/80 backdrop-blur-md border-t border-white/10 flex items-center justify-between text-xs text-slate-400 font-mono">
        <div className="flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>Klik & geser untuk rotasi 360° • Scroll untuk zoom</span>
        </div>
        <div className="hidden sm:block text-slate-500 text-[11px]">
          Fase: Kelas {topic.grade} SMA
        </div>
      </div>
    </div>
  );
}
