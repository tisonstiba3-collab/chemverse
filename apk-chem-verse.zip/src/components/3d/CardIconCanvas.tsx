import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float } from '@react-three/drei';
import * as THREE from 'three';
import { MenuKey } from '../../types/chemistry';

// 1. Materi Kimia: Rotating Molecule
function Molecule3DIcon({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const ring = useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * (isHovered ? 1.8 : 0.8);
      group.current.rotation.x += delta * (isHovered ? 0.9 : 0.4);
    }
    if (ring.current) {
      ring.current.rotation.z += delta * 1.5;
    }
  });

  return (
    <group ref={group}>
      <mesh>
        <sphereGeometry args={[0.55, 32, 32]} />
        <meshStandardMaterial
          color="#38bdf8"
          emissive="#0284c7"
          emissiveIntensity={isHovered ? 0.8 : 0.4}
          roughness={0.2}
          metalness={0.8}
        />
      </mesh>
      <mesh position={[0.9, 0.4, 0]}>
        <sphereGeometry args={[0.3, 24, 24]} />
        <meshStandardMaterial
          color="#818cf8"
          emissive="#4338ca"
          emissiveIntensity={isHovered ? 0.8 : 0.4}
          roughness={0.3}
        />
      </mesh>
      <mesh position={[-0.8, -0.4, 0.3]}>
        <sphereGeometry args={[0.32, 24, 24]} />
        <meshStandardMaterial
          color="#34d399"
          emissive="#059669"
          emissiveIntensity={isHovered ? 0.8 : 0.4}
          roughness={0.3}
        />
      </mesh>
      <mesh position={[0.45, 0.2, 0]} rotation={[0, 0, Math.PI / 6]}>
        <cylinderGeometry args={[0.08, 0.08, 0.9, 16]} />
        <meshStandardMaterial color="#94a3b8" metalness={0.5} roughness={0.4} />
      </mesh>
      <mesh position={[-0.4, -0.2, 0.15]} rotation={[0, 0, -Math.PI / 4]}>
        <cylinderGeometry args={[0.08, 0.08, 0.8, 16]} />
        <meshStandardMaterial color="#94a3b8" metalness={0.5} roughness={0.4} />
      </mesh>
      <mesh ref={ring} rotation={[Math.PI / 3, 0, 0]}>
        <torusGeometry args={[1.2, 0.02, 16, 64]} />
        <meshBasicMaterial color="#38bdf8" transparent opacity={0.6} />
      </mesh>
    </group>
  );
}

// 2. Latihan Soal: Erlenmeyer Flask
function Beaker3DIcon({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const liquid = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * (isHovered ? 2.0 : 0.8);
    }
    if (liquid.current) {
      liquid.current.position.y = -0.2 + Math.sin(state.clock.elapsedTime * 3) * 0.04;
    }
  });

  return (
    <group ref={group} position={[0, -0.2, 0]}>
      <mesh position={[0, 0.6, 0]}>
        <cylinderGeometry args={[0.2, 0.2, 0.6, 24, 1, true]} />
        <meshPhysicalMaterial
          color="#a7f3d0"
          transmission={0.9}
          roughness={0.1}
          metalness={0.1}
          transparent
          opacity={0.6}
          side={THREE.DoubleSide}
        />
      </mesh>
      <mesh position={[0, -0.1, 0]}>
        <coneGeometry args={[0.8, 1.0, 24, 1, true]} />
        <meshPhysicalMaterial
          color="#a7f3d0"
          transmission={0.9}
          roughness={0.1}
          metalness={0.1}
          transparent
          opacity={0.6}
          side={THREE.DoubleSide}
        />
      </mesh>
      <mesh ref={liquid} position={[0, -0.2, 0]}>
        <coneGeometry args={[0.65, 0.7, 24]} />
        <meshStandardMaterial
          color="#10b981"
          emissive="#047857"
          emissiveIntensity={isHovered ? 1.0 : 0.5}
          roughness={0.2}
          transparent
          opacity={0.85}
        />
      </mesh>
      <mesh position={[0, 0.9, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.22, 0.03, 16, 24]} />
        <meshStandardMaterial color="#6ee7b7" roughness={0.2} metalness={0.3} />
      </mesh>
    </group>
  );
}

// 3. Games Kimia: Periodic Table 3D Cube
function Gamepad3DIcon({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (group.current) {
      group.current.rotation.x += delta * (isHovered ? 1.5 : 0.6);
      group.current.rotation.y += delta * (isHovered ? 2.0 : 0.8);
    }
  });

  return (
    <group ref={group}>
      <mesh>
        <boxGeometry args={[1.1, 1.1, 1.1]} />
        <meshStandardMaterial
          color="#6366f1"
          emissive="#4338ca"
          emissiveIntensity={isHovered ? 0.9 : 0.4}
          roughness={0.3}
          metalness={0.7}
        />
      </mesh>
      <mesh>
        <boxGeometry args={[1.12, 1.12, 1.12]} />
        <meshBasicMaterial color="#a5b4fc" wireframe />
      </mesh>
      <mesh position={[0.7, 0.7, 0.7]}>
        <sphereGeometry args={[0.15, 16, 16]} />
        <meshStandardMaterial color="#f43f5e" emissive="#e11d48" emissiveIntensity={1} />
      </mesh>
      <mesh position={[-0.7, -0.7, -0.7]}>
        <sphereGeometry args={[0.15, 16, 16]} />
        <meshStandardMaterial color="#38bdf8" emissive="#0284c7" emissiveIntensity={1} />
      </mesh>
    </group>
  );
}

// 4. Soal TKA: Concentric Target Rings
function TKA3DIcon({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);
  const ring1 = useRef<THREE.Mesh>(null);
  const ring2 = useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * (isHovered ? 1.6 : 0.7);
    }
    if (ring1.current) ring1.current.rotation.z += delta * (isHovered ? 2.5 : 1.2);
    if (ring2.current) ring2.current.rotation.x += delta * (isHovered ? 2.0 : 1.0);
  });

  return (
    <group ref={group}>
      <mesh>
        <sphereGeometry args={[0.35, 24, 24]} />
        <meshStandardMaterial
          color="#f59e0b"
          emissive="#d97706"
          emissiveIntensity={isHovered ? 1.2 : 0.6}
          roughness={0.2}
          metalness={0.8}
        />
      </mesh>
      <mesh ref={ring1}>
        <torusGeometry args={[0.7, 0.05, 16, 48]} />
        <meshStandardMaterial
          color="#fbbf24"
          emissive="#b45309"
          emissiveIntensity={isHovered ? 0.9 : 0.4}
          roughness={0.3}
          metalness={0.6}
        />
      </mesh>
      <mesh ref={ring2} rotation={[Math.PI / 4, 0, 0]}>
        <torusGeometry args={[1.05, 0.04, 16, 48]} />
        <meshStandardMaterial
          color="#fde68a"
          emissive="#d97706"
          emissiveIntensity={isHovered ? 0.8 : 0.3}
          roughness={0.3}
          metalness={0.5}
        />
      </mesh>
    </group>
  );
}

// 5. Progres: 3D Rising Level Pillars
function Progress3DIcon({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);

  useFrame((state, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * (isHovered ? 1.8 : 0.7);
    }
  });

  return (
    <group ref={group} position={[0, -0.3, 0]}>
      <mesh position={[-0.5, 0.3, 0]}>
        <cylinderGeometry args={[0.18, 0.18, 0.6, 24]} />
        <meshStandardMaterial
          color="#06b6d4"
          emissive="#0891b2"
          emissiveIntensity={0.4}
          metalness={0.6}
        />
      </mesh>
      <mesh position={[0, 0.5, 0]}>
        <cylinderGeometry args={[0.18, 0.18, 1.0, 24]} />
        <meshStandardMaterial
          color="#0ea5e9"
          emissive="#0284c7"
          emissiveIntensity={0.6}
          metalness={0.6}
        />
      </mesh>
      <mesh position={[0.5, 0.75, 0]}>
        <cylinderGeometry args={[0.18, 0.18, 1.5, 24]} />
        <meshStandardMaterial
          color="#38bdf8"
          emissive="#0284c7"
          emissiveIntensity={isHovered ? 1.2 : 0.8}
          metalness={0.7}
        />
      </mesh>
      <mesh position={[0.5, 1.6, 0]}>
        <octahedronGeometry args={[0.2, 0]} />
        <meshStandardMaterial
          color="#facc15"
          emissive="#ca8a04"
          emissiveIntensity={isHovered ? 1.8 : 1.0}
        />
      </mesh>
    </group>
  );
}

// 6. Jurnal: 3D Crystal / Polyhedron Book Marker
function Journal3DIcon({ isHovered }: { isHovered?: boolean }) {
  const group = useRef<THREE.Group>(null);

  useFrame((state, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * (isHovered ? 2.0 : 0.9);
      group.current.position.y = Math.sin(state.clock.elapsedTime * 2) * 0.08;
    }
  });

  return (
    <group ref={group}>
      <mesh>
        <octahedronGeometry args={[0.75, 0]} />
        <meshStandardMaterial
          color="#14b8a6"
          emissive="#0f766e"
          emissiveIntensity={isHovered ? 1.0 : 0.5}
          roughness={0.15}
          metalness={0.7}
        />
      </mesh>
      <mesh>
        <octahedronGeometry args={[0.78, 0]} />
        <meshBasicMaterial color="#5eead4" wireframe />
      </mesh>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[1.05, 0.02, 16, 48]} />
        <meshBasicMaterial color="#2dd4bf" transparent opacity={0.6} />
      </mesh>
    </group>
  );
}

interface CardIconCanvasProps {
  type: MenuKey;
  isHovered?: boolean;
}

export default function CardIconCanvas({ type, isHovered = false }: CardIconCanvasProps) {
  const renderIcon = () => {
    switch (type) {
      case 'materi':
        return <Molecule3DIcon isHovered={isHovered} />;
      case 'latihan':
        return <Beaker3DIcon isHovered={isHovered} />;
      case 'games':
        return <Gamepad3DIcon isHovered={isHovered} />;
      case 'tka':
        return <TKA3DIcon isHovered={isHovered} />;
      case 'progres':
        return <Progress3DIcon isHovered={isHovered} />;
      case 'jurnal':
        return <Journal3DIcon isHovered={isHovered} />;
      default:
        return <Molecule3DIcon isHovered={isHovered} />;
    }
  };

  return (
    <Canvas
      camera={{ position: [0, 0, 3.2], fov: 42 }}
      gl={{ antialias: true, alpha: true }}
      // Fix 3: Set dpr={[1, 1.5]}
      dpr={[1, 1.5]}
      // Fix 1: Only render continuous frames when hovered!
      frameloop={isHovered ? 'always' : 'demand'}
    >
      <ambientLight intensity={0.8} />
      <directionalLight position={[3, 4, 3]} intensity={1.5} color="#ffffff" />
      <pointLight position={[-3, -2, -2]} intensity={1.2} color="#38bdf8" />
      <pointLight position={[2, -2, 2]} intensity={1.0} color="#a855f7" />

      <Float speed={2} rotationIntensity={0.3} floatIntensity={0.4}>
        {renderIcon()}
      </Float>
    </Canvas>
  );
}
