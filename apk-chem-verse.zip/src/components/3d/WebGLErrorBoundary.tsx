import React, { Component, ErrorInfo, ReactNode } from 'react';
import { setWebGLAvailable } from './webglUtils';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class WebGLErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Flag WebGL as unavailable globally so subsequent canvases automatically use 2D fallback
    setWebGLAvailable(false);
    console.warn('[WebGL Fallback] Three.js WebGL context creation failed; gracefully switching to 2D view.', error.message);
    this.props.onError?.(error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback ?? null;
    }
    return this.props.children;
  }
}

export default WebGLErrorBoundary;
