import React, { useState, useRef, useEffect, Suspense, lazy } from 'react';
import gsap from 'gsap';
import {
  Atom,
  School,
  GraduationCap,
  User as UserIcon,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  BookOpen,
  Award,
} from 'lucide-react';
import { User } from 'firebase/auth';
import { StudentProfile } from '../types/chemistry';
import CanvasShimmerSkeleton from './3d/CanvasShimmerSkeleton';

// Lazy load 3D atom canvas for header visual badge
const LazyStudentIdentity3DCanvas = lazy(() => import('./3d/StudentIdentity3DCanvas'));

interface IdentityFormProps {
  currentUser?: User | null;
  onGoogleSignIn?: () => Promise<User | null>;
  onSubmit: (studentData: {
    namaLengkap: string;
    kelas: string;
    sekolah: string;
    role?: 'siswa' | 'guru';
  }) => Promise<void>;
  initialData?: StudentProfile | null;
  isSaving?: boolean;
}

export default function IdentityForm({
  currentUser,
  onSubmit,
  initialData,
  isSaving = false,
}: IdentityFormProps) {
  const isDefaultGuru =
    initialData?.role === 'guru' ||
    currentUser?.email?.toLowerCase().includes('guru') ||
    false;

  const [role, setRole] = useState<'siswa' | 'guru'>(isDefaultGuru ? 'guru' : 'siswa');
  const [namaLengkap, setNamaLengkap] = useState(
    initialData?.namaLengkap || currentUser?.displayName || ''
  );
  const [kelas, setKelas] = useState(initialData?.kelas || '');
  const [sekolah, setSekolah] = useState(initialData?.sekolah || '');
  const [guruUsername, setGuruUsername] = useState('');
  const [guruPassword, setGuruPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  const cardRef = useRef<HTMLDivElement>(null);

  // Smooth, non-moving entrance (no 3D tilt, no mouse tracking)
  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;

    gsap.fromTo(
      card,
      { y: 20, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.6, ease: 'power2.out' }
    );
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!namaLengkap.trim()) {
      setError('Silakan masukkan nama lengkap.');
      return;
    }
    if (!kelas.trim()) {
      setError('Silakan isi tingkat kelas secara manual.');
      return;
    }
    if (!sekolah.trim()) {
      setError('Silakan masukkan nama sekolah / SMA Anda.');
      return;
    }

    if (role === 'guru') {
      if (guruUsername.trim() !== 'kristian son' || guruPassword !== 'Kimia123@') {
        setError('Akses Dashboard Guru Terkunci! Username atau Password Guru Salah.');
        return;
      }
      sessionStorage.setItem('chemverse_guru_unlocked', 'true');
    }

    setError(null);

    try {
      await onSubmit({
        namaLengkap: namaLengkap.trim(),
        kelas: kelas.trim(),
        sekolah: sekolah.trim(),
        role,
      });
    } catch (err: any) {
      setError(err?.message || 'Gagal menyimpan profil identitas. Silakan coba kembali.');
    }
  };

  const handleQuickDemo = () => {
    setNamaLengkap('Ahmad Farhan Pradipta');
    setKelas('Kelas 11 SMA (Fase F)');
    setSekolah('SMAN 1 Bandung');
    setError(null);
  };

  return (
    <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8 sm:py-12">
      {/* Top Header Badge */}
      <div className="mb-5 flex flex-wrap items-center justify-center gap-2.5 px-4 py-2 rounded-2xl bg-slate-900/90 border-2 border-cyan-500/40 backdrop-blur-xl shadow-[0_6px_0_0_#083344] select-none">
        <div className="flex items-center gap-2">
          <Atom className="w-4 h-4 text-cyan-400 animate-spin" style={{ animationDuration: '8s' }} />
          <span className="text-xs font-mono font-black tracking-wider text-cyan-300 uppercase">
            ChemiVerse 3D SMA
          </span>
        </div>
        <span className="text-slate-600 font-bold">•</span>
        <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-400">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Akses Langsung Nama & Kelas</span>
        </div>
      </div>

      {/* Main Solid Stationary Card Container - Completely fixed, no tilting */}
      <div
        ref={cardRef}
        className="w-full max-w-3xl rounded-3xl p-6 sm:p-9 relative text-slate-100 shadow-[0_25px_60px_rgba(8,145,178,0.22),0_12px_0_0_#090d16] border-[3px] border-cyan-500/40 bg-slate-900/95 backdrop-blur-2xl"
      >
        {/* Glow Orbs behind card */}
        <div className="absolute -top-16 -left-16 w-44 h-44 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -right-16 w-44 h-44 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* CARD HEADER */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b-2 border-slate-800/80 pb-5 mb-6">
          <div className="flex items-center gap-4 text-left w-full sm:w-auto">
            {/* Mini Atom Icon Stage */}
            <div className="w-16 h-16 sm:w-18 sm:h-18 rounded-2xl bg-slate-950 border-2 border-cyan-400/50 shadow-[0_5px_0_0_#0f172a] relative overflow-hidden shrink-0 flex items-center justify-center">
              <Suspense
                fallback={
                  <CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-xl" />
                }
              >
                <LazyStudentIdentity3DCanvas isHovered={false} role={role} />
              </Suspense>
              <span className="absolute bottom-1 right-1 text-[9px] font-mono font-black px-1 rounded bg-cyan-500 text-slate-950">
                SMA
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono font-extrabold px-2.5 py-0.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 uppercase tracking-wider">
                  Kartu Identitas Belajar
                </span>
                <span className="text-[11px] font-mono font-bold text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Siap Masuk</span>
                </span>
              </div>
              <h1
                className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1"
                style={{ fontFamily: "'Space Grotesk', sans-serif" }}
              >
                Identitas Siswa Kimia
              </h1>
              <p className="text-xs text-slate-400 font-medium">
                Masukkan nama lengkap, tingkat kelas, dan asal sekolah untuk mulai belajar.
              </p>
            </div>
          </div>
        </div>

        {/* Error Alert if any */}
        {error && (
          <div className="mb-6 p-4 rounded-2xl bg-rose-500/20 border-2 border-rose-500 text-rose-200 text-xs font-bold flex items-center gap-3 shadow-[0_4px_0_0_#881337]">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-400 shrink-0 animate-ping" />
            <span>{error}</span>
          </div>
        )}

        {/* MAIN 2-COLUMN FORM (Solid & Stationary) */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
            {/* ══════════════════════════════════════════════════
                KOLOM KIRI: PERAN & NAMA SISWA
            ══════════════════════════════════════════════════ */}
            <div className="space-y-4 p-5 rounded-2xl bg-slate-950/80 border-2 border-slate-800 shadow-[0_5px_0_0_#0f172a]">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                <span className="text-xs font-mono font-extrabold uppercase text-cyan-400 flex items-center gap-1.5">
                  <UserIcon className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Kolom 1: Peran & Nama</span>
                </span>
                <span className="text-[10px] font-mono font-bold text-slate-400 bg-white/5 px-2 py-0.5 rounded border border-white/10">
                  Wajib Diisi
                </span>
              </div>

              {/* Peran Akun: Siswa atau Guru */}
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-1.5">
                  <GraduationCap className="w-4 h-4 text-cyan-400" />
                  <span>Pilih Peran Akun</span>
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setRole('siswa')}
                    className={`py-3 px-3.5 rounded-xl border-2 text-xs font-black transition cursor-pointer flex items-center justify-center gap-2 select-none active:translate-y-0.5 ${
                      role === 'siswa'
                        ? 'bg-gradient-to-r from-cyan-500/30 to-blue-600/30 border-cyan-400 text-white shadow-[0_4px_0_0_#0e7490] ring-1 ring-cyan-400/50'
                        : 'bg-slate-900/80 border-slate-700/80 text-slate-400 hover:text-white shadow-[0_4px_0_0_#0f172a]'
                    }`}
                  >
                    <UserIcon className="w-4 h-4 text-cyan-400" />
                    <span>Siswa SMA</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRole('guru')}
                    className={`py-3 px-3.5 rounded-xl border-2 text-xs font-black transition cursor-pointer flex items-center justify-center gap-2 select-none active:translate-y-0.5 ${
                      role === 'guru'
                        ? 'bg-gradient-to-r from-indigo-600/30 to-purple-600/30 border-indigo-400 text-white shadow-[0_4px_0_0_#3730a3] ring-1 ring-indigo-400/50'
                        : 'bg-slate-900/80 border-slate-700/80 text-slate-400 hover:text-white shadow-[0_4px_0_0_#0f172a]'
                    }`}
                  >
                    <GraduationCap className="w-4 h-4 text-indigo-400" />
                    <span>Guru / Pendidik</span>
                  </button>
                </div>
              </div>

              {/* Form Input Username & Password Guru if role === 'guru' */}
              {role === 'guru' && (
                <div className="p-3.5 rounded-2xl bg-indigo-950/60 border border-indigo-500/40 space-y-3 animate-fade-in">
                  <div className="flex items-center gap-2 text-xs font-mono font-bold text-indigo-300">
                    <GraduationCap className="w-4 h-4 text-indigo-400" />
                    <span>Otentikasi Dasbor Guru:</span>
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono text-slate-300 mb-1">
                      Username Guru:
                    </label>
                    <input
                      type="text"
                      required
                      value={guruUsername}
                      onChange={(e) => setGuruUsername(e.target.value)}
                      placeholder="Masukkan username guru"
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-indigo-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono text-slate-300 mb-1">
                      Password Guru:
                    </label>
                    <input
                      type="password"
                      required
                      value={guruPassword}
                      onChange={(e) => setGuruPassword(e.target.value)}
                      placeholder="Masukkan password guru"
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-indigo-400"
                    />
                  </div>
                </div>
              )}

              {/* Input Nama Lengkap */}
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <UserIcon className="w-4 h-4 text-cyan-400" />
                  <span>Nama Lengkap {role === 'guru' ? 'Guru' : 'Siswa'}</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={namaLengkap}
                    onChange={(e) => setNamaLengkap(e.target.value)}
                    placeholder="Contoh: Ahmad Farhan Pradipta"
                    className="w-full px-4 py-3.5 rounded-2xl bg-slate-900 border-[2.5px] border-slate-700 text-white placeholder-slate-500 text-sm font-bold shadow-[inset_0_2px_4px_rgba(0,0,0,0.6),0_4px_0_0_#0f172a] focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/30 transition"
                  />
                  <div className="absolute right-3.5 top-1/2 -translate-y-1/2">
                    <span className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-300 font-mono text-xs font-black flex items-center justify-center border border-cyan-400/30">
                      {namaLengkap ? namaLengkap.charAt(0).toUpperCase() : '★'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Info Card Profil */}
              <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 text-xs text-slate-300 flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-mono font-black border border-cyan-400/30 shrink-0">
                  {role === 'guru' ? '👨‍🏫' : '🧪'}
                </div>
                <div className="text-left text-[11px] leading-relaxed">
                  <span className="font-bold text-slate-200 block">
                    {role === 'guru' ? 'Mode Dasbor Pendidik' : 'Mode Belajar Siswa Aktif'}
                  </span>
                  <span className="text-slate-400">
                    {role === 'guru'
                      ? 'Akses materi lengkap, bank soal, dan pemantauan kelas.'
                      : 'Simpan poin XP, lencana kimia, dan riwayat belajar.'}
                  </span>
                </div>
              </div>
            </div>

            {/* ══════════════════════════════════════════════════
                KOLOM KANAN: KELAS & ASAL SEKOLAH
            ══════════════════════════════════════════════════ */}
            <div className="space-y-4 p-5 rounded-2xl bg-slate-950/80 border-2 border-slate-800 shadow-[0_5px_0_0_#0f172a]">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                <span className="text-xs font-mono font-extrabold uppercase text-emerald-400 flex items-center gap-1.5">
                  <School className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Kolom 2: Kelas & Sekolah</span>
                </span>
                <span className="text-[10px] font-mono font-bold text-slate-400 bg-white/5 px-2 py-0.5 rounded border border-white/10">
                  Kurikulum Merdeka
                </span>
              </div>

              {/* Input Tingkat Kelas */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <GraduationCap className="w-4 h-4 text-emerald-400" />
                    <span>Tingkat Kelas SMA</span>
                  </label>
                  <span className="text-[10px] font-mono font-bold text-cyan-300 bg-cyan-500/10 px-2 py-0.5 rounded-lg border border-cyan-500/30">
                    Bisa Diubah
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={kelas}
                    onChange={(e) => setKelas(e.target.value)}
                    placeholder="Contoh: Kelas 11 SMA (Fase F) / 11 IPA 1"
                    className="w-full px-4 py-3.5 rounded-2xl bg-slate-900 border-[2.5px] border-slate-700 text-white placeholder-slate-500 text-sm font-bold shadow-[inset_0_2px_4px_rgba(0,0,0,0.6),0_4px_0_0_#0f172a] focus:outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/30 transition"
                  />
                </div>

                {/* Quick Selection Chips */}
                <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
                  <span className="text-[10px] font-mono text-slate-500 font-bold mr-1">
                    Pilihan Cepat:
                  </span>
                  {[
                    'Kelas 10 SMA (Fase E)',
                    'Kelas 11 SMA (Fase F)',
                    'Kelas 12 SMA (Fase F)',
                    'Persiapan UTBK SNBT',
                  ].map((sug) => {
                    const isSelected = kelas === sug;
                    return (
                      <button
                        key={sug}
                        type="button"
                        onClick={() => setKelas(sug)}
                        className={`px-2.5 py-1 rounded-xl border text-[11px] font-mono font-bold transition cursor-pointer select-none active:translate-y-0.5 ${
                          isSelected
                            ? 'bg-emerald-500/25 border-emerald-400 text-emerald-300 shadow-[0_2px_0_0_#065f46]'
                            : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white hover:border-slate-500'
                        }`}
                      >
                        {sug.replace(' (Fase E)', '').replace(' (Fase F)', '')}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Input Nama Asal Sekolah */}
              <div>
                <label className="block text-xs font-black uppercase tracking-wider text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <School className="w-4 h-4 text-emerald-400" />
                  <span>Nama Asal Sekolah (SMA / MA / SMK)</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={sekolah}
                    onChange={(e) => setSekolah(e.target.value)}
                    placeholder="Contoh: SMAN 1 Bandung / SMA Labschool"
                    className="w-full px-4 py-3.5 rounded-2xl bg-slate-900 border-[2.5px] border-slate-700 text-white placeholder-slate-500 text-sm font-bold shadow-[inset_0_2px_4px_rgba(0,0,0,0.6),0_4px_0_0_#0f172a] focus:outline-none focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/30 transition"
                  />
                  <div className="absolute right-3.5 top-1/2 -translate-y-1/2">
                    <School className="w-4 h-4 text-slate-500" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ══════════════════════════════════════════════════
              TOMBOL MASUK (SUBMIT BESAR, TEBAL, TETAP KOKOH)
          ══════════════════════════════════════════════════ */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSaving}
              className="w-full relative group overflow-hidden py-4 px-8 rounded-2xl font-black text-base sm:text-lg tracking-wide text-slate-950 bg-gradient-to-r from-cyan-400 via-sky-300 to-teal-300 border-2 border-cyan-200 border-b-[6px] border-b-cyan-700 shadow-[0_8px_0_0_#0e7490,0_16px_30px_rgba(34,211,238,0.3)] flex items-center justify-center gap-3 cursor-pointer transition-all active:translate-y-1 active:shadow-[0_2px_0_0_#0e7490] disabled:opacity-60 disabled:cursor-not-allowed select-none"
            >
              <Sparkles className="w-5 h-5 text-slate-950" />
              <span>
                {isSaving
                  ? 'Menyimpan Profil...'
                  : 'Masuk & Mulai Belajar Kimia'}
              </span>
              <ArrowRight className="w-5 h-5 text-slate-950 transition-transform group-hover:translate-x-1.5" />
            </button>
          </div>
        </form>

        {/* Quick Demo Pre-fill Helper */}
        <div className="mt-6 pt-4 border-t-2 border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
          <span className="flex items-center gap-1.5 text-slate-400 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Login langsung menggunakan Nama, Kelas, dan Nama Sekolah</span>
          </span>
          <button
            type="button"
            onClick={handleQuickDemo}
            className="text-cyan-400 hover:text-cyan-300 font-bold underline underline-offset-4 cursor-pointer"
          >
            Isi Contoh Otomatis Cepat
          </button>
        </div>
      </div>

      {/* Bottom Feature Badges */}
      <div className="mt-8 flex flex-wrap items-center justify-center gap-3 text-xs font-mono text-slate-400">
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
          <span>Kurikulum Kimia SMA</span>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <Atom className="w-3.5 h-3.5 text-purple-400" />
          <span>Struktur Atom 3D</span>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <Award className="w-3.5 h-3.5 text-amber-400" />
          <span>Sistem Poin & Lencana</span>
        </div>
      </div>
    </div>
  );
}
