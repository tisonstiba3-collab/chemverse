import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  X,
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  Bot,
  User as UserIcon,
  RotateCcw,
  Maximize2,
  Minimize2,
  Loader2,
  GraduationCap,
  Atom,
  Play,
  Square,
  CheckCircle2,
  HelpCircle,
  Lightbulb,
  Camera,
  Image as ImageIcon,
  AlertCircle,
  Zap,
} from 'lucide-react';
import { StudentProfile } from '../../types/chemistry';

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  spokenText?: string;
  timestamp: string;
  audioBase64?: string;
  imageDataUrl?: string;
}

interface TutorChatBoxProps {
  student: StudentProfile;
  isLightweight?: boolean;
}

const QUICK_PROMPTS = [
  { label: 'pH Asam Kuat', prompt: 'Hitung pH larutan 0,01 M HCl secara cepat' },
  { label: 'Setarakan Reaksi', prompt: 'Setarakan reaksi: C₃H₈(g) + O₂(g) → CO₂(g) + H₂O(l)' },
  { label: 'Massa Molar & Mol', prompt: 'Hitung massa 0,5 mol H₂SO₄ jika Ar H=1, S=32, O=16' },
  { label: 'Tata Nama Kimia', prompt: 'Tentukan nama IUPAC dari senyawa FeCl₃ dan CH₃CH₂OH' },
  { label: 'Sel Volta E°', prompt: 'Bagaimana cara cepat menentukan katoda dan anoda dari nilai E°?' },
  { label: 'Konfigurasi Subkulit', prompt: 'Tuliskan konfigurasi elektron subkulit atom ₂₆Fe' },
];

export default function TutorChatBox({ student, isLightweight = true }: TutorChatBoxProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const [isPromptLightweight, setIsPromptLightweight] = useState<boolean>(() => isLightweight ?? true);

  // Sync lightweight mode when updated from parent
  useEffect(() => {
    if (isLightweight !== undefined) {
      setIsPromptLightweight(isLightweight);
    }
  }, [isLightweight]);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'model',
      text: `🎯 **Inti Jawaban:** Halo ${student.namaLengkap}! Kak Kimi (Tutor Kimia SMA) siap membantumu memecahkan soal kimia secara cepat, teliti, dan bersuara.

📐 **Langkah Penyelesaian:**
   1. Ketik soal atau gunakan tombol mikrofon untuk bertanya dengan suara.
   2. Kak Kimi akan jelaskan langkah demi langkah sesuai standar resmi IUPAC.
   3. Setiap penjelasan langsung disertai suara ramah otomatis.

✅ **Hasil Akhir:** **Belajar Kimia Lebih Jelas & Menyenangkan!**
💡 **Catatan/Tips:** Tanyakan rumus stoikiometri, pH asam-basa, sel volta, laju reaksi, atau tata nama organik.
❓ **Cek Pemahaman:** Soal atau konsep kimia apa yang sedang ingin kamu bahas sekarang?

🔊 **Narasi Suara:**
> "Hai, Kak Kimi di sini. Selamat datang di sesi belajar kimia SMA. Ada soal atau materi yang ingin kamu tanyakan hari ini? Tulis atau gunakan mikrofon, Kak Kimi siap menjelaskan lengkap dengan suara dan langkah yang jelas. Kamu pasti bisa!"`,
      spokenText:
        'Hai, Kak Kimi di sini. Selamat datang di sesi belajar kimia SMA. Ada soal atau materi yang ingin kamu tanyakan hari ini? Tulis atau gunakan mikrofon, Kak Kimi siap menjelaskan lengkap dengan suara dan langkah yang jelas. Kamu pasti bisa!',
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [currentlyPlayingMsgId, setCurrentlyPlayingMsgId] = useState<string | null>(null);

  // 1. UPLOAD FOTO SOAL (OCR + AI SOLVER) States
  const [selectedImage, setSelectedImage] = useState<{
    dataUrl: string;
    mimeType: string;
    name: string;
    sizeKb: number;
  } | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Auto-scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  // Listen to open-tutor-chat event from any part of the app
  useEffect(() => {
    const handleOpenChat = (event: Event) => {
      const customEvent = event as CustomEvent<{ prompt?: string; autoSend?: boolean; message?: string }>;
      setIsOpen(true);
      const promptText = customEvent.detail?.prompt || customEvent.detail?.message;
      if (promptText) {
        setInputMessage(promptText);
        if (customEvent.detail?.autoSend) {
          handleSendMessage(promptText);
        }
      }
    };

    window.addEventListener('open-tutor-chat', handleOpenChat);
    window.addEventListener('CHEMIVERSE_OPEN_TUTOR_CHAT', handleOpenChat);
    return () => {
      window.removeEventListener('open-tutor-chat', handleOpenChat);
      window.removeEventListener('CHEMIVERSE_OPEN_TUTOR_CHAT', handleOpenChat);
    };
  }, [messages, student]);

  // Setup Browser Speech Recognition for Indonesian voice interaction
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'id-ID';

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInputMessage(transcript);
          handleSendMessage(transcript);
        }
        setIsListening(false);
      };

      recognition.onerror = (err: any) => {
        console.warn('Speech recognition error:', err);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  // Helper to pick best Indonesian voice from browser
  const getIndonesianVoice = (): SpeechSynthesisVoice | null => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return null;
    const voices = window.speechSynthesis.getVoices();
    // Prefer female Indonesian voice
    const idFemale = voices.find(
      (v) =>
        v.lang.toLowerCase().startsWith('id') &&
        (v.name.toLowerCase().includes('female') ||
          v.name.toLowerCase().includes('gadis') ||
          v.name.toLowerCase().includes('damayanti') ||
          v.name.toLowerCase().includes('google') ||
          v.name.toLowerCase().includes('siti'))
    );
    if (idFemale) return idFemale;
    // Any Indonesian voice
    const idVoice = voices.find((v) => v.lang.toLowerCase().startsWith('id'));
    if (idVoice) return idVoice;
    return null;
  };

  // Extract spoken text from response blockquote if present
  const extractVoiceNarrative = (rawText: string, fallbackSpoken?: string): string => {
    if (fallbackSpoken && fallbackSpoken.trim().length > 0) {
      return fallbackSpoken;
    }
    const voiceIdx = rawText.indexOf('🔊');
    if (voiceIdx !== -1) {
      const voiceSubstring = rawText.slice(voiceIdx);
      const quoteMatch = voiceSubstring.match(/["“]([^"”]+)["”]/);
      if (quoteMatch && quoteMatch[1]) {
        return quoteMatch[1].trim();
      }
      const lines = voiceSubstring.split('\n').filter((l) => l.trim().startsWith('>'));
      if (lines.length > 0) {
        return lines.map((l) => l.replace(/^>\s*/, '').replace(/["“”]/g, '')).join(' ').trim();
      }
    }
    return rawText
      .replace(/🎯|📐|✅|💡|❓|🔊|\*\*|__|```[\s\S]*?```/g, '')
      .replace(/\n+/g, ' ')
      .slice(0, 300);
  };

  // Voice output playback: Gemini TTS with browser synthesis fallback
  const playVoiceResponse = async (text: string, msgId?: string, existingAudio?: string) => {
    if (!voiceEnabled) return;

    // Stop currently playing audio or speech
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    setCurrentlyPlayingMsgId(msgId || null);

    const voiceScript = extractVoiceNarrative(text);

    try {
      let base64 = existingAudio;

      // Try Gemini TTS endpoint first if no pre-generated audio
      if (!base64) {
        try {
          const res = await fetch('/api/tutor/tts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: voiceScript.slice(0, 400) }),
          });
          if (res.ok) {
            const data = await res.json();
            if (data.audio) {
              base64 = data.audio;
            }
          }
        } catch {
          // Fall through to browser Web Speech API
        }
      }

      if (base64) {
        const audio = new Audio(`data:audio/wav;base64,${base64}`);
        currentAudioRef.current = audio;
        setIsPlayingAudio(true);
        audio.onended = () => {
          setIsPlayingAudio(false);
          setCurrentlyPlayingMsgId(null);
        };
        audio.onerror = () => {
          setIsPlayingAudio(false);
          setCurrentlyPlayingMsgId(null);
        };
        await audio.play();
      } else if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        // Fallback: Web Speech API synthesis in Indonesian with Kak Kimi persona parameters
        const utterance = new SpeechSynthesisUtterance(voiceScript);
        utterance.lang = 'id-ID';
        utterance.rate = 1.05; // agak cepat, tidak membosankan (1.0 - 1.1)
        utterance.pitch = 1.0; // netral, ramah
        utterance.volume = 1.0;

        const bestVoice = getIndonesianVoice();
        if (bestVoice) {
          utterance.voice = bestVoice;
        }

        utterance.onstart = () => setIsPlayingAudio(true);
        utterance.onend = () => {
          setIsPlayingAudio(false);
          setCurrentlyPlayingMsgId(null);
        };
        utterance.onerror = () => {
          setIsPlayingAudio(false);
          setCurrentlyPlayingMsgId(null);
        };

        window.speechSynthesis.speak(utterance);
      }
    } catch (e) {
      console.warn('Voice playback failed:', e);
      setIsPlayingAudio(false);
      setCurrentlyPlayingMsgId(null);
    }
  };

  const handleStopAudio = () => {
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlayingAudio(false);
    setCurrentlyPlayingMsgId(null);
  };

  const handleToggleListening = () => {
    if (!recognitionRef.current) {
      alert('Browser Anda tidak mendukung pengenalan suara langsung.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        setIsListening(true);
        recognitionRef.current.start();
      } catch (err) {
        setIsListening(false);
      }
    }
  };

  // Trigger file picker
  const handleTriggerUpload = () => {
    setUploadError(null);
    fileInputRef.current?.click();
  };

  // Handle image file selection & Base64 conversion via FileReader with size validation (<5MB)
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file size (max 5MB)
    const maxSizeBytes = 5 * 1024 * 1024;
    if (file.size > maxSizeBytes) {
      setUploadError('Ukuran file foto melebihi batas 5MB. Silakan pilih foto dengan resolusi lebih kecil.');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    setUploadError(null);
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setSelectedImage({
        dataUrl: result,
        mimeType: file.type || 'image/jpeg',
        name: file.name,
        sizeKb: Math.round(file.size / 1024),
      });
    };
    reader.onerror = () => {
      setUploadError('Gagal membaca file gambar. Silakan coba unggah kembali.');
    };
    reader.readAsDataURL(file);

    // Reset input value so user can re-select the same image if needed
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend !== undefined ? textToSend : inputMessage;
    const hasImage = !!selectedImage;
    if ((!text.trim() && !hasImage) || isLoading) return;

    // Stop current speech before sending new question
    handleStopAudio();

    const imageToSend = selectedImage;
    setSelectedImage(null);
    setUploadError(null);

    // Default instruction when photo is sent without extra text
    const defaultImagePrompt = 'Baca teks soal dari gambar ini. Jangan berikan jawaban akhir, tapi berikan langkah-langkah atau petunjuk pengerjaannya.';
    const effectiveText = text.trim() || (imageToSend ? defaultImagePrompt : '');

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: effectiveText,
      imageDataUrl: imageToSend?.dataUrl,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/tutor/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: effectiveText,
          history: messages.map((m) => ({ role: m.role, text: m.text })),
          studentName: student.namaLengkap,
          grade: student.kelas,
          isLightweight: isPromptLightweight,
          image: imageToSend
            ? {
                data: imageToSend.dataUrl,
                mimeType: imageToSend.mimeType,
              }
            : undefined,
        }),
      });

      if (!response.ok) {
        throw new Error('Gagal mendapatkan respon dari server.');
      }

      const data = await response.json();
      const replyText = data.reply || 'Maaf, saya tidak dapat merespons saat ini.';
      const spokenText = data.spokenText || extractVoiceNarrative(replyText);

      const msgId = `tutor-${Date.now()}`;
      const tutorMsg: Message = {
        id: msgId,
        role: 'model',
        text: replyText,
        spokenText,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, tutorMsg]);

      // WAJIB AKTIF: Putar narasi suara otomatis saat respons tiba!
      if (voiceEnabled) {
        playVoiceResponse(replyText, msgId);
      }
    } catch (error: any) {
      const errId = `err-${Date.now()}`;
      setMessages((prev) => [
        ...prev,
        {
          id: errId,
          role: 'model',
          text: `⚠️ Maaf ${student.namaLengkap}, terjadi sedikit kendala koneksi ke server tutor. Silakan kirim kembali pertanyaanmu ya!\n\n🔊 **Narasi Suara:**\n> "Hai, Kak Kimi di sini. Maaf, ada kendala jaringan singkat. Silakan kirim ulang pertanyaanmu ya. Kamu pasti bisa!"`,
          spokenText: 'Hai, Kak Kimi di sini. Maaf, ada kendala jaringan singkat. Silakan kirim ulang pertanyaanmu ya. Kamu pasti bisa!',
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearChat = () => {
    handleStopAudio();
    setMessages([
      {
        id: 'welcome-reset',
        role: 'model',
        text: `🎯 **Inti Jawaban:** Percakapan baru telah dimulai, ${student.namaLengkap}! Kak Kimi siap menjawab pertanyaan kimia selanjutnya.\n\n❓ **Cek Pemahaman:** Konsep atau soal mana yang ingin kamu bahas sekarang?\n\n🔊 **Narasi Suara:**\n> "Hai, Kak Kimi di sini. Percakapan baru telah dimulai. Silakan ajukan soal atau pertanyaan kimia berikutnya ya!"`,
        spokenText: 'Hai, Kak Kimi di sini. Percakapan baru telah dimulai. Silakan ajukan soal atau pertanyaan kimia berikutnya ya!',
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  // Helper to render formatted response sections (IUPAC, steps, formulas, voice card)
  const renderFormattedText = (raw: string, msgId: string, spokenText?: string) => {
    // Split into lines
    const lines = raw.split('\n');
    let isInVoiceBlock = false;
    const voiceQuoteLines: string[] = [];

    const renderedNodes: React.ReactNode[] = [];

    lines.forEach((line, idx) => {
      const trimmed = line.trim();

      // Detect start of voice narrative block
      if (trimmed.includes('🔊 **Narasi Suara:**') || trimmed.startsWith('🔊 Narasi Suara:')) {
        isInVoiceBlock = true;
        return;
      }

      if (isInVoiceBlock) {
        if (trimmed.startsWith('>') || trimmed.startsWith('"') || trimmed.length > 0) {
          voiceQuoteLines.push(trimmed.replace(/^>\s*/, '').replace(/["“”]/g, ''));
        }
        return;
      }

      // Special highlight for standard sections
      if (trimmed.startsWith('🎯 **Inti Jawaban:**') || trimmed.startsWith('🎯 **Inti:**')) {
        renderedNodes.push(
          <div key={`section-${idx}`} className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-200 font-medium my-1.5 flex items-start gap-2">
            <span className="text-sm">🎯</span>
            <div>
              <strong className="text-cyan-300 font-bold block text-[11px] uppercase tracking-wider font-mono">
                Inti Jawaban
              </strong>
              <span className="text-xs sm:text-sm text-slate-100">
                {trimmed.replace(/^🎯\s*\*\*(?:Inti Jawaban:|Inti:)\*\*\s*/, '')}
              </span>
            </div>
          </div>
        );
        return;
      }

      if (trimmed.startsWith('📐 **Langkah Penyelesaian:**') || trimmed.startsWith('📐 **Langkah:**')) {
        renderedNodes.push(
          <div key={`section-${idx}`} className="text-sky-300 font-bold text-xs uppercase tracking-wider font-mono pt-2 flex items-center gap-1.5">
            <span>📐</span>
            <span>Langkah Penyelesaian (IUPAC):</span>
          </div>
        );
        return;
      }

      if (trimmed.startsWith('✅ **Hasil Akhir:**') || trimmed.startsWith('✅ **Hasil:**')) {
        renderedNodes.push(
          <div key={`section-${idx}`} className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-200 font-semibold my-1.5 flex items-start gap-2">
            <span className="text-sm">✅</span>
            <div>
              <strong className="text-emerald-300 font-bold block text-[11px] uppercase tracking-wider font-mono">
                Hasil Akhir
              </strong>
              <span className="text-xs sm:text-sm font-bold text-emerald-100">
                {trimmed.replace(/^✅\s*\*\*(?:Hasil Akhir:|Hasil:)\*\*\s*/, '')}
              </span>
            </div>
          </div>
        );
        return;
      }

      if (trimmed.startsWith('💡 **Catatan/Tips:**') || trimmed.startsWith('💡 **Tips:**')) {
        renderedNodes.push(
          <div key={`section-${idx}`} className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs my-1.5 flex items-start gap-2">
            <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-amber-300 font-bold block text-[10px] uppercase tracking-wider font-mono">
                Catatan & Tips Kilat
              </strong>
              <span>
                {trimmed.replace(/^💡\s*\*\*(?:Catatan\/Tips:|Tips:)\*\*\s*/, '')}
              </span>
            </div>
          </div>
        );
        return;
      }

      if (trimmed.startsWith('❓ **Cek Pemahaman:**') || trimmed.startsWith('❓ **Cek:**')) {
        renderedNodes.push(
          <div key={`section-${idx}`} className="p-2.5 rounded-xl bg-violet-500/10 border border-violet-500/30 text-violet-200 text-xs my-1.5 flex items-start gap-2">
            <HelpCircle className="w-4 h-4 text-violet-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-violet-300 font-bold block text-[10px] uppercase tracking-wider font-mono">
                Cek Pemahaman Kamu
              </strong>
              <span>
                {trimmed.replace(/^❓\s*\*\*(?:Cek Pemahaman:|Cek:)\*\*\s*/, '')}
              </span>
            </div>
          </div>
        );
        return;
      }

      // Step numbered item
      const stepMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
      if (stepMatch) {
        renderedNodes.push(
          <div key={`step-${idx}`} className="flex items-start gap-2 text-xs sm:text-sm py-0.5 pl-1">
            <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[10px] font-mono font-bold flex items-center justify-center shrink-0 mt-0.5">
              {stepMatch[1]}
            </span>
            <div className="flex-1 text-slate-200 leading-relaxed">
              {renderInlineBold(stepMatch[2])}
            </div>
          </div>
        );
        return;
      }

      // Standard text with inline formatting
      if (trimmed.length > 0) {
        renderedNodes.push(
          <p key={`p-${idx}`} className="text-xs sm:text-sm leading-relaxed text-slate-200">
            {renderInlineBold(line)}
          </p>
        );
      } else {
        renderedNodes.push(<div key={`sp-${idx}`} className="h-1.5" />);
      }
    });

    // Voice Narrative Card
    const fullVoiceScript = voiceQuoteLines.join(' ') || spokenText;
    const isThisPlaying = isPlayingAudio && currentlyPlayingMsgId === msgId;

    if (fullVoiceScript && fullVoiceScript.trim().length > 0) {
      renderedNodes.push(
        <div
          key="voice-card"
          className="mt-3 p-3 rounded-2xl bg-gradient-to-r from-cyan-950/70 via-slate-900 to-indigo-950/70 border border-cyan-500/30 space-y-2 shadow-inner"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center justify-center text-xs">
                🔊
              </span>
              <span className="text-[11px] font-mono font-bold text-cyan-300 uppercase tracking-wider">
                Narasi Suara Kak Kimi
              </span>
            </div>

            {/* Play/Stop Button */}
            <button
              type="button"
              onClick={() => {
                if (isThisPlaying) {
                  handleStopAudio();
                } else {
                  playVoiceResponse(raw, msgId);
                }
              }}
              className={`px-2.5 py-1 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition cursor-pointer ${
                isThisPlaying
                  ? 'bg-rose-500/20 border border-rose-500/40 text-rose-300 hover:bg-rose-500/30'
                  : 'bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/30'
              }`}
            >
              {isThisPlaying ? (
                <>
                  <Square className="w-3 h-3 fill-rose-300" />
                  <span>Hentikan</span>
                </>
              ) : (
                <>
                  <Play className="w-3 h-3 fill-cyan-300" />
                  <span>Putar Suara</span>
                </>
              )}
            </button>
          </div>

          {/* Equalizer animation when speaking */}
          {isThisPlaying && (
            <div className="flex items-center gap-1.5 py-1 px-2 rounded-lg bg-cyan-500/10 text-[10px] font-mono text-cyan-300">
              <span className="w-1.5 h-3 bg-cyan-400 animate-pulse" />
              <span className="w-1.5 h-4 bg-cyan-400 animate-pulse" style={{ animationDelay: '150ms' }} />
              <span className="w-1.5 h-2 bg-cyan-400 animate-pulse" style={{ animationDelay: '300ms' }} />
              <span className="w-1.5 h-5 bg-cyan-400 animate-pulse" style={{ animationDelay: '200ms' }} />
              <span className="ml-1">Sedang membacakan penjelasan Kak Kimi...</span>
            </div>
          )}

          {/* Transcript Quote */}
          <blockquote className="text-[11px] text-slate-300 italic border-l-2 border-cyan-400/50 pl-2 leading-relaxed">
            "{fullVoiceScript}"
          </blockquote>
        </div>
      );
    }

    return renderedNodes;
  };

  // Helper for inline bold tags
  const renderInlineBold = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, idx) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={idx} className="font-bold text-cyan-300">
            {part.slice(2, -2)}
          </strong>
        );
      }
      return part;
    });
  };

  return (
    <>
      {/* Floating Trigger Button (Bottom-Right, above mobile navigation bar on phones) */}
      {!isOpen && (
        <div className="fixed bottom-20 right-3 sm:bottom-6 sm:right-6 z-40 animate-bounce-subtle">
          <button
            onClick={() => setIsOpen(true)}
            className="group relative flex items-center gap-2 sm:gap-3 px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-full bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 text-white font-bold shadow-xl shadow-cyan-500/30 hover:shadow-cyan-500/50 hover:scale-105 transition-all duration-300 cursor-pointer border border-cyan-300/40"
            aria-label="Buka Tanya Tutor Kimia"
          >
            <div className="relative">
              <div className="w-6 h-6 rounded-full bg-slate-950 flex items-center justify-center text-cyan-400 font-mono text-xs font-bold">
                ⚗️
              </div>
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-slate-900" />
            </div>
            <div className="text-left hidden sm:block">
              <span className="text-sm font-extrabold tracking-tight block">Tanya Kak Kimi</span>
              <span className="text-[10px] font-mono text-cyan-200 block">Tutor Kimia SMA Bersuara</span>
            </div>
            <span className="text-xs font-bold sm:hidden">Tanya AI</span>
            <span className="px-2 py-0.5 rounded-full bg-black/30 text-[10px] font-mono text-cyan-200 border border-white/10 hidden sm:inline">
              🔊 TTS
            </span>
          </button>
        </div>
      )}

      {/* Floating Chat Modal Box */}
      {isOpen && (
        <div
          className={`fixed inset-x-2 bottom-2 sm:bottom-6 sm:right-6 sm:inset-x-auto z-50 flex flex-col rounded-3xl bg-slate-950/95 border border-cyan-500/30 backdrop-blur-2xl shadow-2xl shadow-cyan-950/90 transition-all duration-300 overflow-hidden ${
            isExpanded
              ? 'w-auto sm:w-[calc(100vw-3rem)] max-w-2xl h-[88vh] sm:h-[84vh]'
              : 'w-auto sm:w-[440px] h-[82vh] sm:h-[600px]'
          }`}
        >
          {/* Header as requested: "Kak Kimi (Tutor Kimia)" */}
          <div className="p-4 bg-gradient-to-r from-slate-900 via-slate-900/90 to-cyan-950/70 border-b border-slate-800 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 shadow-md shadow-cyan-500/20">
                  <div className="w-full h-full rounded-[14px] bg-slate-950 flex items-center justify-center text-cyan-300 font-bold text-sm">
                    {isPlayingAudio ? (
                      <Volume2 className="w-5 h-5 text-cyan-400 animate-pulse" />
                    ) : (
                      '⚗️'
                    )}
                  </div>
                </div>
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-slate-950" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
                  <span>Kak Kimi (Tutor Kimia)</span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono text-[9px] font-bold border border-emerald-500/30">
                    IUPAC & TTS
                  </span>
                </h3>
                <p className="text-[11px] text-slate-400 flex items-center gap-1 font-normal">
                  <GraduationCap className="w-3 h-3 text-cyan-400" />
                  Guru & Mentor Kimia SMA Indonesia • Selalu Bersuara
                </p>
              </div>
            </div>

            {/* Header Controls */}
            <div className="flex items-center gap-1.5">
              {/* Mode Prompt Ringan (Prompt Kilat & Hemat Data/CPU) */}
              <button
                onClick={() => setIsPromptLightweight((prev) => !prev)}
                className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-mono font-bold flex items-center gap-1.5 transition cursor-pointer select-none ${
                  isPromptLightweight
                    ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 shadow-sm shadow-emerald-500/20'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
                title={
                  isPromptLightweight
                    ? 'Mode Prompt Ringan AKTIF: Format padat, token hemat, respon super cepat < 1 detik'
                    : 'Klik untuk mengaktifkan Mode Prompt Ringan (Hemat Kuota & Lebih Cepat)'
                }
              >
                <Zap className={`w-3.5 h-3.5 ${isPromptLightweight ? 'text-emerald-400 fill-emerald-400' : 'text-slate-400'}`} />
                <span className="hidden sm:inline">
                  {isPromptLightweight ? 'Prompt Kilat' : 'Standar'}
                </span>
              </button>

              {/* Voice toggle */}
              <button
                onClick={() => {
                  const nextVal = !voiceEnabled;
                  setVoiceEnabled(nextVal);
                  if (!nextVal) {
                    handleStopAudio();
                  }
                }}
                className={`p-2 rounded-xl transition cursor-pointer border ${
                  voiceEnabled
                    ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                    : 'bg-slate-900 border-slate-800 text-slate-500'
                }`}
                title={voiceEnabled ? 'Suara Narasi Otomatis: AKTIF' : 'Suara Narasi: NONAKTIF (Hening)'}
              >
                {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>

              {/* Expand / Minimize */}
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition cursor-pointer hidden sm:block"
                title={isExpanded ? 'Kecilkan Chat' : 'Perbesar Chat'}
              >
                {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>

              {/* Clear */}
              <button
                onClick={handleClearChat}
                className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
                title="Mulai Percakapan Baru"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              {/* Close */}
              <button
                onClick={() => {
                  setIsOpen(false);
                  handleStopAudio();
                }}
                className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-rose-400 transition cursor-pointer"
                title="Tutup Chat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Mode Ringan Prompt Info Banner */}
          {isPromptLightweight && (
            <div className="px-4 py-1.5 bg-emerald-950/40 border-b border-emerald-500/30 text-[11px] text-emerald-300 flex items-center justify-between shrink-0 font-mono shadow-inner">
              <span className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400 shrink-0" />
                <span>Mode Prompt Ringan: Jawaban padat to-the-point, hemat token & CPU</span>
              </span>
              <span className="text-[10px] text-emerald-400/90 bg-emerald-500/15 px-1.5 py-0.5 rounded border border-emerald-500/25">
                Ultra-Cepat
              </span>
            </div>
          )}

          {/* Voice Interaction Notice Banner when speaking */}
          {isPlayingAudio && (
            <div className="px-4 py-2 bg-gradient-to-r from-cyan-950 via-slate-900 to-indigo-950 border-b border-cyan-800/60 text-xs text-cyan-300 flex items-center justify-between shrink-0 font-mono shadow-sm">
              <span className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 animate-bounce text-cyan-400" />
                <span>Kak Kimi sedang menjelaskan suara...</span>
              </span>
              <button
                onClick={handleStopAudio}
                className="px-2 py-0.5 rounded-lg bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 text-[11px] font-bold cursor-pointer transition border border-rose-500/30"
              >
                Hentikan Suara
              </button>
            </div>
          )}

          {/* Messages Scroll Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4">
            {messages.map((msg) => {
              const isTutor = msg.role === 'model';
              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${isTutor ? 'items-start' : 'items-start flex-row-reverse'}`}
                >
                  {/* Avatar */}
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border text-xs font-bold ${
                      isTutor
                        ? 'bg-cyan-500/20 border-cyan-400/40 text-cyan-300'
                        : 'bg-indigo-600/30 border-indigo-500/40 text-indigo-300'
                    }`}
                  >
                    {isTutor ? '⚗️' : student.namaLengkap.charAt(0)}
                  </div>

                  {/* Bubble */}
                  <div
                    className={`max-w-[88%] rounded-2xl p-3.5 space-y-2 text-xs sm:text-sm leading-relaxed ${
                      isTutor
                        ? 'bg-slate-900/90 border border-slate-800 text-slate-200'
                        : 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-medium shadow-md shadow-cyan-900/40'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3 text-[10px] opacity-70 mb-1 font-mono">
                      <span>{isTutor ? 'Kak Kimi (Tutor Kimia)' : student.namaLengkap}</span>
                      <span>{msg.timestamp}</span>
                    </div>

                    {/* 1. UPLOAD FOTO SOAL: Render photo preview if user uploaded an image */}
                    {msg.imageDataUrl && (
                      <div className="my-2 rounded-xl overflow-hidden border border-white/20 bg-slate-950/80 shadow-md">
                        <img
                          src={msg.imageDataUrl}
                          alt="Foto Soal Kimia"
                          className="w-full max-h-60 object-contain rounded-t-xl bg-black/60"
                        />
                        <div className="px-2.5 py-1.5 text-[10px] font-mono text-cyan-200 flex items-center gap-1.5 bg-slate-950/90 border-t border-white/10">
                          <Camera className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                          <span className="font-semibold">Foto Soal Kimia Terlampir (OCR & Langkah Pengerjaan)</span>
                        </div>
                      </div>
                    )}

                    <div className="space-y-1">
                      {isTutor ? renderFormattedText(msg.text, msg.id, msg.spokenText) : (
                        <p className="whitespace-pre-wrap">{msg.text}</p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shrink-0">
                  <Bot className="w-4 h-4 animate-spin" />
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center gap-2 text-xs text-cyan-300">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Kak Kimi sedang menganalisis soal & menyusun petunjuk bertahap...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Suggested Quick Prompt Pills */}
          <div className="px-4 py-2 bg-slate-950/60 border-t border-slate-800/80 overflow-x-auto flex items-center gap-2 scrollbar-none shrink-0">
            <span className="text-[10px] font-mono text-slate-400 uppercase shrink-0 flex items-center gap-1">
              <Zap className="w-3 h-3 text-cyan-400" />
              <span>Prompt Cepat:</span>
            </span>
            {QUICK_PROMPTS.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(item.prompt)}
                disabled={isLoading}
                title={item.prompt}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[11px] text-slate-300 hover:text-cyan-300 whitespace-nowrap transition cursor-pointer shrink-0 disabled:opacity-50 font-medium"
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Voice Listening Feedback */}
          {isListening && (
            <div className="px-4 py-2 bg-rose-500/20 border-t border-rose-500/40 text-rose-300 text-xs flex items-center justify-between shrink-0 animate-pulse">
              <span className="flex items-center gap-2 font-mono">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                Mendengarkan suaramu... Katakan soal atau pertanyaan kimiamu!
              </span>
              <button
                onClick={handleToggleListening}
                className="font-bold underline text-xs cursor-pointer"
              >
                Selesai
              </button>
            </div>
          )}

          {/* Upload Error Alert */}
          {uploadError && (
            <div className="px-3 py-2 bg-rose-500/15 border-t border-rose-500/30 text-rose-300 text-xs flex items-center justify-between shrink-0 font-mono">
              <span className="flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                <span>{uploadError}</span>
              </span>
              <button
                type="button"
                onClick={() => setUploadError(null)}
                className="text-rose-400 hover:text-rose-200 cursor-pointer ml-2"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* 1. UPLOAD FOTO SOAL: Selected Image Preview Bar before sending */}
          {selectedImage && (
            <div className="px-3 py-2 bg-slate-950/95 border-t border-cyan-500/40 flex items-center justify-between gap-2 shrink-0 animate-fadeIn">
              <div className="flex items-center gap-2.5 overflow-hidden">
                <img
                  src={selectedImage.dataUrl}
                  alt="Preview Foto Soal"
                  className="w-10 h-10 object-cover rounded-lg border border-cyan-400/50 shrink-0 bg-black/40"
                />
                <div className="text-left text-xs truncate">
                  <span className="font-bold text-cyan-300 block truncate max-w-[200px]">
                    {selectedImage.name}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">
                    {selectedImage.sizeKb} KB • Siap diproses OCR & Solusi Bertahap
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedImage(null)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 border border-slate-700 transition cursor-pointer"
                title="Batalkan foto"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Hidden File Input for Camera and Image selection */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageFileChange}
            className="hidden"
          />

          {/* Input Form with Camera Icon Button */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-3 bg-slate-900/90 border-t border-slate-800 flex items-center gap-2 shrink-0"
          >
            {/* Voice Input Button */}
            <button
              type="button"
              onClick={handleToggleListening}
              className={`p-2.5 rounded-xl border transition cursor-pointer shrink-0 ${
                isListening
                  ? 'bg-rose-500 text-white border-rose-400 shadow-lg shadow-rose-500/30'
                  : 'bg-slate-950 hover:bg-slate-800 border-slate-800 text-cyan-400 hover:text-cyan-300'
              }`}
              title="Bicara dengan Suara (Voice Input)"
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {/* 1. UPLOAD FOTO SOAL (OCR + AI SOLVER): Camera button next to input */}
            <button
              type="button"
              onClick={handleTriggerUpload}
              disabled={isLoading}
              className={`p-2.5 rounded-xl border transition cursor-pointer shrink-0 ${
                selectedImage
                  ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md shadow-cyan-500/30 font-bold'
                  : 'bg-slate-950 hover:bg-slate-800 border-slate-800 text-cyan-400 hover:text-cyan-300'
              }`}
              title="Foto Soal Kimia (OCR + Petunjuk Pengerjaan AI)"
            >
              <Camera className="w-4 h-4" />
            </button>

            {/* Text Input */}
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder={
                selectedImage
                  ? "Beri pertanyaan tambahan atau langsung kirim..."
                  : "Tanya soal kimia SMA atau klik kamera foto..."
              }
              disabled={isLoading}
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs sm:text-sm placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/30 transition disabled:opacity-50"
            />

            {/* Send Button */}
            <button
              type="submit"
              disabled={(!inputMessage.trim() && !selectedImage) || isLoading}
              className="p-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-slate-950 font-bold transition cursor-pointer shadow-md shadow-cyan-500/20 shrink-0 disabled:cursor-not-allowed"
              title="Kirim Pertanyaan / Foto ke Kak Kimi"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
