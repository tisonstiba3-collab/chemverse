import React, { useState } from 'react';
import {
  X,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  Trash2,
  Loader2,
  Lock,
  Paperclip,
} from 'lucide-react';
import { AIPlan, executePlan, ExecutionResult } from '../../services/aiCommandService';

export interface AIPlanPreviewPanelProps {
  isOpen: boolean;
  onClose: () => void;
  plan?: AIPlan | null;
  userPrompt?: string;
  attachedFileName?: string;
  onSuccess?: (result: ExecutionResult) => void;
}

export default function AIPlanPreviewPanel({
  isOpen,
  onClose,
  plan,
  userPrompt = 'Perintah Guru via AI Command',
  attachedFileName,
  onSuccess,
}: AIPlanPreviewPanelProps) {
  // Confirmation state for high risk (Ketik HAPUS)
  const [confirmDeleteText, setConfirmDeleteText] = useState('');
  // Second-layer confirmation for critical risk
  const [showCriticalConfirmDialog, setShowCriticalConfirmDialog] = useState(false);
  // Execution loading state
  const [isExecuting, setIsExecuting] = useState(false);

  if (!isOpen) return null;

  // Fallback dummy plan if none provided (e.g. from developer testing button)
  const activePlan: AIPlan = plan || {
    summary: 'Menambahkan 5 soal pilihan ganda ke Kelas 10 Bab 3 (Ikatan Kimia)',
    operations: [
      {
        op: 'add_soal',
        params: { babId: 'bab_02_ikatan' },
        preview: 'Soal 1: Manakah senyawa di bawah ini yang memiliki ikatan kovalen murni nonpolar?',
        detail: 'Pilihan: A. HCl, B. Cl2, C. H2O, D. NH3 | Kunci: B',
      },
      {
        op: 'add_soal',
        params: { babId: 'bab_02_ikatan' },
        preview: 'Soal 2: Unsur dengan keelektronegatifan sama akan membentuk ikatan...',
        detail: 'Pilihan: A. Ionik, B. Kovalen polar, C. Kovalen nonpolar, D. Logam | Kunci: C',
      },
      {
        op: 'add_soal',
        params: { babId: 'bab_02_ikatan' },
        preview: 'Soal 3: Jumlah pasangan elektron ikatan (PEI) pada molekul CH4 adalah...',
        detail: 'Pilihan: A. 2, B. 3, C. 4, D. 5 | Kunci: C | Pembahasan: Karbon memiliki 4 elektron valensi',
      },
      {
        op: 'add_soal',
        params: { babId: 'bab_02_ikatan' },
        preview: 'Soal 4: Karakteristik utama yang membedakan ikatan kovalen polar dan nonpolar adalah...',
        detail: 'Pilihan: A. Titik leleh, B. Momen dipol, C. Jumlah atom, D. Warna larutan | Kunci: B',
      },
      {
        op: 'add_soal',
        params: { babId: 'bab_02_ikatan' },
        preview: 'Soal 5: Molekul BF3 tidak memenuhi kaidah oktet karena atom boron hanya dikelilingi...',
        detail: 'Pilihan: A. 4 elektron, B. 6 elektron, C. 7 elektron, D. 10 elektron | Kunci: B',
      },
    ],
    impact: {
      added: 5,
      updated: 0,
      deleted: 0,
      risk: 'low',
    },
  };

  // Deteksi operasi penimpaan (Smart Overwrite)
  const overwriteOps = (activePlan.operations || []).filter(
    (op) =>
      (op.op === 'update_materi' || op.op === 'update_soal') &&
      (op.params?.replaceStrategy === 'overwrite' ||
        Boolean(op.params?.targetId) ||
        Boolean(op.params?.isOverwrite) ||
        op.preview?.toLowerCase().includes('timpa') ||
        op.preview?.toLowerCase().includes('menimpa') ||
        op.detail?.toLowerCase().includes('overwrite') ||
        op.detail?.toLowerCase().includes('menimpa'))
  );

  const hasOverwrite = overwriteOps.length > 0;
  const hasDelete = (activePlan.operations || []).some((op) => op.op.startsWith('delete'));

  // Otomatisasi Risk Engine: jika terdapat penimpaan materi, pastikan risk minimal 'high'
  const effectiveRisk: 'low' | 'medium' | 'high' | 'critical' = hasOverwrite
    ? activePlan.impact?.risk === 'critical'
      ? 'critical'
      : 'high'
    : activePlan.impact?.risk || 'low';

  const isHighRisk = effectiveRisk === 'high';
  const isCriticalRisk = effectiveRisk === 'critical';

  // Kata kunci konfirmasi ketik (TIMPA untuk overwrite, HAPUS untuk penghapusan)
  const requiredConfirmationWord = hasOverwrite
    ? 'TIMPA'
    : (isHighRisk || isCriticalRisk) && hasDelete
    ? 'HAPUS'
    : null;

  const isConfirmationPassed =
    !requiredConfirmationWord || confirmDeleteText.trim().toUpperCase() === requiredConfirmationWord;

  // Handler utama eksekusi plan
  const handleProceedExecution = async () => {
    setIsExecuting(true);
    try {
      const result = await executePlan(activePlan, userPrompt);
      if (onSuccess) {
        onSuccess(result);
      }
      // Reset state & close
      setConfirmDeleteText('');
      setShowCriticalConfirmDialog(false);
      onClose();
    } catch (err) {
      console.error('[AI Executor Error]:', err);
      alert('Terjadi kesalahan saat mengeksekusi rencana operasi.');
    } finally {
      setIsExecuting(false);
    }
  };

  const handleApproveClick = () => {
    // Jika Critical Risk (misal hapus massal), tampilkan konfirmasi lapisan kedua
    if (isCriticalRisk && hasDelete) {
      setShowCriticalConfirmDialog(true);
      return;
    }
    // Jika ada kata konfirmasi (TIMPA / HAPUS), pastikan sudah diketik benar
    if (requiredConfirmationWord && !isConfirmationPassed) {
      return;
    }
    handleProceedExecution();
  };

  const getRiskBadge = (r: 'low' | 'medium' | 'high' | 'critical') => {
    switch (r) {
      case 'low':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-mono font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Risiko: 🟢 RENDAH
          </span>
        );
      case 'medium':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-mono font-bold">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            Risiko: 🟡 SEDANG
          </span>
        );
      case 'high':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-orange-500/20 text-orange-300 border border-orange-500/30 text-xs font-mono font-bold">
            <AlertTriangle className="w-3.5 h-3.5 text-orange-400" />
            Risiko: 🟠 TINGGI
          </span>
        );
      case 'critical':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-mono font-bold">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            Risiko: 🔴 KRITIS
          </span>
        );
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm transition-opacity animate-fade-in">
        {/* Click outside to close */}
        <div className="flex-1" onClick={isExecuting ? undefined : onClose} />

        {/* Slide-in Drawer */}
        <div className="w-full max-w-xl h-full bg-slate-900 border-l border-white/10 shadow-2xl flex flex-col justify-between overflow-hidden text-slate-100 font-sans animate-slide-left">
          {/* Header */}
          <div className="p-5 border-b border-white/10 bg-white/[0.02] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 text-lg">
                🤖
              </div>
              <div>
                <h2 className="text-base font-extrabold text-white tracking-tight flex items-center gap-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  <span>AI Plan Preview</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono">
                    Review Guru
                  </span>
                </h2>
                <p className="text-[11px] text-slate-400">
                  AI tidak mengeksekusi langsung. Tinjau rencana di bawah sebelum menyetujui.
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              disabled={isExecuting}
              className="p-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-400 hover:text-white transition cursor-pointer disabled:opacity-50"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Content Body */}
          <div className="flex-1 overflow-y-auto p-5 space-y-5">
            {/* Clarification Box if exists */}
            {activePlan.clarification && (
              <div className="p-4 rounded-2xl bg-amber-500/15 border border-amber-500/30 space-y-2">
                <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-300">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>Klarifikasi Diperlukan:</span>
                </div>
                <p className="text-xs text-amber-200 leading-relaxed font-sans">
                  {activePlan.clarification}
                </p>
              </div>
            )}

            {/* Summary Box */}
            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-cyan-400 font-bold uppercase tracking-wider">
                  Ringkasan Rencana Operasi:
                </span>
                {getRiskBadge(effectiveRisk)}
              </div>
              <p className="text-sm font-semibold text-white leading-relaxed">
                {activePlan.summary}
              </p>

              {/* TUGAS 3: Indikator File Lampiran */}
              {(activePlan.attachedFileName || attachedFileName) && (
                <div className="flex items-center gap-1.5 text-xs font-mono text-cyan-300 bg-cyan-950/60 px-3 py-1.5 rounded-xl border border-cyan-500/40 w-fit shadow-sm">
                  <Paperclip className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>📎 Berdasarkan file: <strong className="text-white font-semibold">{activePlan.attachedFileName || attachedFileName}</strong></span>
                </div>
              )}

              <div className="pt-2 border-t border-white/5 flex items-center gap-4 text-xs font-mono text-slate-400">
                <span className="text-emerald-400">+{activePlan.impact?.added || 0} Soal/Konten Baru</span>
                <span>•</span>
                <span className="text-amber-400">~{activePlan.impact?.updated || 0} Perubahan</span>
                <span>•</span>
                <span className="text-rose-400">-{activePlan.impact?.deleted || 0} Dihapus</span>
              </div>
            </div>

            {/* PERINGATAN MENCOLOK PENIMPAAN MATERI (SMART OVERWRITE) */}
            {hasOverwrite && (
              <div className="space-y-2.5">
                {overwriteOps.map((op, idx) => {
                  const materiLama =
                    op.params?.targetTitle || op.params?.oldTitle || op.params?.targetId || 'Materi Sebelumnya';
                  const materiBaru = op.params?.judul || op.preview || 'Materi Baru';
                  return (
                    <div
                      key={idx}
                      className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-rose-500/10 border-2 border-amber-500/70 shadow-lg shadow-amber-500/10 space-y-2 text-amber-200 animate-pulse-subtle"
                    >
                      <div className="flex items-start gap-2.5 text-xs font-mono font-bold text-amber-300">
                        <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                        <span className="leading-snug">
                          ⚠️ MENIMPA DATA: Materi '{materiLama}' akan diganti dengan '{materiBaru}'
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed pl-7">
                        Konten materi lama akan digantikan dengan data baru. Snapshot sistem telah mencadangkan data sebelum eksekusi (dapat dipulihkan kapan saja melalui menu <span className="text-white font-semibold">Riwayat &gt; Batalkan (Undo)</span>).
                      </p>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Impact Alert */}
            <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 flex items-start gap-3 text-xs">
              <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <div className="text-slate-300 leading-relaxed">
                <strong className="text-cyan-200">Prinsip Keamanan:</strong> Siswa tidak dapat melihat rencana ini. Siswa hanya akan menerima hasil konten yang disetujui setelah guru menekan tombol <span className="text-white font-semibold">"Setujui & Jalankan"</span>.
              </div>
            </div>

            {/* Operations List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
                  Daftar Detail Operasi ({activePlan.operations?.length || 0} Item):
                </span>
                <span className="text-[11px] font-mono text-indigo-400">Tahap Validasi</span>
              </div>

              <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
                {(activePlan.operations || []).map((op, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl bg-white/[0.02] hover:bg-white/[0.05] border border-white/5 hover:border-indigo-500/30 transition space-y-1.5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-md bg-indigo-500/20 text-indigo-300 font-mono text-[10px] font-bold flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <span className="text-xs font-bold text-slate-200">
                          {op.preview}
                        </span>
                      </div>
                      <span className={`text-[10px] px-2 py-0.5 rounded font-mono uppercase shrink-0 ${
                        op.op.startsWith('delete')
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : op.op.startsWith('update')
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      }`}>
                        {op.op}
                      </span>
                    </div>

                    {op.detail && (
                      <p className="text-[11px] text-slate-400 font-mono pl-7 leading-relaxed bg-black/20 p-2 rounded-lg border border-white/[0.03]">
                        {op.detail}
                      </p>
                    )}

                    {/* TUGAS 3: BADGE & PREVIEW MINI UNTUK INTERACTIVE LAYOUT */}
                    {op.params?.layoutType && op.params.layoutType !== 'standard' && (
                      <div className="mt-2.5 pl-7 space-y-2">
                        {/* Layout Indicator Badge */}
                        <div className="flex items-center gap-2">
                          {op.params.layoutType === 'flipbook' && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[11px] font-mono font-bold shadow-sm">
                              <span>📖</span>
                              <span>Flipbook (Buku Digital Interaktif)</span>
                              {op.params.contentPages && (
                                <span className="text-[10px] bg-purple-500/30 px-1.5 py-0.2 rounded text-purple-200">
                                  {op.params.contentPages.length} Halaman
                                </span>
                              )}
                            </span>
                          )}
                          {op.params.layoutType === 'presentation' && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[11px] font-mono font-bold shadow-sm">
                              <span>📊</span>
                              <span>Slide Presentasi (Carousel PPT)</span>
                              {op.params.contentPages && (
                                <span className="text-[10px] bg-cyan-500/30 px-1.5 py-0.2 rounded text-cyan-200">
                                  {op.params.contentPages.length} Slide
                                </span>
                              )}
                            </span>
                          )}
                          {op.params.layoutType === 'pdf_viewer' && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[11px] font-mono font-bold shadow-sm">
                              <span>📄</span>
                              <span>PDF Viewer Terintegrasi</span>
                            </span>
                          )}
                        </div>

                        {/* Mini Preview Box simulating first page/slide */}
                        <div className="rounded-xl p-3 bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950/60 border border-indigo-500/30 shadow-inner space-y-2 relative overflow-hidden">
                          <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 border-b border-white/10 pb-1.5">
                            <span className="flex items-center gap-1 text-indigo-300 font-bold uppercase tracking-wider">
                              <span>👁️</span>
                              <span>
                                {op.params.layoutType === 'flipbook'
                                  ? 'Simulasi Halaman 1 (Buku Digital)'
                                  : op.params.layoutType === 'presentation'
                                  ? 'Simulasi Slide 1 (Presentasi)'
                                  : 'Simulasi Dokumen PDF'}
                              </span>
                            </span>
                            <span className="text-slate-500">Live Preview Siswa</span>
                          </div>

                          {/* Flipbook Mini Page 1 Preview */}
                          {op.params.layoutType === 'flipbook' && (
                            <div className="p-3 rounded-lg bg-amber-950/20 border border-amber-500/30 text-xs text-amber-100 font-serif leading-relaxed relative shadow-md">
                              <div className="absolute top-0 right-0 w-4 h-4 bg-amber-500/30 border-b border-l border-amber-500/50 rounded-bl" title="Efek lipatan buku" />
                              <p className="line-clamp-3 text-[11px]">
                                {op.params.contentPages?.[0] || op.params.isi?.slice(0, 150) || 'Halaman 1: Memuat konsep pembelajaran kimia interaktif...'}
                              </p>
                              <div className="mt-2 pt-1.5 border-t border-amber-500/20 flex items-center justify-between text-[10px] font-mono text-amber-400">
                                <span>📖 Hal 1 dari {op.params.contentPages?.length || 4}</span>
                                <span className="italic text-slate-400">Klik sudut untuk membalik ➔</span>
                              </div>
                            </div>
                          )}

                          {/* Presentation Mini Slide 1 Preview */}
                          {op.params.layoutType === 'presentation' && (
                            <div className="aspect-[16/9] max-h-32 p-3 rounded-lg bg-gradient-to-br from-slate-900 to-indigo-900/60 border border-cyan-500/40 text-xs text-cyan-100 flex flex-col justify-between shadow-md">
                              <div className="space-y-1">
                                <div className="text-[11px] font-extrabold text-white flex items-center gap-1.5">
                                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                                  <span>{op.params.judul || 'Slide 1: Pengantar'}</span>
                                </div>
                                <p className="text-[10px] text-slate-300 line-clamp-2 leading-relaxed">
                                  {op.params.contentPages?.[0]?.replace(/^#+\s*/gm, '') || op.params.isi?.slice(0, 120)}
                                </p>
                              </div>
                              <div className="flex items-center justify-between text-[9px] font-mono text-cyan-400 border-t border-white/10 pt-1">
                                <span>Slide 1 / {op.params.contentPages?.length || 4}</span>
                                <span>◀ ❚❚ ▶</span>
                              </div>
                            </div>
                          )}

                          {/* PDF Viewer Mini Preview */}
                          {op.params.layoutType === 'pdf_viewer' && (
                            <div className="p-3 rounded-lg bg-rose-950/20 border border-rose-500/30 text-xs text-rose-200 flex items-center justify-between gap-3">
                              <div className="space-y-0.5">
                                <span className="font-mono text-[11px] font-bold text-white block">
                                  Dokumen PDF Terpasang
                                </span>
                                <span className="text-[10px] text-slate-400 font-mono">
                                  {op.params.attachmentUrl || 'Dokumen PDF tersemat langsung di halaman materi'}
                                </span>
                              </div>
                              <span className="px-2 py-1 rounded bg-rose-500/20 text-rose-300 font-mono text-[10px] shrink-0 border border-rose-500/40">
                                PDF Embed
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* KONFIRMASI PENGAMANAN (KETIK TIMPA ATAU HAPUS) */}
            {requiredConfirmationWord && (
              <div className={`p-4 rounded-2xl border space-y-2.5 animate-pulse-subtle ${
                hasOverwrite
                  ? 'bg-amber-950/40 border-amber-500/50'
                  : 'bg-orange-950/40 border-orange-500/50'
              }`}>
                <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-300">
                  <Lock className="w-4 h-4 text-amber-400" />
                  <span>Konfirmasi Pengamanan Tindakan Berisiko Tinggi:</span>
                </div>
                <p className="text-xs text-slate-300">
                  {hasOverwrite ? (
                    <>
                      Operasi ini akan <strong className="text-amber-300">MENIMPA data materi yang sudah ada</strong>. Ketik kata <strong className="text-white font-mono bg-black/40 px-1.5 py-0.5 rounded border border-white/10">TIMPA</strong> di bawah untuk mengaktifkan tombol persetujuan:
                    </>
                  ) : (
                    <>
                      Operasi ini akan <strong className="text-rose-300">MENGHAPUS data</strong>. Ketik kata <strong className="text-white font-mono bg-black/40 px-1.5 py-0.5 rounded border border-white/10">HAPUS</strong> di bawah untuk mengaktifkan tombol persetujuan:
                    </>
                  )}
                </p>
                <input
                  type="text"
                  value={confirmDeleteText}
                  onChange={(e) => setConfirmDeleteText(e.target.value)}
                  placeholder={`Ketik ${requiredConfirmationWord} untuk konfirmasi`}
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border text-white font-mono text-xs focus:outline-none uppercase tracking-wider ${
                    hasOverwrite
                      ? 'border-amber-500/50 focus:border-amber-400'
                      : 'border-orange-500/50 focus:border-orange-400'
                  }`}
                />
              </div>
            )}
          </div>

          {/* Footer Actions */}
          <div className="p-4 border-t border-white/10 bg-slate-950/80 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              onClick={onClose}
              disabled={isExecuting}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-xs font-bold text-slate-300 hover:text-white transition cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              <X className="w-3.5 h-3.5 text-rose-400" />
              <span>❌ Batal</span>
            </button>

            {/* Tombol Setujui & Jalankan */}
            <button
              onClick={handleApproveClick}
              disabled={
                isExecuting ||
                !isConfirmationPassed ||
                (activePlan.operations?.length === 0)
              }
              className={`w-full sm:flex-1 py-2.5 rounded-xl font-black text-xs transition flex items-center justify-center gap-2 shadow-lg cursor-pointer ${
                isExecuting ||
                !isConfirmationPassed ||
                (activePlan.operations?.length === 0)
                  ? 'bg-slate-800 text-slate-500 border border-white/5 cursor-not-allowed shadow-none'
                  : hasOverwrite
                  ? 'bg-gradient-to-r from-amber-600 via-orange-600 to-amber-500 hover:from-amber-500 hover:to-orange-500 text-white shadow-amber-600/30'
                  : isCriticalRisk || isHighRisk
                  ? 'bg-gradient-to-r from-orange-600 to-rose-600 hover:from-orange-500 hover:to-rose-500 text-white shadow-rose-600/30'
                  : 'bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white shadow-emerald-600/30'
              }`}
            >
              {isExecuting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Mengeksekusi Operasi...</span>
                </>
              ) : hasOverwrite ? (
                <>
                  <AlertTriangle className="w-4 h-4" />
                  <span>✓ Setujui & Timpa Materi</span>
                </>
              ) : isCriticalRisk || isHighRisk ? (
                <>
                  <Trash2 className="w-4 h-4" />
                  <span>✓ Setujui & Hapus Item</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>✓ Setujui & Jalankan Rencana</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* TUGAS B.2 — DIALOG LAPISAN KEDUA UNTUK RISIKO KRITIS     */}
      {/* ======================================================== */}
      {showCriticalConfirmDialog && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="max-w-md w-full p-6 rounded-3xl bg-slate-900 border border-rose-500/40 shadow-2xl space-y-4 text-slate-100">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center text-2xl mx-auto">
              ⚠️
            </div>

            <div className="text-center space-y-1.5">
              <h3 className="text-base font-extrabold text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Peringatan Risiko Kritis
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Tindakan ini akan menghapus <strong className="text-rose-300">{activePlan.impact?.deleted || activePlan.operations?.length} item</strong> (masuk Sampah, bisa dipulihkan kembali dalam 30 hari). Yakin ingin melanjutkan?
              </p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setShowCriticalConfirmDialog(false)}
                disabled={isExecuting}
                className="flex-1 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-xs font-bold text-slate-300 transition cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleProceedExecution}
                disabled={isExecuting}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs shadow-lg shadow-rose-600/30 transition cursor-pointer flex items-center justify-center gap-2"
              >
                {isExecuting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Menghapus...</span>
                  </>
                ) : (
                  <span>Ya, Eksekusi Sekarang</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
