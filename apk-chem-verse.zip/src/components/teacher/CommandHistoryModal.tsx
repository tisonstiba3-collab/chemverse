import React, { useState, useEffect } from 'react';
import {
  X,
  History,
  RotateCcw,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  AlertCircle,
  Clock,
  Code,
  Sparkles,
} from 'lucide-react';
import {
  getCommandHistory,
  undoCommand,
  CommandHistoryItem,
} from '../../services/aiCommandService';

export interface CommandHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUndoSuccess?: (msg: string) => void;
}

export default function CommandHistoryModal({
  isOpen,
  onClose,
  onUndoSuccess,
}: CommandHistoryModalProps) {
  const [historyList, setHistoryList] = useState<CommandHistoryItem[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [undoStatusMessage, setUndoStatusMessage] = useState<string | null>(null);

  const refreshHistory = () => {
    setHistoryList(getCommandHistory());
  };

  useEffect(() => {
    if (isOpen) {
      refreshHistory();
      setUndoStatusMessage(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleUndo = (cmdId: string) => {
    const res = undoCommand(cmdId);
    if (res.success) {
      setUndoStatusMessage(`✅ ${res.message}`);
      refreshHistory();
      if (onUndoSuccess) {
        onUndoSuccess(res.message);
      }
    } else {
      alert(`Gagal Undo: ${res.message}`);
    }
  };

  const formatTimestamp = (isoStr: string) => {
    try {
      const d = new Date(isoStr);
      return d.toLocaleString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
    } catch {
      return isoStr;
    }
  };

  const getRemainingUndoMinutes = (isoStr: string) => {
    const elapsedMs = Date.now() - new Date(isoStr).getTime();
    const remainingMs = 10 * 60 * 1000 - elapsedMs;
    if (remainingMs <= 0) return 0;
    return Math.ceil(remainingMs / (60 * 1000));
  };

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fade-in text-slate-100 font-sans">
      <div className="w-full max-w-2xl max-h-[85vh] rounded-3xl bg-slate-900 border border-white/10 shadow-2xl flex flex-col justify-between overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-white/10 bg-white/[0.02] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center justify-center text-lg shadow-sm">
              <History className="w-4 h-4 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-white tracking-tight flex items-center gap-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                <span>Riwayat Perintah AI Guru</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono">
                  Audit Log
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Daftar eksekusi perintah AI, detail JSON plan, serta opsi Undo (maksimal 10 menit).
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3.5">
          {undoStatusMessage && (
            <div className="p-3.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{undoStatusMessage}</span>
            </div>
          )}

          {historyList.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-white/[0.02] border border-dashed border-white/10 space-y-2">
              <History className="w-8 h-8 text-slate-600 mx-auto" />
              <p className="text-xs text-slate-400 font-mono">
                Belum ada riwayat perintah AI.
              </p>
              <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                Setiap kali guru menjalankan perintah AI di menu Kelola Konten, riwayat dan snapshot state akan otomatis dicatat di sini.
              </p>
            </div>
          ) : (
            historyList.map((cmd) => {
              const remainingMinutes = getRemainingUndoMinutes(cmd.timestamp);
              const canUndo = !cmd.undone && remainingMinutes > 0;
              const isExpanded = expandedId === cmd.id;

              return (
                <div
                  key={cmd.id}
                  className={`p-4 rounded-2xl border transition space-y-3 ${
                    cmd.undone
                      ? 'bg-white/[0.01] border-white/5 opacity-60'
                      : 'bg-white/[0.03] border-white/10 hover:border-indigo-500/30'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400">
                      <Clock className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{formatTimestamp(cmd.timestamp)}</span>
                      <span>•</span>
                      <span className="text-cyan-300 font-bold">
                        {cmd.plan?.operations?.length || 0} Operasi
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {cmd.undone ? (
                        <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-400 text-[10px] font-mono font-bold border border-slate-700">
                          ↩️ Dibatalkan (Undone)
                        </span>
                      ) : cmd.result?.success ? (
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold border border-emerald-500/30">
                          ✓ Berhasil Dieksekusi
                        </span>
                      ) : (
                        <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-mono font-bold border border-amber-500/30">
                          ⚠️ Sebagian Gagal
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Prompt Text */}
                  <div>
                    <span className="text-[10px] font-mono uppercase text-slate-500 font-bold block mb-0.5">
                      Perintah Guru:
                    </span>
                    <p className="text-xs sm:text-sm font-semibold text-white leading-relaxed">
                      "{cmd.prompt}"
                    </p>
                  </div>

                  {/* Summary */}
                  {cmd.plan?.summary && (
                    <p className="text-[11px] text-slate-400 font-sans">
                      {cmd.plan.summary}
                    </p>
                  )}

                  {/* Action Buttons: Detail & Undo */}
                  <div className="pt-2 border-t border-white/5 flex items-center justify-between gap-3 text-xs">
                    <button
                      type="button"
                      onClick={() => setExpandedId(isExpanded ? null : cmd.id)}
                      className="px-2.5 py-1 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] text-slate-300 text-[11px] font-mono flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <Code className="w-3 h-3 text-indigo-400" />
                      <span>{isExpanded ? 'Sembunyikan Detail' : 'Lihat Detail Plan'}</span>
                      {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    </button>

                    {/* Tombol Undo */}
                    {!cmd.undone && (
                      <button
                        type="button"
                        onClick={() => handleUndo(cmd.id)}
                        disabled={!canUndo}
                        className={`px-3 py-1 rounded-xl text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer ${
                          canUndo
                            ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 shadow-sm'
                            : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                        }`}
                        title={
                          canUndo
                            ? `Batalkan perintah ini (sisa ${remainingMinutes} menit)`
                            : 'Batas waktu undo (10 menit) telah kedaluwarsa'
                        }
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>{canUndo ? `Undo (Sisa ${remainingMinutes}m)` : 'Undo Kedaluwarsa'}</span>
                      </button>
                    )}
                  </div>

                  {/* Expanded JSON Plan Viewer */}
                  {isExpanded && (
                    <div className="p-3 rounded-xl bg-slate-950 border border-white/10 text-[11px] font-mono text-cyan-300 overflow-x-auto max-h-48 leading-relaxed space-y-1">
                      <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-1">
                        JSON Plan Data:
                      </div>
                      <pre className="text-slate-300 text-[10px]">
                        {JSON.stringify(cmd.plan, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-slate-950/80 backdrop-blur-md flex items-center justify-between">
          <span className="text-[11px] font-mono text-slate-500">
            Total {historyList.length} perintah tercatat
          </span>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-xs font-bold text-slate-300 hover:text-white transition cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
}
