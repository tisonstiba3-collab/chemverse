import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  User,
  School,
  GraduationCap,
  Mail,
  Phone,
  Calendar,
  Sparkles,
  ArrowLeft,
  Home,
  MessageCircle,
  Eye,
  RefreshCw,
  Loader2,
  ShieldCheck,
} from 'lucide-react';
import { StudentAccount } from '../../shared/types';
import {
  fetchStudentByVerifyParams,
  updateStudentStatus,
  markVerifyUsed,
} from '../../services/studentVerificationStore';
import { buildConfirmationMessage, openWA } from '../../shared/waTemplates';
import { extractVerifyParamsFromUrl } from '../../shared/urlUtils';
import { adminVerifyStudent, updateStudentStatusInSupabase } from '../../services/supabaseService';
import { ADMIN_WA_NUMBER } from '../../config';
import Dashboard from '../Dashboard';
import ChemistryLoginBackground from '../chemistry/ChemistryLoginBackground';

interface AdminVerificationViewProps {
  adminVerifyId: string;
  token: string;
  onGoHome: () => void;
}

type VerificationViewMode =
  | 'loading'
  | 'scenario_a' // Link tidak valid / kedaluwarsa
  | 'scenario_b' // Siswa sudah aktif
  | 'scenario_c' // Siswa dinonaktifkan / rejected
  | 'scenario_d' // Menunggu verifikasi (Normal)
  | 'preview_dashboard'; // Preview dashboard siswa (read-only)

export default function AdminVerificationView({
  adminVerifyId: propVerifyId,
  token: propToken,
  onGoHome,
}: AdminVerificationViewProps) {
  const [student, setStudent] = useState<StudentAccount | null>(null);
  const [viewMode, setViewMode] = useState<VerificationViewMode>('loading');
  const [isActivating, setIsActivating] = useState(false);

  // Format tanggal & waktu lokal Indonesia
  const formatDate = (timestamp?: number) => {
    if (!timestamp) return 'Baru saja';
    try {
      return new Date(timestamp).toLocaleString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return 'Baru saja';
    }
  };

  // Muat data siswa saat komponen dimuat
  useEffect(() => {
    let isMounted = true;

    const loadStudent = async () => {
      // 1. Ekstraksi URL & Parameter dengan sanitasi WhatsApp
      const fullUrl = typeof window !== 'undefined' ? window.location.href : '';
      const extracted = extractVerifyParamsFromUrl();
      const activeVerifyId = propVerifyId || extracted.adminVerifyId || '';
      const activeToken = propToken || extracted.token || '';

      // 4. LOG UNTUK DEBUGGING (sesuai instruksi)
      console.log('🔍 [AdminVerificationView] URL lengkap yang diterima:', fullUrl);
      console.log('🔍 [AdminVerificationView] Nilai admin_verify dan token yang berhasil diekstrak:', {
        admin_verify: activeVerifyId,
        token: activeToken,
      });

      if (!activeVerifyId || !activeToken) {
        console.warn('🔍 [AdminVerificationView] Parameter verifikasi tidak lengkap.');
        if (isMounted) setViewMode('scenario_a');
        return;
      }

      try {
        const found = await fetchStudentByVerifyParams(activeVerifyId, activeToken);
        if (!isMounted) return;

        // 4. Log hasil pencarian dari database (Supabase / Firestore)
        console.log(
          '🔍 [AdminVerificationView] Hasil pencarian dari Supabase/Database:',
          found ? 'data' : 'null',
          found
        );

        if (!found) {
          setViewMode('scenario_a');
          return;
        }

        setStudent(found);

        if (found.status === 'active') {
          setViewMode('scenario_b');
        } else if (found.status === 'rejected') {
          setViewMode('scenario_c');
        } else {
          // pending_payment, pending_verify, atau locked
          setViewMode('scenario_d');
        }
      } catch (err) {
        console.warn('Error loading student by verify params:', err);
        if (isMounted) setViewMode('scenario_a');
      }
    };

    loadStudent();

    return () => {
      isMounted = false;
    };
  }, [propVerifyId, propToken]);

  // Aksi Tombol AKTIFKAN (Langkah 2.3)
  const handleActivate = async () => {
    if (!student) return;
    setIsActivating(true);

    try {
      // 1. Update status di store & database
      const updated = updateStudentStatus(
        student.id,
        'active',
        'admin-via-link',
        'Akun diaktifkan oleh admin via link WhatsApp'
      );
      markVerifyUsed(student.id, 'active');

      // Sinkronisasi status aktif ke Supabase remote (tabel public.students)
      updateStudentStatusInSupabase(student.id, 'active', {
        token: student.activationToken,
        verifyDecision: 'active',
      }).catch((err) => {
        console.warn('Gagal sinkron status aktif ke Supabase:', err);
      });

      if (updated) {
        setStudent({
          ...updated,
          status: 'active',
          verifyDecision: 'active',
          activatedAt: Date.now(),
        });
      }

      // 2. Loading selama 1 detik sesuai spesifikasi
      setTimeout(() => {
        setIsActivating(false);
        setViewMode('preview_dashboard');
      }, 1000);
    } catch (err) {
      console.warn('Gagal mengaktifkan siswa:', err);
      setIsActivating(false);
    }
  };

  // Aksi Tombol NONAKTIFKAN (Langkah 2.4)
  const handleReject = () => {
    if (!student) return;

    const defaultReason = 'Dibatalkan oleh admin via link';
    const updated = updateStudentStatus(
      student.id,
      'rejected',
      'admin-via-link',
      defaultReason
    );
    markVerifyUsed(student.id, 'rejected');

    // Sinkronisasi status nonaktif ke Supabase remote (tabel public.students)
    updateStudentStatusInSupabase(student.id, 'rejected', {
      token: student.activationToken,
      verifyDecision: 'rejected',
      rejectedReason: defaultReason,
    }).catch((err) => {
      console.warn('Gagal sinkron status lock ke Supabase:', err);
    });

    const rejectedStudent: StudentAccount = {
      ...(updated || student),
      status: 'rejected',
      verifyDecision: 'rejected',
      rejectedReason: defaultReason,
      adminVerifyUsedAt: Date.now(),
    };

    setStudent(rejectedStudent);
    // Otomatis tampil Halaman Identitas Siswa dengan status nonaktif (Langkah 2.4)
    setViewMode('scenario_c');
  };

  // Kirim WhatsApp Konfirmasi ke Siswa dari Banner Preview
  const handleSendWAConfirmation = () => {
    if (!student) return;
    const phone = student.whatsapp || ADMIN_WA_NUMBER;
    const msg = buildConfirmationMessage(student);
    openWA(phone, msg);
  };

  // Loading Awal
  if (viewMode === 'loading') {
    return (
      <div className="relative min-h-screen w-full flex flex-col items-center justify-center p-4 bg-[#040714] text-slate-100">
        <ChemistryLoginBackground />
        <div className="relative z-10 flex flex-col items-center gap-3 p-6 rounded-3xl bg-slate-900/80 border border-cyan-500/30 backdrop-blur-xl">
          <Loader2 className="w-10 h-10 text-cyan-400 animate-spin" />
          <p className="text-sm font-mono text-cyan-200">Memeriksa tautan verifikasi admin...</p>
        </div>
      </div>
    );
  }

  // Loader 1 Detik saat Mengaktifkan Akun (Langkah 2.3)
  if (isActivating) {
    return (
      <div className="relative min-h-screen w-full flex flex-col items-center justify-center p-4 bg-[#040714] text-slate-100">
        <ChemistryLoginBackground />
        <div className="relative z-10 flex flex-col items-center gap-4 p-8 rounded-3xl bg-slate-900/90 border border-emerald-500/40 shadow-2xl backdrop-blur-2xl max-w-sm w-full text-center">
          <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center">
            <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Mengaktifkan akun...</h3>
            <p className="text-xs text-slate-400 mt-1">
              Menyetel status akses & menyiapkan dashboard {student?.name || 'siswa'}
            </p>
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // MODE PREVIEW DASHBOARD SISWA (Langkah 2.3 & 2.5)
  // =========================================================================
  if (viewMode === 'preview_dashboard' && student) {
    const studentProfileForDashboard = {
      userId: student.id,
      namaLengkap: student.name,
      nama: student.name,
      kelas: student.classId,
      sekolah: student.school,
      email: student.email || `${student.name.toLowerCase().replace(/[^a-z0-9]/g, '')}@siswa.sma.belajar.id`,
      role: 'siswa' as const,
      xp: 350,
      completedModules: ['Struktur Atom & Ikatan Kimia'],
      solvedProblemsCount: 5,
      progres_materi: ['Struktur Atom', 'Ikatan Kimia'],
      createdAt: new Date(student.registeredAt || Date.now()).toISOString(),
      updatedAt: new Date().toISOString(),
    };

    return (
      <div className="relative min-h-screen w-full bg-[#040714] text-slate-100 font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
        {/* Banner Preview di Bagian Atas */}
        <header className="sticky top-0 z-50 w-full bg-slate-950/90 border-b border-cyan-500/40 px-4 py-3 backdrop-blur-xl shadow-2xl flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-left w-full md:w-auto">
            <span className="text-2xl" role="img" aria-label="preview">👁</span>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[11px] font-black uppercase tracking-wider bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                  PREVIEW SISWA
                </span>
                <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Akun Aktif
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-200 mt-0.5">
                Beginilah tampilan yang dilihat <strong className="text-white font-semibold">{student.name}</strong> setelah login
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 w-full md:w-auto justify-end">
            <button
              type="button"
              onClick={handleSendWAConfirmation}
              className="flex-1 md:flex-none flex items-center justify-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white shadow-lg shadow-emerald-900/30 transition-all cursor-pointer"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Kirim WA Konfirmasi ke Siswa</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('scenario_b')}
              className="flex-1 md:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 border border-slate-700 transition-all cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Kembali ke Verifikasi</span>
            </button>
          </div>
        </header>

        {/* Dashboard Siswa dalam mode Read-Only */}
        <div className="pointer-events-none select-none opacity-95">
          <Dashboard
            student={studentProfileForDashboard}
            onLogout={() => {}}
            previewMode={true}
          />
        </div>
      </div>
    );
  }

  // =========================================================================
  // SKENARIO A — Validasi Gagal (Langkah 2.2 Skenario A)
  // =========================================================================
  if (viewMode === 'scenario_a' || !student) {
    return (
      <div className="relative min-h-screen w-full flex items-center justify-center p-4 bg-[#040714] text-slate-100 font-sans">
        <ChemistryLoginBackground />
        <div className="relative z-10 w-full max-w-md p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-rose-500/30 shadow-2xl backdrop-blur-2xl text-center space-y-6">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
            <AlertTriangle className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <h2 className="text-xl font-bold text-white">Tautan Tidak Valid</h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              Link verifikasi tidak valid atau sudah kedaluwarsa. Silakan hubungi siswa atau buka dashboard admin.
            </p>
          </div>

          <button
            type="button"
            onClick={onGoHome}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-sm transition-all border border-slate-700 cursor-pointer active:scale-95"
          >
            <Home className="w-4 h-4" />
            <span>Kembali ke Beranda</span>
          </button>
        </div>
      </div>
    );
  }

  // =========================================================================
  // SKENARIO B — Siswa Sudah 'active' (Langkah 2.2 Skenario B)
  // =========================================================================
  if (viewMode === 'scenario_b') {
    return (
      <div className="relative min-h-screen w-full flex items-center justify-center p-4 bg-[#040714] text-slate-100 font-sans">
        <ChemistryLoginBackground />
        <div className="relative z-10 w-full max-w-md p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-emerald-500/40 shadow-2xl backdrop-blur-2xl text-center space-y-6">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              STATUS: AKTIF
            </span>
            <h2 className="text-xl font-bold text-white mt-2">
              Akun <span className="text-emerald-300">{student.name}</span> sudah AKTIF.
            </h2>
            <p className="text-xs text-slate-400 flex items-center justify-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              Diaktifkan pada {formatDate(student.activatedAt || student.adminVerifyUsedAt)}
            </p>
          </div>

          {/* Ringkasan Profil Singkat */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 text-left text-xs space-y-1.5 text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-500">Kelas</span>
              <span className="font-medium text-slate-200">{student.classId}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Sekolah</span>
              <span className="font-medium text-slate-200">{student.school}</span>
            </div>
          </div>

          <div className="space-y-3">
            <button
              type="button"
              onClick={() => setViewMode('preview_dashboard')}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 active:scale-95 text-white font-semibold text-sm transition-all shadow-lg shadow-cyan-900/30 cursor-pointer"
            >
              <Eye className="w-4 h-4" />
              <span>Lihat Halaman Siswa</span>
            </button>
            <button
              type="button"
              onClick={onGoHome}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 font-medium text-sm transition-all border border-slate-700 cursor-pointer"
            >
              <Home className="w-4 h-4" />
              <span>Kembali ke Beranda</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // SKENARIO C — Siswa Sudah 'rejected' / Halaman Identitas Siswa (Langkah 2.2 Skenario C & Langkah 2.4)
  // =========================================================================
  if (viewMode === 'scenario_c') {
    return (
      <div className="relative min-h-screen w-full flex items-center justify-center p-4 bg-[#040714] text-slate-100 font-sans">
        <ChemistryLoginBackground />
        <div className="relative z-10 w-full max-w-lg p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-rose-500/40 shadow-2xl backdrop-blur-2xl space-y-6">
          {/* Header Identitas Siswa */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <XCircle className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white uppercase tracking-wider">IDENTITAS SISWA</h2>
                <p className="text-xs text-rose-400 font-semibold">Akun {student.name} sudah DINONAKTIFKAN.</p>
              </div>
            </div>
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
              ❌ NONAKTIF
            </span>
          </div>

          {/* Kartu Rincian Identitas */}
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-3 text-xs sm:text-sm">
            <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
              <span className="text-slate-400 flex items-center gap-2">
                <User className="w-4 h-4 text-slate-500" /> Nama
              </span>
              <span className="font-semibold text-white">{student.name}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
              <span className="text-slate-400 flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-slate-500" /> Kelas
              </span>
              <span className="font-medium text-slate-200">{student.classId}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
              <span className="text-slate-400 flex items-center gap-2">
                <School className="w-4 h-4 text-slate-500" /> Sekolah
              </span>
              <span className="font-medium text-slate-200">{student.school}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
              <span className="text-slate-400 flex items-center gap-2">
                <Mail className="w-4 h-4 text-slate-500" /> Email
              </span>
              <span className="font-mono text-slate-300 text-xs">{student.email || '-'}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
              <span className="text-slate-400 flex items-center gap-2">
                <Phone className="w-4 h-4 text-slate-500" /> WhatsApp
              </span>
              <span className="font-mono text-slate-300 text-xs">{student.whatsapp || '-'}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-800/50">
              <span className="text-slate-400 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-slate-500" /> Tanggal Keputusan
              </span>
              <span className="text-slate-300">{formatDate(student.adminVerifyUsedAt || Date.now())}</span>
            </div>
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-400">Alasan</span>
              <span className="text-rose-300 font-medium">{student.rejectedReason || 'Dibatalkan oleh admin via link'}</span>
            </div>
          </div>

          {/* Tombol Aksi Skenario C */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <button
              type="button"
              onClick={handleActivate}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-semibold text-sm transition-all shadow-lg shadow-emerald-900/30 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Aktifkan Ulang</span>
            </button>
            <button
              type="button"
              onClick={onGoHome}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 font-medium text-sm transition-all border border-slate-700 cursor-pointer"
            >
              <Home className="w-4 h-4" />
              <span>Kembali ke Beranda</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // SKENARIO D — Verifikasi Akun Siswa (NORMAL / PENDING) (Langkah 2.2 Skenario D)
  // =========================================================================
  return (
    <div className="relative min-h-screen w-full flex items-center justify-center p-4 py-8 bg-[#040714] text-slate-100 font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      <ChemistryLoginBackground />

      <div className="relative z-10 w-full max-w-lg my-auto rounded-3xl bg-slate-900/90 border border-cyan-500/40 shadow-2xl backdrop-blur-2xl overflow-hidden">
        {/* Header Kartu */}
        <div className="p-6 border-b border-cyan-500/20 bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white uppercase tracking-wide">
                VERIFIKASI AKUN SISWA
              </h2>
              <p className="text-xs text-slate-400">
                Persetujuan akses langganan media pembelajaran Chemverse
              </p>
            </div>
          </div>
        </div>

        {/* Tabel / Rincian Identitas Siswa */}
        <div className="p-6 space-y-4">
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3 text-xs sm:text-sm">
            <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400 flex items-center gap-2">
                <User className="w-4 h-4 text-cyan-400" /> Nama
              </span>
              <span className="font-semibold text-white">{student.name}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400 flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-cyan-400" /> Kelas
              </span>
              <span className="font-medium text-slate-200">{student.classId}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400 flex items-center gap-2">
                <School className="w-4 h-4 text-cyan-400" /> Sekolah
              </span>
              <span className="font-medium text-slate-200">{student.school}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400 flex items-center gap-2">
                <Mail className="w-4 h-4 text-cyan-400" /> Email
              </span>
              <span className="font-mono text-slate-300 text-xs">{student.email || '-'}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400 flex items-center gap-2">
                <Phone className="w-4 h-4 text-cyan-400" /> WhatsApp
              </span>
              <span className="font-mono text-slate-300 text-xs">{student.whatsapp || '-'}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-800/60">
              <span className="text-slate-400 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-cyan-400" /> Daftar
              </span>
              <span className="text-slate-300">{formatDate(student.registeredAt)}</span>
            </div>
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-400 flex items-center gap-2">
                <Clock className="w-4 h-4 text-cyan-400" /> Konfirm
              </span>
              <span className="text-cyan-300 font-medium">
                {formatDate(student.paymentProofSentAt || student.adminVerifyCreatedAt)}
              </span>
            </div>
          </div>

          {/* Kotak Peringatan Bukti Transfer */}
          <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3 text-amber-200 text-xs leading-relaxed">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-amber-300">Peringatan Admin</p>
              <p className="mt-0.5">
                Pastikan bukti transfer sudah dicek di WhatsApp sebelum memutuskan.
              </p>
            </div>
          </div>

          {/* Dua Tombol Keputusan: [ ✅ AKTIFKAN ] & [ ❌ NONAKTIFKAN ] */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              type="button"
              onClick={handleActivate}
              className="flex items-center justify-center gap-2 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-lg shadow-emerald-950/40 transition-all active:scale-95 cursor-pointer border border-emerald-400/30"
            >
              <span>✅ AKTIFKAN</span>
            </button>
            <button
              type="button"
              onClick={handleReject}
              className="flex items-center justify-center gap-2 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-rose-700 to-red-700 hover:from-rose-600 hover:to-red-600 text-white font-bold text-sm shadow-lg shadow-rose-950/40 transition-all active:scale-95 cursor-pointer border border-rose-400/30"
            >
              <span>❌ NONAKTIFKAN</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
