import React from 'react';
import { Loader2, Atom } from 'lucide-react';

export default function DashboardLoadingSkeleton({ message = 'Memuat Modul Belajar...' }: { message?: string }) {
  return (
    <div className="w-full min-h-[60vh] flex flex-col items-center justify-center p-8 space-y-4">
      <div className="relative flex items-center justify-center">
        <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center animate-pulse">
          <Atom className="w-8 h-8 text-cyan-400 animate-spin" style={{ animationDuration: '4s' }} />
        </div>
        <Loader2 className="absolute -top-1 -right-1 w-5 h-5 text-cyan-300 animate-spin" />
      </div>

      <div className="text-center space-y-1">
        <h4 className="text-sm font-bold text-white font-mono">{message}</h4>
        <p className="text-xs text-slate-400">Mengoptimalkan aset visual dan data pembelajaran...</p>
      </div>

      {/* Shimmer skeleton bars */}
      <div className="w-full max-w-md space-y-2 pt-4">
        <div className="h-4 bg-white/[0.04] rounded-lg animate-pulse" />
        <div className="h-4 bg-white/[0.04] rounded-lg w-5/6 animate-pulse" />
        <div className="h-4 bg-white/[0.04] rounded-lg w-4/6 animate-pulse" />
      </div>
    </div>
  );
}
