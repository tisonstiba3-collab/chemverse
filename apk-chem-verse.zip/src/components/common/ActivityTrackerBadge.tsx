import React, { useState } from 'react';
import { Clock, Info, CheckCircle2, PauseCircle } from 'lucide-react';
import { ActivityTrackerState } from '../../hooks/useActivityTracker';

interface ActivityTrackerBadgeProps {
  tracker: ActivityTrackerState;
  label?: string;
  className?: string;
}

/**
 * Visual badge shown to the student to transparently indicate
 * that their real learning activity is currently being logged.
 */
export default function ActivityTrackerBadge({
  tracker,
  label = 'Mencatat aktivitas belajar',
  className = '',
}: ActivityTrackerBadgeProps) {
  const [showTooltip, setShowTooltip] = useState(false);

  // Format seconds to mm:ss
  const formatTime = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className={`relative inline-flex items-center ${className}`}>
      <button
        type="button"
        onClick={() => setShowTooltip(!showTooltip)}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-slate-900/90 hover:bg-slate-800 border border-emerald-500/30 text-emerald-300 text-[11px] font-mono shadow-sm cursor-pointer transition-all"
        title="Klik untuk info pelacakan aktivitas belajar"
      >
        {/* Pulsing indicator when tracking, paused icon when idle */}
        {tracker.isTracking ? (
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
        ) : (
          <PauseCircle className="w-3 h-3 text-amber-400 shrink-0" />
        )}

        <span className="flex items-center gap-1 font-semibold">
          <Clock className="w-3 h-3 text-emerald-400" />
          <span>{tracker.isIdle ? 'Jeda (Idle)' : label}</span>
        </span>

        <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-200 text-[10px] font-bold">
          {formatTime(tracker.activeSeconds)}
        </span>
      </button>

      {/* Floating Info Tooltip */}
      {showTooltip && (
        <div className="absolute top-full left-0 mt-2 z-50 w-72 p-3.5 rounded-2xl bg-slate-900/95 border border-emerald-500/40 shadow-2xl backdrop-blur-xl text-left text-xs text-slate-200 space-y-2 animate-fade-in pointer-events-none">
          <div className="flex items-center gap-2 font-bold text-white border-b border-white/10 pb-1.5">
            <Info className="w-4 h-4 text-emerald-400" />
            <span>Pelacakan Aktivitas Belajar Transparan</span>
          </div>

          <p className="text-[11px] text-slate-300 leading-relaxed">
            Sistem menghitung durasi aktif belajar Anda untuk dilaporkan ke Guru. Waktu hanya dicatat saat tab ini aktif dan Anda tidak idle (diam &gt; 2 menit).
          </p>

          <div className="space-y-1 text-[10px] font-mono pt-1 text-slate-400">
            <div className="flex justify-between items-center">
              <span>Status Tab:</span>
              <span className={tracker.isTabVisible ? 'text-emerald-300 font-bold' : 'text-amber-400 font-bold'}>
                {tracker.isTabVisible ? 'Aktif (Terlihat)' : 'Di Latar Belakang'}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span>Status Siswa:</span>
              <span className={tracker.isIdle ? 'text-amber-400 font-bold' : 'text-emerald-300 font-bold'}>
                {tracker.isIdle ? 'Diam / Idle' : 'Berinteraksi'}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span>Kirim Server:</span>
              <span className="text-cyan-300">Setiap 30 detik</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
