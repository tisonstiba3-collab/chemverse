import React from 'react';
import {
  LogIn,
  Clock,
  Send,
  Award,
  GraduationCap,
  X,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  Eye,
  Smartphone,
  Laptop,
} from 'lucide-react';

interface CaraKerjaModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenDashboardGuru?: () => void;
}

export default function CaraKerjaModal({
  isOpen,
  onClose,
  onOpenDashboardGuru,
}: CaraKerjaModalProps) {
  if (!isOpen) return null;

  const steps = [
    {
      number: 1,
      title: 'Masuk',
      subtitle: 'Autentikasi Akun & Perangkat',
      description:
        'Siswa login menggunakan akun sekolah (nama, kelas, dan sekolah). Sistem secara otomatis mencatat waktu masuk sesi, tipe perangkat (Mobile/Desktop), dan kelas siswa di database.',
      icon: LogIn,
      badge: 'Sesi Dimulai',
      color: '#38BDF8', // Sky
      borderColor: 'border-sky-500/30',
      bgColor: 'bg-sky-500/10',
    },
    {
      number: 2,
      title: 'Belajar & Berlatih',
      subtitle: 'Deteksi Keaktifan Waktu Nyata',
      description:
        'Selama siswa membaca modul materi atau mengerjakan latihan soal, aplikasi menghitung durasi belajar murni. Waktu HANYA dihitung saat tab terlihat dan siswa berinteraksi aktif (tidak idle lebih dari 2 menit).',
      icon: Clock,
      badge: 'Deteksi Cerdas',
      color: '#34D399', // Emerald
      borderColor: 'border-emerald-500/30',
      bgColor: 'bg-emerald-500/10',
    },
    {
      number: 3,
      title: 'Pencatatan Otomatis',
      subtitle: 'Sinkronisasi Berkala 30 Detik',
      description:
        'Setiap 30 detik data aktivitas belajar dikirim ke Cloud Firestore: jenis aktivitas (membaca/kuis), ID modul, durasi belajar, serta waktu & hari. Data juga otomatis terkirim saat tab ditutup via Beacon API.',
      icon: Send,
      badge: 'Interval 30s',
      color: '#FBBF24', // Amber
      borderColor: 'border-amber-500/30',
      bgColor: 'bg-amber-500/10',
    },
    {
      number: 4,
      title: 'Pencapaian',
      subtitle: 'Evaluasi & Rekapitulasi Nilai',
      description:
        'Nilai kuis, rasio jawaban benar/salah, perolehan XP belajar, dan modul yang telah tuntas dipelajari disimpan secara terstruktur pada riwayat pencapaian belajar siswa.',
      icon: Award,
      badge: 'Skor & XP',
      color: '#A855F7', // Purple
      borderColor: 'border-purple-500/30',
      bgColor: 'bg-purple-500/10',
    },
    {
      number: 5,
      title: 'Dashboard Guru',
      subtitle: 'Analisis 3 Tingkat (Guru → Kelas → Siswa)',
      description:
        'Guru dapat memantau rekapitulasi komprehensif per kelas dan per siswa: total menit membaca, menit mengerjakan soal, rata-rata nilai, heatmap jam aktif belajar, hingga alarm siswa yang tidak aktif > 7 hari.',
      icon: GraduationCap,
      badge: 'Multi-Level Analytics',
      color: '#F43F5E', // Rose
      borderColor: 'border-rose-500/30',
      bgColor: 'bg-rose-500/10',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-4xl my-auto rounded-3xl bg-slate-900 border border-cyan-500/30 shadow-[0_20px_70px_rgba(0,0,0,0.8)] overflow-hidden text-slate-100 p-6 sm:p-8 space-y-6">
        {/* Glow ambient */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="relative z-10 flex items-start justify-between gap-4 border-b border-white/10 pb-5">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Sistem Pembelajaran Kimia Terintegrasi</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Cara Kerja Aplikasi ChemiVerse
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">
              Alur pelacakan aktivitas belajar siswa otomatis & pemantauan dasbor guru secara transparan dan akurat.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-400 hover:text-white transition cursor-pointer shrink-0"
            aria-label="Tutup modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 5 Steps Grid */}
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {steps.map((step) => {
            const IconComponent = step.icon;
            return (
              <div
                key={step.number}
                className={`relative p-5 rounded-2xl border ${step.borderColor} ${step.bgColor} backdrop-blur-xl transition-all hover:scale-[1.02] flex flex-col justify-between space-y-3`}
              >
                <div className="flex items-center justify-between">
                  <span
                    className="w-8 h-8 rounded-xl flex items-center justify-center font-extrabold font-mono text-sm text-slate-950 shadow-md"
                    style={{ backgroundColor: step.color }}
                  >
                    {step.number}
                  </span>

                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-950/60 border border-white/10 text-slate-300">
                    {step.badge}
                  </span>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <IconComponent className="w-4 h-4" style={{ color: step.color }} />
                    <h3 className="text-base font-bold text-white tracking-tight">
                      {step.title}
                    </h3>
                  </div>
                  <span className="text-[11px] font-mono text-slate-400 block font-semibold">
                    {step.subtitle}
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed pt-1">
                    {step.description}
                  </p>
                </div>
              </div>
            );
          })}

          {/* Card 6: Keamanan & Privasi Ringkas */}
          <div className="relative p-5 rounded-2xl border border-white/10 bg-white/[0.02] backdrop-blur-xl flex flex-col justify-between space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-xl bg-slate-800 border border-white/10 flex items-center justify-center text-cyan-400">
                <ShieldCheck className="w-4 h-4" />
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Aman & Privat
              </span>
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-bold text-white tracking-tight">
                Keamanan & Etika Data
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Sistem tidak mencatat isi ketikan, posisi kursor, atau aktivitas di luar browser. Hanya waktu aktif pada materi kimia yang dicatat untuk pendampingan guru.
              </p>
            </div>

            <div className="pt-1 flex items-center gap-2 text-[11px] text-cyan-300 font-mono">
              <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>Transparan untuk siswa & guru</span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-white/10">
          <div className="flex items-center gap-3 text-xs text-slate-400 font-mono">
            <span className="flex items-center gap-1">
              <Smartphone className="w-3.5 h-3.5 text-slate-400" />
              <span>Mobile</span>
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Laptop className="w-3.5 h-3.5 text-slate-400" />
              <span>Desktop</span>
            </span>
            <span>•</span>
            <span className="text-emerald-400 font-bold">Auto 30s Pulse</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            {onOpenDashboardGuru && (
              <button
                onClick={() => {
                  onClose();
                  onOpenDashboardGuru();
                }}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-lg shadow-indigo-600/30"
              >
                <GraduationCap className="w-4 h-4" />
                <span>Buka Dasbor Guru</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}

            <button
              onClick={onClose}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-white/[0.08] hover:bg-white/[0.15] border border-white/10 text-white font-semibold text-xs transition cursor-pointer"
            >
              Mengerti & Lanjutkan
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
