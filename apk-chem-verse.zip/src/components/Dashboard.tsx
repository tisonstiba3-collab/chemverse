import React, { useState, useEffect, Suspense, lazy } from 'react';
import {
  Atom,
  Sparkles,
  LogOut,
  Zap,
  Cloud,
  CheckCircle2,
  Gauge,
  Cpu,
  Home,
  BookOpen,
  HelpCircle,
  Gamepad2,
  BarChart2,
  Target,
  Award,
  Compass,
  GraduationCap,
  School,
  User as UserIcon,
  Edit3,
  X,
  Box,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { useKakKimiaVoice } from '../hooks/useKakKimiaVoice';
import { StudentProfile, MenuKey, JournalEntry, UserDocument } from '../types/chemistry';
import TutorChatBox from './chat/TutorChatBox';
import CinematicMateriSection from './chemistry/CinematicMateriSection';
import HeroMoleculeBackground from './3d/HeroMoleculeBackground';
import DashboardLoadingSkeleton from './common/DashboardLoadingSkeleton';
import CanvasShimmerSkeleton from './3d/CanvasShimmerSkeleton';
import PetaBelajarView from './chemistry/PetaBelajarView';
import ModalPencapaian from './chemistry/ModalPencapaian';
import GeneratorKuisAIModal from './chemistry/GeneratorKuisAIModal';
import CaraKerjaModal from './common/CaraKerjaModal';

// Lazy-load 3D Student Identity Canvas
const LazyStudentIdentity3DCanvas = lazy(() => import('./3d/StudentIdentity3DCanvas'));
import { INITIAL_JOURNAL_ENTRIES } from '../data/chemistryData';
import {
  getStudentProfile,
  saveStudentProfile,
  saveJournalEntry,
  subscribeStudentJournals,
  subscribeUserDocument,
  tambahXP,
} from '../services/firestoreService';

// Lazy-load subpage views for maximum initial speed and minimal memory footprint
const MateriKimiaView = lazy(() => import('./views/MateriKimiaView'));
const TesDiagnostikView = lazy(() => import('./views/TesDiagnostikView'));
const LatihanSoalView = lazy(() => import('./views/LatihanSoalView'));
const GamesKimiaView = lazy(() => import('./views/GamesKimiaView'));
const SoalTKAView = lazy(() => import('./views/SoalTKAView'));
const ProgresView = lazy(() => import('./views/ProgresView'));
const JurnalView = lazy(() => import('./views/JurnalView'));
const DasborGuruView = lazy(() => import('./views/DasborGuruView'));
const KumpulanRumusView = lazy(() => import('./views/KumpulanRumusView'));

interface DashboardProps {
  student: StudentProfile;
  onLogout: () => void;
  previewMode?: boolean;
}

export default function Dashboard({ student: initialStudent, onLogout, previewMode = false }: DashboardProps) {
  const isInitialGuru =
    initialStudent.role === 'guru' ||
    initialStudent.email?.endsWith('@guru.sma.belajar.id') ||
    initialStudent.email?.toLowerCase().includes('guru') ||
    false;

  const [student, setStudent] = useState<StudentProfile>(initialStudent);
  const [userDoc, setUserDoc] = useState<UserDocument | null>(null);
  const [isAchievementsModalOpen, setIsAchievementsModalOpen] = useState(false);
  const [isQuizGeneratorOpen, setIsQuizGeneratorOpen] = useState(false);
  const [isCaraKerjaOpen, setIsCaraKerjaOpen] = useState(false);
  // Routing: If user role === 'guru', navigate directly to teacher dashboard 'guru'
  const [activeView, setActiveView] = useState<MenuKey | null>(isInitialGuru ? 'guru' : null);
  const [selectedMateriTopicId, setSelectedMateriTopicId] = useState<string | null>(null);
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(INITIAL_JOURNAL_ENTRIES);
  const [isJournalsLoading, setIsJournalsLoading] = useState(true);

  // 3D Student Identity Modal & Edit State
  const [isIdentityModalOpen, setIsIdentityModalOpen] = useState(false);
  const [editNama, setEditNama] = useState(student.namaLengkap);
  const [editKelas, setEditKelas] = useState(student.kelas);
  const [editSekolah, setEditSekolah] = useState(student.sekolah);
  const [editRole, setEditRole] = useState<'siswa' | 'guru'>(student.role || 'siswa');
  const [isSavingIdentity, setIsSavingIdentity] = useState(false);

  // Suara Tegas Kak Kimia pada Bagian Identitas Siswa di Dashboard
  const [isIdentityVoiceMuted, setIsIdentityVoiceMuted] = useState<boolean>(() => {
    if (previewMode) return true;
    return localStorage.getItem('chemverse_kak_kimia_muted') === 'true';
  });

  const identitySpeech = `Perhatian ${student.namaLengkap}! Kamu terdaftar aktif sebagai siswa ${student.kelas} dari ${student.sekolah}. Seluruh materi kimia telah aktif dan siap kamu pelajari. Tetap semangat dan raih pemahaman terbaik!`;

  const {
    speak: speakIdentityVoice,
    stop: stopIdentityVoice,
    isSpeaking: isIdentitySpeaking,
  } = useKakKimiaVoice(identitySpeech, isIdentityVoiceMuted);

  const toggleIdentityVoice = () => {
    if (isIdentitySpeaking) {
      stopIdentityVoice();
      return;
    }
    if (isIdentityVoiceMuted) {
      setIsIdentityVoiceMuted(false);
      localStorage.setItem('chemverse_kak_kimia_muted', 'false');
      speakIdentityVoice(identitySpeech);
    } else {
      speakIdentityVoice(identitySpeech);
    }
  };

  // Guru Dashboard Locking & Authentication State
  const [isGuruUnlocked, setIsGuruUnlocked] = useState<boolean>(
    () => sessionStorage.getItem('chemverse_guru_unlocked') === 'true'
  );
  const [isGuruAuthModalOpen, setIsGuruAuthModalOpen] = useState<boolean>(false);
  const [guruInputUser, setGuruInputUser] = useState('');
  const [guruInputPass, setGuruInputPass] = useState('');
  const [guruAuthError, setGuruAuthError] = useState<string | null>(null);

  const handleOpenGuruDashboard = () => {
    if (isGuruUnlocked) {
      setActiveView(activeView === 'guru' ? null : 'guru');
    } else {
      setGuruAuthError(null);
      setGuruInputUser('');
      setGuruInputPass('');
      setIsGuruAuthModalOpen(true);
    }
  };

  const handleVerifyGuruAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (guruInputUser.trim() === 'kristian son' && guruInputPass === 'Kimia123@') {
      setIsGuruUnlocked(true);
      sessionStorage.setItem('chemverse_guru_unlocked', 'true');
      setIsGuruAuthModalOpen(false);
      setActiveView('guru');
      setGuruAuthError(null);
    } else {
      setGuruAuthError('Username atau Password Guru Salah! Dashboard Guru Terkunci.');
    }
  };

  const handleOpenEditIdentity = () => {
    setEditNama(student.namaLengkap);
    setEditKelas(student.kelas);
    setEditSekolah(student.sekolah);
    setEditRole(student.role || 'siswa');
    setIsIdentityModalOpen(true);
  };

  const handleSaveIdentity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editNama.trim() || !editSekolah.trim()) return;

    if (editRole === 'guru' && !isGuruUnlocked) {
      alert('Untuk mengubah akun ke Guru, Anda harus membuka kunci Dasbor Guru dengan username dan password!');
      handleOpenGuruDashboard();
      return;
    }

    setIsSavingIdentity(true);
    try {
      const updated: StudentProfile = {
        ...student,
        namaLengkap: editNama.trim(),
        nama: editNama.trim(),
        kelas: editKelas.trim(),
        sekolah: editSekolah.trim(),
        role: editRole,
        updatedAt: new Date().toISOString(),
      };
      await saveStudentProfile(updated);
      setStudent(updated);
      setIsIdentityModalOpen(false);
    } catch (err) {
      console.warn('Failed to update student identity:', err);
    } finally {
      setIsSavingIdentity(false);
    }
  };

  // Performance mode state: 'lightweight' for super-fast low-resource mode, '3d' for dynamic WebGL
  const [isLightweight, setIsLightweight] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('chem_perf_mode');
      if (saved) return saved === 'lightweight';
      // Auto-enable lightweight mode on mobile phones and tablets for 60fps instant response:
      if (typeof window !== 'undefined' && (window.innerWidth < 768 || (navigator.maxTouchPoints && navigator.maxTouchPoints > 1))) {
        return true;
      }
      return false;
    } catch {
      return false;
    }
  });

  const togglePerformanceMode = () => {
    const nextVal = !isLightweight;
    setIsLightweight(nextVal);
    try {
      localStorage.setItem('chem_perf_mode', nextVal ? 'lightweight' : '3d');
      window.dispatchEvent(new Event('chem_perf_mode_change'));
    } catch (err) {
      console.warn('Failed to persist performance mode preference:', err);
    }
  };

  // Sync deep link /materi/:topicId on initial load
  useEffect(() => {
    const path = window.location.pathname;
    if (path.startsWith('/materi')) {
      setActiveView('materi');
      if (path.startsWith('/materi/')) {
        const id = path.replace('/materi/', '');
        if (id) {
          setSelectedMateriTopicId(id);
        }
      }
    }
  }, []);

  // Real-time synchronization with Firestore "users" collection (Fase 1: users/{userId})
  useEffect(() => {
    if (!student.userId) return;
    const unsub = subscribeUserDocument(
      student.userId,
      (doc) => {
        if (doc) {
          setUserDoc(doc);
        }
      },
      (err) => console.warn('Real-time listener users error:', err)
    );
    return () => unsub();
  }, [student.userId]);

  // Retrieve latest saved student profile from Firestore upon reaching the dashboard
  useEffect(() => {
    if (initialStudent?.userId) {
      getStudentProfile(initialStudent.userId)
        .then((remoteProfile) => {
          if (remoteProfile) {
            setStudent(remoteProfile);
          }
        })
        .catch((err) => {
          console.warn('Gagal memuat profil terbaru dari Firestore:', err);
        });
    }
  }, [initialStudent?.userId]);

  // 1. DASBOR GURU ROUTING: Jika user login dan role === 'guru' & sudah unlocked, arahkan ke dasbor guru
  useEffect(() => {
    const isGuru =
      student.role === 'guru' ||
      userDoc?.role === 'guru' ||
      student.email?.endsWith('@guru.sma.belajar.id') ||
      student.email?.toLowerCase().includes('guru') ||
      false;
    if (isGuru && isGuruUnlocked && (activeView === null || activeView === 'peta')) {
      setActiveView('guru');
    }
  }, [student.role, userDoc?.role, student.email, isGuruUnlocked]);

  // Real-time synchronization with Firestore "journals" collection
  useEffect(() => {
    if (!student.userId) return;

    setIsJournalsLoading(true);
    const unsubscribe = subscribeStudentJournals(
      student.userId,
      (entries) => {
        if (entries && entries.length > 0) {
          setJournalEntries(entries);
        } else {
          setJournalEntries(INITIAL_JOURNAL_ENTRIES);
        }
        setIsJournalsLoading(false);
      },
      (error) => {
        console.warn('Real-time listener journals error:', error);
        setIsJournalsLoading(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, [student.userId]);

  // 2. SISTEM POIN: Menggunakan tambahXP untuk update field `xp` di Firestore
  const handleAddXP = async (amount: number) => {
    if (student.userId) {
      try {
        const newXP = await tambahXP(student.userId, amount);
        setStudent((prev) => ({
          ...prev,
          xp: newXP,
          solvedProblemsCount: (prev.solvedProblemsCount ?? 5) + 1,
        }));
      } catch (err) {
        console.warn('Failed to update XP via tambahXP:', err);
      }
    }
  };

  const handleAddJournalEntry = async (entry: {
    topic: string;
    content: string;
    understandingLevel: 'Paham' | 'Cukup' | 'Perlu Diulang';
    durationMinutes: number;
    notes?: string;
    formulasLearned?: string[];
  }) => {
    const nowIso = new Date().toISOString();
    await saveJournalEntry({
      studentId: student.userId,
      studentName: student.namaLengkap,
      topic: entry.topic,
      content: entry.content,
      notes: entry.notes || entry.content,
      understandingLevel: entry.understandingLevel,
      durationMinutes: entry.durationMinutes,
      formulasLearned: entry.formulasLearned || [],
      date: nowIso.split('T')[0],
      createdAt: nowIso,
    });
    handleAddXP(40);
  };

  // Helper to render the active page view with Suspense skeleton boundary
  const renderActiveView = () => {
    switch (activeView) {
      case 'peta':
        return (
          <div className="p-4 sm:p-6 lg:p-8">
            <div className="max-w-4xl mx-auto mb-4 flex items-center justify-between">
              <button
                onClick={() => setActiveView(null)}
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-cyan-500/50 text-sm font-medium transition cursor-pointer"
              >
                ← Kembali ke Dashboard
              </button>
              <button
                onClick={() => setIsAchievementsModalOpen(true)}
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold text-xs transition cursor-pointer shadow-sm"
              >
                <Award className="w-4 h-4 text-amber-400" />
                Lencana ({userDoc?.badges?.length || 2}) • {userDoc?.xp ?? student.xp ?? 250} XP
              </button>
            </div>
            <PetaBelajarView
              userId={student.userId}
              onOpenAchievements={() => setIsAchievementsModalOpen(true)}
            />
          </div>
        );
      case 'materi':
        return (
          <Suspense fallback={<DashboardLoadingSkeleton message="Menyiapkan Materi Kimia..." />}>
            <div className="p-4 sm:p-6 lg:p-8">
              <MateriKimiaView
                student={student}
                initialTopicId={selectedMateriTopicId}
                onBack={() => {
                  setActiveView(null);
                  setSelectedMateriTopicId(null);
                }}
                onNavigateToLatihan={() => setActiveView('latihan')}
                onCompleteTopic={() => handleAddXP(70)}
              />
            </div>
          </Suspense>
        );
      case 'diagnostik':
        return (
          <Suspense fallback={<DashboardLoadingSkeleton message="Menyiapkan Tes Diagnostik Adaptif..." />}>
            <div className="p-4 sm:p-6 lg:p-8">
              <TesDiagnostikView
                student={student}
                initialTopic={selectedMateriTopicId || 'Struktur Atom'}
                onBack={() => setActiveView(null)}
                onNavigateToMateri={(topicId) => {
                  setSelectedMateriTopicId(topicId);
                  setActiveView('materi');
                }}
              />
            </div>
          </Suspense>
        );
      case 'latihan':
        return (
          <Suspense fallback={<DashboardLoadingSkeleton message="Memuat Paket Latihan Soal..." />}>
            <div className="p-4 sm:p-6 lg:p-8">
              <LatihanSoalView onBack={() => setActiveView(null)} onAddXP={handleAddXP} />
            </div>
          </Suspense>
        );
      case 'games':
        return (
          <Suspense fallback={<DashboardLoadingSkeleton message="Memuat Arena Games Kimia..." />}>
            <div className="p-4 sm:p-6 lg:p-8">
              <GamesKimiaView
                student={student}
                onBack={() => setActiveView(null)}
                onAddXP={handleAddXP}
              />
            </div>
          </Suspense>
        );
      case 'tka':
        return (
          <Suspense fallback={<DashboardLoadingSkeleton message="Menyiapkan Simulasi Soal TKA..." />}>
            <div className="p-4 sm:p-6 lg:p-8">
              <SoalTKAView onBack={() => setActiveView(null)} onAddXP={handleAddXP} />
            </div>
          </Suspense>
        );
      case 'progres':
        return (
          <Suspense fallback={<DashboardLoadingSkeleton message="Mengalkulasi Statistik Progres..." />}>
            <div className="p-4 sm:p-6 lg:p-8">
              <ProgresView student={student} onBack={() => setActiveView(null)} />
            </div>
          </Suspense>
        );
      case 'jurnal':
        return (
          <Suspense fallback={<DashboardLoadingSkeleton message="Memuat Jurnal Belajar..." />}>
            <div className="p-4 sm:p-6 lg:p-8">
              <JurnalView
                entries={journalEntries}
                onAddEntry={handleAddJournalEntry}
                onBack={() => setActiveView(null)}
                isLoading={isJournalsLoading}
              />
            </div>
          </Suspense>
        );
      case 'rumus':
        return (
          <Suspense fallback={<DashboardLoadingSkeleton message="Menyiapkan Kumpulan Rumus Kimia..." />}>
            <div className="p-4 sm:p-6 lg:p-8">
              <KumpulanRumusView onBack={() => setActiveView(null)} />
            </div>
          </Suspense>
        );
      case 'guru':
        return (
          <Suspense fallback={<DashboardLoadingSkeleton message="Menyiapkan Dasbor Guru & Analisis Kelas..." />}>
            <div className="p-4 sm:p-6 lg:p-8">
              <DasborGuruView onBackToStudentView={() => setActiveView('peta')} />
            </div>
          </Suspense>
        );
      default:
        return (
          <main className="max-w-7xl mx-auto px-3.5 sm:px-8 py-5 sm:py-8 space-y-7 sm:space-y-12 relative z-10 pb-28 sm:pb-12">
            {/* Personalized Welcome Banner with 3D Student Identity Column */}
            <section className="rounded-3xl bg-slate-900/90 backdrop-blur-2xl border-[3px] border-cyan-500/40 p-5 sm:p-8 relative overflow-hidden shadow-[0_20px_50px_rgba(8,145,178,0.2),0_10px_0_0_#0f172a]">
              {/* Subtle ambient accent glows inside banner */}
              <div className="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-cyan-500/15 blur-3xl pointer-events-none" />
              <div className="absolute -left-16 -bottom-16 w-80 h-80 rounded-full bg-violet-500/15 blur-3xl pointer-events-none" />

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center relative z-10">
                {/* Left 7 cols: Welcome Message, Stats & Primary CTAs */}
                <div className="lg:col-span-7 space-y-3.5 text-left">
                  <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-500/15 border-2 border-cyan-400/40 text-cyan-300 text-xs font-black shadow-[0_3px_0_0_#0e7490]">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Dashboard Belajar Siswa Aktif • Kurikulum Kimia 3D</span>
                  </div>

                  {/* Personalized Greeting with student's saved name */}
                  <h1
                    className="text-2xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight"
                    style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                  >
                    Selamat Datang,{' '}
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#22D3EE] via-sky-300 to-[#A78BFA]">
                      {student.namaLengkap}
                    </span>
                    ! 👋
                  </h1>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                    Kamu terdaftar di <span className="text-white font-extrabold">{student.kelas}</span> •{' '}
                    <span className="text-cyan-300 font-bold">{student.sekolah}</span>. Profil, asesmen prasyarat, riwayat latihan, dan jurnal belajarmu tersimpan otomatis di Cloud Firestore.
                  </p>

                  {/* Quick Stats Grid Responsive */}
                  <div className="pt-1 grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs font-mono">
                    <div className="flex items-center gap-2 px-3 py-2.5 rounded-2xl bg-slate-950/80 border-2 border-slate-800 shadow-[0_3px_0_0_#0f172a]">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span className="text-slate-400">Akun:</span>
                      <span className="text-slate-200 font-black truncate">Google Login</span>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-2.5 rounded-2xl bg-slate-950/80 border-2 border-slate-800 shadow-[0_3px_0_0_#0f172a]">
                      <Cloud className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span className="text-slate-400">Database:</span>
                      <span className="text-cyan-300 font-black truncate">Firestore Aktif</span>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-2.5 rounded-2xl bg-slate-950/80 border-2 border-slate-800 shadow-[0_3px_0_0_#0f172a]">
                      <Zap className="w-4 h-4 text-amber-400 fill-amber-400 shrink-0" />
                      <span className="text-slate-400">XP Siswa:</span>
                      <span className="text-amber-300 font-black">{userDoc?.xp ?? student.xp ?? 250} XP</span>
                    </div>
                  </div>

                  {/* CTA Buttons */}
                  <div className="pt-2 flex flex-wrap items-center gap-3">
                    <button
                      onClick={() => setActiveView('peta')}
                      className="inline-flex items-center gap-2 px-4 py-3 rounded-2xl bg-gradient-to-r from-cyan-400 to-teal-300 text-slate-950 font-black text-xs sm:text-sm border-2 border-cyan-200 border-b-4 border-b-cyan-700 shadow-[0_5px_0_0_#0e7490] hover:translate-y-0.5 active:translate-y-1 active:shadow-none transition cursor-pointer"
                    >
                      <Compass className="w-4 h-4 text-slate-950" />
                      <span>Peta Belajar Berkelok ➔</span>
                    </button>
                    <button
                      onClick={() => setIsAchievementsModalOpen(true)}
                      className="inline-flex items-center gap-2 px-3.5 py-3 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border-2 border-amber-500/40 text-amber-300 font-black text-xs shadow-[0_4px_0_0_#0f172a] active:translate-y-1 transition cursor-pointer"
                    >
                      <Award className="w-4 h-4 text-amber-400" />
                      <span>Lencana ({userDoc?.badges?.length || 2})</span>
                    </button>
                    <button
                      onClick={() => setIsQuizGeneratorOpen(true)}
                      className="inline-flex items-center gap-2 px-3.5 py-3 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border-2 border-cyan-500/40 text-cyan-200 font-black text-xs shadow-[0_4px_0_0_#0f172a] active:translate-y-1 transition cursor-pointer group"
                    >
                      <Sparkles className="w-4 h-4 text-cyan-400 group-hover:rotate-12 transition-transform" />
                      <span>Buat Kuis AI</span>
                    </button>
                  </div>
                </div>

                {/* Right 5 cols: KARTU IDENTITAS SISWA KIMIA 3D TEBAL */}
                <div className="lg:col-span-5 w-full">
                  <div className="p-5 rounded-3xl bg-slate-950/90 border-[3px] border-cyan-400/50 shadow-[0_12px_0_0_#0f172a,0_20px_40px_rgba(34,211,238,0.18)] relative overflow-hidden space-y-4">
                    {/* Header with 3D Rotating Atom Stage */}
                    <div className="flex items-center gap-3.5 border-b-2 border-slate-800 pb-3.5">
                      <div className="w-14 h-14 rounded-2xl bg-slate-900 border-2 border-cyan-400/50 shadow-[0_4px_0_0_#0f172a] overflow-hidden shrink-0 relative">
                        <Suspense
                          fallback={
                            <CanvasShimmerSkeleton className="w-full h-full" rounded="rounded-xl" />
                          }
                        >
                          <LazyStudentIdentity3DCanvas role={student.role} />
                        </Suspense>
                        <span className="absolute bottom-0.5 right-0.5 text-[8px] font-mono font-black px-1 rounded bg-cyan-400 text-slate-950">
                          3D
                        </span>
                      </div>

                      <div className="text-left flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono font-extrabold uppercase px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 border border-cyan-400/40">
                            Kolom Identitas Kimia
                          </span>
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={toggleIdentityVoice}
                              className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold border transition flex items-center gap-1 cursor-pointer ${
                                isIdentitySpeaking
                                  ? 'bg-cyan-500/30 border-cyan-400 text-cyan-200 animate-pulse'
                                  : isIdentityVoiceMuted
                                  ? 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                                  : 'bg-cyan-950/70 border-cyan-500/30 text-cyan-300 hover:bg-cyan-900/60 hover:text-white'
                              }`}
                              title="Dengarkan Suara Tegas Kak Kimia (Identitas Siswa)"
                            >
                              {isIdentitySpeaking ? (
                                <>
                                  <Volume2 className="w-3 h-3 text-emerald-400 animate-spin" />
                                  <span>Bicara...</span>
                                </>
                              ) : isIdentityVoiceMuted ? (
                                <>
                                  <VolumeX className="w-3 h-3 text-rose-400" />
                                  <span>Bisu</span>
                                </>
                              ) : (
                                <>
                                  <Volume2 className="w-3 h-3 text-cyan-400" />
                                  <span>🔊 Suara Tegas</span>
                                </>
                              )}
                            </button>
                            <span className="text-[10px] font-mono font-bold text-emerald-400 flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                              Aktif
                            </span>
                          </div>
                        </div>
                        <h3 className="text-base font-black text-white truncate mt-1">
                          {student.namaLengkap}
                        </h3>
                        <p className="text-[11px] font-mono text-slate-400 truncate">
                          {student.role === 'guru' ? 'Guru Pendidik Kimia' : 'Siswa Kimia SMA'}
                        </p>
                      </div>
                    </div>

                    {/* 2-Column Info Grid */}
                    <div className="grid grid-cols-2 gap-2.5 text-left text-xs font-mono">
                      <div className="p-3 rounded-2xl bg-slate-900/90 border-2 border-slate-800 shadow-[0_3px_0_0_#0f172a] space-y-0.5">
                        <span className="text-[10px] font-bold text-slate-400 block uppercase">
                          Tingkat Kelas:
                        </span>
                        <span className="font-black text-cyan-300 block truncate text-xs">
                          {student.kelas}
                        </span>
                      </div>

                      <div className="p-3 rounded-2xl bg-slate-900/90 border-2 border-slate-800 shadow-[0_3px_0_0_#0f172a] space-y-0.5">
                        <span className="text-[10px] font-bold text-slate-400 block uppercase">
                          Asal Sekolah:
                        </span>
                        <span className="font-black text-emerald-300 block truncate text-xs">
                          {student.sekolah}
                        </span>
                      </div>
                    </div>

                    {/* Action Button: Ubah Kolom Identitas 3D */}
                    <button
                      type="button"
                      onClick={handleOpenEditIdentity}
                      className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-slate-900 to-slate-800 hover:from-cyan-950/60 hover:to-slate-800 border-2 border-cyan-500/40 hover:border-cyan-400 text-cyan-200 hover:text-white font-mono font-black text-xs shadow-[0_4px_0_0_#0f172a] active:translate-y-1 active:shadow-none transition flex items-center justify-center gap-2 cursor-pointer select-none"
                    >
                      <Edit3 className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Ubah Kolom Identitas Siswa 3D</span>
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* Cinematic Neo-Academic Materi Kimia Section (Header + Coverflow + Bento Hybrid) */}
            <CinematicMateriSection
              student={student}
              onSelectTopic={(topicId) => {
                setSelectedMateriTopicId(topicId);
                setActiveView('materi');
              }}
              onViewAllMateri={() => {
                setSelectedMateriTopicId(null);
                setActiveView('materi');
              }}
              onNavigateToView={(view) => {
                setActiveView(view);
              }}
            />
          </main>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#070B18] text-[#F8FAFC] relative overflow-hidden flex flex-col">
      {/* Cool Chemistry Animation Background with Lightweight/3D Mode Support */}
      {activeView === null && <HeroMoleculeBackground forceLightweight={isLightweight} />}

      {/* Background Subtle Ambient Glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-1/2 right-10 w-96 h-96 bg-indigo-600/10 rounded-full blur-[140px] pointer-events-none" />

      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-30 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md px-4 sm:px-8 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Logo & Brand */}
          <div
            onClick={() => setActiveView(null)}
            className="flex items-center gap-3 cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 shadow-md shadow-cyan-500/20">
              <div className="w-full h-full rounded-[10px] bg-slate-950 flex items-center justify-center">
                <Atom className="w-5 h-5 text-cyan-400 animate-spin" style={{ animationDuration: '10s' }} />
              </div>
            </div>
            <div>
              <span className="font-extrabold text-base tracking-tight text-white block">
                ChemiVerse SMA
              </span>
              <span className="text-[11px] font-mono text-cyan-400">
                Media Pembelajaran Kimia 3D
              </span>
            </div>
          </div>

          {/* Student Status, Performance Mode Toggle & Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            {/* Tombol Cara Kerja Aplikasi */}
            <button
              onClick={() => setIsCaraKerjaOpen(true)}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl border border-cyan-500/40 bg-cyan-950/50 hover:bg-cyan-900/70 text-cyan-200 text-xs font-mono font-bold flex items-center gap-1.5 transition cursor-pointer select-none shadow-sm"
              title="Buka panduan alur kerja aplikasi & pelacakan aktivitas belajar"
            >
              <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Cara Kerja</span>
            </button>

            {/* Tombol Dasbor Guru (Fase 3: Guru & Deteksi Miskonsepsi) - Desktop */}
            <button
              onClick={handleOpenGuruDashboard}
              className={`hidden md:flex px-3 py-1.5 rounded-xl border text-xs font-mono font-bold items-center gap-1.5 transition cursor-pointer select-none ${
                activeView === 'guru'
                  ? 'bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 text-white border-indigo-300 shadow-md shadow-indigo-600/30 font-black'
                  : student.role === 'guru' || userDoc?.role === 'guru'
                  ? 'bg-indigo-950/70 hover:bg-indigo-900/80 border-indigo-400 text-indigo-200'
                  : 'bg-indigo-950/40 hover:bg-indigo-900/50 border-indigo-500/30 text-indigo-300'
              }`}
              title="Buka Dasbor Guru & Analisis Miskonsepsi Kelas"
            >
              <GraduationCap className="w-3.5 h-3.5 text-indigo-400" />
              <span>Dasbor Guru</span>
              {(student.role === 'guru' || userDoc?.role === 'guru') && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              )}
            </button>

            {/* Tombol Kumpulan Rumus - Desktop */}
            <button
              onClick={() => setActiveView(activeView === 'rumus' ? null : 'rumus')}
              className={`hidden md:flex px-3 py-1.5 rounded-xl border text-xs font-mono font-bold items-center gap-1.5 transition cursor-pointer select-none ${
                activeView === 'rumus'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-slate-950 border-cyan-300 shadow-md shadow-cyan-500/30 font-black'
                  : 'bg-cyan-950/40 hover:bg-cyan-900/50 border-cyan-500/40 text-cyan-300'
              }`}
              title="Buka Kumpulan Rumus Kimia SMA & Kalkulator Mini"
            >
              <BookOpen className="w-3.5 h-3.5 text-cyan-300" />
              <span>Kumpulan Rumus</span>
            </button>

            {/* Tombol Peta Belajar Berkelok - Desktop */}
            <button
              onClick={() => setActiveView(activeView === 'peta' ? null : 'peta')}
              className={`hidden md:flex px-3 py-1.5 rounded-xl border text-xs font-mono font-bold items-center gap-1.5 transition cursor-pointer select-none ${
                activeView === 'peta'
                  ? 'bg-gradient-to-r from-cyan-500 to-teal-500 text-slate-950 border-cyan-300 shadow-md shadow-cyan-500/30 font-black'
                  : 'bg-cyan-950/40 hover:bg-cyan-900/50 border-cyan-500/40 text-cyan-300'
              }`}
              title="Buka Peta Belajar Berkelok (Jalur Materi Kimia)"
            >
              <Compass className="w-3.5 h-3.5 text-cyan-300" />
              <span>Peta Belajar</span>
            </button>

            {/* Direct Tes Diagnostik button - Desktop */}
            <button
              onClick={() => setActiveView('diagnostik')}
              className={`hidden sm:flex px-3 py-1.5 rounded-xl border text-xs font-mono font-bold items-center gap-1.5 transition cursor-pointer select-none ${
                activeView === 'diagnostik'
                  ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 shadow-sm shadow-cyan-500/20'
                  : 'bg-cyan-950/40 hover:bg-cyan-900/50 border-cyan-500/30 text-cyan-300'
              }`}
              title="Uji kesiapan prasyarat dengan 5 soal adaptif AI"
            >
              <Target className="w-3.5 h-3.5 text-cyan-400" />
              <span>Tes Diagnostik</span>
            </button>

            {/* 2. GENERATOR KUIS INSTAN: Buat Kuis AI button in Top Nav */}
            <button
              onClick={() => setIsQuizGeneratorOpen(true)}
              className="hidden lg:flex px-3 py-1.5 rounded-xl border text-xs font-mono font-bold items-center gap-1.5 transition cursor-pointer select-none bg-gradient-to-r from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 border-cyan-400/50 text-cyan-200 shadow-sm shadow-cyan-500/10"
              title="Buat Kuis Pilihan Ganda Instan dari Teks Materi dengan Gemini AI"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>Buat Kuis AI</span>
            </button>

            {/* Performance Mode Switch (Mode Ringan / Mode 3D) */}
            <button
              onClick={togglePerformanceMode}
              className={`px-2.5 sm:px-3 py-1.5 rounded-xl border text-xs font-mono font-bold flex items-center gap-1.5 transition cursor-pointer select-none ${
                isLightweight
                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/25 shadow-sm'
                  : 'bg-white/[0.04] border-white/10 text-slate-300 hover:text-white hover:bg-white/[0.08]'
              }`}
              title={
                isLightweight
                  ? 'Mode Ringan Aktif: Animasi ultra-ringan, konsumsi CPU < 1%, proses super instan'
                  : 'Klik untuk beralih ke Mode Ringan (Super Cepat & Hemat Baterai)'
              }
            >
              <Zap className={`w-3.5 h-3.5 ${isLightweight ? 'text-emerald-400 fill-emerald-400' : 'text-cyan-400'}`} />
              <span className="hidden sm:inline">
                {isLightweight ? 'Mode Ringan: ON' : 'Grafis 3D: ON'}
              </span>
              <span className="sm:hidden text-[11px]">
                {isLightweight ? 'Ringan' : '3D'}
              </span>
            </button>

            {/* Cloud Firestore Status Badge - Desktop */}
            <div className="hidden xl:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-teal-500/30 text-teal-300 font-mono text-[11px]">
              <Cloud className="w-3.5 h-3.5 text-teal-400" />
              <span>Connected</span>
            </div>

            {/* Student Pill displaying saved name with 3D click action */}
            <div
              onClick={handleOpenEditIdentity}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border-2 border-slate-700/80 hover:border-cyan-400/80 cursor-pointer shadow-[0_3px_0_0_#0f172a] active:translate-y-0.5 transition select-none group"
              title="Klik untuk melihat / mengubah Kolom Identitas Siswa 3D"
            >
              <div className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-300 font-mono text-xs font-bold flex items-center justify-center border border-cyan-400/30 group-hover:scale-105 transition-transform">
                {student.namaLengkap ? student.namaLengkap.charAt(0) : 'S'}
              </div>
              <div className="text-left text-xs">
                <span className="font-bold text-slate-200 group-hover:text-cyan-300 block truncate max-w-[110px] transition-colors">
                  {student.namaLengkap}
                </span>
              </div>
              <Edit3 className="w-3 h-3 text-slate-500 group-hover:text-cyan-400" />
            </div>

            {/* 2. SISTEM POIN & LENCANA: Tampilkan XP user di pojok kanan atas */}
            <button
              onClick={() => setIsAchievementsModalOpen(true)}
              className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/40 text-amber-300 font-mono text-xs font-bold transition cursor-pointer shadow-sm shadow-amber-500/10 select-none group"
              title="Buka Modal Pencapaian & Lencana"
            >
              <Award className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
              <span className="text-amber-200 font-black">
                {userDoc?.xp ?? student.xp ?? 250} XP
              </span>
            </button>

            {/* Change Profile / Logout */}
            <button
              onClick={onLogout}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-rose-400 transition cursor-pointer"
              title="Keluar / Logout Akun Google"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Render Active View (Menu Cards Grid or Selected Module) */}
      <div className="flex-1 pb-20 md:pb-6">
        {renderActiveView()}
      </div>

      {/* Floating Bottom Navigation Dock for Mobile Devices (Fast 1-tap navigation on smartphones) */}
      <nav
        aria-label="Navigasi Ponsel Cepat"
        className="md:hidden fixed bottom-3 inset-x-3 z-40 bg-slate-950/90 backdrop-blur-2xl border border-cyan-500/20 rounded-2xl p-1.5 shadow-[0_8px_32px_rgba(0,0,0,0.6)] flex items-center justify-around"
      >
        <button
          onClick={() => setActiveView(null)}
          className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition ${
            activeView === null ? 'text-cyan-400 bg-cyan-500/15 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Home className="w-4 h-4" />
          <span className="text-[10px] font-mono">Beranda</span>
        </button>

        <button
          onClick={() => setActiveView('peta')}
          className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition ${
            activeView === 'peta' ? 'text-cyan-400 bg-cyan-500/15 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Compass className="w-4 h-4" />
          <span className="text-[10px] font-mono">Peta</span>
        </button>

        <button
          onClick={() => setActiveView('rumus')}
          className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition ${
            activeView === 'rumus' ? 'text-cyan-400 bg-cyan-500/15 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span className="text-[10px] font-mono">Rumus</span>
        </button>

        <button
          onClick={() => setActiveView('diagnostik')}
          className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition ${
            activeView === 'diagnostik' ? 'text-cyan-400 bg-cyan-500/15 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Target className="w-4 h-4" />
          <span className="text-[10px] font-mono">Diagnostik</span>
        </button>

        <button
          onClick={() => setIsQuizGeneratorOpen(true)}
          className="flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl text-slate-400 hover:text-cyan-300 transition"
        >
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <span className="text-[10px] font-mono">Kuis AI</span>
        </button>

        <button
          onClick={() => setActiveView('guru')}
          className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition ${
            activeView === 'guru' ? 'text-indigo-400 bg-indigo-500/15 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <GraduationCap className="w-4 h-4 text-indigo-400" />
          <span className="text-[10px] font-mono">Guru</span>
        </button>
      </nav>

      {/* Modal Pencapaian Lencana & XP */}
      <ModalPencapaian
        isOpen={isAchievementsModalOpen}
        onClose={() => setIsAchievementsModalOpen(false)}
        user={userDoc}
      />

      {/* 2. GENERATOR KUIS INSTAN (TEXT-TO-QUIZ) MODAL */}
      <GeneratorKuisAIModal
        isOpen={isQuizGeneratorOpen}
        onClose={() => setIsQuizGeneratorOpen(false)}
        student={student}
        onAddXP={handleAddXP}
      />

      {/* 3. TUTOR AI (CHATBOT): Floating Action Button di pojok kanan bawah terhubung ke Gemini API dengan Mode Ringan */}
      <TutorChatBox student={student} isLightweight={isLightweight} />

      {/* MODAL UBAH KOLOM IDENTITAS SISWA KIMIA 3D */}
      {isIdentityModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-2xl rounded-3xl bg-slate-900 border-[3px] border-cyan-400/50 shadow-[0_25px_60px_rgba(8,145,178,0.35),0_12px_0_0_#0f172a] p-6 sm:p-8 space-y-5 text-left relative overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between border-b-2 border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-950 border-2 border-cyan-400/50 shadow-[0_4px_0_0_#0f172a] overflow-hidden shrink-0 relative flex items-center justify-center">
                  <Suspense fallback={<div className="w-full h-full bg-cyan-500/20" />}>
                    <LazyStudentIdentity3DCanvas role={editRole} />
                  </Suspense>
                </div>
                <div>
                  <h2
                    className="text-xl sm:text-2xl font-black text-white"
                    style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                  >
                    Ubah Kolom Identitas Siswa 3D
                  </h2>
                  <p className="text-xs text-slate-400 font-medium">
                    Perbarui profil kimia dan sinkronkan ke Cloud Firestore.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsIdentityModalOpen(false)}
                className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition border border-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form 2 Kolom */}
            <form onSubmit={handleSaveIdentity} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Kolom 1: Peran & Nama */}
                <div className="space-y-3 p-4 rounded-2xl bg-slate-950/80 border-2 border-slate-800 shadow-[0_4px_0_0_#0f172a]">
                  <label className="block text-xs font-black uppercase text-cyan-300">
                    Peran Akun
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setEditRole('siswa')}
                      className={`py-2 px-2.5 rounded-xl border-2 text-xs font-black transition cursor-pointer flex items-center justify-center gap-1.5 active:translate-y-0.5 ${
                        editRole === 'siswa'
                          ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_3px_0_0_#0e7490]'
                          : 'bg-slate-900 border-slate-700 text-slate-400'
                      }`}
                    >
                      <UserIcon className="w-3.5 h-3.5" />
                      <span>Siswa</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditRole('guru')}
                      className={`py-2 px-2.5 rounded-xl border-2 text-xs font-black transition cursor-pointer flex items-center justify-center gap-1.5 active:translate-y-0.5 ${
                        editRole === 'guru'
                          ? 'bg-indigo-600/30 border-indigo-400 text-white shadow-[0_3px_0_0_#3730a3]'
                          : 'bg-slate-900 border-slate-700 text-slate-400'
                      }`}
                    >
                      <GraduationCap className="w-3.5 h-3.5" />
                      <span>Guru</span>
                    </button>
                  </div>

                  <div>
                    <label className="block text-xs font-black uppercase text-slate-300 mb-1">
                      Nama Lengkap
                    </label>
                    <input
                      type="text"
                      required
                      value={editNama}
                      onChange={(e) => setEditNama(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border-2 border-slate-700 text-white text-xs font-bold shadow-[inset_0_2px_4px_rgba(0,0,0,0.5),0_3px_0_0_#0f172a] focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                {/* Kolom 2: Kelas & Sekolah */}
                <div className="space-y-3 p-4 rounded-2xl bg-slate-950/80 border-2 border-slate-800 shadow-[0_4px_0_0_#0f172a]">
                  <div>
                    <label className="block text-xs font-black uppercase text-emerald-300 mb-1">
                      Tingkat Kelas
                    </label>
                    <input
                      type="text"
                      required
                      value={editKelas}
                      onChange={(e) => setEditKelas(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border-2 border-slate-700 text-white text-xs font-bold shadow-[inset_0_2px_4px_rgba(0,0,0,0.5),0_3px_0_0_#0f172a] focus:outline-none focus:border-emerald-400"
                    />
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {['Kelas 10', 'Kelas 11', 'Kelas 12', 'UTBK'].map((sug) => (
                        <button
                          key={sug}
                          type="button"
                          onClick={() => setEditKelas(`${sug} SMA`)}
                          className="px-2 py-0.5 rounded-lg border border-slate-700 text-[10px] font-mono text-slate-400 hover:text-white hover:border-emerald-400"
                        >
                          {sug}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-black uppercase text-slate-300 mb-1">
                      Asal Sekolah
                    </label>
                    <input
                      type="text"
                      required
                      value={editSekolah}
                      onChange={(e) => setEditSekolah(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border-2 border-slate-700 text-white text-xs font-bold shadow-[inset_0_2px_4px_rgba(0,0,0,0.5),0_3px_0_0_#0f172a] focus:outline-none focus:border-emerald-400"
                    />
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsIdentityModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-700 text-xs font-bold text-slate-300 hover:text-white cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSavingIdentity}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-teal-300 text-slate-950 font-black text-xs border-2 border-cyan-200 border-b-4 border-b-cyan-700 shadow-[0_4px_0_0_#0e7490] active:translate-y-1 active:shadow-none transition flex items-center gap-2 cursor-pointer"
                >
                  <Box className="w-4 h-4" />
                  <span>{isSavingIdentity ? 'Menyimpan...' : 'Simpan Identitas 3D'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Cara Kerja Modal */}
      <CaraKerjaModal
        isOpen={isCaraKerjaOpen}
        onClose={() => setIsCaraKerjaOpen(false)}
        onOpenDashboardGuru={() => {
          setIsCaraKerjaOpen(false);
          handleOpenGuruDashboard();
        }}
      />

      {/* MODAL PROTEKSI & KUNCI DASBOR GURU */}
      {isGuruAuthModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in text-left">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border-2 border-indigo-500/50 p-6 space-y-4 text-left shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center text-indigo-300 font-bold">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white">Dasbor Guru Terkunci</h3>
                  <p className="text-[11px] text-indigo-300 font-mono">Verifikasi Kredensial Guru Kimia</p>
                </div>
              </div>
              <button
                onClick={() => setIsGuruAuthModalOpen(false)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Halaman ini khusus untuk Pendidik/Guru Kimia. Masukkan username dan password untuk membuka kunci Dasbor Guru.
            </p>

            {guruAuthError && (
              <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-bold font-mono">
                {guruAuthError}
              </div>
            )}

            <form onSubmit={handleVerifyGuruAuth} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-mono font-bold text-slate-300 mb-1">
                  Username Guru:
                </label>
                <input
                  type="text"
                  required
                  value={guruInputUser}
                  onChange={(e) => setGuruInputUser(e.target.value)}
                  placeholder="Masukkan username guru"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono focus:outline-none focus:border-indigo-400"
                />
              </div>

              <div>
                <label className="block font-mono font-bold text-slate-300 mb-1">
                  Password Guru:
                </label>
                <input
                  type="password"
                  required
                  value={guruInputPass}
                  onChange={(e) => setGuruInputPass(e.target.value)}
                  placeholder="Masukkan password guru"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono focus:outline-none focus:border-indigo-400"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs shadow-lg shadow-indigo-600/30 transition cursor-pointer flex items-center justify-center gap-2"
              >
                <GraduationCap className="w-4 h-4" />
                <span>Buka Kunci Dasbor Guru ➔</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
