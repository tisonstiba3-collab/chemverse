import React, { useState } from 'react';
import {
  QrCode,
  Send,
  CheckCircle2,
  ArrowLeft,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Clock,
  CreditCard,
  MessageCircle,
} from 'lucide-react';
import { useKakKimiaVoice } from '../../hooks/useKakKimiaVoice';
import VoiceToggleButton from './VoiceToggleButton';
import ChemistryLoginBackground from '../chemistry/ChemistryLoginBackground';
import {
  setStudentStatusPending,
  registerStudentToSupabase,
} from '../../services/supabaseService';
import {
  getOrCreateStudentAccount,
  updateStudentStatus,
  saveStudentAccount,
  appendActivationLog,
  generateAdminVerifyId,
} from '../../services/studentVerificationStore';
import { buildVerificationMessage, openWA } from '../../shared/waTemplates';
import { ADMIN_WA_NUMBER } from '../../config';
import { StudentAccount } from '../../shared/types';

interface OnboardingPaymentViewProps {
  onBack: () => void;
  onPaid: () => void;
}

export default function OnboardingPaymentView({
  onBack,
  onPaid,
}: OnboardingPaymentViewProps) {
  // Voice Mute State
  const [isMuted, setIsMuted] = useState<boolean>(() => {
    return localStorage.getItem('chemverse_kak_kimia_muted') === 'true';
  });

  const toggleMute = () => {
    setIsMuted((prev) => {
      const next = !prev;
      localStorage.setItem('chemverse_kak_kimia_muted', String(next));
      return next;
    });
  };

  // Ambil data identitas siswa dari localStorage
  const identityData = (() => {
    try {
      const saved = localStorage.getItem('chemverse_student_identity');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      // ignore
    }
    return {
      id: localStorage.getItem('chemverse_student_sub_id') || `std_${Date.now()}`,
      nama: localStorage.getItem('chemverse_nama') || 'Siswa Kimia',
      kelas: localStorage.getItem('chemverse_kelas') || 'Kelas 11 SMA',
      sekolah: localStorage.getItem('chemverse_sekolah') || 'SMA Negeri',
    };
  })();

  const namaSiswa = identityData.nama || 'Siswa Kimia';

  // TUGAS 3.1: Suara Otomatis Kak Kimia saat Halaman 2 dimuat
  const speechText = `Selamat datang, ${namaSiswa}! Pada halaman ini, silakan klik menu Konfirmasi via WhatsApp. Kamu akan diarahkan menuju WhatsApp dengan pesan verifikasi otomatis untuk mengirim bukti pembayaran. Kemudian tunggu hingga admin mengkonfirmasi agar akunmu diaktifkan.`;

  const { isSpeaking } = useKakKimiaVoice(speechText, isMuted);

  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [isWaSent, setIsWaSent] = useState(false);

  // BAGIAN 3 Langkah 3.1: Handler tombol "Konfirmasi via WhatsApp"
  const handleKonfirmasiWhatsApp = async () => {
    const studentId =
      identityData.id ||
      localStorage.getItem('chemverse_student_sub_id') ||
      `std_${Date.now()}`;
    const now = Date.now();

    // 1. Pastikan akun siswa dibuat/diambil dengan adminVerifyId & activationToken
    const currentAccount = getOrCreateStudentAccount({
      id: studentId,
      name: identityData.nama,
      classId: identityData.kelas,
      school: identityData.sekolah,
    });

    // 2. Ubah status siswa menjadi 'pending_verify'
    const updated = updateStudentStatus(
      currentAccount.id,
      'pending_verify',
      'student',
      'Siswa menekan Konfirmasi via WhatsApp'
    );

    // 3. Catat paymentProofSentAt
    const finalAccount: StudentAccount = {
      ...(updated || currentAccount),
      status: 'pending_verify',
      paymentProofSentAt: now,
    };
    saveStudentAccount(finalAccount);

    // 4. Catat ActivationLog action='submitted'
    appendActivationLog({
      id: generateAdminVerifyId(),
      studentId: finalAccount.id,
      action: 'submitted',
      by: 'student',
      at: now,
      note: 'Bukti pembayaran dikirim ke WhatsApp admin',
    });

    // Sinkronisasi status di Supabase & localStorage
    try {
      await setStudentStatusPending(finalAccount.id, {
        nama: finalAccount.name,
        kelas: finalAccount.classId,
        sekolah: finalAccount.school,
      });
    } catch (e) {
      console.warn('Sync pending status warning:', e);
    }

    // 5. Panggil openWA(ADMIN_WA_NUMBER, buildVerificationMessage(siswa))
    const message = buildVerificationMessage(finalAccount);
    openWA(ADMIN_WA_NUMBER, message);

    setIsWaSent(true);
  };

  // TUGAS 3.4: Handler tombol "Saya Sudah Bayar"
  const handleSayaSudahBayar = async () => {
    setIsUpdatingStatus(true);
    try {
      const studentId = identityData.id || localStorage.getItem('chemverse_student_sub_id') || `std_${Date.now()}`;
      
      // Simpan / update status di Supabase menjadi 'pending'
      await setStudentStatusPending(studentId, {
        nama: identityData.nama,
        kelas: identityData.kelas,
        sekolah: identityData.sekolah,
      });

      // Arahkan ke Halaman 3 (Pending Gate)
      onPaid();
    } catch (err) {
      console.warn('Gagal set status pending:', err);
      // Tetap lanjutkan ke halaman pending agar alur tidak macet
      onPaid();
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center p-4 py-8 overflow-y-auto bg-[#040714] font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      <ChemistryLoginBackground />

      {/* TUGAS 1.5: Tombol Suara Aktif / Bisu di Pojok Kanan Atas */}
      <div className="fixed top-5 right-5 z-50">
        <VoiceToggleButton
          isMuted={isMuted}
          onToggleMute={toggleMute}
          isSpeaking={isSpeaking}
        />
      </div>

      <div className="relative z-10 w-full max-w-2xl my-auto">
        {/* Glow Effects */}
        <div className="absolute -top-12 -left-12 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/85 border border-cyan-500/30 shadow-2xl backdrop-blur-2xl space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={onBack}
              className="px-3 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-300 hover:text-white text-xs font-mono transition flex items-center gap-1.5 cursor-pointer border border-white/10"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Ubah Identitas</span>
            </button>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 text-xs font-mono font-bold">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>LANGKAH 2 DARI 2</span>
            </div>
          </div>

          <div className="space-y-1.5 text-center">
            <h1
              className="text-2xl sm:text-3xl font-black text-white tracking-tight"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Sistem Langganan Chemverse
            </h1>
            <p className="text-xs sm:text-sm text-slate-300">
              Halo, <strong className="text-cyan-400">{namaSiswa}</strong> ({identityData.kelas} • {identityData.sekolah}).
            </p>
          </div>

          {/* Audio Avatar Indicator */}
          <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/20 text-xs text-cyan-200">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center font-bold text-sm shrink-0">
              🎙️
            </div>
            <div className="space-y-0.5">
              <span className="font-bold text-white flex items-center gap-1.5 font-mono">
                Kak Kimia (Asisten Suara)
                {isSpeaking && (
                  <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                )}
              </span>
              <p className="text-[11px] text-slate-400">
                Kirim bukti transfer ke WhatsApp Admin, lalu klik tombol "Saya Sudah Bayar" di bawah.
              </p>
            </div>
          </div>

          {/* Card Info Pembayaran & QRIS */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Box Transfer / QRIS */}
            <div className="p-4 sm:p-5 rounded-2xl bg-white/[0.03] border border-white/10 space-y-3 flex flex-col items-center text-center justify-center">
              <div className="w-40 h-40 sm:w-44 sm:h-44 rounded-2xl bg-white p-2.5 shadow-xl flex items-center justify-center border border-white/20">
                <img
                  src="/qris.png"
                  alt="QRIS Chemverse"
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    // Fallback jika file gambar tidak ditemukan
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
                <div className="hidden only:flex flex-col items-center justify-center text-slate-800">
                  <QrCode className="w-16 h-16 text-slate-700" />
                  <span className="text-[10px] font-mono mt-1 font-bold">QRIS CHEMVERSE</span>
                </div>
              </div>
              <div className="space-y-0.5">
                <span className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                  Scan QRIS / Transfer Bank
                </span>
                <p className="text-sm font-bold text-white">Biaya: Rp 50.000 / 60 Hari</p>
                <p className="text-[11px] text-cyan-400 font-mono">Akses Penuh Semua Materi & Game 3D</p>
              </div>
            </div>

            {/* Box Instruksi */}
            <div className="p-4 sm:p-5 rounded-2xl bg-white/[0.03] border border-white/10 space-y-3.5 flex flex-col justify-between">
              <div className="space-y-2.5 text-xs text-slate-300">
                <h3 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Alur Aktivasi Instan</span>
                </h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      1
                    </span>
                    <span>Lakukan transfer atau scan QRIS sebesar <strong>Rp 50.000</strong>.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      2
                    </span>
                    <span>
                      Klik tombol <strong>"Buka WhatsApp Admin"</strong> untuk kirim bukti transfer.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                      3
                    </span>
                    <span>
                      Klik <strong>"Saya Sudah Bayar"</strong> dan tunggu verifikasi instan dari admin.
                    </span>
                  </li>
                </ul>
              </div>

              {/* Info Admin */}
              <div className="p-3 rounded-xl bg-slate-950/70 border border-white/5 space-y-1 text-xs">
                <span className="text-[10px] font-mono text-slate-400 uppercase">Kontak Admin Resmi:</span>
                <p className="font-mono font-bold text-emerald-400 flex items-center gap-1.5">
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>+62 821-4575-0970</span>
                </p>
              </div>
            </div>
          </div>

          {/* Action Buttons: TUGAS 3.3 & TUGAS 3.4 */}
          <div className="space-y-3 pt-2">
            {/* Tombol Besar "Konfirmasi via WhatsApp" (BAGIAN 3 Langkah 3.1) */}
            <button
              type="button"
              onClick={handleKonfirmasiWhatsApp}
              className="w-full py-4 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-sm tracking-wide shadow-xl shadow-emerald-600/30 transition-all duration-300 flex items-center justify-center gap-2.5 cursor-pointer text-center group"
            >
              <Send className="w-4 h-4 group-hover:scale-110 transition-transform" />
              <span>Konfirmasi via WhatsApp</span>
              <ExternalLink className="w-3.5 h-3.5 text-emerald-200" />
            </button>

            {/* Petunjuk Setelah WhatsApp Terbuka (BAGIAN 3 Langkah 3.1) */}
            {isWaSent && (
              <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-200 text-xs space-y-2 animate-fade-in text-left">
                <p className="font-bold text-emerald-300 flex items-center gap-1.5 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Pesan WhatsApp sudah disiapkan. Tinggal:
                </p>
                <ol className="list-decimal list-inside space-y-1 text-xs text-slate-200 pl-1 font-medium">
                  <li>Lampirkan foto bukti transfer</li>
                  <li>Klik kirim</li>
                </ol>
                <p className="text-[11px] text-slate-300 pt-1 border-t border-emerald-500/20">
                  Admin akan mengaktifkan akun Anda via link yang ada di pesan itu.
                </p>
              </div>
            )}

            {/* Tombol "Saya Sudah Bayar" */}
            <button
              type="button"
              onClick={handleSayaSudahBayar}
              disabled={isUpdatingStatus}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-cyan-500 via-indigo-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-bold text-sm tracking-wide shadow-lg shadow-cyan-500/20 transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              {isUpdatingStatus ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Menyimpan status ke Supabase Cloud...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  <span>Saya Sudah Bayar</span>
                </>
              )}
            </button>
          </div>

          {/* Security Badge */}
          <div className="pt-2 border-t border-white/5 flex items-center justify-center gap-2 text-[11px] text-slate-400 font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
            <span>Verifikasi Otomatis Terhubung Database Cloud Supabase</span>
          </div>
        </div>
      </div>
    </div>
  );
}
