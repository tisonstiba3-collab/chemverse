import React from 'react';
import { Volume2, VolumeX, Sparkles } from 'lucide-react';

interface VoiceToggleButtonProps {
  isMuted: boolean;
  onToggleMute: () => void;
  isSpeaking?: boolean;
}

export default function VoiceToggleButton({
  isMuted,
  onToggleMute,
  isSpeaking = false,
}: VoiceToggleButtonProps) {
  return (
    <button
      type="button"
      onClick={onToggleMute}
      className={`px-3.5 py-1.5 rounded-full text-xs font-mono font-bold transition-all duration-300 flex items-center gap-2 cursor-pointer shadow-lg backdrop-blur-md border ${
        isMuted
          ? 'bg-rose-950/60 border-rose-500/40 text-rose-300 hover:bg-rose-900/60'
          : 'bg-cyan-950/70 border-cyan-400/50 text-cyan-200 hover:bg-cyan-900/70 hover:border-cyan-300'
      }`}
      title={isMuted ? 'Klik untuk mengaktifkan suara Kak Kimia' : 'Klik untuk membisukan suara Kak Kimia'}
    >
      {isMuted ? (
        <>
          <VolumeX className="w-4 h-4 text-rose-400 shrink-0" />
          <span>🔇 Suara Bisu</span>
        </>
      ) : (
        <>
          <div className="relative">
            <Volume2 className="w-4 h-4 text-cyan-300 shrink-0" />
            {isSpeaking && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            )}
          </div>
          <span className="flex items-center gap-1.5">
            <span>🔊 Suara Aktif</span>
            {isSpeaking && (
              <span className="text-[10px] text-emerald-300 font-sans tracking-wide">
                (Kak Kimia Bicara...)
              </span>
            )}
          </span>
        </>
      )}
    </button>
  );
}
