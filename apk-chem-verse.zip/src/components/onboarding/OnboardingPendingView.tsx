import React, { useState, useEffect, useRef } from 'react';
import {
  Clock,
  Send,
  Settings,
  RefreshCw,
  ExternalLink,
  ShieldAlert,
  CheckCircle2,
  Sparkles,
  Database,
  User,
  GraduationCap,
  School,
  X,
  Save,
} from 'lucide-react';
import { useKakKimiaVoice } from '../../hooks/useKakKimiaVoice';
import VoiceToggleButton from './VoiceToggleButton';
import ChemistryLoginBackground from '../chemistry/ChemistryLoginBackground';
import {
  checkStudentSubscriptionStatus,
  UserSubscriptionRecord,
} from '../../services/supabaseService';
import {
  getStudentAccountById,
} from '../../services/studentVerificationStore';
import { buildVerificationMessage, openWA } from '../../shared/waTemplates';
import { ADMIN_WA_NUMBER } from '../../config';

interface OnboardingPendingViewProps {
  onEditIdentity: () => void;
  onVerified: (record: UserSubscriptionRecord) => void;
}

export default function OnboardingPendingView({
  onEditIdentity,
  onVerified,
}: OnboardingPendingViewProps) {
  // Voice Mute State
  const [isMuted, setIsMuted] = useState<boolean>(() => {
    return localStorage.getItem('chemverse_kak_kimia_muted') === 'true';
  });

  const toggleMute = () => {
    setIsMuted((prev) => {
      const next = !prev;
      localStorage.setItem('chemverse_kak_kimia_muted', String(next));
      return next;
    });
  };

  // Ambil data identitas siswa dari localStorage
  const getStoredIdentity = () => {
    try {
      const saved = localStorage.getItem('chemverse_student_identity');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      // ignore
    }
    return {
      id: localStorage.getItem('chemverse_student_sub_id') || '',
      nama: localStorage.getItem('chemverse_nama') || 'Siswa Kimia',
      kelas: localStorage.getItem('chemverse_kelas') || 'Kelas 11 SMA',
      sekolah: localStorage.getItem('chemverse_sekolah') || 'SMA Negeri',
    };
  };

  const [studentIdentity, setStudentIdentity] = useState(getStoredIdentity);
  const namaSiswa = studentIdentity.nama || 'Siswa Kimia';

  // TUGAS 4.2: Suara Otomatis Kak Kimia saat Halaman 3 dimuat (Tegas & Lantang)
  const initialSpeechText = `Perhatian ${namaSiswa}! Status pembayaranmu saat ini PENDING dan sedang diverifikasi oleh Admin. Sistem memeriksa database secara otomatis setiap 3 detik. Halaman ini akan segera terbuka begitu akunmu diaktifkan.`;

  const [activeSpeechText, setActiveSpeechText] = useState(initialSpeechText);
  const { speak, isSpeaking } = useKakKimiaVoice(activeSpeechText, isMuted);

  // Status Polling State (5 Detik)
  const [countdown, setCountdown] = useState(5);
  const [isCheckingCloud, setIsCheckingCloud] = useState(false);
  const [isVerifiedSuccess, setIsVerifiedSuccess] = useState(false);
  const [verifiedRecord, setVerifiedRecord] = useState<UserSubscriptionRecord | null>(null);
  const [isRejected, setIsRejected] = useState(false);
  const [rejectedReason, setRejectedReason] = useState<string>('');

  // Handler kirim ulang konfirmasi WA dengan token yang sama (BAGIAN 3 Langkah 3.2)
  const handleKirimUlangWA = () => {
    const studentId = studentIdentity.id || localStorage.getItem('chemverse_student_sub_id') || '';
    const acc = getStudentAccountById(studentId);
    if (acc) {
      const message = buildVerificationMessage(acc);
      openWA(ADMIN_WA_NUMBER, message);
    }
  };

  // Modal Edit Identitas (Tombol Gerigi - TUGAS 4.1 & TUGAS 5)
  // Hanya mengubah Nama / Kelas / Sekolah, TIDAK ADA konfigurasi database Supabase
  const [showEditModal, setShowEditModal] = useState(false);
  const [editNama, setEditNama] = useState(studentIdentity.nama);
  const [editKelas, setEditKelas] = useState(studentIdentity.kelas);
  const [editSekolah, setEditSekolah] = useState(studentIdentity.sekolah);

  const pollingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const countdownIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const hasTriggeredSuccessRef = useRef(false);

  // Auto-Polling Supabase & Local/Firestore Store setiap 5 detik
  useEffect(() => {
    const studentId = studentIdentity.id || localStorage.getItem('chemverse_student_sub_id');
    if (!studentId) return;

    const performCheck = async () => {
      if (hasTriggeredSuccessRef.current) return;
      setIsCheckingCloud(true);

      try {
        // Cek store lokal dulu
        const localAcc = getStudentAccountById(studentId);
        if (localAcc?.status === 'rejected') {
          setIsRejected(true);
          setRejectedReason(localAcc.rejectedReason || 'Dibatalkan oleh admin');
          if (pollingIntervalRef.current) clearInterval(pollingIntervalRef.current);
          if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
          return;
        }

        const record = await checkStudentSubscriptionStatus(studentId);
        if (record && record.status === 'active') {
          hasTriggeredSuccessRef.current = true;
          setIsVerifiedSuccess(true);
          setVerifiedRecord(record);

          // Hentikan interval polling
          if (pollingIntervalRef.current) clearInterval(pollingIntervalRef.current);
          if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);

          // Panggil notifikasi suara selamat (Tegas & Bersemangat)
          const successSpeech = 'Akun Anda sudah aktif! Selamat datang di Chemverse!';
          setActiveSpeechText(successSpeech);
          speak(successSpeech);

          // Redirect otomatis ke Dashboard Utama Siswa dalam 1.5 detik
          setTimeout(() => {
            onVerified(record);
          }, 1500);
        } else if (record && (record.status === 'locked' || (record as any).status === 'rejected')) {
          setIsRejected(true);
          setRejectedReason((record as any).rejectedReason || 'Dibatalkan oleh admin');
          if (pollingIntervalRef.current) clearInterval(pollingIntervalRef.current);
          if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
        }
      } catch (err) {
        console.warn('Gagal cek status polling Supabase:', err);
      } finally {
        setIsCheckingCloud(false);
      }
    };

    // Jalankan pemeriksaan awal
    performCheck();

    // Set interval 5 detik untuk query status database
    pollingIntervalRef.current = setInterval(() => {
      setCountdown(5);
      performCheck();
    }, 5000);

    // Set timer visual countdown (5, 4, 3, 2, 1, 5...)
    countdownIntervalRef.current = setInterval(() => {
      setCountdown((prev) => (prev <= 1 ? 5 : prev - 1));
    }, 1000);

    return () => {
      if (pollingIntervalRef.current) clearInterval(pollingIntervalRef.current);
      if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    };
  }, [studentIdentity.id, onVerified, speak]);

  // Handler simpan perubahan identitas (HANYA Nama/Kelas/Sekolah - TUGAS 5)
  const handleSaveIdentity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editNama.trim() || !editSekolah.trim()) return;

    const updated = {
      ...studentIdentity,
      nama: editNama.trim(),
      kelas: editKelas.trim(),
      sekolah: editSekolah.trim(),
    };

    setStudentIdentity(updated);
    localStorage.setItem('chemverse_student_identity', JSON.stringify(updated));
    localStorage.setItem('chemverse_nama', updated.nama);
    localStorage.setItem('chemverse_kelas', updated.kelas);
    localStorage.setItem('chemverse_sekolah', updated.sekolah);
    setShowEditModal(false);
  };

  // BAGIAN 3 Langkah 3.3: Tampilan jika akun berstatus rejected / nonaktif
  if (isRejected) {
    return (
      <div className="relative min-h-screen w-full flex items-center justify-center p-4 bg-[#040714] font-sans text-slate-100">
        <ChemistryLoginBackground />
        <div className="relative z-10 w-full max-w-md p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-rose-500/40 shadow-2xl backdrop-blur-2xl text-center space-y-5">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
            <ShieldAlert className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <h2 className="text-xl font-bold text-white">Akun Belum Diaktifkan</h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Akun Anda belum diaktifkan oleh admin.
            </p>
            <div className="p-3 rounded-xl bg-slate-950/70 border border-rose-500/30 text-rose-300 text-xs font-mono">
              Alasan: {rejectedReason || 'Belum ada keterangan'}
            </div>
            <p className="text-xs text-slate-400">
              Hubungi admin kalau ada pertanyaan.
            </p>
          </div>

          <div className="space-y-3 pt-2">
            <button
              type="button"
              onClick={() => {
                const text = `Halo Admin, saya ${namaSiswa}. Akun saya belum aktif dengan alasan: ${rejectedReason || 'Belum ada keterangan'}. Mohon bantuannya.`;
                openWA(ADMIN_WA_NUMBER, text);
              }}
              className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-semibold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-900/30"
            >
              <Send className="w-4 h-4" />
              <span>Hubungi Admin via WA</span>
            </button>
            <button
              type="button"
              onClick={() => {
                localStorage.clear();
                sessionStorage.clear();
                window.location.reload();
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs transition-all border border-slate-700 cursor-pointer"
            >
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center p-4 py-8 overflow-y-auto bg-[#040714] font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      <ChemistryLoginBackground />

      {/* TUGAS 1.5: Tombol Suara Aktif / Bisu di Pojok Kanan Atas */}
      <div className="fixed top-5 right-5 z-50">
        <VoiceToggleButton
          isMuted={isMuted}
          onToggleMute={toggleMute}
          isSpeaking={isSpeaking}
        />
      </div>

      <div className="relative z-10 w-full max-w-xl my-auto">
        {/* Glow Effects */}
        <div className="absolute -top-12 -left-12 w-64 h-64 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-64 h-64 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-amber-500/40 shadow-2xl backdrop-blur-2xl space-y-6 relative overflow-hidden">
          {/* Header Action Bar */}
          <div className="flex items-center justify-between">
            {/* Tombol Gerigi: Ubah Identitas Siswa (TUGAS 4.1 & TUGAS 5) */}
            <button
              type="button"
              onClick={() => {
                setEditNama(studentIdentity.nama);
                setEditKelas(studentIdentity.kelas);
                setEditSekolah(studentIdentity.sekolah);
                setShowEditModal(true);
              }}
              className="px-3.5 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-300 hover:text-white text-xs font-mono transition flex items-center gap-1.5 cursor-pointer border border-white/10"
              title="Ubah Nama, Kelas, atau Sekolah"
            >
              <Settings className="w-3.5 h-3.5 text-amber-400" />
              <span>Ubah Identitas Siswa</span>
            </button>

            <span className="px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold">
              STATUS: PENDING
            </span>
          </div>

          {/* Sukses Banner jika sudah diverifikasi */}
          {isVerifiedSuccess ? (
            <div className="p-6 rounded-2xl bg-emerald-500/20 border-2 border-emerald-400 text-center space-y-2 animate-bounce-subtle">
              <CheckCircle2 className="w-14 h-14 text-emerald-400 mx-auto" />
              <h2 className="text-xl sm:text-2xl font-black text-white">Akun Anda sudah aktif!</h2>
              <p className="text-xs sm:text-sm text-emerald-200 font-mono">
                Selamat belajar di Chemverse. Mengarahkan otomatis ke Dashboard Siswa...
              </p>
            </div>
          ) : (
            <>
              {/* Teks Judul & Deskripsi (TUGAS 4.1) */}
              <div className="space-y-2 text-center">
                <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 mx-auto flex items-center justify-center font-bold text-2xl shadow-lg shadow-amber-500/10 animate-pulse">
                  ⏳
                </div>
                <h1
                  className="text-2xl sm:text-3xl font-black text-white tracking-tight"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  Akses Tertahan (Status: PENDING)
                </h1>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-md mx-auto">
                  Halo <strong className="text-amber-400">{namaSiswa}</strong>! Pembayaranmu sedang dalam proses verifikasi oleh Admin. Setelah Admin mengklik link verifikasi, halaman ini akan otomatis terbuka!
                </p>
              </div>

              {/* Status Polling Card (TUGAS 4.1) */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-white/10 space-y-3">
                <div className="flex items-center justify-between text-xs font-mono">
                  <div className="flex items-center gap-2 text-cyan-300">
                    <Database className="w-4 h-4 text-cyan-400 animate-spin" />
                    <span>Mengecek Status Supabase Cloud...</span>
                  </div>
                  <span className="text-amber-400 font-bold bg-amber-500/10 px-2.5 py-0.5 rounded-lg border border-amber-500/20">
                    Cek ulang dalam: {countdown} s
                  </span>
                </div>

                <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-amber-400 to-cyan-400 h-1.5 transition-all duration-1000 ease-linear rounded-full"
                    style={{ width: `${((5 - countdown) / 5) * 100}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1 border-t border-white/5">
                  <span>ID Pendaftar: {studentIdentity.id?.slice(0, 14)}...</span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span>Cloud Sync Aktif (5s)</span>
                  </span>
                </div>
              </div>

              {/* Audio Avatar Indicator */}
              <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/20 text-xs text-cyan-200">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center font-bold text-sm shrink-0">
                  🎙️
                </div>
                <div className="space-y-0.5">
                  <span className="font-bold text-white flex items-center gap-1.5 font-mono">
                    Kak Kimia (Asisten Suara)
                    {isSpeaking && (
                      <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    )}
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Silakan tinggalkan halaman ini tetap terbuka atau hubungi Admin WhatsApp jika butuh konfirmasi cepat.
                  </p>
                </div>
              </div>

              {/* Tombol: "Kirim Ulang Konfirmasi WA" (BAGIAN 3 Langkah 3.2) */}
              <div className="space-y-3 pt-2">
                <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/20 text-xs text-slate-300 leading-relaxed text-left">
                  <p className="font-semibold text-cyan-300">Konfirmasi Anda sudah dikirim ke admin.</p>
                  <p className="text-slate-400 mt-0.5">
                    Admin akan mengaktifkan akun Anda setelah memverifikasi pembayaran. Biasanya &lt; 1×24 jam.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleKirimUlangWA}
                  className="w-full py-3.5 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-sm tracking-wide shadow-lg shadow-emerald-600/30 transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer text-center group"
                >
                  <Send className="w-4 h-4 group-hover:scale-110 transition-transform" />
                  <span>Kirim Ulang Konfirmasi WA</span>
                  <ExternalLink className="w-3.5 h-3.5 text-emerald-200" />
                </button>

                <p className="text-[11px] text-slate-400 text-center font-mono">
                  Nomor WhatsApp Admin Resmi: <span className="text-white font-bold">+62 821-4575-0970</span>
                </p>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Modal Ubah Identitas Siswa (Tombol Gerigi - TUGAS 5) */}
      {/* Keamanan: HANYA mengubah Nama, Kelas, Sekolah. TIDAK ADA akses URL/ANON KEY Supabase */}
      {showEditModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-md p-6 rounded-3xl bg-slate-900 border border-cyan-500/30 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Settings className="w-4 h-4 text-cyan-400" />
                <span>Ubah Identitas Siswa</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowEditModal(false)}
                className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveIdentity} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-mono font-semibold text-slate-300 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Nama Siswa</span>
                </label>
                <input
                  type="text"
                  required
                  value={editNama}
                  onChange={(e) => setEditNama(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-white text-sm focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-mono font-semibold text-slate-300 flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Kelas SMA</span>
                </label>
                <select
                  value={editKelas}
                  onChange={(e) => setEditKelas(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-white text-sm focus:outline-none focus:border-cyan-400 cursor-pointer"
                >
                  <option value="Kelas 10 SMA" className="bg-slate-900 text-white">Kelas 10 SMA</option>
                  <option value="Kelas 11 SMA" className="bg-slate-900 text-white">Kelas 11 SMA</option>
                  <option value="Kelas 12 SMA" className="bg-slate-900 text-white">Kelas 12 SMA</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-mono font-semibold text-slate-300 flex items-center gap-1.5">
                  <School className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Nama Sekolah</span>
                </label>
                <input
                  type="text"
                  required
                  value={editSekolah}
                  onChange={(e) => setEditSekolah(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-white/10 text-white text-sm focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-300 text-xs font-mono transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold font-mono transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-cyan-600/30"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Simpan Perubahan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
