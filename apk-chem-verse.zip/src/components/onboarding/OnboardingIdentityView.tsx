import React, { useState, useEffect } from 'react';
import { User, School, GraduationCap, ArrowRight, Sparkles, ShieldCheck } from 'lucide-react';
import { useKakKimiaVoice } from '../../hooks/useKakKimiaVoice';
import VoiceToggleButton from './VoiceToggleButton';
import ChemistryLoginBackground from '../chemistry/ChemistryLoginBackground';
import { getOrCreateStudentAccount } from '../../services/studentVerificationStore';

interface OnboardingIdentityViewProps {
  onNext: () => void;
  initialIdentity?: {
    nama: string;
    kelas: string;
    sekolah: string;
  };
}

export default function OnboardingIdentityView({
  onNext,
  initialIdentity,
}: OnboardingIdentityViewProps) {
  // Voice Mute State
  const [isMuted, setIsMuted] = useState<boolean>(() => {
    return localStorage.getItem('chemverse_kak_kimia_muted') === 'true';
  });

  const toggleMute = () => {
    setIsMuted((prev) => {
      const next = !prev;
      localStorage.setItem('chemverse_kak_kimia_muted', String(next));
      return next;
    });
  };

  // TUGAS 2.1: Suara Otomatis Kak Kimia saat Halaman 1 dimuat (Tegas & Lantang)
  const speechText =
    'Perhatian Siswa! Langkah 1 dari 2: Isi Identitas Siswa. Silakan lengkapi nama lengkap, tingkat kelas, dan nama sekolahmu dengan benar untuk didaftarkan ke sistem Chemverse.';

  const { isSpeaking } = useKakKimiaVoice(speechText, isMuted);

  // Form State
  const [nama, setNama] = useState(initialIdentity?.nama || '');
  const [kelas, setKelas] = useState(initialIdentity?.kelas || 'Kelas 11 SMA');
  const [sekolah, setSekolah] = useState(initialIdentity?.sekolah || '');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Muat data dari localStorage jika ada
  useEffect(() => {
    try {
      const saved = localStorage.getItem('chemverse_student_identity');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.nama && !nama) setNama(parsed.nama);
        if (parsed.kelas && !initialIdentity?.kelas) setKelas(parsed.kelas);
        if (parsed.sekolah && !sekolah) setSekolah(parsed.sekolah);
      } else {
        const legacyNama = localStorage.getItem('chemverse_nama') || localStorage.getItem('chemiverse_nama');
        const legacyKelas = localStorage.getItem('chemverse_kelas');
        const legacySekolah = localStorage.getItem('chemverse_sekolah');
        if (legacyNama && !nama) setNama(legacyNama);
        if (legacyKelas) setKelas(legacyKelas);
        if (legacySekolah && !sekolah) setSekolah(legacySekolah);
      }
    } catch (e) {
      // ignore
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nama.trim()) {
      setErrorMessage('Silakan isi nama lengkapmu terlebih dahulu.');
      return;
    }
    if (!sekolah.trim()) {
      setErrorMessage('Silakan isi nama asal sekolahmu.');
      return;
    }

    setErrorMessage(null);

    // Ambil atau buat ID unik siswa
    let studentId = localStorage.getItem('chemverse_student_sub_id');
    if (!studentId) {
      studentId = typeof crypto !== 'undefined' && crypto.randomUUID
        ? crypto.randomUUID()
        : `std_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      localStorage.setItem('chemverse_student_sub_id', studentId);
    }

    // TUGAS 2.3: Simpan ke localStorage chemverse_student_identity dalam format JSON
    const identityData = {
      id: studentId,
      nama: nama.trim(),
      kelas: kelas.trim(),
      sekolah: sekolah.trim(),
      updatedAt: new Date().toISOString(),
    };

    localStorage.setItem('chemverse_student_identity', JSON.stringify(identityData));
    localStorage.setItem('chemverse_nama', nama.trim());
    localStorage.setItem('chemverse_kelas', kelas.trim());
    localStorage.setItem('chemverse_sekolah', sekolah.trim());

    // Generate adminVerifyId (UUID v4) + activationToken (20 char) dan simpan akun
    getOrCreateStudentAccount({
      id: studentId,
      name: nama.trim(),
      classId: kelas.trim(),
      school: sekolah.trim(),
    });

    // TUGAS 2.4: Lanjut ke Halaman 2 (Sistem Pembayaran)
    onNext();
  };

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center p-4 overflow-hidden bg-[#040714] font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      <ChemistryLoginBackground />

      {/* TUGAS 1.5: Tombol Suara Aktif / Bisu di Pojok Kanan Atas */}
      <div className="fixed top-5 right-5 z-50">
        <VoiceToggleButton
          isMuted={isMuted}
          onToggleMute={toggleMute}
          isSpeaking={isSpeaking}
        />
      </div>

      <div className="relative z-10 w-full max-w-lg">
        {/* Glow Effects */}
        <div className="absolute -top-12 -left-12 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/85 border border-cyan-500/30 shadow-2xl backdrop-blur-2xl space-y-6">
          {/* Header */}
          <div className="space-y-2 text-center">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-cyan-500/15 border border-cyan-400/40 text-cyan-300 text-xs font-mono font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>LANGKAH 1 DARI 2 • ONBOARDING</span>
            </div>

            <h1
              className="text-2xl sm:text-3xl font-black text-white tracking-tight"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Isi Identitas Siswa
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-md mx-auto">
              Silakan isi data dirimu untuk didaftarkan ke sistem langganan{' '}
              <span className="text-cyan-400 font-semibold">Chemverse</span>.
            </p>
          </div>

          {/* Audio Avatar Indicator */}
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-cyan-950/40 border border-cyan-500/20 text-xs text-cyan-200">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center font-bold text-sm shrink-0">
              🎙️
            </div>
            <div className="space-y-0.5">
              <span className="font-bold text-white flex items-center gap-1.5 font-mono">
                Kak Kimia (Asisten Suara)
                {isSpeaking && (
                  <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                )}
              </span>
              <p className="text-[11px] text-slate-400">
                {isMuted
                  ? 'Suara saat ini dibisukan. Klik tombol di pojok kanan atas untuk mengaktifkan.'
                  : 'Kak Kimia sedang memandu langkah pengisian formulir ini.'}
              </p>
            </div>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="p-3.5 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-medium animate-shake">
              ⚠️ {errorMessage}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Nama Lengkap */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-semibold text-slate-300 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-cyan-400" />
                <span>Nama Lengkap Siswa</span>
                <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={nama}
                onChange={(e) => setNama(e.target.value)}
                placeholder="Contoh: Raden Muhammad Yusuf"
                className="w-full px-4 py-3 rounded-xl bg-slate-950/80 border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition"
              />
            </div>

            {/* Kelas (Dropdown 10/11/12) */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-semibold text-slate-300 flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5 text-cyan-400" />
                <span>Tingkat Kelas SMA</span>
                <span className="text-rose-400">*</span>
              </label>
              <select
                value={kelas}
                onChange={(e) => setKelas(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-slate-950/80 border border-white/10 text-white text-sm focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition cursor-pointer"
              >
                <option value="Kelas 10 SMA" className="bg-slate-900 text-white">
                  Kelas 10 SMA (Fase E)
                </option>
                <option value="Kelas 11 SMA" className="bg-slate-900 text-white">
                  Kelas 11 SMA (Fase F)
                </option>
                <option value="Kelas 12 SMA" className="bg-slate-900 text-white">
                  Kelas 12 SMA (Persiapan UTBK/SNBT)
                </option>
              </select>
            </div>

            {/* Nama Sekolah */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono font-semibold text-slate-300 flex items-center gap-1.5">
                <School className="w-3.5 h-3.5 text-cyan-400" />
                <span>Nama Sekolah Asal</span>
                <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={sekolah}
                onChange={(e) => setSekolah(e.target.value)}
                placeholder="Contoh: SMAN 1 Denpasar"
                className="w-full px-4 py-3 rounded-xl bg-slate-950/80 border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full mt-2 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-cyan-500 via-indigo-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-bold text-sm tracking-wide shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/30 transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer group"
            >
              <span>Lanjut ke Sistem Pembayaran</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </form>

          {/* Security Note */}
          <div className="pt-2 border-t border-white/5 flex items-center justify-center gap-2 text-[11px] text-slate-400 font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Koneksi Aman & Terintegrasi Cloud Supabase</span>
          </div>
        </div>
      </div>
    </div>
  );
}
