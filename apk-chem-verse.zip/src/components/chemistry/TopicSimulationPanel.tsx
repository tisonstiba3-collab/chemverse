import React from 'react';
import {
  Sliders,
  RotateCcw,
  Plus,
  Minus,
  Sparkles,
  Zap,
  Flame,
  Activity,
  Layers,
  FlaskConical,
  Check,
} from 'lucide-react';
import { ChemistryTopic, SimulationState } from '../../types/chemistry';
import { getIndicatorColor } from '../3d/TopicDetailViewer3D';

interface TopicSimulationPanelProps {
  topic: ChemistryTopic;
  simulationState: SimulationState;
  onChangeSimulation: (updater: (prev: SimulationState) => SimulationState) => void;
}

export default function TopicSimulationPanel({
  topic,
  simulationState,
  onChangeSimulation,
}: TopicSimulationPanelProps) {
  // 1. Ikatan Kimia (VSEPR / H2O)
  if (topic.modelType === 'h2o' || topic.id === 'ikatan-kimia') {
    const showBonds = simulationState.showBonds !== false;
    const showPEB = simulationState.showPEB !== false;
    const bondAngle = simulationState.bondAngle ?? 104.5;

    let geometryName = 'Bengkok / Huruf V';
    let polarityStatus = 'Polar (Resultan Dipol > 0)';
    if (Math.abs(bondAngle - 180) < 3) {
      geometryName = 'Linier (180°)';
      polarityStatus = 'Nonpolar (Dipol Saling Meniadakan)';
    } else if (Math.abs(bondAngle - 109.5) < 3) {
      geometryName = 'Tetrahedral Ideal (109.5°)';
      polarityStatus = 'Polar Asimetris';
    } else if (Math.abs(bondAngle - 120) < 3) {
      geometryName = 'Trigonal Planar (120°)';
      polarityStatus = 'Nonpolar Simetris';
    }

    return (
      <div className="space-y-5 animate-fade-in">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              <Sliders className="w-4 h-4" />
            </span>
            <h4 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              Simulasi Interaktif Geometri VSEPR
            </h4>
          </div>
          <button
            onClick={() =>
              onChangeSimulation((prev) => ({
                ...prev,
                showBonds: true,
                showPEB: true,
                bondAngle: 104.5,
              }))
            }
            className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Ideal H₂O</span>
          </button>
        </div>

        {/* Bond Angle Slider */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300 font-bold">Sudut Ikatan H-O-H:</span>
            <span className="px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold text-sm">
              {bondAngle.toFixed(1)}°
            </span>
          </div>

          <input
            type="range"
            min="90"
            max="180"
            step="0.5"
            value={bondAngle}
            onChange={(e) => {
              const val = parseFloat(e.target.value);
              onChangeSimulation((prev) => ({ ...prev, bondAngle: val }));
            }}
            className="w-full accent-cyan-400 cursor-pointer"
          />

          {/* Quick Presets */}
          <div className="flex flex-wrap gap-2 pt-1">
            {[
              { label: 'H₂O Alami (104.5°)', angle: 104.5 },
              { label: 'Tetrahedral (109.5°)', angle: 109.5 },
              { label: 'Planar (120°)', angle: 120.0 },
              { label: 'Linier (180°)', angle: 180.0 },
            ].map((p, idx) => (
              <button
                key={idx}
                onClick={() => onChangeSimulation((prev) => ({ ...prev, bondAngle: p.angle }))}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono transition cursor-pointer border ${
                  Math.abs(bondAngle - p.angle) < 0.8
                    ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                    : 'bg-slate-950/70 text-slate-300 border-slate-800 hover:bg-slate-800'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Real-time Molecule Status Card */}
        <div className="grid grid-cols-2 gap-3 text-xs font-mono">
          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-500 block text-[11px] mb-1">Bentuk Geometri Teramati:</span>
            <span className="text-cyan-300 font-bold text-sm block">{geometryName}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-500 block text-[11px] mb-1">Status Kepolaran:</span>
            <span
              className={`font-bold text-sm block ${
                polarityStatus.includes('Nonpolar') ? 'text-emerald-400' : 'text-amber-400'
              }`}
            >
              {polarityStatus}
            </span>
          </div>
        </div>

        {/* Bond and Lone Pair Toggles */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
          <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider block">
            Saklar Komponen Model 3D:
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Toggle Ikatan Kovalen */}
            <button
              onClick={() =>
                onChangeSimulation((prev) => ({
                  ...prev,
                  showBonds: !showBonds,
                }))
              }
              className={`p-3 rounded-xl border flex items-center justify-between text-xs font-medium transition cursor-pointer ${
                showBonds
                  ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-200'
                  : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              <span>Ikatan Kovalen (O-H)</span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                  showBonds ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {showBonds ? 'AKTIF' : 'NONAKTIF'}
              </span>
            </button>

            {/* Toggle PEB */}
            <button
              onClick={() =>
                onChangeSimulation((prev) => ({
                  ...prev,
                  showPEB: !showPEB,
                }))
              }
              className={`p-3 rounded-xl border flex items-center justify-between text-xs font-medium transition cursor-pointer ${
                showPEB
                  ? 'bg-purple-500/15 border-purple-500/40 text-purple-200'
                  : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              <span>Pasangan Elektron Bebas (PEB)</span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                  showPEB ? 'bg-purple-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {showPEB ? 'AKTIF' : 'NONAKTIF'}
              </span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 2. Asam-Basa (pH Indicator & Pipette Titration)
  if (topic.modelType === 'beaker' && (topic.id === 'asam-basa' || topic.category === 'Asam-Basa')) {
    const currentPH = Math.max(0, Math.min(14, simulationState.pH ?? 7.0));
    const indicator = simulationState.indicatorType || 'universal';
    const dropsAcid = simulationState.dropsAcid ?? 0;
    const dropsBase = simulationState.dropsBase ?? 0;
    const liveColor = getIndicatorColor(currentPH, indicator);

    const handleAddAcid = () => {
      onChangeSimulation((prev) => {
        const prevPH = prev.pH ?? 7.0;
        const newPH = Math.max(1.0, prevPH - 1.5);
        return {
          ...prev,
          pH: parseFloat(newPH.toFixed(1)),
          dropsAcid: (prev.dropsAcid ?? 0) + 1,
        };
      });
    };

    const handleAddBase = () => {
      onChangeSimulation((prev) => {
        const prevPH = prev.pH ?? 7.0;
        const newPH = Math.min(13.5, prevPH + 1.5);
        return {
          ...prev,
          pH: parseFloat(newPH.toFixed(1)),
          dropsBase: (prev.dropsBase ?? 0) + 1,
        };
      });
    };

    const handleNeutralize = () => {
      onChangeSimulation((prev) => ({
        ...prev,
        pH: 7.0,
        dropsAcid: 0,
        dropsBase: 0,
      }));
    };

    let sifatLarutan = 'Netral';
    if (currentPH < 6.8) sifatLarutan = 'Asam';
    else if (currentPH > 7.2) sifatLarutan = 'Basa';

    return (
      <div className="space-y-5 animate-fade-in">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-pink-500/20 text-pink-300 border border-pink-500/30">
              <FlaskConical className="w-4 h-4" />
            </span>
            <h4 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              Simulasi Titrasi & Indikator pH
            </h4>
          </div>
          <button
            onClick={handleNeutralize}
            className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Netralkan Air (pH 7)</span>
          </button>
        </div>

        {/* Live Color Swatch & pH Meter Card */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className="w-12 h-12 rounded-2xl border-2 border-white/40 shadow-lg transition-colors duration-500 flex items-center justify-center font-bold text-xs font-mono text-slate-950"
                style={{ backgroundColor: liveColor }}
              >
                pH {currentPH.toFixed(1)}
              </div>
              <div>
                <span className="text-xs font-mono text-slate-400 block">Sifat Larutan Teramati:</span>
                <span
                  className={`text-base font-bold font-display ${
                    sifatLarutan === 'Asam'
                      ? 'text-rose-400'
                      : sifatLarutan === 'Basa'
                      ? 'text-purple-400'
                      : 'text-emerald-400'
                  }`}
                >
                  Larutan {sifatLarutan} (pH {currentPH.toFixed(1)})
                </span>
              </div>
            </div>

            <div className="text-right text-xs font-mono">
              <span className="text-slate-500 block">[H⁺]: 10^-{currentPH.toFixed(1)} M</span>
              <span className="text-slate-500 block">[OH⁻]: 10^-{(14 - currentPH).toFixed(1)} M</span>
            </div>
          </div>

          {/* Color Spectrum Progress Bar */}
          <div className="space-y-1">
            <div className="h-3 w-full rounded-full bg-gradient-to-r from-red-500 via-yellow-400 via-green-500 via-cyan-500 via-blue-600 to-purple-600 relative overflow-hidden shadow-inner">
              <div
                className="absolute top-0 bottom-0 w-2.5 bg-white border-2 border-slate-950 shadow-md transition-all duration-300"
                style={{ left: `calc(${(currentPH / 14) * 100}% - 5px)` }}
              />
            </div>
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>0 (Asam Kuat)</span>
              <span>7 (Netral)</span>
              <span>14 (Basa Kuat)</span>
            </div>
          </div>
        </div>

        {/* Pipette Dropper Action Buttons */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
          <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider block">
            Buret / Pipet Penetes Reagen (Real-Time):
          </span>

          <div className="grid grid-cols-2 gap-3">
            {/* Add Acid */}
            <button
              onClick={handleAddAcid}
              className="p-3.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-500 hover:from-rose-500 hover:to-red-400 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-600/25 transition active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ 1 Tetes HCl 0,1 M</span>
            </button>

            {/* Add Base */}
            <button
              onClick={handleAddBase}
              className="p-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-600/25 transition active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ 1 Tetes NaOH 0,1 M</span>
            </button>
          </div>

          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1">
            <span>Tetes Asam Ditambahkan: {dropsAcid} tetes</span>
            <span>Tetes Basa Ditambahkan: {dropsBase} tetes</span>
          </div>
        </div>

        {/* Indicator Type Selector */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2.5">
          <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider block">
            Pilih Indikator Kimiawi:
          </span>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { id: 'universal', label: 'Universal', desc: 'Merah - Hijau - Ungu' },
              { id: 'pp', label: 'Fenolftalein (PP)', desc: 'Bening → Merah Muda' },
              { id: 'mm', label: 'Metil Merah (MM)', desc: 'Merah → Kuning' },
              { id: 'btb', label: 'Bromtimol Biru', desc: 'Kuning → Biru' },
            ].map((ind) => (
              <button
                key={ind.id}
                onClick={() =>
                  onChangeSimulation((prev) => ({
                    ...prev,
                    indicatorType: ind.id as any,
                  }))
                }
                className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                  indicator === ind.id
                    ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 shadow-md shadow-cyan-500/10'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <span className="font-bold text-xs block text-white">{ind.label}</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">{ind.desc}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // 3. Termokimia (Temperature & Reaction Type)
  if (topic.modelType === 'flame' || topic.id === 'termokimia') {
    const temp = simulationState.temperature ?? 300;
    const reactionType = simulationState.reactionType || 'eksoterm';

    return (
      <div className="space-y-5 animate-fade-in">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30">
              <Flame className="w-4 h-4" />
            </span>
            <h4 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              Simulasi Kalorimetri & Fluktuasi Suhu
            </h4>
          </div>
          <button
            onClick={() =>
              onChangeSimulation((prev) => ({
                ...prev,
                temperature: 300,
                reactionType: 'eksoterm',
              }))
            }
            className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset (300°C)</span>
          </button>
        </div>

        {/* Temperature Slider */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300 font-bold">Temperatur Sistem Pembakaran (T):</span>
            <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold text-sm">
              {temp}°C ({temp + 273} K)
            </span>
          </div>

          <input
            type="range"
            min="25"
            max="1200"
            step="25"
            value={temp}
            onChange={(e) => {
              const val = parseInt(e.target.value);
              onChangeSimulation((prev) => ({ ...prev, temperature: val }));
            }}
            className="w-full accent-amber-400 cursor-pointer"
          />

          <div className="flex justify-between text-[10px] font-mono text-slate-500">
            <span>25°C (Suhu Kamar)</span>
            <span>600°C (Api Sedang)</span>
            <span>1200°C (Api Biru Ekstrem)</span>
          </div>
        </div>

        {/* Mode Reaksi (Eksoterm vs Endoterm) */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
          <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider block">
            Jenis Perubahan Entalpi (ΔH):
          </span>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => onChangeSimulation((prev) => ({ ...prev, reactionType: 'eksoterm' }))}
              className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                reactionType === 'eksoterm'
                  ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                  : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              <span className="font-bold text-xs block text-white">Reaksi Eksotermik</span>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                Melepas Kalor (ΔH &lt; 0), Suhu Naik
              </span>
            </button>

            <button
              onClick={() => onChangeSimulation((prev) => ({ ...prev, reactionType: 'endoterm' }))}
              className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                reactionType === 'endoterm'
                  ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                  : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              <span className="font-bold text-xs block text-white">Reaksi Endotermik</span>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                Menyerap Kalor (ΔH &gt; 0), Suhu Turun
              </span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 4. Elektrokimia (Battery & Redox Cell)
  if (topic.modelType === 'battery' || topic.id === 'elektrokimia') {
    const metalPair = simulationState.selectedMetalPair || 'Zn-Cu';
    const circuitClosed = simulationState.circuitClosed !== false;

    let cellPotential = 1.10;
    if (metalPair === 'Mg-Cu') cellPotential = 2.71;
    if (metalPair === 'Fe-Cu') cellPotential = 0.78;

    return (
      <div className="space-y-5 animate-fade-in">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-teal-500/20 text-teal-300 border border-teal-500/30">
              <Zap className="w-4 h-4" />
            </span>
            <h4 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              Simulasi Sel Volta & Beda Potensial
            </h4>
          </div>
        </div>

        {/* Digital Voltmeter Readout */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs font-mono text-slate-400 block">Potensial Sel Terukur (E°sel):</span>
            <span className="text-3xl font-extrabold text-cyan-300 font-mono tracking-tight">
              {circuitClosed ? `+${cellPotential.toFixed(2)} V` : '0.00 V'}
            </span>
          </div>

          <div className="text-right">
            <span
              className={`px-3 py-1 rounded-full text-xs font-mono font-bold ${
                circuitClosed ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {circuitClosed ? 'Reaksi Spontan Berlangsung' : 'Sirkuit Terputus'}
            </span>
          </div>
        </div>

        {/* Electrode Pair Selector */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
          <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider block">
            Pilih Pasangan Logam Elektroda (Anoda - Katoda):
          </span>

          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'Zn-Cu', label: 'Zn | Cu', volt: '+1.10 V' },
              { id: 'Mg-Cu', label: 'Mg | Cu', volt: '+2.71 V' },
              { id: 'Fe-Cu', label: 'Fe | Cu', volt: '+0.78 V' },
            ].map((pair) => (
              <button
                key={pair.id}
                onClick={() =>
                  onChangeSimulation((prev) => ({
                    ...prev,
                    selectedMetalPair: pair.id as any,
                  }))
                }
                className={`p-3 rounded-xl border text-center transition cursor-pointer ${
                  metalPair === pair.id
                    ? 'bg-teal-500/20 border-teal-400 text-teal-200 font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <span className="text-xs block text-white">{pair.label}</span>
                <span className="text-[10px] text-teal-400 block font-mono mt-0.5">{pair.volt}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Circuit Switch */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-white block">Saklar Sirkuit Aliran Elektron</span>
            <span className="text-[11px] text-slate-400">
              Tutup sirkuit agar elektron mengalir dari anoda ke katoda
            </span>
          </div>

          <button
            onClick={() =>
              onChangeSimulation((prev) => ({
                ...prev,
                circuitClosed: !circuitClosed,
              }))
            }
            className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer border ${
              circuitClosed
                ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md shadow-cyan-500/20'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
          >
            {circuitClosed ? 'SIRKUIT ON' : 'SIRKUIT OFF'}
          </button>
        </div>
      </div>
    );
  }

  // Fallback for general topic simulations (Struktur Atom, Laju Reaksi, etc.)
  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
            <Sliders className="w-4 h-4" />
          </span>
          <h4 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
            Simulasi Parameter {topic.title}
          </h4>
        </div>
      </div>

      <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
        <p className="text-xs text-slate-300 leading-relaxed">
          Manipulasi variabel berikut untuk melihat respons struktur 3D dan parameter stoikiometri secara real-time.
        </p>

        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300">Intensitas Eksitasi Partikel:</span>
            <span className="text-cyan-300 font-bold">Tingkat Optimal</span>
          </div>
          <div className="h-2 w-full rounded-full bg-slate-950 overflow-hidden border border-slate-800">
            <div className="h-full bg-gradient-to-r from-cyan-500 to-indigo-500 w-3/4 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
}
