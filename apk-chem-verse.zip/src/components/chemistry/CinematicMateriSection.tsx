import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  Bookmark,
  BookmarkCheck,
  Sparkles,
  BookOpen,
  Atom,
  Zap,
  CheckCircle2,
  Bot,
  Trophy,
  Flame,
  HelpCircle,
  Gamepad2,
  FileText,
  Target,
  BarChart2,
  Compass,
} from 'lucide-react';
import { CHEMISTRY_TOPICS } from '../../data/chemistryTopicsData';
import { ChemistryTopic, StudentProfile, StudentTopicProgress } from '../../types/chemistry';
import TopicCard3D from '../3d/TopicCard3D';
import TopicCardLightweightVisual from './TopicCardLightweightVisual';
import {
  saveBookmarks,
  subscribeBookmarks,
  subscribeStudentProgress,
} from '../../services/firestoreService';

interface CinematicMateriSectionProps {
  student: StudentProfile;
  onSelectTopic: (topicId: string) => void;
  onViewAllMateri: () => void;
  onNavigateToView: (view: 'diagnostik' | 'latihan' | 'games' | 'tka' | 'rumus' | 'progres' | 'jurnal') => void;
}

// Mini circular SVG progress ring
function MiniProgressRing({
  percent,
  size = 34,
  strokeWidth = 3,
  color = '#22D3EE',
}: {
  percent: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
}) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percent / 100) * circumference;

  return (
    <div className="relative flex items-center justify-center shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform -rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          className="text-slate-800/80"
          fill="transparent"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className="transition-all duration-700 ease-out"
          fill="transparent"
        />
      </svg>
      <span className="absolute text-[9px] font-mono font-bold text-slate-200">
        {Math.round(percent)}%
      </span>
    </div>
  );
}

export default function CinematicMateriSection({
  student,
  onSelectTopic,
  onViewAllMateri,
  onNavigateToView,
}: CinematicMateriSectionProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [hoveredCardId, setHoveredCardId] = useState<string | null>(null);
  const [progressMap, setProgressMap] = useState<Record<string, StudentTopicProgress>>({});
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [isHoveringNext, setIsHoveringNext] = useState(false);
  const [isHoveringPrev, setIsHoveringPrev] = useState(false);

  // Ambient aurora refs
  const auroraCyanRef = useRef<HTMLDivElement>(null);
  const auroraVioletRef = useRef<HTMLDivElement>(null);
  const auroraAmberRef = useRef<HTMLDivElement>(null);

  // Mobile screen detection
  const [isMobileScreen, setIsMobileScreen] = useState<boolean>(() => {
    return typeof window !== 'undefined' ? window.innerWidth < 640 : false;
  });

  // Touch swipe refs for mobile gestures
  const touchStartXRef = useRef<number | null>(null);
  const touchEndXRef = useRef<number | null>(null);

  useEffect(() => {
    const handleResize = () => {
      setIsMobileScreen(window.innerWidth < 640);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndXRef.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (touchStartXRef.current === null || touchEndXRef.current === null) return;
    const diff = touchStartXRef.current - touchEndXRef.current;
    if (diff > 45) {
      handleNext();
    } else if (diff < -45) {
      handlePrev();
    }
    touchStartXRef.current = null;
    touchEndXRef.current = null;
  };

  // Performance mode state
  const [isLightweightMode, setIsLightweightMode] = useState<boolean>(() => {
    try {
      return localStorage.getItem('chem_perf_mode') === 'lightweight';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    const handleModeChange = () => {
      try {
        setIsLightweightMode(localStorage.getItem('chem_perf_mode') === 'lightweight');
      } catch {}
    };
    window.addEventListener('chem_perf_mode_change', handleModeChange);
    return () => window.removeEventListener('chem_perf_mode_change', handleModeChange);
  }, []);

  // Real-time synchronization with Firestore for topic progress & bookmarks
  useEffect(() => {
    if (!student?.userId) {
      const initialMap: Record<string, StudentTopicProgress> = {};
      CHEMISTRY_TOPICS.forEach((t) => {
        initialMap[t.id] = {
          completed: (t.progressPercent ?? 0) >= 100,
          percent: t.progressPercent ?? 0,
        };
      });
      setProgressMap(initialMap);
      return;
    }

    const unsubProgress = subscribeStudentProgress(
      student.userId,
      (remoteMap) => {
        if (remoteMap && Object.keys(remoteMap).length > 0) {
          setProgressMap(remoteMap);
        } else {
          const fallbackMap: Record<string, StudentTopicProgress> = {};
          CHEMISTRY_TOPICS.forEach((t) => {
            fallbackMap[t.id] = {
              completed: (t.progressPercent ?? 0) >= 100,
              percent: t.progressPercent ?? 0,
            };
          });
          setProgressMap(fallbackMap);
        }
      },
      (err) => console.warn('Progress listener warn:', err)
    );

    const unsubBookmarks = subscribeBookmarks(
      student.userId,
      (ids) => setBookmarkedIds(ids),
      (err) => console.warn('Bookmarks listener warn:', err)
    );

    return () => {
      unsubProgress();
      unsubBookmarks();
    };
  }, [student?.userId]);

  // Note: Aurora animations are now handled via pure CSS keyframes (Zero JS/Canvas overhead)

  // Handle bookmark toggle
  const handleToggleBookmark = async (e: React.MouseEvent, topicId: string) => {
    e.stopPropagation();
    const isBookmarked = bookmarkedIds.includes(topicId);
    const updated = isBookmarked
      ? bookmarkedIds.filter((id) => id !== topicId)
      : [...bookmarkedIds, topicId];

    setBookmarkedIds(updated);

    if (student?.userId) {
      try {
        await saveBookmarks(student.userId, updated);
      } catch (err) {
        console.warn('Failed to save bookmark:', err);
      }
    }
  };

  const handlePrev = () => {
    if (activeIndex > 0) {
      setActiveIndex((prev) => prev - 1);
    }
  };

  const handleNext = () => {
    if (activeIndex < CHEMISTRY_TOPICS.length - 1) {
      setActiveIndex((prev) => prev + 1);
    }
  };

  // Keyboard arrow keys navigation for Coverflow
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        handlePrev();
      } else if (e.key === 'ArrowRight') {
        handleNext();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex]);

  const handleOpenTutorWithPrompt = (promptText: string) => {
    window.dispatchEvent(
      new CustomEvent('CHEMIVERSE_OPEN_TUTOR_CHAT', {
        detail: { message: promptText },
      })
    );
  };

  // Quick stats calculation
  const completedTopicsCount = Object.values(progressMap).filter((p) => p.completed).length;
  const overallPercentage = Math.round(
    Object.values(progressMap).reduce((sum, p) => sum + (p.percent || 0), 0) /
      (CHEMISTRY_TOPICS.length || 1)
  );

  return (
    <div className="relative w-full space-y-12">
      {/* Animated Aurora Blobs (pure CSS radial gradients + blur animation, zero JS loop) */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden -z-10">
        <div
          className="absolute -top-32 left-1/4 w-[500px] h-[500px] rounded-full bg-[#22D3EE] opacity-[0.08] blur-[120px] will-change-transform animate-[auroraOne_18s_ease-in-out_infinite_alternate]"
        />
        <div
          className="absolute top-1/3 -right-20 w-[550px] h-[550px] rounded-full bg-[#A78BFA] opacity-[0.08] blur-[120px] will-change-transform animate-[auroraTwo_22s_ease-in-out_infinite_alternate]"
        />
        <div
          className="absolute -bottom-40 left-10 w-[450px] h-[450px] rounded-full bg-[#FBBF24] opacity-[0.08] blur-[120px] will-change-transform animate-[auroraThree_16s_ease-in-out_infinite_alternate]"
        />
      </div>

      {/* ======================================================= */}
      {/* [1] SECTION HEADER                                      */}
      {/* ======================================================= */}
      <section className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-1">
        {/* Left: small animated gradient dot + Space Grotesk 36px title + Inter subtitle */}
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            {/* Small animated gradient dot (pulses every 2s) */}
            <div className="relative flex items-center justify-center w-4 h-4">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-gradient-to-r from-[#22D3EE] to-[#A78BFA] opacity-75 duration-1000" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-gradient-to-tr from-[#22D3EE] via-[#A78BFA] to-[#FBBF24]" />
            </div>
            <span className="text-xs font-mono uppercase tracking-widest text-cyan-400 font-semibold">
              Kurikulum Kimia SMA Interaktif 3D
            </span>
          </div>

          <h2
            className="text-3xl sm:text-4xl font-bold tracking-tight text-[#F8FAFC]"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Materi Kimia
          </h2>
          <p className="text-sm sm:text-[15px] text-[#94A3B8] font-normal max-w-xl leading-relaxed">
            Pilih topikmu dan mulai eksplorasi konsep, ikatan, reaksi, dan simulasi 3D berstandar kurikulum nasional.
          </p>
        </div>

        {/* Right: ghost button "Lihat Semua →" + circular arrow buttons ‹ › (44px) */}
        <div className="flex items-center gap-4 self-start md:self-end">
          {/* Ghost button "Lihat Semua →" with neon underline sweep */}
          <button
            onClick={onViewAllMateri}
            className="group relative px-4 py-2 text-sm font-semibold text-slate-300 hover:text-white transition-colors duration-200 cursor-pointer flex items-center gap-1.5"
          >
            <span>Lihat Semua</span>
            <ArrowRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-1 transition-transform duration-200" />
            {/* Neon underline sweep on hover */}
            <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-gradient-to-r from-[#22D3EE] via-[#A78BFA] to-transparent group-hover:w-full transition-all duration-300 ease-out" />
          </button>

          {/* Two circular arrow buttons ‹ › (44px, glass style, disabled state when at edge) */}
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrev}
              disabled={activeIndex === 0}
              onMouseEnter={() => setIsHoveringPrev(true)}
              onMouseLeave={() => setIsHoveringPrev(false)}
              aria-label="Previous Topic"
              className={`w-11 h-11 rounded-full flex items-center justify-center transition-all duration-200 cursor-pointer ${
                activeIndex === 0
                  ? 'bg-white/[0.02] border border-white/5 text-slate-600 opacity-30 cursor-not-allowed'
                  : 'bg-white/[0.04] backdrop-blur-2xl border border-white/10 hover:border-cyan-400/50 hover:bg-cyan-500/10 text-slate-200 hover:text-cyan-300 shadow-[0_4px_20px_rgba(0,0,0,0.3)] active:scale-95'
              }`}
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <button
              onClick={handleNext}
              disabled={activeIndex === CHEMISTRY_TOPICS.length - 1}
              onMouseEnter={() => setIsHoveringNext(true)}
              onMouseLeave={() => setIsHoveringNext(false)}
              aria-label="Next Topic"
              className={`w-11 h-11 rounded-full flex items-center justify-center transition-all duration-200 cursor-pointer ${
                activeIndex === CHEMISTRY_TOPICS.length - 1
                  ? 'bg-white/[0.02] border border-white/5 text-slate-600 opacity-30 cursor-not-allowed'
                  : 'bg-white/[0.04] backdrop-blur-2xl border border-white/10 hover:border-cyan-400/50 hover:bg-cyan-500/10 text-slate-200 hover:text-cyan-300 shadow-[0_4px_20px_rgba(0,0,0,0.3)] active:scale-95'
              }`}
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* ======================================================= */}
      {/* [2] CINEMATIC COVERFLOW CAROUSEL (hero feature)         */}
      {/* ======================================================= */}
      <section className="relative w-full overflow-hidden py-4">
        {/* Edge fade masks: mask-image linear gradient to transparent on left/right */}
        <div
          className="relative w-full flex items-center justify-center"
          style={{
            perspective: '1600px',
            WebkitMaskImage:
              'linear-gradient(to right, transparent, black 10%, black 90%, transparent)',
            maskImage:
              'linear-gradient(to right, transparent, black 10%, black 90%, transparent)',
          }}
        >
          {/* Track with Framer Motion spring layout and Mobile Touch Gestures */}
          <div
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            className="flex items-center gap-4 sm:gap-6 transition-transform duration-500 ease-out will-change-transform cursor-grab active:cursor-grabbing"
            style={{
              transform: `translateX(calc(50% - ${
                activeIndex * (isMobileScreen ? 276 : 364) + (isMobileScreen ? 130 : 170)
              }px))`,
            }}
          >
            {CHEMISTRY_TOPICS.map((topic, index) => {
              const offset = index - activeIndex;
              const isCenter = offset === 0;
              const isImmediateSide = Math.abs(offset) === 1;
              const isFar = Math.abs(offset) >= 2;
              const progress = progressMap[topic.id]?.percent ?? topic.progressPercent ?? 0;
              const isCompleted = progressMap[topic.id]?.completed || progress >= 100;
              const isBookmarked = bookmarkedIds.includes(topic.id);
              const isHovered = hoveredCardId === topic.id;

              // Calculate depth transforms according to brief:
              // Center: scale 1.0, rotateY 0deg, opacity 1.0, zIndex 10, glow intensified
              // Side: scale 0.82, rotateY +-18deg, opacity 0.55, blur-[2px], zIndex 5
              // Far: scale 0.7, opacity 0.2
              let scale = 1.0;
              let rotateY = 0;
              let opacity = 1.0;
              let zIndex = 10;
              let blurValue = 0;

              if (isCenter) {
                scale = isHovered ? 1.03 : 1.0;
                rotateY = 0;
                opacity = 1.0;
                zIndex = 10;
                blurValue = 0;
              } else if (isImmediateSide) {
                scale = isMobileScreen ? 0.86 : 0.82;
                rotateY = offset > 0 ? (isMobileScreen ? -12 : -18) : (isMobileScreen ? 12 : 18);
                opacity = isMobileScreen ? 0.75 : 0.65;
                zIndex = 5;
                blurValue = isMobileScreen ? 1 : 2;
              } else {
                scale = 0.7;
                rotateY = offset > 0 ? -28 : 28;
                opacity = 0.25;
                zIndex = 1;
                blurValue = 4;
              }

              return (
                <motion.div
                  key={topic.id}
                  layoutId={`coverflow-card-${topic.id}`}
                  onClick={() => {
                    if (isCenter) {
                      onSelectTopic(topic.id);
                    } else {
                      setActiveIndex(index);
                    }
                  }}
                  onMouseEnter={() => setHoveredCardId(topic.id)}
                  onMouseLeave={() => setHoveredCardId(null)}
                  style={{
                    transform: `scale(${scale}) rotateY(${rotateY}deg)`,
                    opacity,
                    zIndex,
                    filter: blurValue > 0 ? `blur(${blurValue}px)` : 'none',
                    transformStyle: 'preserve-3d',
                  }}
                  transition={{
                    type: 'spring',
                    stiffness: 260,
                    damping: 28,
                  }}
                  className={`relative shrink-0 aspect-[3/4] w-[260px] sm:w-[340px] md:w-[380px] rounded-3xl overflow-hidden cursor-pointer select-none transition-shadow duration-300 ${
                    isCenter
                      ? 'bg-white/[0.04] backdrop-blur-2xl border border-white/15 shadow-[0_8px_40px_rgba(34,211,238,0.18)] hover:shadow-[0_12px_60px_rgba(34,211,238,0.28)] hover:border-cyan-400/50'
                      : 'bg-white/[0.02] backdrop-blur-xl border border-white/5 shadow-lg'
                  }`}
                >
                  {/* Subtle rim highlight gradient inside card */}
                  <div className="absolute inset-0 bg-gradient-to-b from-white/[0.08] via-transparent to-black/60 pointer-events-none" />

                  {/* Bookmark Button (Top Right) */}
                  <button
                    onClick={(e) => handleToggleBookmark(e, topic.id)}
                    aria-label={isBookmarked ? 'Hapus bookmark' : 'Simpan bookmark'}
                    className={`absolute top-4 right-4 z-20 w-9 h-9 rounded-full flex items-center justify-center backdrop-blur-md border transition-all duration-200 ${
                      isBookmarked
                        ? 'bg-amber-400/20 border-amber-400/60 text-amber-300'
                        : 'bg-black/40 border-white/10 text-slate-400 hover:text-white hover:bg-black/60'
                    }`}
                  >
                    {isBookmarked ? (
                      <BookmarkCheck className="w-4 h-4 fill-amber-400 text-amber-300" />
                    ) : (
                      <Bookmark className="w-4 h-4" />
                    )}
                  </button>

                  {/* Top Left Status Badge */}
                  <div className="absolute top-4 left-4 z-20 flex items-center gap-1.5">
                    <span
                      className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider backdrop-blur-md border"
                      style={{
                        backgroundColor: `${topic.accentColor || '#22D3EE'}18`,
                        borderColor: `${topic.accentColor || '#22D3EE'}40`,
                        color: topic.accentColor || '#22D3EE',
                      }}
                    >
                      {topic.category}
                    </span>
                    {isCompleted && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        Tuntas
                      </span>
                    )}
                  </div>

                  {/* a) Top 62%: Visual Graphic / On-Demand 3D Scene */}
                  <div className="relative h-[62%] w-full overflow-hidden bg-gradient-to-b from-slate-900/60 to-slate-950/80">
                    {isCenter && !isLightweightMode ? (
                      <TopicCard3D
                        modelType={topic.modelType}
                        accentColor={topic.accentColor}
                        isHovered={isHovered && isCenter}
                        className="h-full"
                        frameloop="demand"
                      />
                    ) : (
                      <TopicCardLightweightVisual
                        modelType={topic.modelType}
                        accentColor={topic.accentColor}
                        isHovered={isHovered}
                      />
                    )}

                    {/* Subtle bottom fade for model area into details */}
                    <div className="absolute bottom-0 inset-x-0 h-16 bg-gradient-to-t from-[#0B1020] to-transparent pointer-events-none" />
                  </div>

                  {/* b) Bottom 35%: Glassmorphism Details */}
                  <div className="relative h-[38%] p-5 flex flex-col justify-between bg-[#0B1020]/80 backdrop-blur-xl border-t border-white/10">
                    <div>
                      {/* Topic Title in Space Grotesk Bold */}
                      <h3
                        className="text-lg sm:text-xl font-bold text-[#F8FAFC] tracking-tight line-clamp-1 group-hover:text-cyan-300 transition-colors"
                        style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                      >
                        {topic.title}
                      </h3>

                      {/* 1-2 line description in Inter muted */}
                      <p className="text-xs text-[#94A3B8] line-clamp-2 mt-1 leading-relaxed">
                        {topic.description}
                      </p>
                    </div>

                    {/* Bottom Row: Progress Ring + Action button */}
                    <div className="pt-3 border-t border-white/10 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <MiniProgressRing
                          percent={progress}
                          color={isCompleted ? '#10B981' : topic.accentColor || '#22D3EE'}
                        />
                        <div className="text-[11px] leading-tight">
                          <span className="text-slate-400 block">Progres</span>
                          <span className="font-semibold text-slate-200">
                            {isCompleted ? 'Selesai' : `${Math.round(progress)}%`}
                          </span>
                        </div>
                      </div>

                      {/* Open / Eksplorasi button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectTopic(topic.id);
                        }}
                        className="px-3.5 py-1.5 rounded-xl bg-white/[0.06] hover:bg-cyan-500 hover:text-slate-950 border border-white/15 hover:border-cyan-400 text-xs font-bold text-slate-200 transition-all duration-200 flex items-center gap-1.5 shadow-sm group/btn cursor-pointer"
                      >
                        <span>Eksplorasi</span>
                        <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-0.5 transition-transform" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Carousel indicators dots */}
        <div className="flex items-center justify-center gap-2 mt-6">
          {CHEMISTRY_TOPICS.map((topic, i) => (
            <button
              key={topic.id}
              onClick={() => setActiveIndex(i)}
              aria-label={`Go to ${topic.title}`}
              className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                activeIndex === i
                  ? 'w-7 bg-gradient-to-r from-[#22D3EE] to-[#A78BFA] shadow-[0_0_10px_rgba(34,211,238,0.8)]'
                  : 'w-1.5 bg-slate-700 hover:bg-slate-500'
              }`}
            />
          ))}
        </div>

        {/* Mobile Swipe Gesture Hint */}
        <div className="sm:hidden flex items-center justify-center gap-2 mt-3 text-[11px] font-mono text-cyan-400/80">
          <span className="animate-pulse">👈</span>
          <span>Geser kartu untuk ganti materi</span>
          <span className="animate-pulse">👉</span>
        </div>
      </section>

      {/* ======================================================= */}
      {/* [3] HYBRID BENTO COMPANION PANELS                       */}
      {/* ======================================================= */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Compass className="w-4 h-4" />
            </div>
            <div>
              <h3
                className="text-xl font-bold text-[#F8FAFC]"
                style={{ fontFamily: "'Space Grotesk', sans-serif" }}
              >
                Ekosistem Pembelajaran ChemiVerse
              </h3>
              <p className="text-xs text-[#94A3B8]">
                Akses cepat latihan soal, laboratorium simulasi, evaluasi ujian, dan catatan belajar.
              </p>
            </div>
          </div>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {/* Bento Cell 1: Quick Progress Summary (Span 2 cols on tablet/desktop) */}
          <div className="md:col-span-2 lg:col-span-2 rounded-3xl bg-white/[0.04] backdrop-blur-2xl border border-white/10 shadow-[0_8px_40px_rgba(34,211,238,0.12)] p-6 flex flex-col justify-between relative overflow-hidden group">
            <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none group-hover:bg-cyan-500/20 transition-all" />

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono uppercase tracking-wider text-cyan-300 font-bold bg-cyan-500/10 border border-cyan-500/20 px-2.5 py-1 rounded-lg flex items-center gap-1.5">
                  <BarChart2 className="w-3.5 h-3.5" />
                  Rangkuman Progres Belajar
                </span>
                <span className="text-xs font-mono text-slate-400">
                  {completedTopicsCount} dari {CHEMISTRY_TOPICS.length} Modul Tuntas
                </span>
              </div>

              <div>
                <h4
                  className="text-2xl font-bold text-white tracking-tight"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  {student.namaLengkap} • {student.kelas}
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  Penguasaan keseluruhan materi kimia SMA mencapai{' '}
                  <span className="text-cyan-400 font-bold">{overallPercentage}%</span>. Terus pelajari simulasi dan uji pemahaman lewat latihan soal.
                </p>
              </div>

              {/* Progress bar */}
              <div className="w-full h-2 rounded-full bg-slate-800/80 overflow-hidden relative">
                <div
                  className="h-full bg-gradient-to-r from-[#22D3EE] via-[#A78BFA] to-[#FBBF24] transition-all duration-1000 ease-out"
                  style={{ width: `${Math.max(overallPercentage, 6)}%` }}
                />
              </div>

              {/* Stat Pills */}
              <div className="grid grid-cols-3 gap-3 pt-2">
                <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/5">
                  <span className="text-[10px] font-mono text-slate-400 block">Total XP Siswa</span>
                  <div className="flex items-center gap-1 mt-1 text-amber-300 font-bold text-base font-mono">
                    <Zap className="w-4 h-4 fill-amber-400" />
                    <span>{student.xp ?? 250}</span>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/5">
                  <span className="text-[10px] font-mono text-slate-400 block">Soal Dipecahkan</span>
                  <div className="flex items-center gap-1 mt-1 text-cyan-300 font-bold text-base font-mono">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                    <span>{student.solvedProblemsCount ?? 12}</span>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/5">
                  <span className="text-[10px] font-mono text-slate-400 block">Topik Disimpan</span>
                  <div className="flex items-center gap-1 mt-1 text-violet-300 font-bold text-base font-mono">
                    <Bookmark className="w-4 h-4 text-violet-400" />
                    <span>{bookmarkedIds.length}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between">
              <span className="text-xs text-slate-400">Lihat grafik analitik & histori lengkap</span>
              <button
                onClick={() => onNavigateToView('progres')}
                className="px-3.5 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-xs font-bold text-cyan-300 hover:text-white transition cursor-pointer flex items-center gap-1.5"
              >
                <span>Buka Detail Progres</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Bento Cell: Tes Diagnostik Adaptif Prasyarat Card */}
          <div
            onClick={() => onNavigateToView('diagnostik')}
            className="rounded-3xl bg-gradient-to-br from-cyan-950/40 via-slate-900/90 to-blue-950/40 backdrop-blur-2xl border border-cyan-500/40 shadow-[0_8px_40px_rgba(34,211,238,0.18)] p-6 flex flex-col justify-between relative overflow-hidden group hover:border-cyan-400 hover:-translate-y-1 transition-all duration-300 cursor-pointer"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 group-hover:scale-110 transition-transform shadow-md shadow-cyan-500/20">
                <Target className="w-6 h-6 text-cyan-400" />
              </div>
              <div>
                <span className="text-[10px] font-mono text-cyan-300 font-bold uppercase tracking-wider block flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3 text-cyan-400" />
                  <span>Uji Kesiapan Adaptif</span>
                </span>
                <h4
                  className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  Tes Diagnostik Prasyarat
                </h4>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                5 soal adaptif (Level 1, 2, dan 3 HOTS) untuk menguji kesiapan materi prasyarat sebelum mempelajari topik kimia baru.
              </p>
            </div>

            <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between text-xs font-bold text-cyan-400">
              <span>Pilih Topik & Mulai</span>
              <div className="w-7 h-7 rounded-lg bg-cyan-500/20 group-hover:bg-cyan-500 group-hover:text-slate-950 flex items-center justify-center transition-all">
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Bento Cell 2: Latihan Soal Card */}
          <div
            onClick={() => onNavigateToView('latihan')}
            className="rounded-3xl bg-white/[0.04] backdrop-blur-2xl border border-white/10 shadow-[0_8px_40px_rgba(34,211,238,0.12)] p-6 flex flex-col justify-between relative overflow-hidden group hover:border-cyan-400/40 hover:-translate-y-1 transition-all duration-300 cursor-pointer"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
                <HelpCircle className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider block">
                  Latihan Interaktif
                </span>
                <h4
                  className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  Latihan Soal & Pembahasan
                </h4>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Puluhan butir soal kurikulum lengkap dengan langkah kalkulasi KaTeX dan pembahasan terurai.
              </p>
            </div>

            <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between text-xs font-bold text-cyan-400">
              <span>Mulai Latihan</span>
              <div className="w-7 h-7 rounded-lg bg-cyan-500/20 group-hover:bg-cyan-500 group-hover:text-slate-950 flex items-center justify-center transition-all">
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Bento Cell 3: Games Kimia & Virtual Lab */}
          <div
            onClick={() => onNavigateToView('games')}
            className="rounded-3xl bg-white/[0.04] backdrop-blur-2xl border border-white/10 shadow-[0_8px_40px_rgba(34,211,238,0.12)] p-6 flex flex-col justify-between relative overflow-hidden group hover:border-violet-400/40 hover:-translate-y-1 transition-all duration-300 cursor-pointer"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-violet-500/10 border border-violet-500/30 flex items-center justify-center text-violet-400 group-hover:scale-110 transition-transform">
                <Gamepad2 className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-mono text-violet-400 font-bold uppercase tracking-wider block">
                  Gamifikasi & Lab
                </span>
                <h4
                  className="text-xl font-bold text-white group-hover:text-violet-300 transition-colors"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  Games Kimia 3D
                </h4>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Tantangan seru perakitan molekul, tebak unsur periodik, dan titrasi warna interaktif.
              </p>
            </div>

            <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between text-xs font-bold text-violet-400">
              <span>Mainkan Game</span>
              <div className="w-7 h-7 rounded-lg bg-violet-500/20 group-hover:bg-violet-500 group-hover:text-slate-950 flex items-center justify-center transition-all">
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Bento Cell 4: Soal TKA Evaluasi */}
          <div
            onClick={() => onNavigateToView('tka')}
            className="rounded-3xl bg-white/[0.04] backdrop-blur-2xl border border-white/10 shadow-[0_8px_40px_rgba(34,211,238,0.12)] p-6 flex flex-col justify-between relative overflow-hidden group hover:border-amber-400/40 hover:-translate-y-1 transition-all duration-300 cursor-pointer"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                <Target className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-mono text-amber-400 font-bold uppercase tracking-wider block">
                  Ujian Saintek & SNBT
                </span>
                <h4
                  className="text-xl font-bold text-white group-hover:text-amber-300 transition-colors"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  Evaluasi Soal TKA
                </h4>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Simulasi ujian berwaktu dengan analitik skor akurasi dan pemetaan kelemahan konsep.
              </p>
            </div>

            <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between text-xs font-bold text-amber-400">
              <span>Mulai Ujian</span>
              <div className="w-7 h-7 rounded-lg bg-amber-500/20 group-hover:bg-amber-500 group-hover:text-slate-950 flex items-center justify-center transition-all">
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Bento Cell 5: Jurnal Refleksi Belajar */}
          <div
            onClick={() => onNavigateToView('jurnal')}
            className="rounded-3xl bg-white/[0.04] backdrop-blur-2xl border border-white/10 shadow-[0_8px_40px_rgba(34,211,238,0.12)] p-6 flex flex-col justify-between relative overflow-hidden group hover:border-emerald-400/40 hover:-translate-y-1 transition-all duration-300 cursor-pointer"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase tracking-wider block">
                  Refleksi Pribadi
                </span>
                <h4
                  className="text-xl font-bold text-white group-hover:text-emerald-300 transition-colors"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  Jurnal Belajar Kimia
                </h4>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Catat ringkasan rumus baru, kesulitan konsep, dan refleksi yang otomatis tersimpan di Cloud Firestore.
              </p>
            </div>

            <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between text-xs font-bold text-emerald-400">
              <span>Buka Catatan</span>
              <div className="w-7 h-7 rounded-lg bg-emerald-500/20 group-hover:bg-emerald-500 group-hover:text-slate-950 flex items-center justify-center transition-all">
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Bento Cell: Kumpulan Rumus & Kalkulator Mini */}
          <div
            onClick={() => onNavigateToView('rumus')}
            className="rounded-3xl bg-white/[0.04] backdrop-blur-2xl border border-white/10 shadow-[0_8px_40px_rgba(34,211,238,0.12)] p-6 flex flex-col justify-between relative overflow-hidden group hover:border-cyan-400/40 hover:-translate-y-1 transition-all duration-300 cursor-pointer"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
                <BookOpen className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider block">
                  Ensiklopedia Rumus
                </span>
                <h4
                  className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  Kumpulan Rumus Kimia
                </h4>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Kuasai seluruh rumus stoikiometri, pH, sel volta, dan hukum Faraday dengan kalkulator mini interaktif.
              </p>
            </div>

            <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between text-xs font-bold text-cyan-400">
              <span>Buka Rumus</span>
              <div className="w-7 h-7 rounded-lg bg-cyan-500/20 group-hover:bg-cyan-500 group-hover:text-slate-950 flex items-center justify-center transition-all">
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Bento Cell 6: Gemini AI Chemistry Tutor Interactive Banner (Span 2 cols) */}
          <div className="md:col-span-2 lg:col-span-2 rounded-3xl bg-gradient-to-r from-cyan-950/40 via-slate-900/80 to-indigo-950/50 backdrop-blur-2xl border border-cyan-500/30 shadow-[0_8px_40px_rgba(34,211,238,0.15)] p-6 flex flex-col justify-between relative overflow-hidden">
            <div className="absolute right-0 top-0 w-60 h-60 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="space-y-3 relative z-10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-slate-950 shadow-md">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-cyan-300 font-bold block">
                      Didukung Gemini API 2.5
                    </span>
                    <h4
                      className="text-lg font-bold text-white"
                      style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                    >
                      Asisten Tutor Kimia Virtual
                    </h4>
                  </div>
                </div>

                <span className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Online 24/7
                </span>
              </div>

              <p className="text-xs text-slate-300 max-w-lg leading-relaxed">
                Tanyakan rumus sulit, mekanisme reaksi, atau minta penjelasan konsep kimia SMA kapan saja dengan respons cerdas dan suara narasi AI.
              </p>

              {/* Contextual Question Chips */}
              <div className="pt-2">
                <span className="text-[11px] font-mono text-slate-400 block mb-2">
                  Pertanyaan Populer Hari Ini:
                </span>
                <div className="flex flex-wrap gap-2">
                  {[
                    'Bagaimana cara cepat menentukan konfigurasi elektron?',
                    'Jelaskan perbedaan ikatan kovalen polar dan nonpolar',
                    'Apa trik menyetarakan reaksi redoks metode ion-elektron?',
                    'Bagaimana pengaruh katalis terhadap energi aktivasi?',
                  ].map((chip, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleOpenTutorWithPrompt(chip)}
                      className="text-[11px] px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-cyan-500/20 border border-white/10 hover:border-cyan-400/50 text-slate-300 hover:text-cyan-200 transition-all text-left cursor-pointer flex items-center gap-1.5"
                    >
                      <Sparkles className="w-3 h-3 text-cyan-400 shrink-0" />
                      <span>{chip}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-white/10 flex items-center justify-between relative z-10">
              <span className="text-xs text-slate-400">
                Klik pertanyaan di atas atau buka dialog chat di pojok kanan bawah.
              </span>
              <button
                onClick={() =>
                  handleOpenTutorWithPrompt('Halo Tutor Kimia, saya butuh bimbingan belajar kimia hari ini!')
                }
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/25 flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
              >
                <Bot className="w-3.5 h-3.5" />
                <span>Buka Chat Tutor</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
