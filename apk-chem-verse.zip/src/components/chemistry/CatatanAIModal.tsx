import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Download,
  X,
  FileText,
  Check,
  Copy,
  Loader2,
  AlertCircle,
  Atom,
  RefreshCw,
} from 'lucide-react';

interface CatatanAIModalProps {
  isOpen: boolean;
  onClose: () => void;
  topicTitle: string;
  materiContent: string;
  urutan?: number;
}

declare global {
  interface Window {
    html2pdf?: () => any;
  }
}

export default function CatatanAIModal({
  isOpen,
  onClose,
  topicTitle,
  materiContent,
  urutan,
}: CatatanAIModalProps) {
  const [summaryHtml, setSummaryHtml] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [isDownloadingPdf, setIsDownloadingPdf] = useState<boolean>(false);
  const printableRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && materiContent) {
      generateSummary();
    }
  }, [isOpen, materiContent, topicTitle]);

  const generateSummary = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/notes/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topicTitle,
          materiTeks: materiContent,
          isLightweight: true,
        }),
      });

      if (!response.ok) {
        throw new Error('Gagal merangkum materi kimia.');
      }

      const data = await response.json();
      if (data.summaryHtml) {
        setSummaryHtml(data.summaryHtml);
      } else {
        throw new Error('Respon rangkuman kosong.');
      }
    } catch (err: any) {
      console.error('Error generating AI notes:', err);
      setError(
        err?.message || 'Terjadi kesalahan saat memproses rangkuman AI. Silakan coba kembali.'
      );
      // Fallback robust default summary
      setSummaryHtml(`
        <ul>
          <li><strong>Konsep Utama:</strong> Memahami keterkaitan sifat fisis dan interaksi partikel kimia pada materi ${topicTitle}.</li>
          <li><strong>Aplikasi Praktis:</strong> Penerapan reaksi dan stoikiometri dalam eksperimen laboratorium serta fenomena alam.</li>
          <li><strong>Poin Evaluasi:</strong> Penguasaan konsep dasar dan prasyarat sangat penting sebelum melanjutkan ke modul selanjutnya.</li>
        </ul>
      `);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyText = async () => {
    try {
      // Strip HTML tags for clean clipboard text
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = summaryHtml;
      const plainText = tempDiv.textContent || tempDiv.innerText || '';
      await navigator.clipboard.writeText(
        `Catatan Rangkuman AI: ${topicTitle}\n\n${plainText}`
      );
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    } catch (err) {
      console.warn('Gagal menyalin teks:', err);
    }
  };

  const handleDownloadPDF = async () => {
    if (!printableRef.current) return;
    setIsDownloadingPdf(true);

    try {
      const element = printableRef.current;
      const cleanFileName = `Catatan_Kimia_${topicTitle.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`;

      // Check if html2pdf is available globally
      if (typeof window.html2pdf === 'function') {
        const opt = {
          margin: [12, 12, 12, 12],
          filename: cleanFileName,
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2, useCORS: true, logging: false },
          jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
        };
        await window.html2pdf().set(opt).from(element).save();
      } else {
        // Fallback: load script dynamically if not yet ready
        const script = document.createElement('script');
        script.src =
          'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';
        script.onload = async () => {
          if (typeof window.html2pdf === 'function') {
            const opt = {
              margin: [12, 12, 12, 12],
              filename: cleanFileName,
              image: { type: 'jpeg', quality: 0.98 },
              html2canvas: { scale: 2, useCORS: true },
              jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
            };
            await window.html2pdf().set(opt).from(element).save();
          } else {
            window.print();
          }
        };
        script.onerror = () => {
          window.print();
        };
        document.head.appendChild(script);
      }
    } catch (err) {
      console.error('Error exporting PDF:', err);
      // Fallback
      window.print();
    } finally {
      setIsDownloadingPdf(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[92vh] flex flex-col rounded-3xl bg-slate-900 border border-cyan-500/30 shadow-2xl shadow-cyan-950/50 overflow-hidden">
        {/* Glow accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-24 bg-gradient-to-b from-cyan-500/20 to-transparent blur-2xl pointer-events-none" />

        {/* Modal Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/25">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono font-bold text-cyan-400 uppercase tracking-wider">
                  Notebook Ringkasan AI
                </span>
                <span className="text-[10px] bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 px-2 py-0.5 rounded-full font-semibold">
                  3 Poin Penting
                </span>
              </div>
              <h3 className="text-lg sm:text-xl font-black text-white tracking-tight">
                {topicTitle}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            aria-label="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-200">
          {isLoading ? (
            <div className="py-16 flex flex-col items-center justify-center text-center space-y-4">
              <div className="relative">
                <div className="w-16 h-16 rounded-full border-2 border-cyan-500/30 border-t-cyan-400 animate-spin flex items-center justify-center">
                  <Atom className="w-7 h-7 text-cyan-400 animate-pulse" />
                </div>
              </div>
              <div className="space-y-1">
                <h4 className="text-base font-bold text-white">Menyusun Catatan AI...</h4>
                <p className="text-xs text-slate-400 max-w-sm">
                  Gemini AI sedang mengekstrak 3 poin inti materi{' '}
                  <span className="text-cyan-300 font-semibold">{topicTitle}</span> agar mudah dipelajari & diingat.
                </p>
              </div>
            </div>
          ) : (
            <>
              {error && (
                <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
                    <span>{error}</span>
                  </div>
                  <button
                    onClick={generateSummary}
                    className="px-2.5 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 font-bold text-[11px] transition flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    Coba Lagi
                  </button>
                </div>
              )}

              {/* Printable Card with Custom Style for html2pdf */}
              <div
                ref={printableRef}
                className="bg-slate-950/90 border border-cyan-500/20 rounded-2xl p-6 sm:p-7 shadow-inner relative overflow-hidden"
                style={{
                  color: '#e2e8f0',
                }}
              >
                {/* Header inside the document */}
                <div className="pb-4 mb-4 border-b border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 font-bold block">
                      ChemiVerse SMA • Catatan Ringkasan Materi
                    </span>
                    <h2 className="text-xl sm:text-2xl font-black text-white mt-0.5">
                      {topicTitle}
                    </h2>
                    {urutan && (
                      <span className="text-xs text-slate-400 font-medium">
                        Modul Kurikulum #{urutan}
                      </span>
                    )}
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                    <FileText className="w-5 h-5" />
                  </div>
                </div>

                {/* Rendered HTML <ul> and <li> output */}
                <div
                  className="prose prose-invert max-w-none text-slate-200 text-sm leading-relaxed
                    [&>ul]:space-y-3.5 [&>ul]:list-none [&>ul]:pl-0
                    [&>ul>li]:relative [&>ul>li]:pl-7 [&>ul>li]:py-1.5 [&>ul>li]:text-slate-200 [&>ul>li]:leading-relaxed
                    [&>ul>li]:before:content-['✦'] [&>ul>li]:before:absolute [&>ul>li]:before:left-1 [&>ul>li]:before:text-cyan-400 [&>ul>li]:before:font-bold [&>ul>li]:before:text-base
                    [&>ul>li>strong]:text-cyan-300 [&>ul>li>strong]:font-bold"
                  dangerouslySetInnerHTML={{ __html: summaryHtml }}
                />

                {/* Footer in the document */}
                <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>Diringkas otomatis dengan AI Gemini</span>
                  <span>{new Date().toLocaleDateString('id-ID', { dateStyle: 'long' })}</span>
                </div>
              </div>

              {/* Tips Callout */}
              <div className="p-3.5 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-xs text-cyan-200/90 flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Tips Belajar:</strong> Simpan atau unduh catatan PDF ini untuk bahan review kilat sebelum asesmen diagnostik atau ulangan harian.
                </span>
              </div>
            </>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="p-4 sm:p-6 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleCopyText}
              disabled={isLoading || !summaryHtml}
              className="px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-slate-600 text-slate-300 hover:text-white font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 w-1/2 sm:w-auto disabled:opacity-50"
            >
              {isCopied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Tersalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Salin Teks</span>
                </>
              )}
            </button>

            <button
              onClick={generateSummary}
              disabled={isLoading}
              className="px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-slate-600 text-slate-300 hover:text-white font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 w-1/2 sm:w-auto disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              <span>Regenerasi</span>
            </button>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-400 hover:text-white font-bold text-xs transition cursor-pointer"
            >
              Tutup
            </button>

            {/* DOWNLOAD PDF BUTTON */}
            <button
              onClick={handleDownloadPDF}
              disabled={isLoading || isDownloadingPdf || !summaryHtml}
              className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-xs shadow-lg shadow-cyan-500/25 transition cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isDownloadingPdf ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Membuat PDF...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Download PDF</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
