import React, { useState, useEffect } from 'react';
import {
  Check,
  Lock,
  Play,
  Sparkles,
  BookOpen,
  ArrowRight,
  X,
  Award,
  ChevronRight,
  Flame,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Share2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { UserDocument, MaterialDocument } from '../../types/chemistry';
import {
  subscribeMaterialsList,
  subscribeUserDocument,
  selesaikanMateri,
  tambahXP,
} from '../../services/firestoreService';
import CatatanAIModal from './CatatanAIModal';

interface PetaBelajarViewProps {
  userId: string;
  onOpenAchievements?: () => void;
}

export default function PetaBelajarView({ userId, onOpenAchievements }: PetaBelajarViewProps) {
  const [materials, setMaterials] = useState<MaterialDocument[]>([]);
  const [user, setUser] = useState<UserDocument | null>(null);
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialDocument | null>(null);
  const [isReadingModalOpen, setIsReadingModalOpen] = useState(false);
  const [isNotesModalOpen, setIsNotesModalOpen] = useState(false);
  const [notesTargetMaterial, setNotesTargetMaterial] = useState<MaterialDocument | null>(null);
  const [lockedAlertModal, setLockedAlertModal] = useState<{
    material: MaterialDocument;
    missingPrereqs: string[];
  } | null>(null);
  const [isCompleting, setIsCompleting] = useState(false);

  // Subscribe to real-time materials from Firestore collection `materials`
  useEffect(() => {
    const unsub = subscribeMaterialsList(
      (mats) => {
        setMaterials(mats);
      },
      (err) => console.warn('Gagal memuat materi dari Firestore:', err)
    );
    return () => unsub();
  }, []);

  // Subscribe to real-time user document from Firestore collection `users/{userId}`
  useEffect(() => {
    if (!userId) return;
    const unsub = subscribeUserDocument(
      userId,
      (userDoc) => {
        if (userDoc) setUser(userDoc);
      },
      (err) => console.warn('Gagal memuat profil user dari Firestore:', err)
    );
    return () => unsub();
  }, [userId]);

  const userProgress = Array.isArray(user?.progres_materi) ? user.progres_materi : [];

  // Helper: check if a material is unlocked
  const checkIsUnlocked = (mat: MaterialDocument) => {
    if (!mat.prasyarat || mat.prasyarat.length === 0) return true;
    return mat.prasyarat.every((reqId) => userProgress.includes(reqId));
  };

  // Helper: get titles of missing prerequisites
  const getMissingPrereqTitles = (mat: MaterialDocument) => {
    if (!mat.prasyarat || mat.prasyarat.length === 0) return [];
    const missing = mat.prasyarat.filter((reqId) => !userProgress.includes(reqId));
    return missing.map((reqId) => {
      const found = materials.find((m) => m.id === reqId);
      return found ? found.judul : reqId;
    });
  };

  const handleNodeClick = (mat: MaterialDocument) => {
    const isUnlocked = checkIsUnlocked(mat);
    if (!isUnlocked) {
      const missingTitles = getMissingPrereqTitles(mat);
      setLockedAlertModal({ material: mat, missingPrereqs: missingTitles });
      return;
    }

    setSelectedMaterial(mat);
    setIsReadingModalOpen(true);
  };

  const handleCompleteMaterial = async (mat: MaterialDocument) => {
    if (!userId || isCompleting) return;
    setIsCompleting(true);
    try {
      await selesaikanMateri(userId, mat.id, 50);

      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {
        // fallback
      }

      setIsReadingModalOpen(false);
    } catch (err) {
      console.warn('Gagal menandai materi selesai:', err);
    } finally {
      setIsCompleting(false);
    }
  };

  // Calculate overall learning path stats
  const completedCount = materials.filter((m) => userProgress.includes(m.id)).length;
  const progressPercent = materials.length > 0 ? Math.round((completedCount / materials.length) * 100) : 0;

  return (
    <div className="space-y-8 animate-fade-in max-w-4xl mx-auto pb-16">
      {/* Top Learning Path Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 border border-cyan-500/30 p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-mono text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              Peta Belajar Kimia SMA (Kurikulum Merdeka)
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Peta Jalur Belajar Berkelok
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl leading-relaxed">
              Ikuti jalur petualangan kimia dari konsep dasar hingga reaksi lanjutan. Selesaikan materi
              prasyarat untuk membuka gerbang materi berikutnya dan klaim +50 XP per materi!
            </p>
          </div>

          {/* Progress Card */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 shrink-0 w-full md:w-64 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300">Progres Jalur:</span>
              <span className="font-mono font-bold text-cyan-400">
                {completedCount} / {materials.length} Selesai ({progressPercent}%)
              </span>
            </div>
            <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-indigo-500 transition-all duration-700"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            {onOpenAchievements && (
              <button
                onClick={onOpenAchievements}
                className="w-full py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Award className="w-3.5 h-3.5" />
                Lihat Lencana & XP
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Serpentine / Winding Road Path UI */}
      <div className="relative py-8 px-4 sm:px-12">
        {/* Central Winding Guide Track (Subtle glowing dashed trail) */}
        <div className="absolute left-1/2 top-4 bottom-4 w-1 -translate-x-1/2 border-l-2 border-dashed border-slate-800 pointer-events-none hidden sm:block" />

        <div className="space-y-12 relative z-10">
          {materials.map((material, idx) => {
            const isCompleted = userProgress.includes(material.id);
            const isUnlocked = checkIsUnlocked(material);
            const isCurrent = isUnlocked && !isCompleted;

            // Serpentine lateral offset pattern: alternating left and right
            const isEven = idx % 2 === 0;

            return (
              <div
                key={material.id}
                className={`flex flex-col sm:flex-row items-center gap-4 sm:gap-8 ${
                  isEven ? 'sm:flex-row' : 'sm:flex-row-reverse'
                }`}
              >
                {/* Node Button (Bulatan Berkelok) */}
                <div className="relative shrink-0 flex items-center justify-center">
                  {/* Subtle connection line to center */}
                  <div
                    className={`hidden sm:block absolute top-1/2 w-12 h-0.5 border-t-2 border-dashed ${
                      isCompleted
                        ? 'border-cyan-500/40'
                        : isUnlocked
                        ? 'border-indigo-500/40'
                        : 'border-slate-800'
                    } ${isEven ? 'right-full' : 'left-full'}`}
                  />

                  <button
                    onClick={() => handleNodeClick(material)}
                    className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer shadow-xl relative ${
                      isCompleted
                        ? 'bg-gradient-to-tr from-cyan-500 to-teal-400 text-slate-950 border-4 border-cyan-200 ring-8 ring-cyan-500/20 hover:scale-105 shadow-[0_0_25px_rgba(6,182,212,0.4)]'
                        : isCurrent
                        ? 'bg-gradient-to-tr from-indigo-600 to-blue-500 text-white border-4 border-indigo-300 ring-8 ring-indigo-500/30 hover:scale-110 shadow-[0_0_25px_rgba(99,102,241,0.5)] animate-pulse'
                        : 'bg-slate-800 text-slate-500 border-4 border-slate-700 ring-4 ring-slate-800/40 hover:bg-slate-750'
                    }`}
                    title={
                      isCompleted
                        ? `${material.judul} - Selesai`
                        : isUnlocked
                        ? `${material.judul} - Siap Dipelajari`
                        : `${material.judul} - Terkunci`
                    }
                  >
                    {isCompleted ? (
                      /* Selesai: Warna Cyan dan Ikon Centang (Sesuai Aturan) */
                      <Check className="w-8 h-8 font-black stroke-[3.5] text-slate-950" />
                    ) : isUnlocked ? (
                      /* Siap Dipelajari: Ikon Play/Mulai */
                      <Play className="w-7 h-7 fill-current ml-1" />
                    ) : (
                      /* Terkunci: Ikon Gembok dan Warna Abu-Abu (Sesuai Aturan) */
                      <Lock className="w-7 h-7 text-slate-400" />
                    )}

                    {/* Step Sequence Badge */}
                    <span
                      className={`absolute -bottom-2 px-2.5 py-0.5 rounded-full text-[11px] font-mono font-black border ${
                        isCompleted
                          ? 'bg-cyan-950 text-cyan-200 border-cyan-400'
                          : isCurrent
                          ? 'bg-indigo-950 text-indigo-200 border-indigo-400'
                          : 'bg-slate-900 text-slate-400 border-slate-700'
                      }`}
                    >
                      #{material.urutan}
                    </span>
                  </button>
                </div>

                {/* Content Card next to Node */}
                <div
                  onClick={() => handleNodeClick(material)}
                  className={`w-full sm:max-w-md p-5 sm:p-6 rounded-3xl border transition-all cursor-pointer relative overflow-hidden ${
                    isCompleted
                      ? 'bg-slate-900/90 border-cyan-500/40 hover:border-cyan-400 shadow-lg shadow-cyan-500/5'
                      : isCurrent
                      ? 'bg-slate-900/95 border-indigo-500/50 hover:border-indigo-400 shadow-xl shadow-indigo-500/10'
                      : 'bg-slate-950/70 border-slate-800/80 hover:border-slate-700 opacity-70'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span
                      className={`text-xs font-mono font-bold uppercase tracking-wider ${
                        isCompleted
                          ? 'text-cyan-400'
                          : isCurrent
                          ? 'text-indigo-400'
                          : 'text-slate-500'
                      }`}
                    >
                      Materi #{material.urutan}
                    </span>

                    {isCompleted ? (
                      <span className="px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 font-bold text-[10px] flex items-center gap-1 border border-cyan-500/30">
                        <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                        SELESAI (+50 XP)
                      </span>
                    ) : isCurrent ? (
                      <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 font-bold text-[10px] flex items-center gap-1 border border-indigo-500/30 animate-pulse">
                        <Sparkles className="w-3 h-3 text-amber-400" />
                        SIAP DIBACA
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 font-bold text-[10px] flex items-center gap-1 border border-slate-700">
                        <Lock className="w-3 h-3 text-slate-400" />
                        TERKUNCI
                      </span>
                    )}
                  </div>

                  <h3
                    className={`text-base sm:text-lg font-bold leading-snug ${
                      isCompleted ? 'text-white' : isCurrent ? 'text-white font-extrabold' : 'text-slate-400'
                    }`}
                  >
                    {material.judul}
                  </h3>

                  <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                    {material.konten_materi}
                  </p>

                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                    {isCompleted ? (
                      <span className="text-cyan-300 font-medium flex items-center gap-1">
                        Baca Ulang Materi ➔
                      </span>
                    ) : isUnlocked ? (
                      <span className="text-indigo-300 font-bold flex items-center gap-1">
                        Mulai Belajar Sekarang ➔
                      </span>
                    ) : (
                      <span className="text-slate-500 flex items-center gap-1">
                        Selesaikan materi prasyarat untuk membuka
                      </span>
                    )}

                    <div className="flex items-center gap-2">
                      {isUnlocked && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setNotesTargetMaterial(material);
                            setIsNotesModalOpen(true);
                          }}
                          className="px-2 py-1 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 font-bold text-[10px] transition flex items-center gap-1 cursor-pointer"
                          title="Buat Catatan AI & Unduh PDF"
                        >
                          <Sparkles className="w-3 h-3 text-cyan-400" />
                          <span>Catatan AI</span>
                        </button>
                      )}
                      <ChevronRight className="w-4 h-4 text-slate-500" />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* MODAL: Baca Materi Lengkap */}
      {isReadingModalOpen && selectedMaterial && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
              <div className="space-y-1">
                <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
                  Materi #{selectedMaterial.urutan} • Pembelajaran Kimia SMA
                </span>
                <h3 className="text-xl font-black text-white">{selectedMaterial.judul}</h3>
              </div>

              <button
                onClick={() => setIsReadingModalOpen(false)}
                className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto space-y-5 text-slate-200 text-sm leading-relaxed">
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80 text-xs text-slate-400 space-y-1">
                <div className="flex justify-between">
                  <span>Prasyarat Materi:</span>
                  <span className="font-bold text-slate-300">
                    {selectedMaterial.prasyarat.length === 0
                      ? 'Tidak ada (Materi Awal)'
                      : `${selectedMaterial.prasyarat.length} Materi Prasyarat`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Hadiah XP Penyelesaian:</span>
                  <span className="font-bold text-amber-400">+50 XP</span>
                </div>
              </div>

              {/* Renders material content with paragraph breaks */}
              <div className="space-y-3 whitespace-pre-line font-normal text-slate-200 leading-relaxed bg-slate-950/40 p-5 rounded-2xl border border-slate-800/60">
                {selectedMaterial.konten_materi}
              </div>

              {/* HALAMAN AKHIR MODUL MATERI: Tombol "Buat Catatan AI" (Fase 3 Siswa) */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/50 via-slate-950 to-indigo-950/50 border border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg shadow-cyan-950/30">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shrink-0 shadow-md shadow-cyan-500/20">
                    <Sparkles className="w-5 h-5 animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-extrabold text-white flex items-center gap-1.5">
                      <span>Notebook Ringkasan Siswa</span>
                      <span className="text-[10px] font-mono text-cyan-300 bg-cyan-500/15 border border-cyan-500/30 px-1.5 py-0.5 rounded">
                        AI Gemini
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Rangkum 3 poin penting materi ini dan unduh sebagai file PDF
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setNotesTargetMaterial(selectedMaterial);
                    setIsNotesModalOpen(true);
                  }}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-xs shadow-lg shadow-cyan-500/25 transition cursor-pointer flex items-center justify-center gap-2 shrink-0 group"
                >
                  <Sparkles className="w-3.5 h-3.5 group-hover:rotate-12 transition" />
                  <span>Buat Catatan AI</span>
                </button>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 sm:p-6 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 shrink-0">
              <span className="text-xs text-slate-400 text-center sm:text-left">
                {userProgress.includes(selectedMaterial.id)
                  ? 'Materi ini sudah Anda selesaikan sebelumnya.'
                  : 'Klik tombol di kanan untuk menyelesaikan materi dan menambah 50 XP ke database.'}
              </span>

              <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={() => {
                    setNotesTargetMaterial(selectedMaterial);
                    setIsNotesModalOpen(true);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 font-bold text-xs transition cursor-pointer flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Buat Catatan AI</span>
                </button>

                <button
                  onClick={() => setIsReadingModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
                >
                  Tutup
                </button>

                {!userProgress.includes(selectedMaterial.id) && (
                  <button
                    onClick={() => handleCompleteMaterial(selectedMaterial)}
                    disabled={isCompleting}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-black text-xs shadow-lg shadow-cyan-500/25 transition cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-4 h-4 font-black" />
                    {isCompleting ? 'Menyimpan...' : 'Tandai Selesai & Klaim +50 XP'}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Materi Masih Terkunci Alert */}
      {lockedAlertModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-md p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl space-y-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto shadow-md">
              <Lock className="w-7 h-7" />
            </div>

            <div className="space-y-1.5">
              <h3 className="text-lg font-bold text-white">Materi Masih Terkunci</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Untuk membuka materi <strong>"{lockedAlertModal.material.judul}"</strong>, Anda harus
                menyelesaikan materi prasyarat berikut terlebih dahulu:
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-left space-y-2">
              <span className="font-bold text-slate-400 block mb-1">Daftar Prasyarat:</span>
              {lockedAlertModal.missingPrereqs.map((title, i) => (
                <div key={i} className="flex items-center gap-2 text-amber-300 font-medium">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                  <span>{title}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => setLockedAlertModal(null)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition cursor-pointer"
            >
              Saya Mengerti
            </button>
          </div>
        </div>
      )}

      {/* MODAL: Notebook Ringkasan Otomatis (Catatan AI & Download PDF) */}
      {notesTargetMaterial && (
        <CatatanAIModal
          isOpen={isNotesModalOpen}
          onClose={() => {
            setIsNotesModalOpen(false);
            setNotesTargetMaterial(null);
          }}
          topicTitle={notesTargetMaterial.judul}
          materiContent={notesTargetMaterial.konten_materi}
          urutan={notesTargetMaterial.urutan}
        />
      )}
    </div>
  );
}
