import React, { useState } from 'react';
import { CheckCircle2, XCircle, HelpCircle, RotateCcw, Award } from 'lucide-react';
import { MiniQuizQuestion } from '../../types/chemistry';

interface InlineMiniQuizProps {
  quiz: MiniQuizQuestion[];
  onCorrectAnswer?: () => void;
}

export default function InlineMiniQuiz({ quiz, onCorrectAnswer }: InlineMiniQuizProps) {
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [showExplanations, setShowExplanations] = useState<Record<string, boolean>>({});

  const handleSelect = (questionId: string, optionIndex: number, correctIndex: number) => {
    // If already answered, allow reselection or keep
    const isFirstTimeCorrect = selectedAnswers[questionId] === undefined && optionIndex === correctIndex;
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: optionIndex }));
    setShowExplanations((prev) => ({ ...prev, [questionId]: true }));

    if (isFirstTimeCorrect && onCorrectAnswer) {
      onCorrectAnswer();
    }
  };

  const handleReset = () => {
    setSelectedAnswers({});
    setShowExplanations({});
  };

  const answeredCount = Object.keys(selectedAnswers).length;
  const correctCount = quiz.filter((q) => selectedAnswers[q.id] === q.correctIndex).length;

  return (
    <div className="mt-4 pt-3.5 border-t border-slate-800/80 space-y-4">
      {/* Quiz Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
            <HelpCircle className="w-3.5 h-3.5" />
          </span>
          <div>
            <h5 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
              Uji Konsep Mandiri (Mini-Quiz)
            </h5>
            <span className="text-[11px] text-slate-400">
              Jawab 2 pertanyaan untuk mengecek pemahamanmu
            </span>
          </div>
        </div>

        {answeredCount > 0 && (
          <div className="flex items-center gap-2 text-xs font-mono">
            <span
              className={`font-bold px-2 py-0.5 rounded-md ${
                correctCount === quiz.length
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-slate-800 text-slate-300'
              }`}
            >
              {correctCount} / {quiz.length} Benar
            </span>
            <button
              onClick={handleReset}
              className="p-1 rounded text-slate-400 hover:text-white transition cursor-pointer"
              title="Ulangi Kuis"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>

      {/* 2 Quiz Questions */}
      <div className="space-y-3.5">
        {quiz.map((q, qIdx) => {
          const selected = selectedAnswers[q.id];
          const hasAnswered = selected !== undefined;
          const isCorrect = selected === q.correctIndex;

          return (
            <div
              key={q.id}
              className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2.5 transition-all"
            >
              <div className="flex items-start gap-2">
                <span className="text-xs font-mono font-bold text-cyan-400 shrink-0 mt-0.5">
                  Q{qIdx + 1}.
                </span>
                <p className="text-xs font-medium text-slate-200 leading-relaxed">
                  {q.question}
                </p>
              </div>

              {/* Options */}
              <div className="grid grid-cols-1 gap-2 pt-1">
                {q.options.map((opt, optIdx) => {
                  const isThisSelected = selected === optIdx;
                  const isThisCorrect = optIdx === q.correctIndex;

                  let buttonStyle = 'bg-slate-950/60 border-slate-800 text-slate-300 hover:bg-slate-850 hover:text-white';
                  if (hasAnswered) {
                    if (isThisCorrect) {
                      buttonStyle = 'bg-emerald-500/20 border-emerald-500/50 text-emerald-200 font-medium shadow-[0_0_12px_rgba(16,185,129,0.2)]';
                    } else if (isThisSelected && !isThisCorrect) {
                      buttonStyle = 'bg-rose-500/20 border-rose-500/50 text-rose-200 font-medium';
                    } else {
                      buttonStyle = 'bg-slate-950/30 border-slate-850 text-slate-500 opacity-60';
                    }
                  }

                  return (
                    <button
                      key={optIdx}
                      onClick={() => handleSelect(q.id, optIdx, q.correctIndex)}
                      className={`w-full p-2.5 rounded-lg border text-left text-xs transition flex items-center justify-between gap-2 cursor-pointer ${buttonStyle}`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-md bg-slate-900 text-slate-400 font-mono text-[10px] font-bold flex items-center justify-center shrink-0">
                          {String.fromCharCode(65 + optIdx)}
                        </span>
                        <span>{opt}</span>
                      </div>

                      {hasAnswered && isThisCorrect && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      )}
                      {hasAnswered && isThisSelected && !isThisCorrect && (
                        <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Instant Explanation Feedback */}
              {hasAnswered && showExplanations[q.id] && (
                <div
                  className={`p-2.5 rounded-lg text-xs leading-relaxed border transition-all ${
                    isCorrect
                      ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-300'
                      : 'bg-amber-950/30 border-amber-500/30 text-amber-200'
                  }`}
                >
                  <span className="font-bold block mb-0.5">
                    {isCorrect ? '✅ Jawaban Benar!' : '💡 Pembahasan:'}
                  </span>
                  <span>{q.explanation}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {correctCount === quiz.length && (
        <div className="p-3 rounded-xl bg-gradient-to-r from-emerald-500/20 via-teal-500/20 to-cyan-500/20 border border-emerald-500/40 text-emerald-300 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <span className="font-semibold">Bagus sekali! Semua soal sub-bab ini terjawab benar.</span>
          </div>
          <span className="font-mono font-bold">+10 XP</span>
        </div>
      )}
    </div>
  );
}
