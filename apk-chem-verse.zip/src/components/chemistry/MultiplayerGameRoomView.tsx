import React, { useState, useEffect, useRef } from 'react';
import {
  Users,
  Trophy,
  Swords,
  Play,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  Crown,
  LogOut,
  PlusCircle,
  Clock,
  ArrowRight,
  ShieldCheck,
  Flame,
  Radio,
  Share2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { StudentProfile, GameRoom, GameRoomPlayer, GameRoomQuestion } from '../../types/chemistry';
import {
  createGameRoom,
  joinGameRoom,
  subscribeGameRoom,
  updateGameRoom,
  subscribeOpenGameRooms,
  deleteGameRoom,
  DEFAULT_MULTIPLAYER_QUESTIONS,
} from '../../services/firestoreService';

interface MultiplayerGameRoomViewProps {
  student?: StudentProfile | null;
  onAddXP?: (amount: number) => void;
  onBack?: () => void;
}

export default function MultiplayerGameRoomView({
  student,
  onAddXP,
  onBack,
}: MultiplayerGameRoomViewProps) {
  // Current active room state
  const [currentRoomId, setCurrentRoomId] = useState<string | null>(null);
  const [roomData, setRoomData] = useState<GameRoom | null>(null);
  const [openRooms, setOpenRooms] = useState<GameRoom[]>([]);
  const [joinCodeInput, setJoinCodeInput] = useState('');
  const [customTitle, setCustomTitle] = useState('Duel Kuis Cepat Kimia SMA');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  // Local question answering state for the active question
  const [hasAnsweredCurrent, setHasAnsweredCurrent] = useState(false);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number | null>(null);
  const [isAnswerCorrect, setIsAnswerCorrect] = useState<boolean | null>(null);
  const [questionTimer, setQuestionTimer] = useState<number>(20);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const currentUserId = student?.userId || 'guest_user_' + Math.random().toString(36).substring(2, 6);
  const currentUserName = student?.namaLengkap || student?.nama || 'Siswa Kimia';
  const isHost = roomData?.hostId === currentUserId;

  // Listen to open waiting rooms in real-time
  useEffect(() => {
    const unsub = subscribeOpenGameRooms(
      (rooms) => {
        setOpenRooms(rooms);
      },
      (err) => {
        console.warn('Error subscribing to open game rooms:', err);
      }
    );
    return () => unsub();
  }, []);

  // Listen to the current joined room in real-time
  useEffect(() => {
    if (!currentRoomId) {
      setRoomData(null);
      return;
    }

    const unsub = subscribeGameRoom(
      currentRoomId,
      (room) => {
        if (!room) {
          setErrorMsg('Room ini telah ditutup atau dihapus oleh Host.');
          setCurrentRoomId(null);
          setRoomData(null);
          return;
        }
        setRoomData(room);
      },
      (err) => {
        console.warn('Error subscribing to game room:', err);
      }
    );

    return () => unsub();
  }, [currentRoomId]);

  // Reset local answer state when currentQuestionIndex changes
  useEffect(() => {
    setHasAnsweredCurrent(false);
    setSelectedOptionIndex(null);
    setIsAnswerCorrect(null);
    setQuestionTimer(20);

    if (roomData?.status === 'playing') {
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = setInterval(() => {
        setQuestionTimer((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [roomData?.currentQuestionIndex, roomData?.status]);

  // Trigger celebration confetti when room finishes
  useEffect(() => {
    if (roomData?.status === 'finished') {
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.5 },
        });
      } catch {
        // Fallback
      }

      // Check if current user is top scorer and award XP
      if (onAddXP) {
        onAddXP(100);
      }
    }
  }, [roomData?.status]);

  // Action: Create Room
  const handleCreateRoom = async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const newRoom = await createGameRoom({
        hostId: currentUserId,
        hostName: currentUserName,
        title: customTitle,
        questions: DEFAULT_MULTIPLAYER_QUESTIONS,
      });
      if (newRoom.id) {
        setCurrentRoomId(newRoom.id);
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Gagal membuat room permainan.');
    } finally {
      setIsLoading(false);
    }
  };

  // Action: Create Demo 2-Player Room (Exact Match for user schema with Budi & Ani)
  const handleCreateDemoRoom = async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const room = await createGameRoom({
        hostId: currentUserId,
        hostName: currentUserName,
        title: 'Duel Kimia (Simulasi 2 Pemain)',
        questions: DEFAULT_MULTIPLAYER_QUESTIONS,
      });

      if (room.id) {
        // Append a simulated second player "Ani" or "Budi" if user is already one
        const simulatedName = currentUserName.toLowerCase().includes('budi') ? 'Ani' : 'Budi';
        const simulatedPlayer: GameRoomPlayer = {
          uid: 'simulated_student_' + Math.random().toString(36).substring(2, 6),
          nama: simulatedName,
          score: 0,
        };

        const updatedPlayers = [...(room.players || []), simulatedPlayer];
        await updateGameRoom(room.id, {
          players: updatedPlayers,
        });

        setCurrentRoomId(room.id);
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Gagal membuat room demo.');
    } finally {
      setIsLoading(false);
    }
  };

  // Action: Join Room by Code
  const handleJoinByCode = async (codeToJoin?: string) => {
    const code = codeToJoin || joinCodeInput;
    if (!code.trim()) {
      setErrorMsg('Masukkan kode room terlebih dahulu.');
      return;
    }
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const joined = await joinGameRoom(code.trim(), {
        uid: currentUserId,
        nama: currentUserName,
      });
      if (joined.id) {
        setCurrentRoomId(joined.id);
        setJoinCodeInput('');
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Gagal bergabung ke room.');
    } finally {
      setIsLoading(false);
    }
  };

  // Action: Add Simulated Practice Bot to Room (for testing)
  const handleAddBotPlayer = async () => {
    if (!roomData?.id || !isHost) return;
    const botNames = ['Budi', 'Ani', 'Citra', 'Dimas', 'Eka'];
    const existingNames = (roomData.players || []).map((p) => p.nama);
    const availableName = botNames.find((n) => !existingNames.includes(n)) || 'Teman Belajar';

    const newBotPlayer: GameRoomPlayer = {
      uid: 'sim_bot_' + Math.random().toString(36).substring(2, 7),
      nama: availableName,
      score: 0,
    };

    const newPlayers = [...(roomData.players || []), newBotPlayer];
    await updateGameRoom(roomData.id, {
      players: newPlayers,
    });
  };

  // Action: Start Game (Host only)
  const handleStartGame = async () => {
    if (!roomData?.id || !isHost) return;
    setIsLoading(true);
    try {
      await updateGameRoom(roomData.id, {
        status: 'playing',
        currentQuestionIndex: 0,
      });
    } catch (err: any) {
      setErrorMsg(err?.message || 'Gagal memulai permainan.');
    } finally {
      setIsLoading(false);
    }
  };

  // Action: Submit Answer for current user
  const handleSubmitAnswer = async (optionIdx: number) => {
    if (hasAnsweredCurrent || !roomData?.id || roomData.status !== 'playing') return;

    const currentQuestions = roomData.questions || DEFAULT_MULTIPLAYER_QUESTIONS;
    const currentQ = currentQuestions[roomData.currentQuestionIndex || 0];
    const isCorrect = optionIdx === currentQ.correctIndex;

    setHasAnsweredCurrent(true);
    setSelectedOptionIndex(optionIdx);
    setIsAnswerCorrect(isCorrect);

    // Calculate score addition
    const pointsToAdd = isCorrect ? 100 + Math.max(0, questionTimer * 2) : 0;

    // Update current user's score in the room players array
    const updatedPlayers = (roomData.players || []).map((p) => {
      if (p.uid === currentUserId) {
        return {
          ...p,
          score: (p.score || 0) + pointsToAdd,
          answeredCurrent: true,
          selectedOption: optionIdx,
        };
      }
      return p;
    });

    try {
      await updateGameRoom(roomData.id, {
        players: updatedPlayers,
      });

      if (isCorrect) {
        try {
          confetti({ particleCount: 30, spread: 45, origin: { y: 0.7 } });
        } catch {
          // ignore
        }
      }

      // If simulated bot exists, simulate bot answer with 70% random chance after a delay
      const botPlayer = updatedPlayers.find((p) => p.uid.startsWith('sim_'));
      if (botPlayer && isHost) {
        setTimeout(async () => {
          const botWins = Math.random() > 0.3;
          const botPoints = botWins ? 100 : 0;
          const freshPlayers = (roomData.players || updatedPlayers).map((p) => {
            if (p.uid === botPlayer.uid) {
              return {
                ...p,
                score: (p.score || 0) + botPoints,
                answeredCurrent: true,
              };
            }
            return p;
          });
          await updateGameRoom(roomData.id!, {
            players: freshPlayers,
          });
        }, 1200);
      }
    } catch (err: any) {
      console.warn('Error updating player score in Firestore:', err);
    }
  };

  // Action: Next Question (Host action or manual advance)
  const handleNextQuestion = async () => {
    if (!roomData?.id) return;
    const currentQuestions = roomData.questions || DEFAULT_MULTIPLAYER_QUESTIONS;
    const nextIdx = (roomData.currentQuestionIndex || 0) + 1;

    if (nextIdx >= currentQuestions.length) {
      // Game finished!
      await updateGameRoom(roomData.id, {
        status: 'finished',
      });
    } else {
      // Reset answered flags for all players
      const resetPlayers = (roomData.players || []).map((p) => ({
        ...p,
        answeredCurrent: false,
        selectedOption: null,
      }));

      await updateGameRoom(roomData.id, {
        currentQuestionIndex: nextIdx,
        players: resetPlayers,
      });
    }
  };

  // Action: Rematch / Play Again
  const handleRematch = async () => {
    if (!roomData?.id) return;
    const resetPlayers = (roomData.players || []).map((p) => ({
      ...p,
      score: 0,
      answeredCurrent: false,
      selectedOption: null,
    }));

    await updateGameRoom(roomData.id, {
      status: 'waiting',
      currentQuestionIndex: 0,
      players: resetPlayers,
    });
  };

  // Action: Leave Room
  const handleLeaveRoom = async () => {
    if (roomData?.id) {
      // Remove self from room players
      const remainingPlayers = (roomData.players || []).filter((p) => p.uid !== currentUserId);
      if (remainingPlayers.length === 0 || isHost) {
        // If host leaves or room is empty, delete the room
        await deleteGameRoom(roomData.id);
      } else {
        await updateGameRoom(roomData.id, {
          players: remainingPlayers,
        });
      }
    }
    setCurrentRoomId(null);
    setRoomData(null);
  };

  const copyRoomCode = () => {
    if (roomData?.roomCode) {
      navigator.clipboard.writeText(roomData.roomCode);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  /* -------------------------------------------------------------
   * RENDER: 1. LOBBY (When not currently in any room)
   * -----------------------------------------------------------*/
  if (!roomData) {
    return (
      <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
        {/* Header Hero Banner */}
        <div className="rounded-2xl bg-gradient-to-r from-cyan-950/70 via-indigo-950/60 to-slate-900 border border-cyan-500/30 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden">
          <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-cyan-500/10 blur-2xl pointer-events-none" />
          <div className="relative z-10">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-mono text-xs font-bold mb-2">
              <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              Multiplayer Firestore Real-Time
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2">
              <Swords className="w-7 h-7 text-cyan-400" />
              Duel Kuis Kimia Multi-Pemain
            </h2>
            <p className="text-sm text-slate-300 mt-1 max-w-xl">
              Tantang teman sekelas atau guru dalam kuis cepat kimia SMA secara real-time. Sinkronisasi
              skor langsung dan papan peringkat instan via Firestore!
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0">
            <button
              onClick={handleCreateDemoRoom}
              disabled={isLoading}
              className="px-4 py-2.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-indigo-200 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              title="Buat Room instan dengan 2 pemain (Budi & Ani) untuk menguji skema"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              Demo 2 Pemain (Budi & Ani)
            </button>
          </div>
        </div>

        {errorMsg && (
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between">
            <span>{errorMsg}</span>
            <button onClick={() => setErrorMsg(null)} className="text-rose-400 hover:text-white">
              ✕
            </button>
          </div>
        )}

        {/* 2-Column Action Cards: Create Room vs Join Room */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card 1: Buat Room Baru */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4 hover:border-cyan-500/30 transition shadow-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Crown className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Buat Room Baru</h3>
                <p className="text-xs text-slate-400">Jadilah Host dan bagikan kode room ke teman</p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Nama Topik / Judul Kuis:
                </label>
                <input
                  type="text"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  placeholder="Misal: Kuis Cepat Struktur Atom & Ikatan"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700/80 text-white text-sm focus:outline-none focus:border-cyan-500 transition font-medium"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-400 space-y-1">
                <div className="flex justify-between">
                  <span>Host:</span>
                  <span className="font-bold text-cyan-300">{currentUserName}</span>
                </div>
                <div className="flex justify-between">
                  <span>Jumlah Soal:</span>
                  <span className="font-bold text-slate-200">
                    {DEFAULT_MULTIPLAYER_QUESTIONS.length} Pertanyaan
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Status Awal:</span>
                  <span className="font-mono text-amber-300">waiting</span>
                </div>
              </div>

              <button
                onClick={handleCreateRoom}
                disabled={isLoading}
                className="w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-500/25 transition cursor-pointer flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4 fill-current" />
                {isLoading ? 'Membuat Room...' : 'Buat Room Permainan'}
              </button>
            </div>
          </div>

          {/* Card 2: Gabung dengan Kode Room */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4 hover:border-indigo-500/30 transition shadow-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Gabung Room</h3>
                <p className="text-xs text-slate-400">Masukkan 6 digit kode yang dibagikan oleh Host</p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Kode Room (6 Karakter):
                </label>
                <input
                  type="text"
                  maxLength={10}
                  value={joinCodeInput}
                  onChange={(e) => setJoinCodeInput(e.target.value.toUpperCase())}
                  placeholder="Contoh: KIMIA8"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700/80 text-white text-lg font-mono font-bold tracking-widest uppercase focus:outline-none focus:border-indigo-500 transition text-center"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-400 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Pemain akan langsung terhubung ke sesi sinkron Firestore.</span>
              </div>

              <button
                onClick={() => handleJoinByCode()}
                disabled={isLoading || !joinCodeInput.trim()}
                className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-sm shadow-lg shadow-indigo-600/25 transition cursor-pointer flex items-center justify-center gap-2"
              >
                <ArrowRight className="w-4 h-4" />
                {isLoading ? 'Menghubungkan...' : 'Gabung ke Room'}
              </button>
            </div>
          </div>
        </div>

        {/* Live Open Waiting Rooms List */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <h3 className="text-base font-bold text-white">Room Terbuka Sedang Menunggu Lawan</h3>
            </div>
            <span className="text-xs font-mono text-slate-400">{openRooms.length} room aktif</span>
          </div>

          {openRooms.length === 0 ? (
            <div className="p-8 text-center rounded-xl bg-slate-950/40 border border-slate-800/60 text-slate-400 text-xs space-y-2">
              <Users className="w-8 h-8 text-slate-600 mx-auto" />
              <p>Belum ada room terbuka saat ini.</p>
              <p className="text-slate-500">
                Buat room pertamamu di atas dan undang teman sekelas untuk bertanding!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {openRooms.map((room) => (
                <div
                  key={room.id}
                  className="p-4 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500/50 transition flex items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <span className="text-xs font-mono font-bold text-cyan-400">
                      Kode: {room.roomCode || room.id?.substring(0, 6)}
                    </span>
                    <h4 className="text-sm font-bold text-white line-clamp-1">{room.title}</h4>
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <span>Host: {room.players?.[0]?.nama || 'Guru/Siswa'}</span>
                      <span>•</span>
                      <span>{room.players?.length || 1} Pemain</span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleJoinByCode(room.roomCode || room.id)}
                    className="px-3.5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shrink-0 transition cursor-pointer"
                  >
                    Ikut ➔
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  /* -------------------------------------------------------------
   * RENDER: 2. WAITING LOBBY (roomData.status === 'waiting')
   * -----------------------------------------------------------*/
  if (roomData.status === 'waiting') {
    const players = roomData.players || [];
    return (
      <div className="space-y-6 animate-fade-in max-w-3xl mx-auto">
        {/* Waiting Room Card */}
        <div className="rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/40 border border-indigo-500/30 p-6 sm:p-8 space-y-6 shadow-2xl relative">
          {/* Top Bar with Room Code */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <span className="px-2.5 py-1 rounded-md bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold uppercase tracking-wider">
                Status: WAITING
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white mt-1.5">{roomData.title}</h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={copyRoomCode}
                className="px-3.5 py-2 rounded-xl bg-slate-950 border border-indigo-500/40 hover:border-indigo-400 text-indigo-300 text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
                title="Salin Kode Room"
              >
                {copiedCode ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    Tersalin!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    Kode: <span className="text-white tracking-widest">{roomData.roomCode}</span>
                  </>
                )}
              </button>
              <button
                onClick={handleLeaveRoom}
                className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-rose-500/50 text-slate-400 hover:text-rose-300 text-xs transition cursor-pointer"
                title="Tinggalkan Room"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Lobby Instruction */}
          <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-200 flex items-center gap-3">
            <Radio className="w-5 h-5 text-indigo-400 shrink-0 animate-pulse" />
            <div>
              <p className="font-bold">Lobby Sinkronisasi Real-Time</p>
              <p className="text-indigo-300/80">
                Bagikan kode <strong>{roomData.roomCode}</strong> kepada teman. Pemain yang bergabung
                akan otomatis muncul di daftar bawah ini.
              </p>
            </div>
          </div>

          {/* Players in Lobby */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-bold text-slate-300">Pemain Bergabung ({players.length}):</span>
              {isHost && (
                <button
                  onClick={handleAddBotPlayer}
                  className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-bold transition cursor-pointer"
                  title="Tambah bot simulasi untuk menguji multi-pemain"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  Tambah Lawan Uji Coba (Budi/Ani)
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {players.map((player, idx) => {
                const isPlayerHost = player.uid === roomData.hostId;
                const isMe = player.uid === currentUserId;
                return (
                  <div
                    key={player.uid || idx}
                    className={`p-4 rounded-xl border flex items-center justify-between gap-3 ${
                      isMe
                        ? 'bg-cyan-950/30 border-cyan-500/50 shadow-md'
                        : 'bg-slate-950/80 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow">
                        {player.nama?.charAt(0)?.toUpperCase() || 'P'}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm font-bold text-white">{player.nama}</span>
                          {isPlayerHost && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-300 font-bold flex items-center gap-0.5">
                              <Crown className="w-2.5 h-2.5 text-amber-400" />
                              HOST
                            </span>
                          )}
                          {isMe && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] bg-cyan-500/20 text-cyan-300 font-bold">
                              Anda
                            </span>
                          )}
                        </div>
                        <span className="text-xs text-slate-400 font-mono">Skor: {player.score || 0}</span>
                      </div>
                    </div>
                    <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
                  </div>
                );
              })}
            </div>
          </div>

          {/* Host Start Game CTA */}
          <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-slate-400 text-center sm:text-left">
              {isHost ? (
                <span>Anda adalah Host. Klik tombol di kanan saat semua pemain sudah masuk.</span>
              ) : (
                <span className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400 animate-spin" />
                  Menunggu Host memulai pertandingan...
                </span>
              )}
            </div>

            {isHost && (
              <button
                onClick={handleStartGame}
                disabled={isLoading}
                className="w-full sm:w-auto px-8 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-sm shadow-lg shadow-emerald-500/30 transition cursor-pointer flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4 fill-current" />
                Mulai Duel Sekarang!
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  /* -------------------------------------------------------------
   * RENDER: 3. PLAYING PHASE (roomData.status === 'playing')
   * -----------------------------------------------------------*/
  if (roomData.status === 'playing') {
    const questions = roomData.questions || DEFAULT_MULTIPLAYER_QUESTIONS;
    const currentQIndex = roomData.currentQuestionIndex || 0;
    const currentQ: GameRoomQuestion = questions[currentQIndex] || questions[0];
    const players = [...(roomData.players || [])].sort((a, b) => (b.score || 0) - (a.score || 0));

    return (
      <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
        {/* Top Battle Header with Live Leaderboard */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 sm:p-6 space-y-4 shadow-xl">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-300 font-mono text-xs font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                STATUS: PLAYING
              </span>
              <span className="text-xs text-slate-400 font-medium">
                Soal #{currentQIndex + 1} dari {questions.length}
              </span>
            </div>

            {/* Timer countdown */}
            <div className="flex items-center gap-2 px-3 py-1 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs font-bold text-amber-300">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>{questionTimer}s</span>
            </div>
          </div>

          {/* Live Score Strip of all players */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {players.map((p, idx) => {
              const isMe = p.uid === currentUserId;
              return (
                <div
                  key={p.uid || idx}
                  className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 transition ${
                    isMe
                      ? 'bg-cyan-950/40 border-cyan-500/60 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
                      : 'bg-slate-950/60 border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-xs font-bold text-amber-400">#{idx + 1}</span>
                    <span className="text-xs font-bold text-white truncate">
                      {p.nama} {isMe && '(Anda)'}
                    </span>
                  </div>
                  <span className="text-xs font-mono font-black text-cyan-300 shrink-0">
                    {p.score || 0}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Current Question Arena Card */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="space-y-2">
            <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
              Topik: {currentQ.topic || 'Kimia SMA'}
            </span>
            <h3 className="text-lg sm:text-xl font-bold text-white leading-relaxed">
              {currentQ.question}
            </h3>
          </div>

          {/* Multiple Choice Options */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            {currentQ.options.map((opt, optIdx) => {
              const isSelected = selectedOptionIndex === optIdx;
              const isCorrect = optIdx === currentQ.correctIndex;

              let btnClass =
                'bg-slate-950/80 border-slate-800 text-slate-200 hover:bg-slate-800 hover:border-slate-700';

              if (hasAnsweredCurrent) {
                if (isCorrect) {
                  btnClass =
                    'bg-emerald-500/20 border-emerald-500 text-emerald-200 font-bold shadow-[0_0_15px_rgba(16,185,129,0.2)]';
                } else if (isSelected && !isCorrect) {
                  btnClass = 'bg-rose-500/20 border-rose-500 text-rose-200 font-bold';
                } else {
                  btnClass = 'bg-slate-950/40 border-slate-800/40 text-slate-500 opacity-60';
                }
              }

              return (
                <button
                  key={optIdx}
                  disabled={hasAnsweredCurrent}
                  onClick={() => handleSubmitAnswer(optIdx)}
                  className={`p-4 rounded-xl border text-left font-medium transition cursor-pointer flex items-center justify-between gap-3 text-sm sm:text-base ${btnClass}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-lg bg-slate-800 flex items-center justify-center text-xs font-mono font-bold text-slate-300">
                      {String.fromCharCode(65 + optIdx)}
                    </span>
                    <span>{opt}</span>
                  </div>
                  {hasAnsweredCurrent && isCorrect && (
                    <span className="text-xs font-bold text-emerald-400 shrink-0">✓ BENAR</span>
                  )}
                  {hasAnsweredCurrent && isSelected && !isCorrect && (
                    <span className="text-xs font-bold text-rose-400 shrink-0">✗ SALAH</span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation if answered */}
          {hasAnsweredCurrent && (
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-xs space-y-1 animate-fade-in">
              <span className="font-bold text-cyan-400">💡 Pembahasan:</span>
              <p className="text-slate-300">{currentQ.explanation}</p>
            </div>
          )}

          {/* Navigation to Next Question */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-800">
            <span className="text-xs text-slate-400">
              {hasAnsweredCurrent ? 'Jawaban Anda telah tercatat ke server!' : 'Pilih jawaban di atas'}
            </span>

            {/* Advance button */}
            <button
              onClick={handleNextQuestion}
              className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md transition cursor-pointer flex items-center gap-2"
            >
              {currentQIndex >= questions.length - 1 ? (
                <>Lihat Hasil Akhir ➔</>
              ) : (
                <>Soal Selanjutnya ➔</>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  /* -------------------------------------------------------------
   * RENDER: 4. FINISHED PHASE (roomData.status === 'finished')
   * -----------------------------------------------------------*/
  const sortedPlayers = [...(roomData.players || [])].sort(
    (a, b) => (b.score || 0) - (a.score || 0)
  );
  const winner = sortedPlayers[0];

  return (
    <div className="space-y-6 animate-fade-in max-w-3xl mx-auto">
      {/* Victory Podium Banner */}
      <div className="rounded-2xl bg-gradient-to-b from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/30 p-8 text-center space-y-6 shadow-2xl relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-500/10 via-transparent to-transparent pointer-events-none" />

        <div className="space-y-2 relative z-10">
          <span className="px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-mono font-bold uppercase tracking-wider">
            Pertandingan Selesai (status: finished)
          </span>
          <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/40 mx-auto flex items-center justify-center text-amber-400 shadow-lg mt-3">
            <Trophy className="w-9 h-9" />
          </div>
          <h2 className="text-3xl font-black text-white">Juara: {winner?.nama || 'Pemenang'}!</h2>
          <p className="text-sm text-slate-300">
            Selamat kepada semua pemain! Skor tertinggi berhasil diraih dengan{' '}
            <strong className="text-amber-400">{winner?.score || 0} poin</strong>.
          </p>
        </div>

        {/* Podium Leaderboard */}
        <div className="space-y-3 max-w-lg mx-auto relative z-10">
          {sortedPlayers.map((player, idx) => {
            const isMe = player.uid === currentUserId;
            const medals = ['🥇', '🥈', '🥉'];
            const medal = medals[idx] || `#${idx + 1}`;

            return (
              <div
                key={player.uid || idx}
                className={`p-4 rounded-xl border flex items-center justify-between gap-4 transition ${
                  idx === 0
                    ? 'bg-amber-500/10 border-amber-500/40 shadow-md'
                    : isMe
                    ? 'bg-cyan-950/30 border-cyan-500/40'
                    : 'bg-slate-950 border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-xl">{medal}</span>
                  <div className="text-left">
                    <span className="text-sm font-bold text-white block">
                      {player.nama} {isMe && '(Anda)'}
                    </span>
                    <span className="text-xs text-slate-400">Peringkat ke-{idx + 1}</span>
                  </div>
                </div>
                <span className="text-base font-mono font-black text-amber-400">
                  {player.score || 0} Poin
                </span>
              </div>
            );
          })}
        </div>

        {/* Action Controls */}
        <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-center gap-3 relative z-10">
          {isHost && (
            <button
              onClick={handleRematch}
              className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition cursor-pointer flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Main Lagi (Reset Room & Skor)
            </button>
          )}

          <button
            onClick={handleLeaveRoom}
            className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition cursor-pointer flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            Keluar ke Menu Games
          </button>
        </div>
      </div>
    </div>
  );
}
