import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  baseRadius: number;
  radius: number;
  color: string;
  glowColor: string;
  symbol?: string;
  alpha: number;
}

export default function ChemistryNetworkBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = 0;
    let height = 0;

    // Mouse coordinates (global window tracking so canvas can remain pointer-events: none)
    const mouse = {
      x: -1000,
      y: -1000,
      radius: 130, // Interaction radius in pixels
      active: false,
    };

    const handleMouseMove = (e: MouseEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
      mouse.active = true;
    };

    const handleMouseLeave = () => {
      mouse.x = -1000;
      mouse.y = -1000;
      mouse.active = false;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('mouseleave', handleMouseLeave, { passive: true });

    // Chemical symbols floating subtly with some key particles
    const CHEMICAL_TAGS = ['H₂O', 'CH₄', 'NaCl', 'CO₂', 'Fe²⁺', 'OH⁻', 'H⁺', 'O₂', 'NH₃'];

    const PARTICLE_PALETTE = [
      { color: '#22D3EE', glow: 'rgba(34, 211, 238, 0.4)' }, // Neon Cyan (primary)
      { color: '#38BDF8', glow: 'rgba(56, 189, 248, 0.35)' }, // Electric Sky
      { color: '#A78BFA', glow: 'rgba(167, 139, 250, 0.35)' }, // Quantum Violet
      { color: '#67E8F9', glow: 'rgba(103, 232, 249, 0.3)' }, // Bright Cyan
      { color: '#F8FAFC', glow: 'rgba(248, 250, 252, 0.25)' }, // Pure White Sparkle
    ];

    let particles: Particle[] = [];

    const initParticles = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;

      // Responsive particle count: ~40 on mobile, up to ~95 on desktop
      const isMobile = width < 768;
      const count = isMobile
        ? Math.max(30, Math.floor((width * height) / 22000))
        : Math.min(100, Math.max(60, Math.floor((width * height) / 16000)));

      particles = [];

      for (let i = 0; i < count; i++) {
        const style = PARTICLE_PALETTE[Math.floor(Math.random() * PARTICLE_PALETTE.length)];
        const isSpecialNode = Math.random() > 0.82; // Some larger "atoms" with formulas
        const baseRadius = isSpecialNode
          ? Math.random() * 1.5 + 2.8
          : Math.random() * 1.2 + 1.6;

        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 0.55,
          vy: (Math.random() - 0.5) * 0.55,
          baseRadius,
          radius: baseRadius,
          color: style.color,
          glowColor: style.glow,
          symbol: isSpecialNode
            ? CHEMICAL_TAGS[Math.floor(Math.random() * CHEMICAL_TAGS.length)]
            : undefined,
          alpha: Math.random() * 0.45 + 0.35,
        });
      }
    };

    initParticles();

    const handleResize = () => {
      initParticles();
    };

    window.addEventListener('resize', handleResize, { passive: true });

    // Handle tab visibility to pause animation and save CPU/battery
    let isVisible = document.visibilityState === 'visible';
    const handleVisibility = () => {
      isVisible = document.visibilityState === 'visible';
    };
    document.addEventListener('visibilitychange', handleVisibility);

    // Max distance for molecular bond line
    const maxBondDistance = window.innerWidth < 768 ? 95 : 135;

    // Main 60fps render loop
    const render = () => {
      if (!isVisible) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      ctx.clearRect(0, 0, width, height);

      // 1. Update particle positions and apply subtle mouse evasion physics
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Natural Brownian drift
        p.x += p.vx;
        p.y += p.vy;

        // Wrap around edges smoothly
        if (p.x < -10) p.x = width + 10;
        if (p.x > width + 10) p.x = -10;
        if (p.y < -10) p.y = height + 10;
        if (p.y > height + 10) p.y = -10;

        // Interactive Mouse Evasion (Smooth chemical repulsion)
        if (mouse.active) {
          const dx = p.x - mouse.x;
          const dy = p.y - mouse.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < mouse.radius && dist > 0.1) {
            // Repulsion force inversely proportional to distance
            const force = (1 - dist / mouse.radius) * 1.8;
            const angle = Math.atan2(dy, dx);
            p.x += Math.cos(angle) * force;
            p.y += Math.sin(angle) * force;

            // Slight temporary excitation of particle size when near cursor
            p.radius = p.baseRadius * (1 + (1 - dist / mouse.radius) * 0.4);
          } else {
            // Smooth recovery to base size
            p.radius += (p.baseRadius - p.radius) * 0.08;
          }
        } else {
          p.radius += (p.baseRadius - p.radius) * 0.08;
        }
      }

      // 2. Draw molecular chemical bonds between nearby particles
      ctx.lineWidth = 0.85;

      for (let i = 0; i < particles.length; i++) {
        const p1 = particles[i];

        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dx = p1.x - p2.x;
          const dy = p1.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < maxBondDistance) {
            // Opacity fades as particles drift apart
            const bondAlpha = (1 - dist / maxBondDistance) * 0.22;

            // Subtle gradient bond line
            const gradient = ctx.createLinearGradient(p1.x, p1.y, p2.x, p2.y);
            gradient.addColorStop(0, `rgba(34, 211, 238, ${bondAlpha})`);
            gradient.addColorStop(1, `rgba(167, 139, 250, ${bondAlpha})`);

            ctx.strokeStyle = gradient;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }

        // Draw delicate bond line to cursor if mouse is nearby (catalyst probe effect)
        if (mouse.active) {
          const dxMouse = p1.x - mouse.x;
          const dyMouse = p1.y - mouse.y;
          const distMouse = Math.sqrt(dxMouse * dxMouse + dyMouse * dyMouse);

          if (distMouse < mouse.radius) {
            const probeAlpha = (1 - distMouse / mouse.radius) * 0.15;
            ctx.strokeStyle = `rgba(34, 211, 238, ${probeAlpha})`;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(mouse.x, mouse.y);
            ctx.stroke();
          }
        }
      }

      // 3. Draw atoms / particles with glowing halos
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Outer soft glow halo
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius * 2.2, 0, Math.PI * 2);
        ctx.fillStyle = p.glowColor;
        ctx.fill();

        // Solid atom nucleus
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.fill();

        // Optional tiny chemical formula tag next to special atoms
        if (p.symbol) {
          ctx.font = '9px "JetBrains Mono", monospace';
          ctx.fillStyle = '#67E8F9';
          ctx.globalAlpha = p.alpha * 0.7;
          ctx.fillText(p.symbol, p.x + p.radius + 3, p.y + 3);
        }

        ctx.globalAlpha = 1.0;
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, []);

  return (
    <div
      className="fixed inset-0 overflow-hidden pointer-events-none select-none bg-[#040714]"
      style={{ zIndex: 0 }}
      aria-hidden="true"
    >
      {/* ========================================================= */}
      {/* PRE-RENDERED AMBIENT RADIAL GLOWS (Left: Cyan, Right: Purple) */}
      {/* ========================================================= */}
      {/* Left side: Soft glowing Neon Cyan orb */}
      <div
        className="absolute -top-16 -left-20 w-[520px] h-[520px] rounded-full pointer-events-none opacity-[0.16] blur-[120px]"
        style={{
          background: 'radial-gradient(circle, #06B6D4 0%, #22D3EE 40%, transparent 70%)',
        }}
      />
      <div
        className="absolute bottom-10 left-[5%] w-[420px] h-[420px] rounded-full pointer-events-none opacity-[0.12] blur-[110px]"
        style={{
          background: 'radial-gradient(circle, #0891B2 0%, #38BDF8 40%, transparent 70%)',
        }}
      />

      {/* Right side: Soft glowing Quantum Violet/Purple orb */}
      <div
        className="absolute top-[20%] -right-24 w-[560px] h-[560px] rounded-full pointer-events-none opacity-[0.15] blur-[130px]"
        style={{
          background: 'radial-gradient(circle, #8B5CF6 0%, #A855F7 40%, transparent 70%)',
        }}
      />
      <div
        className="absolute -bottom-16 right-[15%] w-[460px] h-[460px] rounded-full pointer-events-none opacity-[0.11] blur-[120px]"
        style={{
          background: 'radial-gradient(circle, #6366F1 0%, #7C3AED 40%, transparent 70%)',
        }}
      />

      {/* HTML5 Canvas with molecular constellation network */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full block"
        style={{ pointerEvents: 'none' }}
      />

      {/* Cinematic Vignette Overlay (darkens viewport perimeter, keeps form highlighted in center) */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse at center, transparent 35%, rgba(4, 7, 20, 0.45) 75%, rgba(4, 7, 20, 0.85) 100%)',
        }}
      />
    </div>
  );
}
