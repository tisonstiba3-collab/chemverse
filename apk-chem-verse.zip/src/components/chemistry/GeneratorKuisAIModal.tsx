import React, { useState } from 'react';
import {
  Sparkles,
  X,
  BookOpen,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  RefreshCw,
  Award,
  Zap,
  ArrowRight,
  RotateCcw,
  FileText,
  Copy,
  ChevronRight,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { StudentProfile } from '../../types/chemistry';

export interface QuizQuestion {
  soal: string;
  pilihan: {
    A: string;
    B: string;
    C: string;
    D: string;
    E: string;
  };
  jawaban_benar: 'A' | 'B' | 'C' | 'D' | 'E' | string;
}

interface GeneratorKuisAIModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentProfile;
  onAddXP?: (amount: number) => void;
}

const SAMPLE_CHEMISTRY_TEXTS = [
  {
    title: 'Termokimia & Hukum Hess',
    text: `Termokimia adalah cabang ilmu kimia yang mempelajari hubungan antara reaksi kimia dengan perubahan energi kalor. Reaksi eksoterm membebaskan kalor ke lingkungan (ΔH bernilai negatif), sedangkan reaksi endoterm menyerap kalor dari lingkungan (ΔH bernilai positif). Hukum Hess menyatakan bahwa perubahan entalpi reaksi hanya bergantung pada keadaan awal dan keadaan akhir reaktan serta produk, tidak bergantung pada jalannya reaksi bertahap. Kalorimeter digunakan secara eksperimen untuk mengukur jumlah kalor reaksi dengan rumus q = m × c × ΔT. Entalpi pembentukan standar (ΔHf°) didefinisikan sebagai perubahan entalpi pada pembentukan 1 mol senyawa dari unsur-unsurnya dalam bentuk paling stabil pada kondisi standar (25°C, 1 atm).`,
  },
  {
    title: 'Kesetimbangan Kimia & Azas Le Chatelier',
    text: `Kesetimbangan kimia dinamis tercapai ketika laju reaksi maju sama dengan laju reaksi balik, dan konsentrasi reaktan serta produk bernilai konstan sepanjang waktu. Azas Le Chatelier berbunyi: Jika suatu sistem kesetimbangan diberikan aksi atau gangguan (seperti perubahan konsentrasi, tekanan, volume, atau suhu), sistem akan melakukan reaksi untuk meminimalkan pengaruh gangguan tersebut. Peningkatan konsentrasi reaktan menggeser kesetimbangan ke arah produk (kanan). Peningkatan tekanan (atau penurunan volume) menggeser reaksi ke arah jumlah koefisien gas yang lebih kecil. Peningkatan suhu menggeser kesetimbangan ke arah reaksi endotermik. Katalis mempercepat tercapainya kesetimbangan tanpa mengubah posisi nilai tetapan kesetimbangan (Kc atau Kp).`,
  },
  {
    title: 'Stoikiometri & Konsep Mol',
    text: `Stoikiometri mempelajari aspek kuantitatif zat dalam reaksi kimia berdasarkan hukum-hukum dasar kimia seperti Hukum Kekekalan Massa (Lavoisier) dan Hukum Perbandingan Tetap (Proust). Satu mol didefinisikan mengandung 6,022 × 10²³ partikel (Bilangan Avogadro). Hubungan jumlah mol (n) dengan massa (m) dan massa molar (Mr) dinyatakan dengan n = m / Mr. Pada keadaan standar (STP, 0°C dan 1 atm), volume molar satu mol gas ideal sama dengan 22,4 Liter. Pereaksi pembatas adalah reaktan yang habis terlebih dahulu dalam reaksi kimia dan membatasi jumlah maksimum produk yang dapat terbentuk.`,
  },
];

export default function GeneratorKuisAIModal({
  isOpen,
  onClose,
  student,
  onAddXP,
}: GeneratorKuisAIModalProps) {
  const [inputText, setInputText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [questions, setQuestions] = useState<QuizQuestion[] | null>(null);

  // Quiz interactive state
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [xpClaimed, setXpClaimed] = useState(false);

  if (!isOpen) return null;

  const handleGenerateQuiz = async () => {
    const trimmed = inputText.trim();
    if (!trimmed) {
      setErrorMessage('Silakan masukkan artikel atau materi kimia terlebih dahulu.');
      return;
    }

    if (trimmed.length < 25) {
      setErrorMessage('Teks materi terlalu pendek. Masukkan minimal 25 karakter agar AI dapat membuat 5 soal berkualitas.');
      return;
    }

    setIsGenerating(true);
    setErrorMessage(null);
    setQuestions(null);
    setSelectedAnswers({});
    setIsSubmitted(false);
    setScore(0);
    setXpClaimed(false);

    try {
      const response = await fetch('/api/quiz/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: trimmed, isLightweight: true }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server error (${response.status})`);
      }

      const data = await response.json();
      if (!data.success || !Array.isArray(data.questions) || data.questions.length === 0) {
        throw new Error('Format respon kuis dari AI tidak valid. Coba ulangi dengan materi lain.');
      }

      // Validate question structure
      const validatedQuestions: QuizQuestion[] = data.questions.map((q: any, idx: number) => ({
        soal: q.soal || `Soal Kimia Nomor ${idx + 1}`,
        pilihan: {
          A: q.pilihan?.A || 'Pilihan A',
          B: q.pilihan?.B || 'Pilihan B',
          C: q.pilihan?.C || 'Pilihan C',
          D: q.pilihan?.D || 'Pilihan D',
          E: q.pilihan?.E || 'Pilihan E',
        },
        jawaban_benar: String(q.jawaban_benar || 'A').toUpperCase().trim(),
      }));

      setQuestions(validatedQuestions);
    } catch (err: any) {
      console.error('Quiz Generator Error:', err);
      setErrorMessage(
        err.message || 'Terjadi kesalahan saat memproses kuis dengan Gemini API. Silakan coba kembali.'
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSelectOption = (questionIndex: number, optionKey: string) => {
    if (isSubmitted) return;
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionIndex]: optionKey,
    }));
  };

  const handleCheckAnswers = () => {
    if (!questions) return;

    let correctCount = 0;
    questions.forEach((q, idx) => {
      const studentChoice = selectedAnswers[idx];
      const correctChoice = q.jawaban_benar.toUpperCase().trim();
      if (studentChoice && studentChoice.toUpperCase().trim() === correctChoice) {
        correctCount++;
      }
    });

    const finalScore = Math.round((correctCount / questions.length) * 100);
    setScore(finalScore);
    setIsSubmitted(true);

    // Award XP
    if (!xpClaimed && onAddXP) {
      const earnedXP = correctCount * 20; // 20 XP per correct question
      if (earnedXP > 0) {
        onAddXP(earnedXP);
        setXpClaimed(true);
      }
    }

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#22D3EE', '#38BDF8', '#818CF8', '#34D399', '#FBBF24'],
      });
    } catch {
      // Ignored if confetti fails
    }
  };

  const handleResetQuiz = () => {
    setSelectedAnswers({});
    setIsSubmitted(false);
    setScore(0);
    setXpClaimed(false);
  };

  const handleStartNewGeneration = () => {
    setQuestions(null);
    setSelectedAnswers({});
    setIsSubmitted(false);
    setScore(0);
    setXpClaimed(false);
    setErrorMessage(null);
  };

  const answeredCount = Object.keys(selectedAnswers).length;
  const totalQuestions = questions?.length || 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-[#090D1F] border border-cyan-500/40 rounded-3xl shadow-2xl shadow-cyan-950/80 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-6 bg-gradient-to-r from-slate-900 via-slate-900/90 to-cyan-950/70 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-indigo-600 p-0.5 shadow-md shadow-cyan-500/20">
              <div className="w-full h-full rounded-[14px] bg-slate-950 flex items-center justify-center text-cyan-400">
                <Sparkles className="w-5 h-5 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-xl font-extrabold text-white tracking-tight">
                  Buat Kuis AI
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[10px] font-bold border border-cyan-500/30">
                  Text-to-Quiz 5 Soal
                </span>
              </div>
              <p className="text-xs text-slate-400 font-normal">
                Tempelkan artikel materi kimia apa saja, AI akan meracik 5 soal pilihan ganda (A-E) otomatis!
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
            title="Tutup Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* View 1: Input text & Generate */}
          {!questions && (
            <div className="space-y-5">
              {/* Sample Quick Snippets */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-cyan-300 font-bold uppercase tracking-wider flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5" />
                    Pilih Contoh Cepat Materi Kimia:
                  </span>
                  <span className="text-[11px] text-slate-400">Klik untuk menempel instan</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {SAMPLE_CHEMISTRY_TEXTS.map((sample, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setInputText(sample.text)}
                      className="p-3 text-left rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 transition cursor-pointer group"
                    >
                      <div className="text-xs font-bold text-slate-200 group-hover:text-cyan-300 transition flex items-center justify-between">
                        <span>{sample.title}</span>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 transition" />
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">
                        {sample.text}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Textarea Input */}
              <div className="space-y-2">
                <label className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider block">
                  Teks Artikel atau Materi Kimia
                </label>
                <div className="relative">
                  <textarea
                    rows={8}
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Tempelkan artikel atau materi kimia di sini... (contoh: ringkasan stoikiometri, kesetimbangan, sel elektrokimia, atau konsep asam-basa dari modul belajar)"
                    disabled={isGenerating}
                    className="w-full p-4 rounded-2xl bg-slate-950 border border-slate-800 text-slate-100 text-xs sm:text-sm placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/40 transition leading-relaxed disabled:opacity-50"
                  />
                  <div className="absolute right-3 bottom-3 flex items-center gap-2">
                    <span className="text-[10px] font-mono text-slate-500">
                      {inputText.trim().length} karakter
                    </span>
                    {inputText.trim() && (
                      <button
                        type="button"
                        onClick={() => setInputText('')}
                        className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-[10px] font-mono text-slate-300 cursor-pointer"
                      >
                        Hapus
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Error Alert */}
              {errorMessage && (
                <div className="p-3.5 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <strong className="block font-bold">Terjadi Kendala</strong>
                    <span>{errorMessage}</span>
                  </div>
                </div>
              )}

              {/* Action Button */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-bold transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleGenerateQuiz}
                  disabled={isGenerating || !inputText.trim()}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-cyan-500/30 hover:scale-102 transition flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                      <span>Sedang Meracik 5 Soal AI...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-slate-950" />
                      <span>Generate Kuis</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* View 2: Interactive Quiz UI */}
          {questions && (
            <div className="space-y-6">
              {/* Score / Status Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-cyan-950/60 to-slate-900 border border-cyan-500/40 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 font-black text-base font-mono">
                    5
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-white">
                      Kuis Berhasil Dihasilkan oleh Gemini AI
                    </h3>
                    <p className="text-xs text-slate-400">
                      Pilihlah salah satu jawaban yang paling tepat (A, B, C, D, atau E) untuk setiap soal.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-cyan-300 px-3 py-1.5 rounded-xl bg-slate-950/80 border border-cyan-500/30">
                    Dijawab: {answeredCount} / {totalQuestions}
                  </span>
                  {isSubmitted && (
                    <span
                      className={`text-xs font-mono font-bold px-3 py-1.5 rounded-xl border ${
                        score >= 80
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          : score >= 60
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                          : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      }`}
                    >
                      Nilai: {score}%
                    </span>
                  )}
                </div>
              </div>

              {/* Questions List */}
              <div className="space-y-6">
                {questions.map((q, qIdx) => {
                  const studentAnswer = selectedAnswers[qIdx];
                  const correctAnswer = q.jawaban_benar.toUpperCase().trim();
                  const isCorrect = isSubmitted && studentAnswer === correctAnswer;
                  const isWrong = isSubmitted && studentAnswer && studentAnswer !== correctAnswer;

                  return (
                    <div
                      key={qIdx}
                      className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                        isSubmitted
                          ? isCorrect
                            ? 'bg-emerald-950/20 border-emerald-500/50 shadow-md shadow-emerald-950/40'
                            : 'bg-rose-950/20 border-rose-500/40 shadow-md shadow-rose-950/40'
                          : studentAnswer
                          ? 'bg-slate-900/90 border-cyan-500/40'
                          : 'bg-slate-900/60 border-slate-800'
                      }`}
                    >
                      {/* Question Header */}
                      <div className="flex items-start gap-3 mb-3">
                        <span className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-mono font-bold flex items-center justify-center shrink-0 mt-0.5">
                          {qIdx + 1}
                        </span>
                        <div className="flex-1">
                          <p className="text-sm font-semibold text-slate-100 leading-relaxed">
                            {q.soal}
                          </p>
                        </div>

                        {/* Result Badge */}
                        {isSubmitted && (
                          <span
                            className={`px-2.5 py-1 rounded-xl text-[10px] font-mono font-bold border shrink-0 flex items-center gap-1 ${
                              isCorrect
                                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                                : 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                            }`}
                          >
                            {isCorrect ? (
                              <>
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                                <span>Benar (+20 XP)</span>
                              </>
                            ) : (
                              <>
                                <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                                <span>Kunci: {correctAnswer}</span>
                              </>
                            )}
                          </span>
                        )}
                      </div>

                      {/* Options A - E */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pl-0 sm:pl-9 mt-3">
                        {(['A', 'B', 'C', 'D', 'E'] as const).map((key) => {
                          const optionText = q.pilihan[key];
                          if (!optionText) return null;

                          const isOptionSelected = studentAnswer === key;
                          const isOptionKeyCorrect = key === correctAnswer;

                          let optionStyle =
                            'bg-slate-950/80 hover:bg-slate-800/80 border-slate-800 text-slate-300';

                          if (isSubmitted) {
                            if (isOptionKeyCorrect) {
                              optionStyle =
                                'bg-emerald-500/25 border-emerald-400 text-emerald-200 font-bold shadow-sm shadow-emerald-500/30';
                            } else if (isOptionSelected) {
                              optionStyle =
                                'bg-rose-500/25 border-rose-400 text-rose-200 font-bold shadow-sm shadow-rose-500/30';
                            } else {
                              optionStyle =
                                'bg-slate-950/40 border-slate-800/60 text-slate-500 opacity-60';
                            }
                          } else if (isOptionSelected) {
                            optionStyle =
                              'bg-cyan-500/25 border-cyan-400 text-cyan-200 font-semibold shadow-md shadow-cyan-500/20';
                          }

                          return (
                            <button
                              key={key}
                              type="button"
                              onClick={() => handleSelectOption(qIdx, key)}
                              disabled={isSubmitted}
                              className={`p-3 rounded-xl border text-left text-xs transition flex items-start gap-2.5 cursor-pointer disabled:cursor-default ${optionStyle}`}
                            >
                              <span
                                className={`w-5 h-5 rounded-md flex items-center justify-center font-mono font-bold text-[10px] shrink-0 border ${
                                  isSubmitted && isOptionKeyCorrect
                                    ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-black'
                                    : isSubmitted && isOptionSelected
                                    ? 'bg-rose-500 text-white border-rose-400 font-black'
                                    : isOptionSelected
                                    ? 'bg-cyan-400 text-slate-950 border-cyan-300 font-black'
                                    : 'bg-slate-900 border-slate-700 text-slate-400'
                                }`}
                              >
                                {key}
                              </span>
                              <span className="flex-1 leading-relaxed">{optionText}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Quiz Footer Actions */}
              <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={handleStartNewGeneration}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-bold transition flex items-center gap-2 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Buat Kuis dari Materi Lain</span>
                </button>

                <div className="flex items-center gap-2.5">
                  {isSubmitted ? (
                    <button
                      type="button"
                      onClick={handleResetQuiz}
                      className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 text-xs font-bold transition cursor-pointer flex items-center gap-1.5"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Ulangi Kuis Ini</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleCheckAnswers}
                      disabled={answeredCount === 0}
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-emerald-500/25 transition flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <CheckCircle2 className="w-4 h-4 text-slate-950" />
                      <span>Cek Jawaban ({answeredCount}/{totalQuestions})</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
