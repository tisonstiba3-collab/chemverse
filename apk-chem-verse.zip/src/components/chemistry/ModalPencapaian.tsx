import React from 'react';
import { Trophy, Award, Star, CheckCircle2, Lock, Sparkles, X, Flame, Shield, Atom } from 'lucide-react';
import { UserDocument } from '../../types/chemistry';

interface ModalPencapaianProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserDocument | null;
}

interface BadgeDefinition {
  id: string;
  name: string;
  category: string;
  description: string;
  requirement: string;
  icon: string;
  color: string;
}

export const BADGE_DEFINITIONS: BadgeDefinition[] = [
  {
    id: 'pemula_kimia',
    name: 'Kadet Kimia Muda',
    category: 'Selamat Datang',
    description: 'Memulai perjalanan pembelajaran kimia interaktif di ChemiVerse.',
    requirement: 'Buat akun dan bergabung ke platform',
    icon: '⚗️',
    color: 'from-cyan-500 to-blue-600',
  },
  {
    id: 'rajin_belajar',
    name: 'Pelajar Tekun',
    category: 'Konsistensi',
    description: 'Menyelesaikan 5 materi pembelajaran kimia pada Peta Belajar.',
    requirement: 'Selesaikan minimal 5 materi',
    icon: '📚',
    color: 'from-emerald-500 to-teal-600',
  },
  {
    id: 'penjelajah_atom',
    name: 'Penjelajah Inti Atom',
    category: 'Materi Inti',
    description: 'Menguasai konsep struktur atom, proton, neutron, dan konfigurasi Bohr-Aufbau.',
    requirement: 'Selesaikan materi Struktur Atom atau capai 300 XP',
    icon: '⚛️',
    color: 'from-violet-500 to-purple-600',
  },
  {
    id: 'ahli_ikatan',
    name: 'Ahli Ikatan Kimia',
    category: 'Ikatan & Molekul',
    description: 'Memahami kaidah oktet, ikatan ionik, kovalen polar/nonpolar, dan VSEPR.',
    requirement: 'Selesaikan materi Ikatan Kimia atau capai 500 XP',
    icon: '💎',
    color: 'from-amber-500 to-orange-600',
  },
  {
    id: 'master_stoikiometri',
    name: 'Master Stoikiometri',
    category: 'Kuantitatif',
    description: 'Menguasai hukum kekekalan massa Lavoisier, konsep mol, dan perhitungan reaksi.',
    requirement: 'Selesaikan materi Hukum Dasar Kimia & Konsep Mol',
    icon: '⚖️',
    color: 'from-rose-500 to-pink-600',
  },
  {
    id: 'alkemis_modern',
    name: 'Alkemis Modern',
    category: 'Pangkat Tertinggi',
    description: 'Mengumpulkan lebih dari 1.000 XP melalui latihan soal dan peta belajar.',
    requirement: 'Kumpulkan total 1.000 XP',
    icon: '👑',
    color: 'from-yellow-400 to-amber-600',
  },
];

export default function ModalPencapaian({ isOpen, onClose, user }: ModalPencapaianProps) {
  if (!isOpen) return null;

  const currentBadges = Array.isArray(user?.badges) ? user.badges : ['pemula_kimia'];
  const userXP = typeof user?.xp === 'number' ? user.xp : 0;
  const completedBadgesCount = BADGE_DEFINITIONS.filter((b) => currentBadges.includes(b.id)).length;

  // Level computation
  const level = Math.floor(userXP / 200) + 1;
  const nextLevelXP = level * 200;
  const prevLevelXP = (level - 1) * 200;
  const progressPercent = Math.min(
    100,
    Math.max(0, Math.round(((userXP - prevLevelXP) / (nextLevelXP - prevLevelXP)) * 100))
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shadow-lg">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-black text-white">Lencana & Pencapaian</h3>
                <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 font-mono text-xs font-bold">
                  {completedBadgesCount} / {BADGE_DEFINITIONS.length} Terbuka
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Koleksi lencana resmi yang tersimpan pada database profil Firestore Anda
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            title="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User XP Rank Summary Banner */}
        <div className="px-6 py-4 bg-slate-950/60 border-b border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center text-slate-950 font-black text-sm shadow">
              Lvl {level}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white">{user?.nama || 'Siswa Kimia'}</span>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold">
                  {user?.role === 'guru' ? 'Guru Kimia' : user?.kelas || 'Siswa SMA'}
                </span>
              </div>
              <div className="text-xs text-slate-400 font-mono mt-0.5 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Total XP:</span>
                <strong className="text-amber-400">{userXP} XP</strong>
              </div>
            </div>
          </div>

          {/* Progress bar to next level */}
          <div className="w-full sm:w-48 space-y-1.5">
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>Ke Level {level + 1}</span>
              <span className="text-cyan-300 font-bold">{progressPercent}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-indigo-500 transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Badges Grid */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {BADGE_DEFINITIONS.map((badge) => {
              const isUnlocked = currentBadges.includes(badge.id);

              return (
                <div
                  key={badge.id}
                  className={`p-4 rounded-2xl border transition-all relative overflow-hidden flex gap-3.5 ${
                    isUnlocked
                      ? 'bg-slate-950/90 border-amber-500/40 shadow-lg shadow-amber-500/5'
                      : 'bg-slate-950/40 border-slate-800/80 opacity-60'
                  }`}
                >
                  {/* Badge Icon Medallion */}
                  <div
                    className={`w-14 h-14 rounded-2xl shrink-0 flex items-center justify-center text-2xl shadow-inner border relative ${
                      isUnlocked
                        ? `bg-gradient-to-br ${badge.color} border-white/20 text-white shadow-[0_0_15px_rgba(251,191,36,0.2)]`
                        : 'bg-slate-900 border-slate-800 text-slate-500 grayscale'
                    }`}
                  >
                    <span>{badge.icon}</span>
                    {isUnlocked ? (
                      <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center text-[10px] font-black border-2 border-slate-900">
                        ✓
                      </span>
                    ) : (
                      <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-slate-800 text-slate-400 flex items-center justify-center text-[9px] border-2 border-slate-900">
                        <Lock className="w-2.5 h-2.5" />
                      </span>
                    )}
                  </div>

                  {/* Badge Description */}
                  <div className="space-y-1 min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <h4
                        className={`text-sm font-bold truncate ${
                          isUnlocked ? 'text-white' : 'text-slate-400'
                        }`}
                      >
                        {badge.name}
                      </h4>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800 shrink-0">
                        {badge.category}
                      </span>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                      {badge.description}
                    </p>

                    <div className="pt-1 text-[11px] font-mono flex items-center gap-1.5">
                      {isUnlocked ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          Terbuka
                        </span>
                      ) : (
                        <span className="text-slate-500 flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          Syarat: {badge.requirement}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 shrink-0">
          <span>Selesaikan materi pada Peta Belajar untuk mengklaim lencana berikutnya.</span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
}
