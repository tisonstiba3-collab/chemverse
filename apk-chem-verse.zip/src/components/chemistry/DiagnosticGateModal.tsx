import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import {
  Lock,
  Unlock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Timer,
  Volume2,
  VolumeX,
  ArrowRight,
  HelpCircle,
  BookOpen,
  Award,
  Bot,
  Loader2,
  Check,
  X,
  FileText,
  UserCheck,
} from 'lucide-react';
import {
  DiagnosticSet,
  DiagnosticQuestion,
  DiagnosticResult,
  StudentProfile,
  JawabanSoalSiswa,
} from '../../types/chemistry';
import { findPrerequisiteItem } from '../../data/diagnosticCurriculumData';
import {
  KAMUS_PRASYARAT,
  cariPrasyaratTopik,
  formatKesiapanAnalysis,
} from '../../data/kamusPrasyarat';
import KaTeXFormula from './KaTeXFormula';
import { saveDiagnosticResult, saveJawabanSoalBatch } from '../../services/firestoreService';

interface DiagnosticGateModalProps {
  isOpen: boolean;
  materiId: string; // e.g. "X.05" or "stoikiometri-x"
  materiTitle: string;
  grade: string;
  student?: StudentProfile;
  existingResult?: DiagnosticResult | null;
  onPass: (result: DiagnosticResult) => void;
  onClose: () => void;
  onOpenTutorForHelp?: (topic: string, questionText?: string) => void;
}

export default function DiagnosticGateModal({
  isOpen,
  materiId,
  materiTitle,
  grade,
  student,
  existingResult,
  onPass,
  onClose,
  onOpenTutorForHelp,
}: DiagnosticGateModalProps) {
  const kamusMapping = cariPrasyaratTopik(materiTitle || materiId);
  const prereqItem = findPrerequisiteItem(materiId || materiTitle);
  const effectiveMateriCode = prereqItem.code;
  const effectiveMateriName = kamusMapping.topik || prereqItem.name;
  const effectivePrasyarat = kamusMapping.prasyarat || prereqItem.prasyarat[0];

  // Test set state
  const [diagnosticSet, setDiagnosticSet] = useState<DiagnosticSet | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loadingError, setLoadingError] = useState<string | null>(null);

  // Student answers: question id -> answer
  const [userAnswers, setUserAnswers] = useState<Record<string, any>>({});
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedMatchingLeftId, setSelectedMatchingLeftId] = useState<string | null>(null);

  // Timer state (15 minutes = 900 seconds)
  const [timeLeft, setTimeLeft] = useState(900);
  const [timerActive, setTimerActive] = useState(false);

  // Review & scoring state
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [testResult, setTestResult] = useState<DiagnosticResult | null>(null);
  const [showPembahasan, setShowPembahasan] = useState(false);

  // Remedial state
  const [remedialCount, setRemedialCount] = useState(existingResult?.remedialCount ?? 0);
  const [previousSetIds, setPreviousSetIds] = useState<string[]>(
    existingResult?.setId ? [existingResult.setId] : []
  );
  const [showMiniPrasyaratModule, setShowMiniPrasyaratModule] = useState(false);
  const [miniQuizAnswers, setMiniQuizAnswers] = useState<Record<number, number>>({});
  const [miniQuizSubmitted, setMiniQuizSubmitted] = useState(false);

  // Voice narration (TTS) state
  const [isVoicePlaying, setIsVoicePlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Fetch or generate new diagnostic questions set
  const loadDiagnosticSet = async (isRemedialAttempt: boolean = false) => {
    setIsLoading(true);
    setLoadingError(null);
    setUserAnswers({});
    setCurrentQuestionIndex(0);
    setIsSubmitted(false);
    setShowPembahasan(false);
    setShowMiniPrasyaratModule(false);
    setMiniQuizAnswers({});
    setMiniQuizSubmitted(false);

    try {
      const response = await fetch('/api/diagnostic/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          materiId: effectiveMateriCode,
          topicName: effectiveMateriName,
          topik: effectiveMateriName,
          previousSetIds: previousSetIds,
        }),
      });

      if (!response.ok) {
        throw new Error('Gagal menghubungi generator diagnostik server');
      }

      const data: DiagnosticSet = await response.json();
      setDiagnosticSet(data);
      setTimeLeft(900); // 15 mins
      setTimerActive(true);

      // Play welcome narration
      const introVoice = isRemedialAttempt
        ? `Hai ${student?.namaLengkap || 'Siswa'}! Ini adalah tes diagnostik remedial paralel baru untuk materi ${effectiveMateriName}. Soal telah diperbarui dengan tingkat kesulitan setara. Fokus pada konsep prasyarat ya, kamu pasti bisa!`
        : `Halo ${student?.namaLengkap || 'Siswa'}! Sebelum mempelajari materi ${effectiveMateriName}, kita selesaikan tes diagnostik 5 soal adaptif ini terlebih dahulu untuk menguji kesiapan konsep prasyaratmu. Selamat mengerjakan!`;

      speakText(introVoice);
    } catch (err: any) {
      console.warn('Diagnostic generation error, using fallback:', err);
      setLoadingError(err?.message || 'Gagal memuat soal diagnostik.');
    } finally {
      setIsLoading(false);
    }
  };

  // Initial load when modal opens
  useEffect(() => {
    if (isOpen) {
      loadDiagnosticSet(false);
    } else {
      stopAudio();
      setTimerActive(false);
    }
    return () => {
      stopAudio();
    };
  }, [isOpen, effectiveMateriCode]);

  // Timer countdown hook
  useEffect(() => {
    if (!timerActive || isSubmitted || timeLeft <= 0) return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          handleSubmitTest(true); // Auto-submit when time expires
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [timerActive, isSubmitted, timeLeft]);

  // Voice TTS helper
  const speakText = async (text: string) => {
    stopAudio();
    try {
      const res = await fetch('/api/tutor/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.audio) {
          const snd = new Audio(`data:audio/wav;base64,${data.audio}`);
          audioRef.current = snd;
          setIsVoicePlaying(true);
          snd.onended = () => setIsVoicePlaying(false);
          snd.onerror = () => setIsVoicePlaying(false);
          snd.play().catch(() => setIsVoicePlaying(false));
          return;
        }
      }
    } catch {
      // Fallback to browser SpeechSynthesis
    }

    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'id-ID';
      utterance.rate = 1.0;
      utterance.onend = () => setIsVoicePlaying(false);
      utterance.onerror = () => setIsVoicePlaying(false);
      setIsVoicePlaying(true);
      window.speechSynthesis.speak(utterance);
    }
  };

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsVoicePlaying(false);
  };

  // Option selection handlers
  const handleSelectPG = (qId: string, optKey: string) => {
    if (isSubmitted) return;
    setUserAnswers((prev) => ({ ...prev, [qId]: optKey }));
  };

  const handleTogglePGK = (qId: string, optKey: string) => {
    if (isSubmitted) return;
    const current = (userAnswers[qId] as string[]) || [];
    let updated: string[];
    if (current.includes(optKey)) {
      updated = current.filter((k) => k !== optKey);
    } else {
      updated = [...current, optKey].sort();
    }
    setUserAnswers((prev) => ({ ...prev, [qId]: updated }));
  };

  const handleSelectBS = (qId: string, value: 'B' | 'S') => {
    if (isSubmitted) return;
    setUserAnswers((prev) => ({ ...prev, [qId]: value }));
  };

  const handleToggleBSStatement = (qId: string, statementId: number, value: 'B' | 'S') => {
    if (isSubmitted) return;
    const currentMap = (userAnswers[qId] as Record<number, 'B' | 'S'>) || {};
    setUserAnswers((prev) => ({
      ...prev,
      [qId]: {
        ...currentMap,
        [statementId]: value,
      },
    }));
  };

  const handleSelectMatchingLeft = (leftId: string) => {
    if (isSubmitted) return;
    setSelectedMatchingLeftId((prev) => (prev === leftId ? null : leftId));
  };

  const handlePairMatchingRight = (qId: string, rightId: string) => {
    if (isSubmitted || !selectedMatchingLeftId) return;
    const currentPairs = (userAnswers[qId] as Record<string, string>) || {};
    const updated = {
      ...currentPairs,
      [selectedMatchingLeftId]: rightId,
    };
    setUserAnswers((prev) => ({ ...prev, [qId]: updated }));
    setSelectedMatchingLeftId(null);
  };

  const handleRemovePair = (qId: string, leftId: string) => {
    if (isSubmitted) return;
    const currentPairs = (userAnswers[qId] as Record<string, string>) || {};
    const updated = { ...currentPairs };
    delete updated[leftId];
    setUserAnswers((prev) => ({ ...prev, [qId]: updated }));
  };

  // Submit test and calculate score
  const handleSubmitTest = async (autoTimedOut = false) => {
    if (!diagnosticSet || isSubmitted) return;
    setTimerActive(false);
    setIsSubmitted(true);

    let correctCount = 0;
    const missedPrereqs: string[] = [];
    let l1Correct = 0;
    let l1Total = 0;
    let l2Correct = 0;
    let l2Total = 0;
    let l3Correct = 0;
    let l3Total = 0;

    diagnosticSet.soal.forEach((q, idx) => {
      const userAns = userAnswers[q.id];
      let isCorrect = false;

      if (q.tipe === 'PG') {
        isCorrect = String(userAns).toUpperCase() === String(q.kunci).toUpperCase();
      } else if (q.tipe === 'BS') {
        if (q.statements && Array.isArray(q.statements)) {
          if (typeof userAns === 'object' && userAns !== null && !Array.isArray(userAns)) {
            isCorrect = q.statements.every((st) => userAns[st.id] === st.kunci);
          } else if (typeof userAns === 'string') {
            isCorrect = userAns.trim().toUpperCase() === String(q.kunci).trim().toUpperCase();
          }
        } else {
          isCorrect = String(userAns).toUpperCase() === String(q.kunci).toUpperCase();
        }
      } else if (q.tipe === 'PGK') {
        const correctKeys = (q.kunci as string[]).sort();
        const userKeys = Array.isArray(userAns) ? [...userAns].sort() : [];
        isCorrect =
          correctKeys.length === userKeys.length &&
          correctKeys.every((val, i) => val === userKeys[i]);
      } else if (q.tipe === 'MENJODOHKAN') {
        const cMap = (q.kunci as Record<string, string>) || {};
        const uMap = (userAns as Record<string, string>) || {};
        const keys = Object.keys(cMap);
        isCorrect = keys.length > 0 && keys.every((k) => uMap[k] === cMap[k]);
      }

      if (q.level === 1) {
        l1Total++;
        if (isCorrect) l1Correct++;
      } else if (q.level === 2) {
        l2Total++;
        if (isCorrect) l2Correct++;
      } else if (q.level === 3) {
        l3Total++;
        if (isCorrect) l3Correct++;
      }

      if (isCorrect) {
        correctCount += 1;
      } else {
        const prereqName =
          q.prasyaratTerkait ||
          prereqItem.prasyarat[idx % prereqItem.prasyarat.length] ||
          'Konsep Prasyarat Terkait';
        if (!missedPrereqs.includes(prereqName)) {
          missedPrereqs.push(prereqName);
        }
      }
    });

    const rawScore = Math.round((correctCount / diagnosticSet.soal.length) * 100);
    const passed = rawScore >= 70;
    const nextRemedialCount = passed ? remedialCount : remedialCount + 1;
    const isEscalated = nextRemedialCount >= 2;

    const l1Pct = l1Total > 0 ? Math.round((l1Correct / l1Total) * 100) : 0;
    const l2Pct = l2Total > 0 ? Math.round((l2Correct / l2Total) * 100) : 0;
    const primaryPrereq = effectivePrasyarat || (effectiveMateriName ? prereqItem.prasyarat[0] : 'prasyarat');
    const analysisObj = formatKesiapanAnalysis(rawScore, effectiveMateriName, primaryPrereq);
    const analysisFeedback = `${analysisObj.kesiapanText}. ${analysisObj.saranText}`;

    const result: DiagnosticResult = {
      materiId: effectiveMateriCode,
      materiNama: effectiveMateriName,
      kelas: grade,
      setId: diagnosticSet.set_id,
      score: rawScore,
      passed,
      totalCorrect: correctCount,
      totalQuestions: diagnosticSet.soal.length,
      attemptCount: (existingResult?.attemptCount ?? 0) + 1,
      remedialCount: nextRemedialCount,
      missedPrasyarat: missedPrereqs,
      levelBreakdown: {
        level1: { correct: l1Correct, total: l1Total, percent: l1Pct },
        level2: { correct: l2Correct, total: l2Total, percent: l2Pct },
        level3: { correct: l3Correct, total: l3Total, percent: l3Total > 0 ? Math.round((l3Correct / l3Total) * 100) : 0 },
      },
      analysisFeedback,
      answers: userAnswers,
      completedAt: new Date().toISOString(),
      teacherEscalated: isEscalated,
    };

    setTestResult(result);
    setRemedialCount(nextRemedialCount);
    setPreviousSetIds((prev) => [...prev, diagnosticSet.set_id]);

    // Save to Firestore under 'students/{uid}/diagnostics/{materiId}' & 'students/{uid}/jawaban_soal'
    if (student?.userId) {
      try {
        await saveDiagnosticResult(student.userId, result);

        // Format individual question answers matching user schema
        const itemizedAnswers: JawabanSoalSiswa[] = diagnosticSet.soal.map((q) => {
          const userAns = userAnswers[q.id];
          let isCorrect = false;

          if (q.tipe === 'PG' || q.tipe === 'BS') {
            isCorrect = String(userAns || '').toUpperCase() === String(q.kunci || '').toUpperCase();
          } else if (q.tipe === 'PGK') {
            const correctKeys = (Array.isArray(q.kunci) ? (q.kunci as string[]) : []).sort();
            const userKeys = Array.isArray(userAns) ? [...userAns].sort() : [];
            isCorrect =
              correctKeys.length === userKeys.length &&
              correctKeys.every((val, i) => val === userKeys[i]);
          } else if (q.tipe === 'MENJODOHKAN') {
            const cMap = (q.kunci as Record<string, string>) || {};
            const uMap = (userAns as Record<string, string>) || {};
            const keys = Object.keys(cMap);
            isCorrect = keys.length > 0 && keys.every((k) => uMap[k] === cMap[k]);
          }

          // Format answer text for readable logging
          let displayJawabanSiswa: any = userAns ?? '';
          let displayJawabanBenar: any = q.kunci ?? '';

          if (q.tipe === 'PG' && q.opsi) {
            displayJawabanSiswa = q.opsi[userAns] ? `${userAns}. ${q.opsi[userAns]}` : (userAns || '-');
            displayJawabanBenar = q.opsi[q.kunci as string] ? `${q.kunci}. ${q.opsi[q.kunci as string]}` : q.kunci;
          } else if (q.tipe === 'BS') {
            displayJawabanSiswa = userAns === 'B' ? 'Benar' : userAns === 'S' ? 'Salah' : (userAns || '-');
            displayJawabanBenar = q.kunci === 'B' ? 'Benar' : 'Salah';
          }

          return {
            userId: student.userId,
            namaSiswa: student.namaLengkap || student.nama || 'Siswa',
            topik: effectiveMateriName,
            soalId: q.id,
            teksSoal: q.soal,
            jawabanSiswa: displayJawabanSiswa,
            jawabanBenar: displayJawabanBenar,
            isBenar: isCorrect,
            timestamp: new Date().toISOString(),
          };
        });

        await saveJawabanSoalBatch(itemizedAnswers);
      } catch (err) {
        console.warn('Failed to save diagnostic result to Firestore:', err);
      }
    }

    if (passed) {
      try {
        confetti({
          particleCount: 90,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#22D3EE', '#10B981', '#FBBF24', '#A78BFA'],
        });
      } catch {}

      const passVoice = `Selamat ${student?.namaLengkap || 'Siswa'}! Kamu LULUS tes diagnostik dengan nilai ${rawScore}. ${analysisFeedback} Materi ${effectiveMateriName} sekarang telah terbuka!`;
      speakText(passVoice);
    } else {
      const remVoice = autoTimedOut
        ? `Waktu habis. Nilai kamu adalah ${rawScore}. ${analysisFeedback}`
        : `Nilai kamu adalah ${rawScore}. ${analysisFeedback} Pelajari modul penguatan prasyarat sebelum mengulang ya.`;
      speakText(remVoice);
    }
  };

  // Re-diagnostic handler
  const handleReDiagnostic = () => {
    loadDiagnosticSet(true);
  };

  // Unlock materi and proceed to main view
  const handleUnlockAndEnter = () => {
    if (testResult && testResult.passed) {
      onPass(testResult);
      onClose();
    }
  };

  if (!isOpen) return null;

  // Format timer MM:SS
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const timeFormatted = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  const isTimeCritical = timeLeft < 120; // under 2 mins

  const currentQ = diagnosticSet?.soal[currentQuestionIndex];
  const isCurrentAnswered =
    currentQ &&
    (currentQ.tipe === 'PGK'
      ? Array.isArray(userAnswers[currentQ.id]) && (userAnswers[currentQ.id] as string[]).length > 0
      : typeof userAnswers[currentQ.id] === 'object' && userAnswers[currentQ.id] !== null
      ? Object.keys(userAnswers[currentQ.id]).length > 0
      : !!userAnswers[currentQ.id]);

  const answeredCount = Object.keys(userAnswers).filter((k) => {
    const val = userAnswers[k];
    if (val && typeof val === 'object' && !Array.isArray(val)) {
      return Object.keys(val).length > 0;
    }
    return Array.isArray(val) ? val.length > 0 : !!val;
  }).length;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-xl flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div className="relative w-full max-w-4xl rounded-3xl bg-[#090D1A]/95 border border-cyan-500/30 shadow-[0_0_60px_rgba(34,211,238,0.18)] overflow-hidden flex flex-col my-auto max-h-[92vh]">
        {/* ========================================================= */}
        {/* MODAL HEADER: Topic, Prerequisite Badges, & Timer / Audio */}
        {/* ========================================================= */}
        <div className="p-4 sm:p-6 border-b border-white/10 bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold uppercase tracking-wider">
                {effectiveMateriCode} • Kelas {grade}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1 font-semibold">
                <Lock className="w-3 h-3 text-amber-400" />
                <span>Materi Terkunci: Wajib Lulus Skor ≥ 70</span>
              </span>
              {diagnosticSet && (
                <span className="text-[10px] font-mono text-slate-400">
                  ID: {diagnosticSet.set_id.split('_').slice(-2).join('_')}
                </span>
              )}
            </div>

            <h2
              className="text-lg sm:text-2xl font-extrabold text-white tracking-tight flex items-center gap-2"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              <span>Asesmen Kesiapan Belajar untuk:</span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-sky-200">
                {effectiveMateriName}
              </span>
            </h2>

            {/* List of Prerequisites being tested */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1 text-xs text-slate-300">
              <span className="text-slate-400 font-mono text-[11px]">Materi Prasyarat yang Diuji:</span>
              <span className="px-2.5 py-0.5 rounded-md bg-emerald-500/15 border border-emerald-500/30 text-[11px] font-bold text-emerald-300">
                ✓ {effectivePrasyarat}
              </span>
            </div>
          </div>

          {/* Right Header: Timer & Controls */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Audio narration button */}
            <button
              onClick={() => {
                if (isVoicePlaying) {
                  stopAudio();
                } else if (diagnosticSet) {
                  speakText(
                    `Soal nomor ${currentQuestionIndex + 1}. ${currentQ?.soal || 'Silakan baca soal berikut dan tentukan jawabannya.'}`
                  );
                }
              }}
              className={`p-2.5 rounded-xl border text-xs font-mono transition flex items-center gap-1.5 cursor-pointer ${
                isVoicePlaying
                  ? 'bg-cyan-500/30 border-cyan-400 text-cyan-200 animate-pulse'
                  : 'bg-white/[0.05] border-white/10 text-slate-300 hover:text-white'
              }`}
              title={isVoicePlaying ? 'Hentikan Suara' : 'Dengarkan Suara Tutor Kak Kimi'}
            >
              {isVoicePlaying ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
              <span className="hidden sm:inline">{isVoicePlaying ? 'Stop' : 'Suara'}</span>
            </button>

            {/* Timer Badge */}
            {!isSubmitted && (
              <div
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl border font-mono text-xs font-bold transition-colors ${
                  isTimeCritical
                    ? 'bg-rose-500/20 border-rose-500/60 text-rose-300 animate-pulse'
                    : 'bg-white/[0.04] border-white/10 text-cyan-300'
                }`}
              >
                <Timer className={`w-4 h-4 ${isTimeCritical ? 'text-rose-400' : 'text-cyan-400'}`} />
                <span>{timeFormatted}</span>
              </div>
            )}

            {/* Close button (allows exiting back to list) */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-slate-400 hover:text-white transition cursor-pointer"
              title="Tutup & Kembali"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ========================================================= */}
        {/* MODAL BODY                                                */}
        {/* ========================================================= */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {isLoading ? (
            /* Loading State with Dynamic AI Generation message */
            <div className="py-20 flex flex-col items-center justify-center text-center space-y-4">
              <div className="relative">
                <div className="w-16 h-16 rounded-full border-4 border-cyan-500/20 border-t-cyan-400 animate-spin" />
                <Sparkles className="w-6 h-6 text-cyan-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
              </div>
              <div className="space-y-1">
                <h3
                  className="text-lg font-bold text-white tracking-tight"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  Membuat Set Soal Diagnostik Baru...
                </h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                  AI sedang menyusun 9 soal baru (3 PG + 3 PGK + 3 B/S) yang menguji prasyarat materi{' '}
                  <span className="text-cyan-300 font-semibold">{effectiveMateriName}</span> dengan standar IUPAC dan tingkat kesulitan setara.
                </p>
              </div>
            </div>
          ) : loadingError && !diagnosticSet ? (
            /* Error State */
            <div className="p-8 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-center space-y-4 max-w-md mx-auto">
              <AlertTriangle className="w-10 h-10 text-rose-400 mx-auto" />
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-white">Gagal Memuat Soal Diagnostik</h4>
                <p className="text-xs text-rose-300/90 leading-relaxed">{loadingError}</p>
              </div>
              <button
                onClick={() => loadDiagnosticSet(false)}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition cursor-pointer"
              >
                Coba Lagi
              </button>
            </div>
          ) : !isSubmitted && diagnosticSet ? (
            /* ======================================================= */
            /* RUNNER VIEW: Student answering 9 questions              */
            /* ======================================================= */
            <div className="space-y-6">
              {/* Question Navigation Dots & Progress Bar */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-mono text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                    <span>
                      Soal <strong className="text-cyan-300">{currentQuestionIndex + 1}</strong> dari{' '}
                      <strong>{diagnosticSet.soal.length}</strong>
                    </span>
                  </span>
                  <span>
                    Terjawab: <strong className="text-white">{answeredCount}</strong> /{' '}
                    {diagnosticSet.soal.length}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 sm:gap-2">
                  {diagnosticSet.soal.map((q, idx) => {
                    const ans = userAnswers[q.id];
                    const hasAnswer = Array.isArray(ans) ? ans.length > 0 : !!ans;
                    const isCurrent = idx === currentQuestionIndex;

                    return (
                      <button
                        key={q.id}
                        onClick={() => setCurrentQuestionIndex(idx)}
                        className={`flex-1 h-2 rounded-full transition-all cursor-pointer ${
                          isCurrent
                            ? 'bg-cyan-400 ring-2 ring-cyan-400/50 scale-y-125'
                            : hasAnswer
                            ? 'bg-emerald-500'
                            : 'bg-white/15 hover:bg-white/30'
                        }`}
                        title={`Soal ${idx + 1} (${q.tipe}): ${hasAnswer ? 'Sudah dijawab' : 'Belum dijawab'}`}
                      />
                    );
                  })}
                </div>
              </div>

              {/* Active Question Box */}
              {currentQ && (
                <div className="p-5 sm:p-7 rounded-3xl bg-white/[0.03] backdrop-blur-2xl border border-white/10 shadow-[0_8px_30px_rgba(0,0,0,0.3)] space-y-5">
                  {/* Question Meta Badge */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={`text-[10px] font-mono font-bold px-2.5 py-1 rounded-lg border uppercase tracking-wider ${
                          currentQ.level === 1
                            ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                            : currentQ.level === 2
                            ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                            : 'bg-rose-500/20 border-rose-400 text-rose-300'
                        }`}
                      >
                        {currentQ.levelLabel || `Level ${currentQ.level}`}
                      </span>

                      <span className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 uppercase tracking-wider">
                        {currentQ.tipe === 'PG'
                          ? currentQ.level === 3
                            ? 'Pilihan Ganda Biasa (Level Tertinggi - HOTS)'
                            : 'Pilihan Ganda Biasa (1 Jawaban)'
                          : currentQ.tipe === 'PGK'
                          ? 'Pilihan Ganda Kompleks (Multi-Opsi)'
                          : currentQ.tipe === 'BS'
                          ? 'Benar / Salah (Pernyataan)'
                          : 'Menjodohkan (Mencocokkan Pasangan)'}
                      </span>
                    </div>

                    <span className="text-[11px] font-mono text-slate-400">
                      Estimasi: ~{currentQ.estimasi_detik || 60} detik
                    </span>
                  </div>

                  {/* Question Indikator */}
                  {currentQ.indikator && (
                    <div className="text-[11px] font-mono text-cyan-300/80 italic">
                      🎯 Indikator Prasyarat: {currentQ.indikator}
                    </div>
                  )}

                  {/* Question Stem Text */}
                  <div className="text-sm sm:text-base text-slate-100 font-semibold leading-relaxed">
                    {currentQ.soal}
                  </div>

                  {/* Options Renderer */}
                  <div className="space-y-2.5 pt-2">
                    {currentQ.tipe === 'PG' && currentQ.opsi && (
                      <div className="space-y-2">
                        {Object.entries(currentQ.opsi).map(([optKey, optText]) => {
                          const isSelected = userAnswers[currentQ.id] === optKey;

                          return (
                            <button
                              key={optKey}
                              onClick={() => handleSelectPG(currentQ.id, optKey)}
                              className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-start gap-3 cursor-pointer ${
                                isSelected
                                  ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_0_20px_rgba(34,211,238,0.2)] font-semibold'
                                  : 'bg-white/[0.03] hover:bg-white/[0.07] border-white/10 text-slate-300 hover:text-white'
                              }`}
                            >
                              <span
                                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-mono font-bold shrink-0 border transition ${
                                  isSelected
                                    ? 'bg-cyan-400 text-slate-950 border-cyan-400'
                                    : 'border-slate-600 text-slate-400'
                                }`}
                              >
                                {optKey}
                              </span>
                              <span className="text-xs sm:text-sm leading-relaxed">{optText}</span>
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {currentQ.tipe === 'PGK' && currentQ.opsi && (
                      <div className="space-y-2">
                        <div className="text-[11px] font-mono text-amber-300/90 pb-1 flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-amber-400" />
                          <span>Pilih semua opsi yang menurutmu BENAR (bisa lebih dari satu opsi):</span>
                        </div>

                        {Object.entries(currentQ.opsi).map(([optKey, optText]) => {
                          const currentSelected = (userAnswers[currentQ.id] as string[]) || [];
                          const isSelected = currentSelected.includes(optKey);

                          return (
                            <button
                              key={optKey}
                              onClick={() => handleTogglePGK(currentQ.id, optKey)}
                              className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-start gap-3 cursor-pointer ${
                                isSelected
                                  ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_0_20px_rgba(34,211,238,0.2)] font-semibold'
                                  : 'bg-white/[0.03] hover:bg-white/[0.07] border-white/10 text-slate-300 hover:text-white'
                              }`}
                            >
                              <span
                                className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-mono font-bold shrink-0 border transition ${
                                  isSelected
                                    ? 'bg-cyan-400 text-slate-950 border-cyan-400'
                                    : 'border-slate-600 text-slate-400'
                                }`}
                              >
                                {isSelected ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : optKey}
                              </span>
                              <span className="text-xs sm:text-sm leading-relaxed">{optText}</span>
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {currentQ.tipe === 'BS' && (
                      <div className="space-y-4 pt-2">
                        {/* Prominent Question & Instruction Card */}
                        <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/30 space-y-1.5 shadow-inner">
                          <span className="text-[11px] font-mono font-bold text-amber-400 uppercase tracking-wider block">
                            📋 Pertanyaan & Instruksi Soal Benar / Salah:
                          </span>
                          <p className="text-xs sm:text-sm font-semibold text-white leading-relaxed">
                            {currentQ.soal}
                          </p>
                        </div>

                        {currentQ.statements && currentQ.statements.length > 0 ? (
                          <div className="overflow-x-auto rounded-2xl border border-slate-700/80 bg-slate-950/60">
                            <table className="w-full text-left text-xs sm:text-sm border-collapse">
                              <thead>
                                <tr className="border-b border-slate-800 bg-slate-900/80 text-slate-400 font-mono text-xs uppercase">
                                  <th className="py-3 px-3 w-12 text-center">No</th>
                                  <th className="py-3 px-4">Pernyataan Konsep Prasyarat</th>
                                  <th className="py-3 px-3 w-28 text-center">Pilihan</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-800/80">
                                {currentQ.statements.map((st) => {
                                  const userBsMap = (userAnswers[currentQ.id] as Record<number, 'B' | 'S'>) || {};
                                  const userVal = userBsMap[st.id];

                                  return (
                                    <tr key={st.id} className="hover:bg-white/[0.02] transition">
                                      <td className="py-3.5 px-3 text-center font-mono font-bold text-slate-400">
                                        {st.id}
                                      </td>
                                      <td className="py-3.5 px-4 text-slate-200 leading-relaxed font-medium">
                                        {st.pernyataan}
                                      </td>
                                      <td className="py-3.5 px-3">
                                        <div className="flex items-center justify-center gap-1.5">
                                          <button
                                            type="button"
                                            onClick={() => handleToggleBSStatement(currentQ.id, st.id, 'B')}
                                            className={`px-3 py-1.5 rounded-lg font-mono text-xs font-bold transition cursor-pointer border ${
                                              userVal === 'B'
                                                ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-md shadow-emerald-500/30 font-black'
                                                : 'bg-white/[0.04] border-white/10 text-slate-400 hover:text-white hover:border-emerald-500/50'
                                            }`}
                                          >
                                            B
                                          </button>
                                          <button
                                            type="button"
                                            onClick={() => handleToggleBSStatement(currentQ.id, st.id, 'S')}
                                            className={`px-3 py-1.5 rounded-lg font-mono text-xs font-bold transition cursor-pointer border ${
                                              userVal === 'S'
                                                ? 'bg-rose-500 border-rose-400 text-white shadow-md shadow-rose-500/30 font-black'
                                                : 'bg-white/[0.04] border-white/10 text-slate-400 hover:text-white hover:border-rose-500/50'
                                            }`}
                                          >
                                            S
                                          </button>
                                        </div>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        ) : (
                          <div className="grid grid-cols-2 gap-3 pt-1">
                            <button
                              type="button"
                              onClick={() => handleSelectBS(currentQ.id, 'B')}
                              className={`p-4 rounded-2xl border font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer ${
                                userAnswers[currentQ.id] === 'B'
                                  ? 'bg-emerald-500/25 border-emerald-400 text-emerald-200 shadow-[0_0_25px_rgba(16,185,129,0.25)]'
                                  : 'bg-white/[0.03] hover:bg-white/[0.07] border-white/10 text-slate-300'
                              }`}
                            >
                              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                              <span>BENAR (B)</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => handleSelectBS(currentQ.id, 'S')}
                              className={`p-4 rounded-2xl border font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer ${
                                userAnswers[currentQ.id] === 'S'
                                  ? 'bg-rose-500/25 border-rose-400 text-rose-200 shadow-[0_0_25px_rgba(244,63,94,0.25)]'
                                  : 'bg-white/[0.03] hover:bg-white/[0.07] border-white/10 text-slate-300'
                              }`}
                            >
                              <XCircle className="w-5 h-5 text-rose-400" />
                              <span>SALAH (S)</span>
                            </button>
                          </div>
                        )}
                      </div>
                    )}

                    {currentQ.tipe === 'MENJODOHKAN' && currentQ.matchingLeft && currentQ.matchingRight && (
                      <div className="space-y-4 pt-2">
                        <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-cyan-200 text-xs font-mono">
                          Klik istilah di Kolom Kiri, lalu klik definisi pasangannya di Kolom Kanan:
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {/* Left Column */}
                          <div className="space-y-2">
                            <span className="text-xs font-mono font-bold text-slate-400 block">Kolom Kiri (Istilah):</span>
                            {currentQ.matchingLeft.map((item) => {
                              const pairs = (userAnswers[currentQ.id] as Record<string, string>) || {};
                              const pairedRId = pairs[item.id];
                              const pairedR = currentQ.matchingRight?.find((r) => r.id === pairedRId);
                              const isSelected = selectedMatchingLeftId === item.id;

                              return (
                                <div
                                  key={item.id}
                                  onClick={() => handleSelectMatchingLeft(item.id)}
                                  className={`p-3 rounded-xl border text-xs cursor-pointer transition ${
                                    isSelected
                                      ? 'bg-cyan-500/25 border-cyan-400 ring-2 ring-cyan-400/50'
                                      : pairedRId
                                      ? 'bg-indigo-950/40 border-indigo-500/40'
                                      : 'bg-white/[0.03] border-white/10'
                                  }`}
                                >
                                  <div className="flex items-center justify-between">
                                    <span className="font-semibold text-white">{item.text}</span>
                                    {pairedRId && (
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleRemovePair(currentQ.id, item.id);
                                        }}
                                        className="text-[10px] text-rose-300 bg-rose-500/20 px-1.5 py-0.5 rounded"
                                      >
                                        ×
                                      </button>
                                    )}
                                  </div>
                                  {pairedR && (
                                    <div className="text-[10px] text-cyan-300 mt-1 truncate">⟷ {pairedR.text}</div>
                                  )}
                                </div>
                              );
                            })}
                          </div>

                          {/* Right Column */}
                          <div className="space-y-2">
                            <span className="text-xs font-mono font-bold text-slate-400 block">Kolom Kanan (Definisi):</span>
                            {currentQ.matchingRight.map((item) => {
                              const pairs = (userAnswers[currentQ.id] as Record<string, string>) || {};
                              const isPaired = Object.values(pairs).includes(item.id);

                              return (
                                <div
                                  key={item.id}
                                  onClick={() => handlePairMatchingRight(currentQ.id, item.id)}
                                  className={`p-3 rounded-xl border text-xs cursor-pointer transition ${
                                    selectedMatchingLeftId ? 'hover:border-cyan-400' : ''
                                  } ${isPaired ? 'bg-indigo-950/40 border-indigo-500/40' : 'bg-white/[0.03] border-white/10'}`}
                                >
                                  <span className="text-slate-200">{item.text}</span>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Navigation Controls: Prev, Next, Submit */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                <button
                  disabled={currentQuestionIndex === 0}
                  onClick={() => setCurrentQuestionIndex((prev) => Math.max(0, prev - 1))}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs font-bold text-slate-300 hover:text-white transition disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                >
                  ← Soal Sebelumnya
                </button>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  {currentQuestionIndex < diagnosticSet.soal.length - 1 ? (
                    <button
                      onClick={() => setCurrentQuestionIndex((prev) => prev + 1)}
                      className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-white/[0.08] hover:bg-white/[0.15] border border-white/20 text-xs font-bold text-white transition cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <span>Soal Berikutnya</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  ) : null}

                  <button
                    onClick={() => handleSubmitTest(false)}
                    className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/25 transition cursor-pointer flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Kirim Jawaban Diagnostik ({answeredCount}/{diagnosticSet.soal.length})</span>
                  </button>
                </div>
              </div>
            </div>
          ) : isSubmitted && testResult ? (
            /* ======================================================= */
            /* RESULT GATE: LULUS (≥70) vs REMEDIAL (<70)              */
            /* ======================================================= */
            <div className="space-y-6">
              {/* Score Banner */}
              <div
                className={`p-6 sm:p-8 rounded-3xl border shadow-2xl relative overflow-hidden text-center space-y-4 ${
                  testResult.passed
                    ? 'bg-gradient-to-b from-emerald-950/40 via-slate-900/90 to-cyan-950/40 border-emerald-400/60 shadow-[0_0_60px_rgba(16,185,129,0.2)]'
                    : 'bg-gradient-to-b from-rose-950/40 via-slate-900/90 to-amber-950/40 border-rose-400/50 shadow-[0_0_60px_rgba(244,63,94,0.18)]'
                }`}
              >
                {/* Result Icon */}
                <div
                  className={`w-16 h-16 rounded-2xl mx-auto flex items-center justify-center border shadow-lg ${
                    testResult.passed
                      ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                      : 'bg-rose-500/20 border-rose-400 text-rose-300'
                  }`}
                >
                  {testResult.passed ? <Unlock className="w-8 h-8" /> : <Lock className="w-8 h-8" />}
                </div>

                <div className="space-y-1">
                  <span
                    className={`text-xs font-mono font-bold uppercase tracking-wider px-3 py-1 rounded-full border ${
                      testResult.passed
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    }`}
                  >
                    {testResult.passed ? 'Status: LULUS AMBANG BATAS' : 'Status: PERLU REMEDIAL'}
                  </span>

                  <h3
                    className="text-3xl sm:text-5xl font-black text-white pt-2"
                    style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                  >
                    Kesiapan Anda: {testResult.score}%
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto leading-relaxed pt-1 font-semibold">
                    {testResult.passed
                      ? `Selamat! Kesiapan Anda sangat baik (${testResult.score}%). Anda siap untuk mempelajari materi ${effectiveMateriName}!`
                      : `Silakan pelajari kembali materi prasyarat ${effectivePrasyarat} sebelum masuk ke ${effectiveMateriName}.`}
                  </p>
                </div>

                {/* Teacher Escalation Warning if remedial count > 2 */}
                {testResult.teacherEscalated && !testResult.passed && (
                  <div className="p-3.5 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs flex items-center justify-center gap-2 font-mono">
                    <UserCheck className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>
                      ⚠️ Kamu telah melakukan remedial sebanyak {testResult.remedialCount}x. Disarankan melakukan bimbingan 1-on-1 dengan Kak Kimi atau guru kimia pendamping!
                    </span>
                  </div>
                )}

                {/* Primary Action Button */}
                <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                  {testResult.passed ? (
                    <button
                      onClick={handleUnlockAndEnter}
                      className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 text-slate-950 font-extrabold text-sm shadow-[0_0_35px_rgba(16,185,129,0.35)] transition-all transform hover:scale-105 cursor-pointer flex items-center gap-2"
                    >
                      <Unlock className="w-5 h-5" />
                      <span>Buka Materi Utama & Mulai Belajar</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <div className="flex flex-wrap items-center justify-center gap-2.5">
                      <button
                        onClick={() => setShowMiniPrasyaratModule(true)}
                        className="px-5 py-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-200 font-bold text-xs transition cursor-pointer flex items-center gap-2"
                      >
                        <BookOpen className="w-4 h-4 text-amber-400" />
                        <span>Pelajari Modul Penguatan Prasyarat</span>
                      </button>

                      <button
                        onClick={handleReDiagnostic}
                        className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg transition cursor-pointer flex items-center gap-2"
                      >
                        <RotateCcw className="w-4 h-4" />
                        <span>Ulangi Diagnostik (Set Soal Baru)</span>
                      </button>

                      {onOpenTutorForHelp && (
                        <button
                          onClick={() => {
                            onOpenTutorForHelp(
                              effectiveMateriName,
                              `Saya belum lulus tes diagnostik untuk prasyarat materi ${effectiveMateriName}. Konsep yang belum saya kuasai: ${testResult.missedPrasyarat.join(', ')}. Bisakah Kak Kimi jelaskan konsep dasarnya?`
                            );
                            onClose();
                          }}
                          className="px-4 py-3 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-cyan-300 hover:text-white font-bold text-xs transition cursor-pointer flex items-center gap-1.5"
                        >
                          <Bot className="w-4 h-4 text-cyan-400" />
                          <span>Tanya Kak Kimi (Tutor Khusus)</span>
                        </button>
                      )}
                    </div>
                  )}

                  <button
                    onClick={() => setShowPembahasan(!showPembahasan)}
                    className="px-4 py-3 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs font-bold text-slate-300 hover:text-white transition cursor-pointer flex items-center gap-1.5"
                  >
                    <FileText className="w-4 h-4 text-cyan-400" />
                    <span>{showPembahasan ? 'Sembunyikan Pembahasan' : 'Lihat Pembahasan 9 Soal'}</span>
                  </button>
                </div>
              </div>

              {/* ===================================================== */}
              {/* REMEDIAL PREREQUISITE BOOST MODULE                    */}
              {/* ===================================================== */}
              {showMiniPrasyaratModule && (
                <div className="p-6 rounded-3xl bg-slate-900/90 border border-amber-500/40 shadow-xl space-y-5 animate-fade-in">
                  <div className="flex items-center justify-between border-b border-white/10 pb-3">
                    <div className="flex items-center gap-2 text-amber-300">
                      <BookOpen className="w-5 h-5 text-amber-400" />
                      <h4
                        className="text-base font-bold text-white tracking-tight"
                        style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                      >
                        Modul Penguatan Konsep Prasyarat ({effectiveMateriCode})
                      </h4>
                    </div>
                    <button
                      onClick={() => setShowMiniPrasyaratModule(false)}
                      className="text-slate-400 hover:text-white text-xs cursor-pointer font-mono"
                    >
                      Tutup [×]
                    </button>
                  </div>

                  {/* Summary Text */}
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                    {prereqItem.remedialSummary ||
                      'Konsep prasyarat adalah pondasi terpenting sebelum mempelajari materi tingkat lanjut. Pahami hubungan antar besaran, rumus dasar, dan prinsip konservasi materi.'}
                  </p>

                  {/* Key Formulas */}
                  {prereqItem.keyFormulas && prereqItem.keyFormulas.length > 0 && (
                    <div className="space-y-2">
                      <span className="text-[11px] font-mono text-cyan-400 font-bold block uppercase tracking-wider">
                        Rumus Kunci Prasyarat:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {prereqItem.keyFormulas.map((f, i) => (
                          <div
                            key={i}
                            className="p-3 rounded-xl bg-slate-950/70 border border-white/10 text-center"
                          >
                            <KaTeXFormula formula={f} displayMode={true} />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Interactive Mini-Quiz Prasyarat (3 Quick Questions) */}
                  <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-3">
                    <span className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-cyan-400" />
                      <span>Cek Pemahaman Cepat (Mini-Quiz Prasyarat)</span>
                    </span>

                    <p className="text-xs text-slate-300">
                      Berdasarkan konsep dasar prasyarat, manakah pernyataan berikut yang paling tepat?
                    </p>

                    <div className="space-y-2">
                      {[
                        { text: 'Massa molar zat (g·mol⁻¹) secara numerik setara dengan massa molekul relatif (Mr) zat tersebut.', correct: true },
                        { text: 'Semua reaksi kimia menghasilkan gas dan mengubah jenis atom menjadi atom baru.', correct: false },
                        { text: 'Jumlah mol tidak memiliki kaitan sama sekali dengan massa zat.', correct: false },
                      ].map((mq, mqIdx) => {
                        const isChosen = miniQuizAnswers[0] === mqIdx;

                        return (
                          <button
                            key={mqIdx}
                            disabled={miniQuizSubmitted}
                            onClick={() => setMiniQuizAnswers({ 0: mqIdx })}
                            className={`w-full text-left p-3 rounded-xl border text-xs transition flex items-center gap-2.5 cursor-pointer ${
                              miniQuizSubmitted
                                ? mq.correct
                                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200 font-bold'
                                  : isChosen
                                  ? 'bg-rose-500/20 border-rose-400 text-rose-200'
                                  : 'bg-white/[0.02] border-white/5 text-slate-500'
                                : isChosen
                                ? 'bg-cyan-500/20 border-cyan-400 text-white font-semibold'
                                : 'bg-white/[0.03] hover:bg-white/[0.07] border-white/10 text-slate-300'
                            }`}
                          >
                            <span className="w-5 h-5 rounded-full border flex items-center justify-center font-mono text-[10px]">
                              {String.fromCharCode(65 + mqIdx)}
                            </span>
                            <span>{mq.text}</span>
                          </button>
                        );
                      })}
                    </div>

                    {!miniQuizSubmitted ? (
                      <button
                        onClick={() => {
                          if (miniQuizAnswers[0] !== undefined) {
                            setMiniQuizSubmitted(true);
                          }
                        }}
                        disabled={miniQuizAnswers[0] === undefined}
                        className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition cursor-pointer disabled:opacity-40"
                      >
                        Periksa Mini-Quiz
                      </button>
                    ) : (
                      <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10 text-xs text-slate-200 flex items-center justify-between">
                        <span>{miniQuizAnswers[0] === 0 ? '🎉 Benar! Konsep prasyarat telah kamu ingat kembali.' : '💡 Kurang tepat. Pahami rumus Mr dan konsep mol.'}</span>
                        <button
                          onClick={handleReDiagnostic}
                          className="px-3 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-bold text-xs cursor-pointer hover:bg-cyan-400 transition"
                        >
                          Mulai Re-Diagnostik Sekarang →
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ===================================================== */}
              {/* DETAILED QUESTION REVIEW & IUPAC EXPLANATION          */}
              {/* ===================================================== */}
              {showPembahasan && diagnosticSet && (
                <div className="space-y-4 pt-2">
                  <h4
                    className="text-base font-bold text-white flex items-center gap-2"
                    style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                  >
                    <FileText className="w-4 h-4 text-cyan-400" />
                    <span>Pembahasan Lengkap & Analisis Miskonsepsi (9 Soal)</span>
                  </h4>

                  <div className="space-y-3">
                    {diagnosticSet.soal.map((q, idx) => {
                      const userAns = testResult.answers[q.id];
                      let isCorrect = false;

                      if (q.tipe === 'PG') {
                        isCorrect = String(userAns).toUpperCase() === String(q.kunci).toUpperCase();
                      } else if (q.tipe === 'BS') {
                        if (q.statements && Array.isArray(q.statements)) {
                          if (typeof userAns === 'object' && userAns !== null && !Array.isArray(userAns)) {
                            isCorrect = q.statements.every((st) => userAns[st.id] === st.kunci);
                          } else if (typeof userAns === 'string') {
                            isCorrect = userAns.trim().toUpperCase() === String(q.kunci).trim().toUpperCase();
                          }
                        } else {
                          isCorrect = String(userAns).toUpperCase() === String(q.kunci).toUpperCase();
                        }
                      } else if (q.tipe === 'PGK') {
                        const correctKeys = (q.kunci as string[]).sort();
                        const userKeys = Array.isArray(userAns) ? [...userAns].sort() : [];
                        isCorrect =
                          correctKeys.length === userKeys.length &&
                          correctKeys.every((val, i) => val === userKeys[i]);
                      } else if (q.tipe === 'MENJODOHKAN') {
                        const cMap = (q.kunci as Record<string, string>) || {};
                        const uMap = (userAns as Record<string, string>) || {};
                        const keys = Object.keys(cMap);
                        isCorrect = keys.length > 0 && keys.every((k) => uMap[k] === cMap[k]);
                      }

                      return (
                        <div
                          key={q.id}
                          className={`p-4 rounded-2xl border transition space-y-3 ${
                            isCorrect
                              ? 'bg-emerald-500/5 border-emerald-500/20'
                              : 'bg-rose-500/5 border-rose-500/20'
                          }`}
                        >
                          <div className="flex items-center justify-between pb-1 border-b border-white/5">
                            <span className="text-xs font-mono font-bold text-white flex items-center gap-2">
                              {isCorrect ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                              ) : (
                                <XCircle className="w-4 h-4 text-rose-400" />
                              )}
                              <span>
                                Soal {idx + 1} ({q.tipe}) — {isCorrect ? 'Benar (+1)' : 'Salah (0)'}
                              </span>
                            </span>
                            <span className="text-[10px] font-mono text-slate-400">Bloom: {q.bloom}</span>
                          </div>

                          {/* Full Question Text */}
                          <div className="p-3 rounded-xl bg-slate-900/60 border border-white/5 space-y-1">
                            <span className="text-[10px] font-mono font-bold text-cyan-300 uppercase tracking-wider block">
                              📋 Pertanyaan Soal:
                            </span>
                            <p className="text-xs sm:text-sm text-slate-100 font-semibold leading-relaxed">
                              {q.soal}
                            </p>
                          </div>

                          {/* BS Statements Detail */}
                          {q.tipe === 'BS' && q.statements && q.statements.length > 0 ? (
                            <div className="space-y-2">
                              <span className="text-slate-300 block font-bold text-xs">
                                Evaluasi Tiap Pernyataan:
                              </span>
                              {q.statements.map((st) => {
                                const userBs = (userAns as Record<number, 'B' | 'S'>)?.[st.id];
                                const isStCorrect = userBs === st.kunci;
                                return (
                                  <div key={st.id} className="p-2.5 rounded-xl bg-slate-950/70 border border-white/5 space-y-1.5 text-xs">
                                    <div className="text-slate-200 leading-relaxed font-medium">
                                      <span className="text-amber-400 font-bold font-mono mr-1.5">{st.id}.</span>
                                      {st.pernyataan}
                                    </div>
                                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-white/5 font-mono text-[11px]">
                                      <div className="flex items-center gap-2">
                                        <span className="text-slate-400">Pilihanmu:</span>
                                        <span className={`font-bold px-2 py-0.5 rounded ${
                                          userBs === 'B'
                                            ? 'bg-emerald-500/20 text-emerald-300'
                                            : userBs === 'S'
                                            ? 'bg-rose-500/20 text-rose-300'
                                            : 'bg-slate-800 text-slate-400'
                                        }`}>
                                          {userBs ? (userBs === 'B' ? 'BENAR (B)' : 'SALAH (S)') : 'Kosong'}
                                        </span>
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <span className="text-slate-400">Kunci:</span>
                                        <span className="font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                                          {st.kunci === 'B' ? 'BENAR (B)' : 'SALAH (S)'}
                                        </span>
                                        <span className={isStCorrect ? 'text-emerald-400 font-bold ml-1' : 'text-rose-400 font-bold ml-1'}>
                                          {isStCorrect ? '✓ Tepat' : '✗ Belum Tepat'}
                                        </span>
                                      </div>
                                    </div>
                                    {st.pembahasan && (
                                      <p className="text-[11px] text-slate-300 italic pt-0.5">
                                        💡 {st.pembahasan}
                                      </p>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          ) : (
                            <div className="p-3 rounded-xl bg-slate-950/60 border border-white/5 space-y-1 text-xs">
                              <div className="flex flex-wrap items-center gap-3">
                                <span className="text-slate-400">
                                  Jawaban Kamu:{' '}
                                  <strong className={isCorrect ? 'text-emerald-300' : 'text-rose-300'}>
                                    {typeof userAns === 'object' && userAns !== null && !Array.isArray(userAns)
                                      ? JSON.stringify(userAns)
                                      : Array.isArray(userAns)
                                      ? userAns.join(', ') || '(Kosong)'
                                      : userAns || '(Kosong)'}
                                  </strong>
                                </span>
                                <span className="text-slate-400">
                                  Kunci Benar:{' '}
                                  <strong className="text-emerald-400">
                                    {typeof q.kunci === 'object' && !Array.isArray(q.kunci)
                                      ? JSON.stringify(q.kunci)
                                      : Array.isArray(q.kunci)
                                      ? q.kunci.join(', ')
                                      : String(q.kunci)}
                                  </strong>
                                </span>
                              </div>
                            </div>
                          )}

                          <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/20 text-xs">
                            <p className="text-slate-300 text-[11px] leading-relaxed">
                              💡 <strong className="text-cyan-300">Pembahasan Ilmiah:</strong> {q.pembahasan}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
