import React, { useMemo } from 'react';
import katex from 'katex';

interface KaTeXFormulaProps {
  formula: string;
  displayMode?: boolean;
  className?: string;
}

export default function KaTeXFormula({
  formula,
  displayMode = true,
  className = '',
}: KaTeXFormulaProps) {
  const html = useMemo(() => {
    try {
      return katex.renderToString(formula, {
        displayMode,
        throwOnError: false,
        strict: false,
      });
    } catch (err) {
      console.warn('KaTeX rendering error:', err);
      return `<code class="font-mono text-cyan-300 text-xs">${formula}</code>`;
    }
  }, [formula, displayMode]);

  return (
    <div
      className={`katex-wrapper overflow-x-auto py-2 text-slate-100 ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
