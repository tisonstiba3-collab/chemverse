import React from 'react';
import {
  Atom,
  Flame,
  Zap,
  Leaf,
  Globe,
  Scale,
  Clock,
  FlaskConical,
  Activity,
  Layers,
  Sparkles,
} from 'lucide-react';

interface TopicCardLightweightVisualProps {
  modelType: string;
  accentColor?: string;
  isHovered?: boolean;
}

export default function TopicCardLightweightVisual({
  modelType,
  accentColor = '#22d3ee',
  isHovered = false,
}: TopicCardLightweightVisualProps) {
  // Ultra-lightweight CSS/SVG animated visual for each chemical model type
  const renderVisual = () => {
    switch (modelType) {
      case 'atom':
        return (
          <div className="relative w-28 h-28 flex items-center justify-center">
            {/* Pulsing center nucleus */}
            <div
              className={`w-9 h-9 rounded-full shadow-lg flex items-center justify-center transition-transform duration-300 ${
                isHovered ? 'scale-110 shadow-cyan-500/50' : ''
              }`}
              style={{
                background: `radial-gradient(circle, #ffffff 10%, ${accentColor} 70%, #0891b2 100%)`,
                boxShadow: `0 0 24px ${accentColor}80`,
              }}
            >
              <span className="text-[10px] font-mono font-bold text-slate-950">p⁺n⁰</span>
            </div>

            {/* Orbiting electron rings via CSS transforms */}
            <div
              className={`absolute inset-0 rounded-full border border-cyan-400/40 border-dashed animate-spin ${
                isHovered ? 'border-cyan-300' : ''
              }`}
              style={{ animationDuration: '6s' }}
            >
              <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-cyan-300 shadow-[0_0_8px_#22d3ee]" />
            </div>
            <div
              className="absolute inset-2 rounded-full border border-violet-400/30 animate-spin"
              style={{ animationDuration: '8s', animationDirection: 'reverse' }}
            >
              <div className="absolute top-1/2 -right-1.5 -translate-y-1/2 w-2.5 h-2.5 rounded-full bg-violet-300 shadow-[0_0_8px_#a78bfa]" />
            </div>
            <div
              className="absolute inset-4 rounded-full border border-emerald-400/30 animate-spin"
              style={{ animationDuration: '10s' }}
            >
              <div className="absolute -bottom-1 left-1/3 w-2.5 h-2.5 rounded-full bg-emerald-300 shadow-[0_0_8px_#34d399]" />
            </div>
          </div>
        );

      case 'h2o':
        return (
          <div className="relative w-32 h-28 flex items-center justify-center">
            {/* Oxygen central atom */}
            <div
              className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-white shadow-xl transition-transform ${
                isHovered ? 'scale-110' : ''
              }`}
              style={{
                background: 'radial-gradient(circle, #f87171 10%, #ef4444 60%, #991b1b 100%)',
                boxShadow: '0 0 20px rgba(239,68,68,0.5)',
              }}
            >
              <span className="text-sm font-mono font-bold">O</span>
            </div>

            {/* Left Hydrogen */}
            <div
              className="absolute -top-1 -left-1 w-8 h-8 rounded-full flex items-center justify-center font-bold text-slate-900 shadow-md"
              style={{
                background: 'radial-gradient(circle, #ffffff 30%, #e2e8f0 80%, #94a3b8 100%)',
                boxShadow: '0 0 12px rgba(255,255,255,0.4)',
              }}
            >
              <span className="text-xs font-mono font-bold">H</span>
            </div>

            {/* Right Hydrogen */}
            <div
              className="absolute -top-1 -right-1 w-8 h-8 rounded-full flex items-center justify-center font-bold text-slate-900 shadow-md"
              style={{
                background: 'radial-gradient(circle, #ffffff 30%, #e2e8f0 80%, #94a3b8 100%)',
                boxShadow: '0 0 12px rgba(255,255,255,0.4)',
              }}
            >
              <span className="text-xs font-mono font-bold">H</span>
            </div>

            {/* Covalent bonds */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 128 112">
              <line x1="26" y1="26" x2="64" y2="56" stroke="#94a3b8" strokeWidth="4" strokeLinecap="round" />
              <line x1="102" y1="26" x2="64" y2="56" stroke="#94a3b8" strokeWidth="4" strokeLinecap="round" />
            </svg>
            <span className="absolute bottom-0 text-[10px] font-mono text-cyan-300 font-semibold px-2 py-0.5 rounded-full bg-slate-900/80 border border-cyan-500/30">
              104.5°
            </span>
          </div>
        );

      case 'beaker':
      case 'flask':
        return (
          <div className="relative w-28 h-28 flex flex-col items-center justify-center">
            <div
              className={`p-4 rounded-3xl backdrop-blur-xl border border-white/20 flex items-center justify-center transition-all ${
                isHovered ? 'scale-110 shadow-lg' : ''
              }`}
              style={{
                background: `linear-gradient(135deg, ${accentColor}25, rgba(15,23,42,0.8))`,
                boxShadow: `0 0 25px ${accentColor}40`,
              }}
            >
              <FlaskConical className="w-12 h-12" style={{ color: accentColor }} />
            </div>
            {/* Bubbles */}
            <div className="absolute top-3 right-6 w-2 h-2 rounded-full bg-cyan-300 animate-ping" />
            <div className="absolute top-6 left-6 w-1.5 h-1.5 rounded-full bg-white/70 animate-pulse" />
          </div>
        );

      case 'flame':
      case 'thermometer':
        return (
          <div className="relative w-28 h-28 flex items-center justify-center">
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-xl transition-all ${
                isHovered ? 'scale-110' : ''
              }`}
              style={{
                background: 'radial-gradient(circle, #f59e0b 20%, #ea580c 70%, #9a3412 100%)',
                boxShadow: '0 0 30px rgba(245,158,11,0.5)',
              }}
            >
              <Flame className="w-10 h-10 text-amber-100 fill-amber-100" />
            </div>
            <span className="absolute -bottom-2 text-[10px] font-mono text-amber-300 font-bold px-2 py-0.5 rounded bg-slate-900/90 border border-amber-500/40">
              ΔH Termokimia
            </span>
          </div>
        );

      case 'battery':
        return (
          <div className="relative w-28 h-28 flex items-center justify-center">
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-xl transition-all ${
                isHovered ? 'scale-110' : ''
              }`}
              style={{
                background: 'radial-gradient(circle, #3b82f6 20%, #1d4ed8 70%, #1e3a8a 100%)',
                boxShadow: '0 0 30px rgba(59,130,246,0.5)',
              }}
            >
              <Zap className="w-9 h-9 text-cyan-200 fill-cyan-200" />
            </div>
            <span className="absolute -bottom-2 text-[10px] font-mono text-cyan-300 font-bold px-2 py-0.5 rounded bg-slate-900/90 border border-cyan-500/40">
              E° Sel Volta
            </span>
          </div>
        );

      case 'equilibrium':
        return (
          <div className="relative w-28 h-28 flex flex-col items-center justify-center">
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-xl transition-all ${
                isHovered ? 'scale-110' : ''
              }`}
              style={{
                background: 'radial-gradient(circle, #10b981 20%, #059669 70%, #064e3b 100%)',
                boxShadow: '0 0 30px rgba(16,185,129,0.5)',
              }}
            >
              <span className="text-2xl font-extrabold text-white">⇄</span>
            </div>
            <span className="absolute -bottom-2 text-[10px] font-mono text-emerald-300 font-bold px-2 py-0.5 rounded bg-slate-900/90 border border-emerald-500/40">
              Kc ⇌ Kp
            </span>
          </div>
        );

      case 'kinetics':
      case 'clock':
        return (
          <div className="relative w-28 h-28 flex items-center justify-center">
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-xl transition-all ${
                isHovered ? 'scale-110' : ''
              }`}
              style={{
                background: 'radial-gradient(circle, #8b5cf6 20%, #6d28d9 70%, #4c1d95 100%)',
                boxShadow: '0 0 30px rgba(139,92,246,0.5)',
              }}
            >
              <Clock className="w-9 h-9 text-violet-100" />
            </div>
            <span className="absolute -bottom-2 text-[10px] font-mono text-violet-300 font-bold px-2 py-0.5 rounded bg-slate-900/90 border border-violet-500/40">
              v = k[A]ᵐ[B]ⁿ
            </span>
          </div>
        );

      case 'organic':
        return (
          <div className="relative w-28 h-28 flex items-center justify-center">
            {/* Benzene Hexagon SVG */}
            <svg
              className={`w-20 h-20 text-cyan-400 transition-transform ${isHovered ? 'scale-110' : ''}`}
              viewBox="0 0 100 100"
              fill="none"
            >
              <polygon
                points="50,10 85,30 85,70 50,90 15,70 15,30"
                stroke={accentColor}
                strokeWidth="4"
                strokeLinejoin="round"
                className="drop-shadow-[0_0_8px_rgba(34,211,238,0.6)]"
              />
              <circle
                cx="50"
                cy="50"
                r="22"
                stroke={accentColor}
                strokeWidth="3"
                strokeDasharray="6 4"
                className="animate-spin origin-center"
                style={{ animationDuration: '12s' }}
              />
            </svg>
            <span className="absolute -bottom-1 text-[10px] font-mono text-cyan-300 font-bold px-2 py-0.5 rounded bg-slate-900/90 border border-cyan-500/40">
              C₆H₆ Benzena
            </span>
          </div>
        );

      case 'leaf':
        return (
          <div className="relative w-28 h-28 flex items-center justify-center">
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-xl transition-all ${
                isHovered ? 'scale-110' : ''
              }`}
              style={{
                background: 'radial-gradient(circle, #34d399 20%, #10b981 70%, #047857 100%)',
                boxShadow: '0 0 30px rgba(16,185,129,0.5)',
              }}
            >
              <Leaf className="w-9 h-9 text-emerald-100 fill-emerald-100" />
            </div>
            <span className="absolute -bottom-2 text-[10px] font-mono text-emerald-300 font-bold px-2 py-0.5 rounded bg-slate-900/90 border border-emerald-500/40">
              12 Prinsip Hijau
            </span>
          </div>
        );

      case 'globe':
        return (
          <div className="relative w-28 h-28 flex items-center justify-center">
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-xl transition-all ${
                isHovered ? 'scale-110' : ''
              }`}
              style={{
                background: 'radial-gradient(circle, #0284c7 20%, #0369a1 70%, #075985 100%)',
                boxShadow: '0 0 30px rgba(2,132,199,0.5)',
              }}
            >
              <Globe className="w-9 h-9 text-sky-200" />
            </div>
            <span className="absolute -bottom-2 text-[10px] font-mono text-sky-300 font-bold px-2 py-0.5 rounded bg-slate-900/90 border border-sky-500/40">
              Pemanasan Global
            </span>
          </div>
        );

      case 'balance':
        return (
          <div className="relative w-28 h-28 flex items-center justify-center">
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-xl transition-all ${
                isHovered ? 'scale-110' : ''
              }`}
              style={{
                background: 'radial-gradient(circle, #f43f5e 20%, #e11d48 70%, #be123c 100%)',
                boxShadow: '0 0 30px rgba(244,63,94,0.5)',
              }}
            >
              <Scale className="w-9 h-9 text-rose-100" />
            </div>
            <span className="absolute -bottom-2 text-[10px] font-mono text-rose-300 font-bold px-2 py-0.5 rounded bg-slate-900/90 border border-rose-500/40">
              Stoikiometri
            </span>
          </div>
        );

      default:
        return (
          <div className="relative w-28 h-28 flex items-center justify-center">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg"
              style={{
                background: `linear-gradient(135deg, ${accentColor}, #0284c7)`,
                boxShadow: `0 0 20px ${accentColor}60`,
              }}
            >
              <Atom className="w-8 h-8 text-white animate-spin" style={{ animationDuration: '10s' }} />
            </div>
          </div>
        );
    }
  };

  return (
    <div className="w-full h-full flex flex-col items-center justify-center select-none relative">
      {/* Subtle radial ambient background glow */}
      <div
        className="absolute w-36 h-36 rounded-full opacity-20 blur-xl pointer-events-none"
        style={{ backgroundColor: accentColor }}
      />
      {renderVisual()}
    </div>
  );
}
