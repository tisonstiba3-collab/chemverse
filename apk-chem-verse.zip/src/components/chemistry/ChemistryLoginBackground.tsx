import React, { useEffect, useRef } from 'react';

// Standard atom node
interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  glowColor: string;
  alpha: number;
  excited: number; // 0 to 1 when excited by click shockwave
}

// Quantum Bohr Atom with orbiting electrons
interface QuantumAtom {
  x: number;
  y: number;
  vx: number;
  vy: number;
  coreRadius: number;
  orbitRadiusX: number;
  orbitRadiusY: number;
  orbitAngle: number;
  orbitTilt: number;
  electronSpeed: number;
  symbol: string;
}

// Actual geometric molecular structure drifting in space
interface MoleculeStructure {
  type: 'benzene' | 'water' | 'methane';
  x: number;
  y: number;
  vx: number;
  vy: number;
  rotation: number;
  vRot: number;
  scale: number;
}

// Rising micro-bubble (effervescence / gas evolution reaction)
interface Bubble {
  x: number;
  y: number;
  baseX: number;
  vy: number;
  radius: number;
  wobbleSpeed: number;
  wobbleAmp: number;
  alpha: number;
}

// Click reaction shockwave
interface Shockwave {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  alpha: number;
  speed: number;
}

// Floating chemical formula chip
interface FormulaChip {
  formula: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  alpha: number;
}

const FORMULAS = [
  'C₆H₆',
  'ΔH < 0',
  'pH = -log[H⁺]',
  'PV = nRT',
  '[Ar] 3d¹⁰ 4s²',
  'K_sp = [Ag⁺][Cl⁻]',
  'E = hν',
  '2H₂ + O₂ → 2H₂O',
];

export default function ChemistryLoginBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationFrameId: number;
    let width = 0;
    let height = 0;
    let time = 0;

    // Interactive mouse coordinates & probe state
    const mouse = {
      x: -9999,
      y: -9999,
      radius: 130,
      active: false,
    };

    let particles: Particle[] = [];
    let quantumAtoms: QuantumAtom[] = [];
    let molecules: MoleculeStructure[] = [];
    let bubbles: Bubble[] = [];
    let shockwaves: Shockwave[] = [];
    let formulaChips: FormulaChip[] = [];

    // Resize handler with High-DPI support
    const resizeCanvas = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);

      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;

      ctx.scale(dpr, dpr);
      initWorld();
    };

    // Initialize all chemical elements
    const initWorld = () => {
      const isMobile = width < 768;

      // 1. Particle Constellation Network
      const particleCount = isMobile
        ? Math.min(32, Math.max(18, Math.floor((width * height) / 24000)))
        : Math.min(75, Math.max(45, Math.floor((width * height) / 18000)));

      particles = [];
      const colors = [
        { fill: '#00f5ff', glow: 'rgba(0, 245, 255, 0.7)' },
        { fill: '#38bdf8', glow: 'rgba(56, 189, 248, 0.6)' },
        { fill: '#818cf8', glow: 'rgba(129, 140, 248, 0.5)' },
        { fill: '#c084fc', glow: 'rgba(192, 132, 252, 0.5)' },
      ];

      for (let i = 0; i < particleCount; i++) {
        const c = colors[i % colors.length];
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * (isMobile ? 0.3 : 0.4),
          vy: (Math.random() - 0.5) * (isMobile ? 0.3 : 0.4),
          radius: Math.random() * 1.8 + 1.2,
          color: c.fill,
          glowColor: c.glow,
          alpha: Math.random() * 0.4 + 0.35,
          excited: 0,
        });
      }

      // 2. Quantum Bohr Atoms with spinning electron orbits (2 on mobile, 4 on desktop)
      quantumAtoms = [];
      const qCount = isMobile ? 2 : 4;
      const qSymbols = ['C₆', 'N₇', 'O₈', 'Na₁₁'];

      for (let i = 0; i < qCount; i++) {
        // Distribute nicely across quadrants
        const qx = (width / (qCount + 1)) * (i + 1) + (Math.random() - 0.5) * 80;
        const qy = (height / 2) + ((i % 2 === 0 ? -1 : 1) * (height * 0.28)) + (Math.random() - 0.5) * 60;

        quantumAtoms.push({
          x: qx,
          y: qy,
          vx: (Math.random() - 0.5) * 0.2,
          vy: (Math.random() - 0.5) * 0.2,
          coreRadius: 5.5,
          orbitRadiusX: isMobile ? 32 : 42,
          orbitRadiusY: isMobile ? 14 : 18,
          orbitAngle: Math.random() * Math.PI * 2,
          orbitTilt: (i * Math.PI) / 3,
          electronSpeed: 0.035 + (i * 0.008),
          symbol: qSymbols[i % qSymbols.length],
        });
      }

      // 3. Floating Geometric Molecules: 1 Benzene Ring, 2 Water molecules
      molecules = [
        {
          type: 'benzene',
          x: width * 0.16,
          y: height * 0.28,
          vx: 0.15,
          vy: 0.08,
          rotation: 0,
          vRot: 0.004,
          scale: isMobile ? 0.75 : 1.0,
        },
        {
          type: 'water',
          x: width * 0.82,
          y: height * 0.25,
          vx: -0.12,
          vy: 0.1,
          rotation: 0.4,
          vRot: -0.005,
          scale: isMobile ? 0.8 : 1.1,
        },
        {
          type: 'water',
          x: width * 0.22,
          y: height * 0.78,
          vx: 0.1,
          vy: -0.09,
          rotation: 1.2,
          vRot: 0.006,
          scale: isMobile ? 0.75 : 0.95,
        },
      ];

      // 4. Effervescence micro-bubbles rising from bottom
      const bubbleCount = isMobile ? 12 : 22;
      bubbles = [];
      for (let i = 0; i < bubbleCount; i++) {
        const bx = Math.random() * width;
        bubbles.push({
          x: bx,
          baseX: bx,
          y: height + Math.random() * 200,
          vy: -(Math.random() * 0.55 + 0.45),
          radius: Math.random() * 2.2 + 1.2,
          wobbleSpeed: Math.random() * 0.03 + 0.015,
          wobbleAmp: Math.random() * 14 + 6,
          alpha: Math.random() * 0.35 + 0.2,
        });
      }

      // 5. Stylized floating formula chips
      formulaChips = [];
      const chipCount = isMobile ? 3 : 6;
      for (let i = 0; i < chipCount; i++) {
        formulaChips.push({
          formula: FORMULAS[i % FORMULAS.length],
          x: (width / chipCount) * i + Math.random() * 60,
          y: (height / chipCount) * ((i * 2) % chipCount) + Math.random() * 60,
          vx: (Math.random() - 0.5) * 0.15,
          vy: (Math.random() - 0.5) * 0.15,
          alpha: Math.random() * 0.25 + 0.2,
        });
      }
    };

    // Mouse handlers (attached to window so pointer-events: none on canvas doesn't block)
    const handleMouseMove = (e: MouseEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
      mouse.active = true;
    };

    const handleMouseLeave = () => {
      mouse.x = -9999;
      mouse.y = -9999;
      mouse.active = false;
    };

    // Click / Tap generates an interactive Chemical Excitation Shockwave!
    const handleClick = (e: MouseEvent) => {
      // Don't trigger if clicked directly inside input/button (handled by form)
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'BUTTON' || target.closest('button')) {
        return;
      }
      createShockwave(e.clientX, e.clientY);
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        mouse.x = e.touches[0].clientX;
        mouse.y = e.touches[0].clientY;
        mouse.active = true;
      }
    };

    const handleTouchEnd = () => {
      mouse.x = -9999;
      mouse.y = -9999;
      mouse.active = false;
    };

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const target = e.target as HTMLElement;
        if (target.tagName === 'INPUT' || target.tagName === 'BUTTON' || target.closest('button')) {
          return;
        }
        createShockwave(e.touches[0].clientX, e.touches[0].clientY);
      }
    };

    const createShockwave = (x: number, y: number) => {
      shockwaves.push({
        x,
        y,
        radius: 5,
        maxRadius: Math.min(width, height) * 0.45,
        alpha: 0.9,
        speed: 5.5,
      });

      // Excite nearby particles
      for (const p of particles) {
        const dx = p.x - x;
        const dy = p.y - y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 220) {
          p.excited = 1.0;
          const force = (220 - dist) / 220;
          const angle = Math.atan2(dy, dx);
          p.vx += Math.cos(angle) * force * 1.5;
          p.vy += Math.sin(angle) * force * 1.5;
        }
      }
    };

    window.addEventListener('resize', resizeCanvas);
    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('click', handleClick);
    window.addEventListener('touchmove', handleTouchMove, { passive: true });
    window.addEventListener('touchend', handleTouchEnd);
    window.addEventListener('touchstart', handleTouchStart, { passive: true });

    let isTabVisible = document.visibilityState === 'visible';
    const handleVisibility = () => {
      isTabVisible = document.visibilityState === 'visible';
    };
    document.addEventListener('visibilitychange', handleVisibility);

    resizeCanvas();

    // ==========================================
    // RENDER HELPER FUNCTIONS
    // ==========================================

    // Draw Benzene Ring (C₆H₆) with Kekulé alternating double bonds & central delocalized circle
    const drawBenzene = (mol: MoleculeStructure) => {
      ctx.save();
      ctx.translate(mol.x, mol.y);
      ctx.rotate(mol.rotation);
      ctx.scale(mol.scale, mol.scale);

      const R = 38; // Radius of carbon ring
      const vertices: { x: number; y: number }[] = [];

      for (let i = 0; i < 6; i++) {
        const angle = (i * Math.PI) / 3;
        vertices.push({ x: R * Math.cos(angle), y: R * Math.sin(angle) });
      }

      // Outer covalent bonds
      ctx.strokeStyle = 'rgba(0, 245, 255, 0.45)';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const p1 = vertices[i];
        const p2 = vertices[(i + 1) % 6];
        if (i === 0) ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
      }
      ctx.closePath();
      ctx.stroke();

      // Alternating inner double bonds
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
      ctx.lineWidth = 1.2;
      for (let i = 0; i < 6; i += 2) {
        const p1 = vertices[i];
        const p2 = vertices[(i + 1) % 6];
        const innerP1 = { x: p1.x * 0.78, y: p1.y * 0.78 };
        const innerP2 = { x: p2.x * 0.78, y: p2.y * 0.78 };
        ctx.beginPath();
        ctx.moveTo(innerP1.x, innerP1.y);
        ctx.lineTo(innerP2.x, innerP2.y);
        ctx.stroke();
      }

      // Delocalized pi-electron aromatic circle (subtle glow)
      ctx.beginPath();
      ctx.arc(0, 0, R * 0.52, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(168, 85, 247, 0.35)';
      ctx.lineWidth = 1.2;
      ctx.setLineDash([4, 4]);
      ctx.stroke();
      ctx.setLineDash([]);

      // Carbon atom nodes & outward Hydrogens
      for (let i = 0; i < 6; i++) {
        const v = vertices[i];
        // Carbon nucleus
        ctx.beginPath();
        ctx.arc(v.x, v.y, 3.2, 0, Math.PI * 2);
        ctx.fillStyle = '#00f5ff';
        ctx.shadowColor = '#00f5ff';
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.shadowBlur = 0;

        // C-H bond extending outward
        const hAngle = (i * Math.PI) / 3;
        const hx = (R + 15) * Math.cos(hAngle);
        const hy = (R + 15) * Math.sin(hAngle);

        ctx.strokeStyle = 'rgba(0, 245, 255, 0.25)';
        ctx.lineWidth = 0.9;
        ctx.beginPath();
        ctx.moveTo(v.x, v.y);
        ctx.lineTo(hx, hy);
        ctx.stroke();

        // Hydrogen atom node
        ctx.beginPath();
        ctx.arc(hx, hy, 2, 0, Math.PI * 2);
        ctx.fillStyle = '#e0f2fe';
        ctx.fill();
      }

      // Small formula label
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.fillStyle = 'rgba(0, 245, 255, 0.45)';
      ctx.textAlign = 'center';
      ctx.fillText('C₆H₆', 0, 4);

      ctx.restore();
    };

    // Draw Water Molecule (H₂O) with 104.5° bent geometry
    const drawWater = (mol: MoleculeStructure) => {
      ctx.save();
      ctx.translate(mol.x, mol.y);
      ctx.rotate(mol.rotation);
      ctx.scale(mol.scale, mol.scale);

      const bondLength = 26;
      const halfAngle = (104.5 * Math.PI) / 360; // 52.25 degrees in rad

      const h1x = bondLength * Math.sin(halfAngle);
      const h1y = bondLength * Math.cos(halfAngle);
      const h2x = -bondLength * Math.sin(halfAngle);
      const h2y = bondLength * Math.cos(halfAngle);

      // Covalent bonds O-H
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(h1x, h1y);
      ctx.moveTo(0, 0);
      ctx.lineTo(h2x, h2y);
      ctx.stroke();

      // Hydrogen 1
      ctx.beginPath();
      ctx.arc(h1x, h1y, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = '#e0f2fe';
      ctx.fill();

      // Hydrogen 2
      ctx.beginPath();
      ctx.arc(h2x, h2y, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = '#e0f2fe';
      ctx.fill();

      // Oxygen Central Atom (Larger with red-cyan glow)
      ctx.beginPath();
      ctx.arc(0, 0, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#38bdf8';
      ctx.shadowColor = '#00f5ff';
      ctx.shadowBlur = 10;
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.restore();
    };

    // Draw Quantum Bohr Atom with orbiting electrons leaving trail
    const drawQuantumAtom = (qa: QuantumAtom) => {
      ctx.save();
      ctx.translate(qa.x, qa.y);

      // Draw Orbit 1 (tilted)
      ctx.save();
      ctx.rotate(qa.orbitTilt);
      ctx.strokeStyle = 'rgba(0, 245, 255, 0.22)';
      ctx.lineWidth = 1.0;
      ctx.beginPath();
      ctx.ellipse(0, 0, qa.orbitRadiusX, qa.orbitRadiusY, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Electron 1 on Orbit 1
      const e1Angle = qa.orbitAngle;
      const e1x = qa.orbitRadiusX * Math.cos(e1Angle);
      const e1y = qa.orbitRadiusY * Math.sin(e1Angle);

      ctx.beginPath();
      ctx.arc(e1x, e1y, 2.2, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = '#00f5ff';
      ctx.shadowBlur = 8;
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.restore();

      // Draw Orbit 2 (counter-tilted)
      ctx.save();
      ctx.rotate(-qa.orbitTilt);
      ctx.strokeStyle = 'rgba(168, 85, 247, 0.22)';
      ctx.lineWidth = 1.0;
      ctx.beginPath();
      ctx.ellipse(0, 0, qa.orbitRadiusX * 1.08, qa.orbitRadiusY * 1.15, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Electron 2 on Orbit 2 (moving opposite direction)
      const e2Angle = -qa.orbitAngle * 1.25;
      const e2x = qa.orbitRadiusX * 1.08 * Math.cos(e2Angle);
      const e2y = qa.orbitRadiusY * 1.15 * Math.sin(e2Angle);

      ctx.beginPath();
      ctx.arc(e2x, e2y, 2.0, 0, Math.PI * 2);
      ctx.fillStyle = '#38bdf8';
      ctx.shadowColor = '#a855f7';
      ctx.shadowBlur = 8;
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.restore();

      // Glowing Nucleus Cluster
      ctx.beginPath();
      ctx.arc(0, 0, qa.coreRadius, 0, Math.PI * 2);
      ctx.fillStyle = '#00f5ff';
      ctx.shadowColor = '#00f5ff';
      ctx.shadowBlur = 12;
      ctx.fill();
      ctx.shadowBlur = 0;

      // Symbol
      ctx.font = '8px "JetBrains Mono", monospace';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(qa.symbol, 0, 0);

      ctx.restore();
    };

    // Draw Corner High-Tech Holographic Orbital Compass HUD
    const drawHoloHUD = () => {
      // Top Right Orbital Ring
      ctx.save();
      const trX = width - 40;
      const trY = 40;
      ctx.translate(trX, trY);
      ctx.rotate(time * 0.002);

      ctx.strokeStyle = 'rgba(0, 245, 255, 0.08)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(0, 0, 110, 0, Math.PI * 2);
      ctx.stroke();

      ctx.setLineDash([6, 12]);
      ctx.beginPath();
      ctx.arc(0, 0, 85, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.restore();

      // Bottom Left Orbital Ring
      ctx.save();
      const blX = 40;
      const blY = height - 40;
      ctx.translate(blX, blY);
      ctx.rotate(-time * 0.0015);

      ctx.strokeStyle = 'rgba(168, 85, 247, 0.08)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(0, 0, 130, 0, Math.PI * 2);
      ctx.stroke();

      ctx.setLineDash([4, 8]);
      ctx.beginPath();
      ctx.arc(0, 0, 100, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.restore();
    };

    // ==========================================
    // MAIN ANIMATION LOOP (60 FPS)
    // ==========================================
    const maxBondDistance = width < 768 ? 95 : 130;

    const render = () => {
      if (!isTabVisible) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      time += 1;
      ctx.clearRect(0, 0, width, height);

      // 1. Draw subtle holographic analyzer compass HUD in background
      drawHoloHUD();

      // 2. Update and draw floating formula chips
      for (const fc of formulaChips) {
        fc.x += fc.vx;
        fc.y += fc.vy;
        if (fc.x < -40) fc.x = width + 40;
        else if (fc.x > width + 40) fc.x = -40;
        if (fc.y < -40) fc.y = height + 40;
        else if (fc.y > height + 40) fc.y = -40;

        ctx.font = '11px "Space Grotesk", "JetBrains Mono", monospace';
        ctx.fillStyle = `rgba(56, 189, 248, ${fc.alpha})`;
        ctx.fillText(fc.formula, fc.x, fc.y);
      }

      // 3. Update & Draw Effervescence Micro-Bubbles
      for (const b of bubbles) {
        b.y += b.vy;
        b.x = b.baseX + Math.sin(time * b.wobbleSpeed) * b.wobbleAmp;

        if (b.y < -20) {
          b.y = height + Math.random() * 80;
          b.baseX = Math.random() * width;
          b.x = b.baseX;
        }

        ctx.save();
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(0, 245, 255, ${b.alpha * 0.7})`;
        ctx.lineWidth = 0.8;
        ctx.stroke();

        ctx.fillStyle = `rgba(0, 245, 255, ${b.alpha * 0.25})`;
        ctx.fill();
        ctx.restore();
      }

      // 4. Update & Draw Geometric Molecules (Benzene & Water)
      for (const mol of molecules) {
        mol.x += mol.vx;
        mol.y += mol.vy;
        mol.rotation += mol.vRot;

        if (mol.x < -80) mol.x = width + 80;
        else if (mol.x > width + 80) mol.x = -80;
        if (mol.y < -80) mol.y = height + 80;
        else if (mol.y > height + 80) mol.y = -80;

        if (mol.type === 'benzene') {
          drawBenzene(mol);
        } else if (mol.type === 'water') {
          drawWater(mol);
        }
      }

      // 5. Chemical Bonds between nearby particles
      for (let i = 0; i < particles.length; i++) {
        const p1 = particles[i];

        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dx = p1.x - p2.x;
          const dy = p1.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < maxBondDistance) {
            const ratio = 1 - dist / maxBondDistance;
            const extraExcited = Math.max(p1.excited, p2.excited);
            const alpha = (ratio * 0.22) + (extraExcited * 0.4);

            const gradient = ctx.createLinearGradient(p1.x, p1.y, p2.x, p2.y);
            gradient.addColorStop(0, `rgba(0, 245, 255, ${alpha})`);
            gradient.addColorStop(0.5, `rgba(56, 189, 248, ${alpha * 0.85})`);
            gradient.addColorStop(1, `rgba(168, 85, 247, ${alpha * 0.6})`);

            ctx.strokeStyle = gradient;
            ctx.lineWidth = ratio > 0.5 ? 1.0 : 0.65;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }
      }

      // 6. Interactive Mouse Chemical Reagent Probe (Dynamic Laser Tethers)
      if (mouse.active && mouse.x > 0 && mouse.y > 0) {
        // Find 3 closest particles to mouse
        const distances = particles.map((p, idx) => {
          const dx = p.x - mouse.x;
          const dy = p.y - mouse.y;
          return { idx, dist: Math.sqrt(dx * dx + dy * dy), p };
        });
        distances.sort((a, b) => a.dist - b.dist);

        for (let k = 0; k < Math.min(3, distances.length); k++) {
          const item = distances[k];
          if (item.dist < 180) {
            const alpha = (1 - item.dist / 180) * 0.35;
            ctx.strokeStyle = `rgba(0, 245, 255, ${alpha})`;
            ctx.lineWidth = 0.9;
            ctx.setLineDash([2, 4]);
            ctx.beginPath();
            ctx.moveTo(mouse.x, mouse.y);
            ctx.lineTo(item.p.x, item.p.y);
            ctx.stroke();
            ctx.setLineDash([]);
          }
        }

        // Draw luminous probe point at cursor
        ctx.beginPath();
        ctx.arc(mouse.x, mouse.y, 4, 0, Math.PI * 2);
        ctx.fillStyle = '#00f5ff';
        ctx.shadowColor = '#00f5ff';
        ctx.shadowBlur = 12;
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      // 7. Update & Draw Particles (Atoms)
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Smooth decay of excitation state
        if (p.excited > 0) {
          p.excited = Math.max(0, p.excited - 0.015);
        }

        // Mouse gentle repulsion physics
        if (mouse.x !== -9999 && mouse.y !== -9999) {
          const dx = p.x - mouse.x;
          const dy = p.y - mouse.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < mouse.radius && dist > 0) {
            const force = (mouse.radius - dist) / mouse.radius;
            const angle = Math.atan2(dy, dx);
            p.x += Math.cos(angle) * force * 2.6;
            p.y += Math.sin(angle) * force * 2.6;
          }
        }

        p.x += p.vx;
        p.y += p.vy;

        if (p.x < -10) p.x = width + 10;
        else if (p.x > width + 10) p.x = -10;
        if (p.y < -10) p.y = height + 10;
        else if (p.y > height + 10) p.y = -10;

        // Atom Glow Aura
        ctx.save();
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius * (2.2 + p.excited * 1.5), 0, Math.PI * 2);
        ctx.fillStyle = p.glowColor;
        ctx.globalAlpha = p.alpha * (0.35 + p.excited * 0.4);
        ctx.fill();
        ctx.restore();

        // Atom Core
        ctx.save();
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius * (1 + p.excited * 0.5), 0, Math.PI * 2);
        ctx.fillStyle = p.excited > 0.4 ? '#ffffff' : p.color;
        ctx.globalAlpha = Math.min(1.0, p.alpha + p.excited * 0.5);
        ctx.shadowColor = '#00f5ff';
        ctx.shadowBlur = p.excited > 0.2 ? 14 : 4;
        ctx.fill();
        ctx.restore();
      }

      // 8. Update & Draw Quantum Bohr Atoms
      for (const qa of quantumAtoms) {
        qa.x += qa.vx;
        qa.y += qa.vy;
        qa.orbitAngle += qa.electronSpeed;

        if (qa.x < -50) qa.x = width + 50;
        else if (qa.x > width + 50) qa.x = -50;
        if (qa.y < -50) qa.y = height + 50;
        else if (qa.y > height + 50) qa.y = -50;

        drawQuantumAtom(qa);
      }

      // 9. Update & Draw Click Excitation Shockwaves
      for (let s = shockwaves.length - 1; s >= 0; s--) {
        const sw = shockwaves[s];
        sw.radius += sw.speed;
        sw.alpha -= 0.018;

        if (sw.alpha <= 0 || sw.radius >= sw.maxRadius) {
          shockwaves.splice(s, 1);
          continue;
        }

        ctx.save();
        ctx.beginPath();
        ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(0, 245, 255, ${sw.alpha * 0.75})`;
        ctx.lineWidth = Math.max(1, 3 * sw.alpha);
        ctx.shadowColor = '#00f5ff';
        ctx.shadowBlur = 10;
        ctx.stroke();

        // Secondary inner purple wave
        ctx.beginPath();
        ctx.arc(sw.x, sw.y, Math.max(0, sw.radius - 15), 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(168, 85, 247, ${sw.alpha * 0.5})`;
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', resizeCanvas);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('click', handleClick);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
      window.removeEventListener('touchstart', handleTouchStart);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0 bg-[#040714]">
      {/* 
        Sisi Kiri: Radial gradient glow neon CYAN terang
        Sisi Kanan: Radial gradient glow UNGU futuristik
      */}
      <div
        className="absolute top-1/2 -left-48 -translate-y-1/2 w-[550px] h-[550px] rounded-full pointer-events-none opacity-25 blur-[130px] animate-pulse"
        style={{
          background: 'radial-gradient(circle, #00f5ff 0%, #06b6d4 40%, transparent 70%)',
          animationDuration: '6s',
        }}
      />
      <div
        className="absolute top-1/2 -right-48 -translate-y-1/2 w-[580px] h-[580px] rounded-full pointer-events-none opacity-25 blur-[140px] animate-pulse"
        style={{
          background: 'radial-gradient(circle, #9333ea 0%, #7c3aed 45%, transparent 70%)',
          animationDuration: '8s',
        }}
      />

      {/* Top subtle cyan energy band */}
      <div
        className="absolute -top-36 left-1/2 -translate-x-1/2 w-[650px] h-[320px] rounded-full pointer-events-none opacity-15 blur-[110px]"
        style={{
          background: 'radial-gradient(circle, #38bdf8 0%, #0284c7 50%, transparent 70%)',
        }}
      />

      {/* HTML5 Canvas Background: z-index: 0, pointer-events: none */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 block w-full h-full pointer-events-none z-0"
      />

      {/* Cinematic Vignette for deep laboratory atmosphere */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_center,transparent_35%,rgba(4,7,20,0.8)_100%)] z-0" />
    </div>
  );
}
