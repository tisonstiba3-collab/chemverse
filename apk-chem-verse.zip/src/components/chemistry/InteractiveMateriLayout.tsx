import React, { useState, useEffect, useRef } from 'react';
import {
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  FileText,
  Presentation,
  ExternalLink,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Sparkles,
  Layers,
  Play,
  Pause,
  Download,
  Eye,
} from 'lucide-react';

export type MateriLayoutType = 'standard' | 'flipbook' | 'presentation' | 'pdf_viewer';

export interface InteractiveMateriLayoutProps {
  layoutType?: MateriLayoutType;
  contentPages?: string[];
  contentHtml?: string;
  attachmentUrl?: string;
  topicTitle: string;
  topicCategory?: string;
}

export default function InteractiveMateriLayout({
  layoutType = 'standard',
  contentPages,
  contentHtml = '',
  attachmentUrl,
  topicTitle,
  topicCategory = 'Kimia SMA',
}: InteractiveMateriLayoutProps) {
  // Allow user to toggle view mode while defaulting to the AI/Teacher's preferred layout
  const [activeLayout, setActiveLayout] = useState<MateriLayoutType>(layoutType);

  // Sync state if layoutType prop changes
  useEffect(() => {
    setActiveLayout(layoutType);
  }, [layoutType]);

  // Flipbook State
  const [flipPage, setFlipPage] = useState<number>(0);
  const [isFlipping, setIsFlipping] = useState<boolean>(false);
  const [flipDirection, setFlipDirection] = useState<'next' | 'prev'>('next');

  // Presentation State
  const [currentSlide, setCurrentSlide] = useState<number>(0);
  const [isPresentationFullscreen, setIsPresentationFullscreen] = useState<boolean>(false);
  const [isAutoplay, setIsAutoplay] = useState<boolean>(false);

  // PDF Viewer State
  const [pdfZoom, setPdfZoom] = useState<number>(100);
  const [pdfPage, setPdfPage] = useState<number>(1);

  // Derive pages if contentPages is not provided or empty
  const pages: string[] = React.useMemo(() => {
    if (contentPages && contentPages.length > 0) {
      return contentPages;
    }
    // Auto-split contentHtml by <h3>, <h2>, or paragraph markers
    if (contentHtml) {
      const clean = contentHtml.replace(/<[^>]*>?/gm, ' ');
      const parts = clean.split(/(?=[0-9]+\.\s|[A-Z][a-z]+:)/g).filter((p) => p.trim().length > 30);
      if (parts.length >= 2) {
        return parts.slice(0, 6);
      }
    }
    // Default fallback structured pages
    return [
      `### Halaman 1: Konsep Kunci & Pendahuluan\n${topicTitle} merupakan fondasi penting dalam kurikulum kimia SMA. Pemahaman konsep ini menghubungkan fenomena mikroskopis partikel atom dengan karakteristik zat makroskopis di alam semesta.`,
      `### Halaman 2: Landasan Teori & Hukum Kimia\nPrinsip-prinsip ilmiah mendasari interaksi materi dan energi. Perhitungan stoikiometri dan hukum kekekalan materi membuktikan bahwa reaksi kimia adalah penataan ulang atom tanpa kehilangan massa.`,
      `### Halaman 3: Pembahasan Soal & Analisis Ilmiah\nPerhatikan variabel yang diketahui, tentukan rumus yang relevan, dan periksa kesesuaian satuan. Evaluasi bertahap meminimalkan miskonsepsi dalam pemecahan masalah kimia.`,
      `### Halaman 4: Kesimpulan & Aplikasi Nyata\nPenerapan materi ${topicTitle} memberikan kontribusi nyata dalam bidang energi terbarukan, farmasi, nanomaterial, dan kelestarian kimia hijau (green chemistry).`,
    ];
  }, [contentPages, contentHtml, topicTitle]);

  const totalPages = pages.length;

  // Keyboard navigation for Flipbook and Presentation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (activeLayout === 'flipbook') {
        if (e.key === 'ArrowRight' || e.key === 'PageDown') {
          handleNextFlipPage();
        } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
          handlePrevFlipPage();
        }
      } else if (activeLayout === 'presentation') {
        if (e.key === 'ArrowRight' || e.key === 'Space') {
          setCurrentSlide((prev) => Math.min(totalPages - 1, prev + 1));
        } else if (e.key === 'ArrowLeft') {
          setCurrentSlide((prev) => Math.max(0, prev - 1));
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeLayout, totalPages, flipPage]);

  // Autoplay handler for presentation
  useEffect(() => {
    if (!isAutoplay || activeLayout !== 'presentation') return;
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % totalPages);
    }, 4500);
    return () => clearInterval(timer);
  }, [isAutoplay, activeLayout, totalPages]);

  // Flipbook Page Handlers with 3D animation cue
  const handleNextFlipPage = () => {
    if (flipPage < totalPages - 1 && !isFlipping) {
      setIsFlipping(true);
      setFlipDirection('next');
      setTimeout(() => {
        setFlipPage((prev) => Math.min(totalPages - 1, prev + 1));
        setIsFlipping(false);
      }, 250);
    }
  };

  const handlePrevFlipPage = () => {
    if (flipPage > 0 && !isFlipping) {
      setIsFlipping(true);
      setFlipDirection('prev');
      setTimeout(() => {
        setFlipPage((prev) => Math.max(0, prev - 1));
        setIsFlipping(false);
      }, 250);
    }
  };

  // Helper to format text with headings and bold tags
  const renderFormattedText = (text: string) => {
    const lines = text.split('\n');
    return (
      <div className="space-y-3">
        {lines.map((line, idx) => {
          const trimmed = line.trim();
          if (trimmed.startsWith('### ') || trimmed.startsWith('## ') || trimmed.startsWith('# ')) {
            const headingText = trimmed.replace(/^#+\s*/, '');
            return (
              <h3
                key={idx}
                className="text-base sm:text-lg font-black text-white tracking-tight flex items-center gap-2 pt-1 pb-1 border-b border-white/10"
                style={{ fontFamily: "'Space Grotesk', sans-serif" }}
              >
                <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>{headingText}</span>
              </h3>
            );
          }
          if (trimmed.startsWith('- ') || trimmed.startsWith('* ') || trimmed.startsWith('• ')) {
            return (
              <li key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-200 ml-2">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0 mt-2" />
                <span>{trimmed.replace(/^[-*•]\s*/, '')}</span>
              </li>
            );
          }
          if (!trimmed) return <div key={idx} className="h-1.5" />;
          return (
            <p key={idx} className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
              {trimmed}
            </p>
          );
        })}
      </div>
    );
  };

  return (
    <div className="space-y-4 animate-fade-in text-slate-100 font-sans">
      {/* ======================================================== */}
      {/* 1. TOP LAYOUT SWITCHER & INDICATOR BAR                   */}
      {/* ======================================================== */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-white/[0.03] backdrop-blur-xl border border-white/10">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>Format Tampilan:</span>
          </span>

          {layoutType !== 'standard' && (
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Desain Guru: {layoutType.toUpperCase()}
            </span>
          )}
        </div>

        {/* Layout Selector Pills */}
        <div className="flex items-center gap-1.5 bg-black/40 p-1 rounded-xl border border-white/5">
          <button
            onClick={() => setActiveLayout('standard')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeLayout === 'standard'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Standar</span>
          </button>

          <button
            onClick={() => setActiveLayout('flipbook')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeLayout === 'flipbook'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
            }`}
          >
            <span>📖</span>
            <span>Flipbook</span>
          </button>

          <button
            onClick={() => setActiveLayout('presentation')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeLayout === 'presentation'
                ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-600/30'
                : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
            }`}
          >
            <Presentation className="w-3.5 h-3.5" />
            <span>Slide PPT</span>
          </button>

          <button
            onClick={() => setActiveLayout('pdf_viewer')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeLayout === 'pdf_viewer'
                ? 'bg-gradient-to-r from-rose-600 to-amber-600 text-white shadow-md shadow-rose-600/30'
                : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
            }`}
          >
            <span>📄</span>
            <span>PDF Viewer</span>
          </button>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 2. RENDER BERSYARAT BERDASARKAN LAYOUT TYPE              */}
      {/* ======================================================== */}

      {/* -------------------------------------------------------- */}
      {/* OPTION A: FLIPBOOK INTERAKTIF (BUKU DIGITAL 3D)          */}
      {/* -------------------------------------------------------- */}
      {activeLayout === 'flipbook' && (
        <div className="space-y-4">
          {/* Flipbook Header Controls */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-purple-950/30 border border-purple-500/30 text-xs">
            <div className="flex items-center gap-2 text-purple-300 font-mono font-bold">
              <span>📖</span>
              <span>Buku Digital Flipbook: {topicTitle}</span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono text-purple-300 bg-purple-500/20 px-2.5 py-1 rounded-lg border border-purple-500/30 font-bold">
                Halaman {flipPage + 1} dari {totalPages}
              </span>
              <span className="text-slate-500 text-[10px] hidden sm:inline font-mono">
                (Gunakan tombol panah ◀ ▶ keyboard)
              </span>
            </div>
          </div>

          {/* 3D Flipbook Stage */}
          <div
            className="relative w-full min-h-[460px] sm:min-h-[520px] rounded-3xl p-6 sm:p-10 flex flex-col justify-between overflow-hidden shadow-2xl transition-all duration-300"
            style={{
              perspective: '1200px',
              background: 'linear-gradient(135deg, #090d1a 0%, #131b2e 50%, #0d1527 100%)',
              border: '1px solid rgba(168, 85, 247, 0.35)',
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.7), inset 0 0 40px rgba(168, 85, 247, 0.1)',
            }}
          >
            {/* Book Spine Texture Effect (Left Border Spine) */}
            <div className="absolute top-0 bottom-0 left-0 w-4 sm:w-6 bg-gradient-to-r from-purple-950 via-slate-900 to-transparent border-r border-purple-500/30 opacity-70" />

            {/* Corner Curl Effect Indicator */}
            <div
              onClick={handleNextFlipPage}
              className="absolute top-0 right-0 w-12 h-12 bg-gradient-to-bl from-purple-500/30 via-purple-500/10 to-transparent border-b border-l border-purple-400/40 rounded-bl-2xl cursor-pointer hover:bg-purple-500/40 transition group"
              title="Klik sudut untuk membalik halaman berikutnya"
            >
              <span className="absolute top-1.5 right-1.5 text-[9px] font-mono text-purple-300 group-hover:scale-110 transition">
                ↻
              </span>
            </div>

            {/* Page Content with Flip Animation Transition */}
            <div
              className={`pl-4 sm:pl-6 space-y-4 transition-all duration-300 ${
                isFlipping
                  ? flipDirection === 'next'
                    ? 'opacity-0 translate-x-4 rotate-y-6'
                    : 'opacity-0 -translate-x-4 -rotate-y-6'
                  : 'opacity-100 translate-x-0 rotate-y-0'
              }`}
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="space-y-0.5">
                  <span className="text-[10px] font-mono text-purple-400 font-bold uppercase tracking-wider block">
                    {topicCategory} • Edisi Digital Pelajar
                  </span>
                  <h4 className="text-lg sm:text-xl font-extrabold text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                    {topicTitle}
                  </h4>
                </div>

                <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-300 font-mono text-xs font-bold shrink-0">
                  #{flipPage + 1}
                </div>
              </div>

              {/* Formatted Text Content for Current Page */}
              <div className="min-h-[280px] sm:min-h-[320px] py-2">
                {renderFormattedText(pages[flipPage])}
              </div>
            </div>

            {/* Flipbook Footer & Navigation Bar */}
            <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-3 text-xs font-mono">
              <button
                onClick={handlePrevFlipPage}
                disabled={flipPage === 0 || isFlipping}
                className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white transition flex items-center gap-1.5 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronLeft className="w-4 h-4 text-purple-400" />
                <span className="hidden sm:inline">Halaman Sebelumnya</span>
                <span className="sm:hidden">Sebelumnya</span>
              </button>

              {/* Page Dots Indicator */}
              <div className="flex items-center gap-1.5">
                {pages.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setFlipPage(idx)}
                    className={`h-2 rounded-full transition-all cursor-pointer ${
                      flipPage === idx
                        ? 'w-6 bg-purple-400 shadow-sm shadow-purple-400/50'
                        : 'w-2 bg-white/20 hover:bg-white/40'
                    }`}
                    title={`Lompat ke halaman ${idx + 1}`}
                  />
                ))}
              </div>

              <button
                onClick={handleNextFlipPage}
                disabled={flipPage === totalPages - 1 || isFlipping}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold transition flex items-center gap-1.5 cursor-pointer shadow-lg shadow-purple-600/30 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <span className="hidden sm:inline">Halaman Selanjutnya</span>
                <span className="sm:hidden">Selanjutnya</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* -------------------------------------------------------- */}
      {/* OPTION B: PRESENTATION SLIDE (CAROUSEL PPT INTERAKTIF)   */}
      {/* -------------------------------------------------------- */}
      {activeLayout === 'presentation' && (
        <div className="space-y-4">
          {/* Presentation Toolbar */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 text-xs">
            <div className="flex items-center gap-2">
              <Presentation className="w-4 h-4 text-cyan-400" />
              <span className="text-cyan-300 font-mono font-bold">Slide Presentasi Kimia</span>
            </div>

            <div className="flex items-center gap-2">
              {/* Autoplay button */}
              <button
                onClick={() => setIsAutoplay(!isAutoplay)}
                className={`px-2.5 py-1 rounded-lg border text-[11px] font-mono flex items-center gap-1 transition cursor-pointer ${
                  isAutoplay
                    ? 'bg-cyan-500/30 border-cyan-400 text-cyan-200'
                    : 'bg-white/[0.05] border-white/10 text-slate-300 hover:text-white'
                }`}
              >
                {isAutoplay ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                <span>{isAutoplay ? 'Jeda' : 'Otomatis'}</span>
              </button>

              {/* Fullscreen button */}
              <button
                onClick={() => setIsPresentationFullscreen(!isPresentationFullscreen)}
                className="p-1.5 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white transition cursor-pointer"
                title={isPresentationFullscreen ? 'Tutup Fullscreen' : 'Layar Penuh'}
              >
                {isPresentationFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* 16:9 Presentation Canvas */}
          <div
            className={`w-full rounded-3xl p-6 sm:p-10 flex flex-col justify-between shadow-2xl relative overflow-hidden transition-all duration-300 ${
              isPresentationFullscreen
                ? 'fixed inset-4 z-50 bg-slate-950 border-2 border-cyan-400 shadow-cyan-500/20'
                : 'min-h-[460px] sm:min-h-[520px] bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950/40 border border-cyan-500/30'
            }`}
          >
            {/* Slide Header */}
            <div className="flex items-center justify-between border-b border-cyan-500/20 pb-4">
              <div className="space-y-1">
                <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase tracking-widest flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <span>Chemverse Interactive Slide Deck</span>
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  {topicTitle}
                </h3>
              </div>

              <div className="px-3 py-1 rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 font-mono text-xs font-bold">
                Slide {currentSlide + 1} / {totalPages}
              </div>
            </div>

            {/* Slide Body */}
            <div className="my-auto py-6 max-w-3xl">
              <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/5 space-y-4 shadow-inner">
                {renderFormattedText(pages[currentSlide])}
              </div>
            </div>

            {/* Slide Controls & Thumbnails */}
            <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-3 text-xs font-mono">
              <button
                onClick={() => setCurrentSlide((prev) => Math.max(0, prev - 1))}
                disabled={currentSlide === 0}
                className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white transition flex items-center gap-1.5 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronLeft className="w-4 h-4 text-cyan-400" />
                <span>Prev Slide</span>
              </button>

              {/* Slide number dots */}
              <div className="flex items-center gap-2">
                {pages.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentSlide(idx)}
                    className={`h-2.5 rounded-full transition-all cursor-pointer ${
                      currentSlide === idx
                        ? 'w-7 bg-cyan-400 shadow-sm shadow-cyan-400/50'
                        : 'w-2.5 bg-white/20 hover:bg-white/40'
                    }`}
                    title={`Slide ${idx + 1}`}
                  />
                ))}
              </div>

              <button
                onClick={() => setCurrentSlide((prev) => Math.min(totalPages - 1, prev + 1))}
                disabled={currentSlide === totalPages - 1}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold transition flex items-center gap-1.5 cursor-pointer shadow-lg shadow-cyan-600/30 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <span>Next Slide</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* -------------------------------------------------------- */}
      {/* OPTION C: PDF VIEWER TERINTEGRASI                        */}
      {/* -------------------------------------------------------- */}
      {activeLayout === 'pdf_viewer' && (
        <div className="space-y-4">
          {/* PDF Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-rose-950/30 border border-rose-500/30 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-base">📄</span>
              <span className="text-rose-300 font-mono font-bold">
                Dokumen PDF Materi: {topicTitle}.pdf
              </span>
            </div>

            <div className="flex items-center gap-2">
              {/* Zoom Controls */}
              <button
                onClick={() => setPdfZoom((prev) => Math.max(75, prev - 10))}
                className="p-1.5 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white transition cursor-pointer"
                title="Perkecil Zoom"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="text-[11px] font-mono text-slate-300 min-w-[42px] text-center">
                {pdfZoom}%
              </span>
              <button
                onClick={() => setPdfZoom((prev) => Math.min(150, prev + 10))}
                className="p-1.5 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white transition cursor-pointer"
                title="Perbesar Zoom"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>

              {attachmentUrl && !attachmentUrl.includes('[URL_FILE') && (
                <a
                  href={attachmentUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-mono font-bold transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-rose-600/30 ml-2"
                >
                  <ExternalLink className="w-3 h-3" />
                  <span>Buka PDF Asli</span>
                </a>
              )}
            </div>
          </div>

          {/* PDF Viewer Container */}
          <div className="rounded-3xl bg-slate-950 border border-rose-500/30 shadow-2xl p-4 sm:p-6 space-y-4">
            {attachmentUrl && !attachmentUrl.includes('[URL_FILE') ? (
              <div className="w-full h-[620px] rounded-2xl overflow-hidden border border-white/10 bg-slate-900">
                <iframe
                  src={attachmentUrl}
                  title={`PDF ${topicTitle}`}
                  className="w-full h-full"
                />
              </div>
            ) : (
              /* High-fidelity PDF Reader Simulation with Multi-page scroll */
              <div className="space-y-4">
                <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>
                    <strong>Dokumen Terbaca Sempurna:</strong> Teks materi dari dokumen PDF telah diintegrasikan langsung dalam format pembaca PDF digital interaktif.
                  </span>
                </div>

                <div
                  className="space-y-6 max-h-[580px] overflow-y-auto p-4 sm:p-8 bg-slate-900/90 rounded-2xl border border-white/5 font-sans"
                  style={{ transform: `scale(${pdfZoom / 100})`, transformOrigin: 'top center' }}
                >
                  {pages.map((pageText, pIdx) => (
                    <div
                      key={pIdx}
                      className="p-6 sm:p-8 rounded-xl bg-white/[0.02] border border-white/10 shadow-lg space-y-3 relative"
                    >
                      <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 border-b border-white/10 pb-2">
                        <span>DOKUMEN KIMIA SMA • {topicTitle.toUpperCase()}</span>
                        <span>Halaman {pIdx + 1}</span>
                      </div>
                      <div className="py-2">
                        {renderFormattedText(pageText)}
                      </div>
                      <div className="pt-2 border-t border-white/5 text-[9px] font-mono text-slate-500 text-right">
                        Hak Cipta Bahan Ajar • Chemverse Indonesia
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* -------------------------------------------------------- */}
      {/* OPTION D: STANDARD HTML FORMAT                           */}
      {/* -------------------------------------------------------- */}
      {activeLayout === 'standard' && (
        <div className="p-5 sm:p-6 rounded-3xl bg-cyan-950/30 border border-cyan-500/30 text-xs sm:text-sm text-slate-200 leading-relaxed space-y-3">
          <div className="flex items-center gap-2 text-cyan-400 font-mono font-bold text-xs uppercase tracking-wider">
            <BookOpen className="w-4 h-4" />
            <span>Konten Pembelajaran Lengkap:</span>
          </div>

          {contentHtml ? (
            <div
              className="space-y-2 leading-relaxed"
              dangerouslySetInnerHTML={{ __html: contentHtml }}
            />
          ) : (
            <div className="space-y-4">
              {pages.map((p, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-2">
                  {renderFormattedText(p)}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
