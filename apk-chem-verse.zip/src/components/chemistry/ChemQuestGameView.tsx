import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Heart,
  HelpCircle,
  Zap,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Trophy,
  ArrowRight,
  Flame,
  Award,
  Clock,
  Lightbulb,
  Split,
  ChevronRight,
  Target,
  ArrowLeft,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { StudentProfile } from '../../types/chemistry';

interface ChemQuestGameViewProps {
  student?: StudentProfile | null;
  onAddXP?: (amount: number) => void;
  onBack: () => void;
}

// Question Interface
interface QuestQuestion {
  id: string;
  kelas: 'Kelas X' | 'Kelas XI' | 'Kelas XII';
  bab: string;
  difficulty: 'Mudah' | 'Sedang' | 'Sulit';
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  hint: string;
}

// Extended Question Bank for ChemQuest Mode
const CHEMQUEST_QUESTION_BANK: QuestQuestion[] = [
  // KELAS X - STOIKIOMETRI
  {
    id: 'cq-x-stoi-1',
    kelas: 'Kelas X',
    bab: 'Stoikiometri',
    difficulty: 'Mudah',
    question: 'Berapakah jumlah mol yang terkandung dalam 11,2 Liter gas O₂ pada keadaan Standar (STP 0°C, 1 atm)?',
    options: ['0,25 mol', '0,50 mol', '1,00 mol', '2,00 mol', '4,00 mol'],
    correctIndex: 1,
    explanation: 'Pada kondisi STP, 1 mol gas ideal menempati volume 22,4 L. Maka n = V / 22,4 = 11,2 / 22,4 = 0,50 mol.',
    hint: 'Gunakan hubungan volume molar standar V = n × 22,4 Liter.',
  },
  {
    id: 'cq-x-stoi-2',
    kelas: 'Kelas X',
    bab: 'Stoikiometri',
    difficulty: 'Sedang',
    question: 'Sebanyak 12 gram Karbon (Ar C = 12) dibakar sempurna dengan 32 gram Oksigen (Ar O = 16) menurut reaksi: C + O₂ → CO₂. Berapakah massa CO₂ yang terbentuk?',
    options: ['12 gram', '22 gram', '32 gram', '44 gram', '56 gram'],
    correctIndex: 3,
    explanation: 'mol C = 12/12 = 1 mol. mol O₂ = 32/32 = 1 mol. Perbandingan koefisien C : O₂ : CO₂ = 1 : 1 : 1, sehingga terbentuk 1 mol CO₂. Massa CO₂ = 1 × (12 + 2(16)) = 44 gram.',
    hint: 'Hukum Kekekalan Massa Lavoisier: Massa zat sebelum reaksi = massa zat setelah reaksi.',
  },
  {
    id: 'cq-x-stoi-3',
    kelas: 'Kelas X',
    bab: 'Stoikiometri',
    difficulty: 'Sulit',
    question: 'Suatu senyawa hidrokarbon mengandung 80% massa Karbon dan 20% massa Hidrogen (Ar C = 12, H = 1). Jika Mr senyawa = 30, tentukan rumus molekulnya!',
    options: ['CH₄', 'C₂H₄', 'C₂H₆', 'C₃H₈', 'C₄H₁₀'],
    correctIndex: 2,
    explanation: 'Perbandingan mol C : H = (80/12) : (20/1) = 6,67 : 20 = 1 : 3. Rumus empiris (CH₃)n dengan Mr = (12+3)n = 15n = 30 → n = 2. Rumus molekul = C₂H₆ (Etana).',
    hint: 'Cari rumus empiris terlebih dahulu melalui perbandingan mol (massa / Ar).',
  },
  {
    id: 'cq-x-stoi-4',
    kelas: 'Kelas X',
    bab: 'Stoikiometri',
    difficulty: 'Mudah',
    question: 'Jumlah partikel molekul air yang terdapat dalam 2 mol H₂O (L = 6,02 × 10²³ partikel/mol) adalah...',
    options: ['3,01 × 10²³', '6,02 × 10²³', '1,204 × 10²⁴', '2,408 × 10²⁴', '6,02 × 10²⁴'],
    correctIndex: 2,
    explanation: 'Jumlah Partikel = n × L = 2 mol × 6,02 × 10²³ = 1,204 × 10²⁴ molekul.',
    hint: 'Gunakan tetapan Avogadro L = 6,02 × 10²³ partikel/mol.',
  },

  // KELAS X - STRUKTUR ATOM & PERIODIK
  {
    id: 'cq-x-atom-1',
    kelas: 'Kelas X',
    bab: 'Struktur Atom',
    difficulty: 'Mudah',
    question: 'Jumlah proton, neutron, dan elektron pada ion ₂₆Fe³⁺ dengan nomor massa 56 adalah...',
    options: ['26, 30, 23', '26, 30, 26', '26, 30, 29', '23, 30, 26', '30, 26, 23'],
    correctIndex: 0,
    explanation: 'Nomor atom Z = 26 (Proton = 26). Neutron = A - Z = 56 - 26 = 30. Ion positif melepas 3 elektron, maka elektron = 26 - 3 = 23.',
    hint: 'Proton = Z, Neutron = A - Z, Elektron kation = Z - muatan.',
  },
  {
    id: 'cq-x-atom-2',
    kelas: 'Kelas X',
    bab: 'Sistem Periodik',
    difficulty: 'Sedang',
    question: 'Unsur X memiliki nomor atom 17. Terletak pada golongan dan periode berapakah unsur X dalam Sistem Periodik Unsur?',
    options: ['Golongan VA, Periode 3', 'Golongan VIA, Periode 3', 'Golongan VIIA, Periode 3', 'Golongan VIIA, Periode 4', 'Golongan VIIIA, Periode 3'],
    correctIndex: 2,
    explanation: 'Konfigurasi elektron 17X: 1s² 2s² 2p⁶ 3s² 3p⁵. Elektron valensi = 2 + 5 = 7 (Golongan VIIA). Kulit terbesar = 3 (Periode 3).',
    hint: 'Lihat jumlah elektron pada subkulit s dan p tingkat kulit tertinggi.',
  },

  // KELAS X - IKATAN KIMIA & LAINNYA
  {
    id: 'cq-x-ikatan-1',
    kelas: 'Kelas X',
    bab: 'Ikatan Kimia',
    difficulty: 'Sedang',
    question: 'Tipe hibridisasi dan geometri molekul dari Metana (CH₄) adalah...',
    options: ['sp, Linier', 'sp², Segitiga Sama Sisi', 'sp³, Tetrahedral', 'sp³d, Bipiramida Trigonal', 'sp³d², Oktahedral'],
    correctIndex: 2,
    explanation: 'Atom pusat C mengikat 4 atom H tanpa PEB (AX₄). Memiliki 4 domain elektron setara dengan hibridisasi sp³ dan geometri Tetrahedral (sudut 109,5°).',
    hint: 'Metana tidak memiliki pasangan elektron bebas (PEB) pada atom C.',
  },

  // KELAS XI - TERMOKIMIA & LAJU REAKSI
  {
    id: 'cq-xi-termo-1',
    kelas: 'Kelas XI',
    bab: 'Termokimia',
    difficulty: 'Mudah',
    question: 'Suatu reaksi kimia memiliki nilai ΔH = -250 kJ. Ciri utama dari reaksi tersebut adalah...',
    options: ['Endoterm, menyerap kalor dari lingkungan', 'Eksoterm, melepaskan kalor ke lingkungan', 'Eksoterm, entalpi produk lebih besar dari reaktan', 'Endoterm, wadah reaksi terasa dingin', 'Tidak terjadi perubahan energi sama sekali'],
    correctIndex: 1,
    explanation: 'Nilai ΔH negatif menunjukkan reaksi eksoterm di mana kalor mengalir dari sistem ke lingkungan, sehingga suhu wadah terasa hangat/panas.',
    hint: 'Tanda minus (-) berarti sistem melepaskan energi panas.',
  },
  {
    id: 'cq-xi-laju-1',
    kelas: 'Kelas XI',
    bab: 'Laju Reaksi',
    difficulty: 'Sedang',
    question: 'Setiap kenaikan suhu 10°C, laju reaksi menjadi 2 kali lebih cepat. Jika pada suhu 20°C reaksi berlangsung dalam 80 detik, berapa lama reaksi berlangsung pada suhu 50°C?',
    options: ['40 detik', '20 detik', '10 detik', '5 detik', '2,5 detik'],
    correctIndex: 2,
    explanation: 'ΔT = 50 - 20 = 30°C. Banyaknya kenaikan n = 30/10 = 3 kali. Waktu t₂ = 80 × (1/2)³ = 80 / 8 = 10 detik.',
    hint: 'Gunakan rumus waktu reaksi t₂ = t₁ × (1/n)^(ΔT / 10).',
  },

  // KELAS XI - ASAM BASA & BUFFER
  {
    id: 'cq-xi-asbas-1',
    kelas: 'Kelas XI',
    bab: 'Asam Basa',
    difficulty: 'Mudah',
    question: 'Berapakah nilai pH dari larutan Ba(OH)₂ 0,005 M?',
    options: ['2', '3', '11', '12', '13'],
    correctIndex: 3,
    explanation: 'Ba(OH)₂ basa kuat bivalen (b = 2). [OH⁻] = 2 × 0,005 = 0,01 M = 10⁻² M. pOH = -log(10⁻²) = 2. pH = 14 - 2 = 12.',
    hint: 'Ba(OH)₂ melepaskan 2 ion OH⁻ per molekul.',
  },

  // KELAS XII - ELEKTROKIMIA & KOLIGATIF
  {
    id: 'cq-xii-volta-1',
    kelas: 'Kelas XII',
    bab: 'Reaksi Redoks & Elektrokimia',
    difficulty: 'Sedang',
    question: 'Diketahui E° Zn²⁺/Zn = -0,76 V dan E° Cu²⁺/Cu = +0,34 V. Berapakah potensial sel standar (E° sel) untuk sel Volta Zn|Zn²⁺||Cu²⁺|Cu?',
    options: ['-1,10 V', '-0,42 V', '+0,42 V', '+1,10 V', '+1,52 V'],
    correctIndex: 3,
    explanation: 'E° sel = E° Katoda - E° Anoda = +0,34 V - (-0,76 V) = +1,10 V.',
    hint: 'Katoda = reduksi (E° lebih besar), Anoda = oksidasi (E° lebih kecil).',
  },
  {
    id: 'cq-xii-koligatif-1',
    kelas: 'Kelas XII',
    bab: 'Sifat Koligatif Larutan',
    difficulty: 'Sedang',
    question: 'Larutan 18 gram glukosa (Mr = 180) dilarutkan dalam 500 gram air (Kf = 1,86 °C/m). Berapakah titik beku larutan tersebut?',
    options: ['-0,186°C', '-0,372°C', '-0,558°C', '-0,744°C', '-1,860°C'],
    correctIndex: 1,
    explanation: 'mol = 18/180 = 0,1. Molalitas m = 0,1 / 0,5 kg = 0,2 m. Glukosa nonelektrolit (i = 1). ΔTf = 0,2 × 1,86 = 0,372°C. Titik beku = 0 - 0,372 = -0,372°C.',
    hint: 'Glukosa adalah senyawa nonelektrolit, faktor i = 1.',
  },
];

export default function ChemQuestGameView({ student, onAddXP, onBack }: ChemQuestGameViewProps) {
  // Game Flow Stage: 'setup' | 'playing' | 'gameover' | 'victory'
  const [stage, setStage] = useState<'setup' | 'playing' | 'gameover' | 'victory'>('setup');

  // Setup Options
  const [selectedKelas, setSelectedKelas] = useState<'Kelas X' | 'Kelas XI' | 'Kelas XII'>('Kelas X');
  const [selectedBab, setSelectedBab] = useState<string>('Stoikiometri');
  const [soalCount, setSoalCount] = useState<number>(10);
  const [difficulty, setDifficulty] = useState<'Mudah' | 'Sedang' | 'Sulit' | 'Campur'>('Campur');

  // Active Game State
  const [activeQuestions, setActiveQuestions] = useState<QuestQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [lives, setLives] = useState<number>(3);
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [timerSeconds, setTimerSeconds] = useState<number>(30);

  // Lifelines
  const [lifeline5050Used, setLifeline5050Used] = useState<boolean>(false);
  const [lifelineHintUsed, setLifelineHintUsed] = useState<boolean>(false);
  const [hiddenOptions, setHiddenOptions] = useState<number[]>([]);
  const [showHintModal, setShowHintModal] = useState<boolean>(false);

  // Answer handling state
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  // Available Bab list per Kelas
  const BAB_LIST: Record<string, string[]> = {
    'Kelas X': [
      'Stoikiometri',
      'Hakikat Ilmu Kimia',
      'Struktur Atom',
      'Sistem Periodik',
      'Ikatan Kimia',
      'Larutan Elektrolit',
      'Reaksi Redoks',
      'Tata Nama Senyawa',
      '🎲 Acak semua bab',
    ],
    'Kelas XI': [
      'Termokimia',
      'Laju Reaksi',
      'Kesetimbangan Kimia',
      'Asam Basa',
      'Larutan Penyangga',
      'Hidrolisis Garam',
      'Ksp',
      'Sistem Koloid',
      '🎲 Acak semua bab',
    ],
    'Kelas XII': [
      'Sifat Koligatif Larutan',
      'Reaksi Redoks & Elektrokimia',
      'Kimia Unsur',
      'Senyawa Karbon & Turunan Alkana',
      'Benzena & Turunannya',
      'Makromolekul Polimer & Biomolekul',
      '🎲 Acak semua bab',
    ],
  };

  // Timer Countdown Effect
  useEffect(() => {
    if (stage !== 'playing' || isAnswered || timerSeconds <= 0) return;
    const interval = setInterval(() => {
      setTimerSeconds((prev) => {
        if (prev <= 1) {
          handleTimeout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [stage, isAnswered, timerSeconds]);

  // Handle Question Timeout (Heart lost)
  const handleTimeout = () => {
    setIsAnswered(true);
    setIsCorrect(false);
    setSelectedOption(-1);
    setStreak(0);
    const nextLives = lives - 1;
    setLives(nextLives);

    if (nextLives <= 0) {
      setTimeout(() => setStage('gameover'), 1500);
    }
  };

  // Start ChemQuest Game
  const handleStartGame = () => {
    // Filter questions by Kelas & Bab & Difficulty
    let filtered = CHEMQUEST_QUESTION_BANK.filter((q) => q.kelas === selectedKelas);

    if (selectedBab !== '🎲 Acak semua bab') {
      filtered = filtered.filter((q) => q.bab.toLowerCase().includes(selectedBab.toLowerCase()));
    }

    if (difficulty !== 'Campur') {
      filtered = filtered.filter((q) => q.difficulty === difficulty);
    }

    // Fallback if question pool is small
    if (filtered.length === 0) {
      filtered = CHEMQUEST_QUESTION_BANK.filter((q) => q.kelas === selectedKelas);
    }

    // Shuffle and pick soalCount
    const shuffled = [...filtered].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, Math.min(soalCount, shuffled.length));

    setActiveQuestions(selected);
    setCurrentIndex(0);
    setLives(3);
    setScore(0);
    setStreak(0);
    setTimerSeconds(30);
    setLifeline5050Used(false);
    setLifelineHintUsed(false);
    setHiddenOptions([]);
    setShowHintModal(false);
    setSelectedOption(null);
    setIsAnswered(false);
    setIsCorrect(null);
    setStage('playing');
  };

  // Handle Option Click
  const handleSelectOption = (idx: number) => {
    if (isAnswered) return;

    const currentQ = activeQuestions[currentIndex];
    const correct = idx === currentQ.correctIndex;

    setSelectedOption(idx);
    setIsAnswered(true);
    setIsCorrect(correct);

    if (correct) {
      const timeBonus = Math.max(10, timerSeconds * 3);
      const streakBonus = streak * 25;
      const points = 100 + timeBonus + streakBonus;

      setScore((prev) => prev + points);
      setStreak((prev) => prev + 1);

      try {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      } catch {
        // Fallback
      }
    } else {
      setStreak(0);
      const nextLives = lives - 1;
      setLives(nextLives);

      if (nextLives <= 0) {
        setTimeout(() => setStage('gameover'), 1800);
      }
    }
  };

  // Handle Lifeline 50:50
  const handleUseLifeline5050 = () => {
    if (lifeline5050Used || isAnswered) return;
    const currentQ = activeQuestions[currentIndex];
    const wrongIndices = currentQ.options
      .map((_, i) => i)
      .filter((i) => i !== currentQ.correctIndex);

    // Pick 2 wrong indices to hide
    const shuffledWrong = [...wrongIndices].sort(() => 0.5 - Math.random());
    const toHide = shuffledWrong.slice(0, 2);

    setHiddenOptions(toHide);
    setLifeline5050Used(true);
  };

  // Handle Lifeline Hint
  const handleUseLifelineHint = () => {
    if (lifelineHintUsed || isAnswered) return;
    setShowHintModal(true);
    setLifelineHintUsed(true);
  };

  // Advance to Next Question or Finish
  const handleNextQuestion = () => {
    if (currentIndex >= activeQuestions.length - 1) {
      // Victory!
      const finalXP = Math.round(score / 2);
      if (onAddXP) onAddXP(finalXP);
      try {
        confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 } });
      } catch {
        // Fallback
      }
      setStage('victory');
    } else {
      setCurrentIndex((prev) => prev + 1);
      setTimerSeconds(30);
      setHiddenOptions([]);
      setShowHintModal(false);
      setSelectedOption(null);
      setIsAnswered(false);
      setIsCorrect(null);
    }
  };

  const currentQ = activeQuestions[currentIndex];

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto text-left">
      {/* ======================================================== */}
      {/* 1. SETUP SCREEN (Pilih Kelas, Bab, Soal, Kesulitan)    */}
      {/* ======================================================== */}
      {stage === 'setup' && (
        <div className="space-y-6">
          {/* Header Banner */}
          <div className="rounded-3xl bg-gradient-to-r from-cyan-950 via-slate-900 to-indigo-950 border-[3px] border-cyan-500/40 p-6 sm:p-8 space-y-3 relative overflow-hidden shadow-2xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-500/15 border border-cyan-400/40 text-cyan-300 font-mono text-xs font-black shadow-sm">
              <Sparkles className="w-4 h-4 text-cyan-400 animate-spin" style={{ animationDuration: '8s' }} />
              <span>Mode Game RPG • 🧪 CHEMQUEST</span>
            </div>
            <h1
              className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Uji Otak Kimia SMA! 🧪✨
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-xl">
              Atur kelas, bab, jumlah soal, dan tingkat kesulitanmu. Bertahan dengan 3 Nyawa, gunakan Bantuan 50:50 & Hint, dan dapatkan XP Melimpah!
            </p>
          </div>

          {/* Setup Control Form */}
          <div className="rounded-3xl bg-slate-900 border-2 border-slate-800 p-6 sm:p-8 space-y-6 shadow-xl">
            {/* Step 1: Pilih Kelas */}
            <div className="space-y-2.5">
              <label className="block text-xs font-mono font-black text-cyan-400 uppercase tracking-wider">
                [1] Pilih Tingkat Kelasmu:
              </label>
              <div className="grid grid-cols-3 gap-3">
                {(['Kelas X', 'Kelas XI', 'Kelas XII'] as const).map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => {
                      setSelectedKelas(k);
                      setSelectedBab(BAB_LIST[k][0]);
                    }}
                    className={`py-3 px-4 rounded-2xl border-2 font-mono font-black text-xs sm:text-sm transition cursor-pointer active:translate-y-0.5 ${
                      selectedKelas === k
                        ? 'bg-cyan-500 text-slate-950 border-cyan-300 shadow-[0_4px_0_0_#0e7490]'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {k}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 2: Pilih Bab */}
            <div className="space-y-2.5">
              <label className="block text-xs font-mono font-black text-cyan-400 uppercase tracking-wider">
                [2] Pilih Bab / Topik Materi ({selectedKelas}):
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {BAB_LIST[selectedKelas].map((b) => (
                  <button
                    key={b}
                    type="button"
                    onClick={() => setSelectedBab(b)}
                    className={`p-3 rounded-xl border text-left text-xs font-semibold transition cursor-pointer ${
                      selectedBab === b
                        ? 'bg-indigo-600/30 border-indigo-400 text-white font-bold shadow-md'
                        : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 3: Jumlah Soal */}
            <div className="space-y-2.5">
              <label className="block text-xs font-mono font-black text-amber-400 uppercase tracking-wider">
                [3] Jumlah Soal Pertandingan:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { count: 5, label: '[5] Cepat' },
                  { count: 10, label: '[10] Standar' },
                  { count: 15, label: '[15] Tantangan' },
                  { count: 20, label: '[20] Mode Dewa' },
                ].map((s) => (
                  <button
                    key={s.count}
                    type="button"
                    onClick={() => setSoalCount(s.count)}
                    className={`py-2.5 px-3 rounded-xl border font-mono font-black text-xs transition cursor-pointer ${
                      soalCount === s.count
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-md'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 4: Tingkat Kesulitan */}
            <div className="space-y-2.5">
              <label className="block text-xs font-mono font-black text-emerald-400 uppercase tracking-wider">
                [4] Tingkat Kesulitan Soal:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { level: 'Mudah', label: '🟢 Mudah' },
                  { level: 'Sedang', label: '🟡 Sedang' },
                  { level: 'Sulit', label: '🔴 Sulit' },
                  { level: 'Campur', label: '🎨 Campur' },
                ].map((d) => (
                  <button
                    key={d.level}
                    type="button"
                    onClick={() => setDifficulty(d.level as any)}
                    className={`py-2.5 px-3 rounded-xl border font-mono font-bold text-xs transition cursor-pointer ${
                      difficulty === d.level
                        ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 shadow-md'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Summary Box & START CTA */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
                <span className="text-slate-400">Aturan Pertandingan:</span>
                <span className="text-cyan-300 font-bold flex items-center gap-1">
                  <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" /> 3 Nyawa • 💡 1x 50:50 • 🔮 1x Hint
                </span>
              </div>

              <button
                type="button"
                onClick={handleStartGame}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400 text-slate-950 font-black text-sm border-2 border-cyan-200 border-b-4 border-b-cyan-700 shadow-lg shadow-cyan-500/25 hover:translate-y-0.5 active:translate-y-1 transition cursor-pointer flex items-center justify-center gap-2"
              >
                <Zap className="w-5 h-5 text-slate-950 fill-current" />
                <span>MULAI PERTANDINGAN (START) 🚀</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 2. PLAYING SCREEN (Pertandingan Berlangsung)            */}
      {/* ======================================================== */}
      {stage === 'playing' && currentQ && (
        <div className="space-y-5 animate-fade-in">
          {/* Top Status Bar: Lives, Timer, Score, Lifelines */}
          <div className="p-4 sm:p-5 rounded-3xl bg-slate-900 border-2 border-slate-800 flex flex-wrap items-center justify-between gap-4 shadow-xl">
            {/* Lives / Nyawa */}
            <div className="flex items-center gap-1.5 bg-slate-950 px-3.5 py-1.5 rounded-2xl border border-slate-800">
              <span className="text-xs font-mono font-bold text-slate-400 mr-1">Nyawa:</span>
              {[1, 2, 3].map((num) => (
                <Heart
                  key={num}
                  className={`w-5 h-5 transition-all ${
                    num <= lives
                      ? 'fill-rose-500 text-rose-500 scale-110 drop-shadow-[0_0_8px_rgba(244,63,94,0.6)]'
                      : 'fill-slate-800 text-slate-800 scale-90'
                  }`}
                />
              ))}
            </div>

            {/* Timer & Question Progress */}
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono font-bold px-3 py-1 rounded-xl bg-slate-950 border border-slate-800 text-slate-300">
                Soal {currentIndex + 1} / {activeQuestions.length}
              </span>
              <div
                className={`flex items-center gap-1.5 px-3 py-1 rounded-xl font-mono text-xs font-black border ${
                  timerSeconds <= 8
                    ? 'bg-rose-500/20 border-rose-500 text-rose-300 animate-pulse'
                    : 'bg-slate-950 border-amber-500/40 text-amber-300'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>{timerSeconds}s</span>
              </div>
            </div>

            {/* Score & Streak */}
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono font-bold px-3 py-1 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 text-amber-400" />
                {score} PTS
              </span>
              {streak > 1 && (
                <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-xl bg-orange-500/20 border border-orange-500/40 text-orange-300 flex items-center gap-1 animate-bounce">
                  <Flame className="w-3.5 h-3.5 text-orange-400 fill-orange-400" />
                  {streak}x
                </span>
              )}
            </div>
          </div>

          {/* Lifelines Control Strip */}
          <div className="flex items-center justify-between gap-2 p-3 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs font-mono">
            <span className="text-slate-400 font-bold">Bantuan Lifeline:</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={lifeline5050Used || isAnswered}
                onClick={handleUseLifeline5050}
                className={`px-3 py-1.5 rounded-xl border font-bold flex items-center gap-1.5 transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                  lifeline5050Used
                    ? 'bg-slate-900 border-slate-800 text-slate-600'
                    : 'bg-cyan-950/60 hover:bg-cyan-900/80 border-cyan-500/40 text-cyan-300'
                }`}
                title="Hapus 2 pilihan jawaban salah"
              >
                <Split className="w-3.5 h-3.5 text-cyan-400" />
                <span>50:50 {lifeline5050Used ? '(Terpakai)' : ''}</span>
              </button>

              <button
                type="button"
                disabled={lifelineHintUsed || isAnswered}
                onClick={handleUseLifelineHint}
                className={`px-3 py-1.5 rounded-xl border font-bold flex items-center gap-1.5 transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                  lifelineHintUsed
                    ? 'bg-slate-900 border-slate-800 text-slate-600'
                    : 'bg-amber-950/60 hover:bg-amber-900/80 border-amber-500/40 text-amber-300'
                }`}
                title="Buka petunjuk kata kunci kimia"
              >
                <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                <span>Hint {lifelineHintUsed ? '(Terpakai)' : ''}</span>
              </button>
            </div>
          </div>

          {/* Main Question Card */}
          <div className="rounded-3xl bg-slate-900 border-2 border-slate-800 p-6 sm:p-8 space-y-6 shadow-xl relative overflow-hidden">
            <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <span className="text-xs font-mono font-bold px-3 py-1 rounded-lg bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 uppercase">
                {currentQ.kelas} • {currentQ.bab}
              </span>
              <span
                className={`text-[11px] font-mono font-bold px-2.5 py-0.5 rounded ${
                  currentQ.difficulty === 'Mudah'
                    ? 'bg-emerald-500/20 text-emerald-300'
                    : currentQ.difficulty === 'Sedang'
                    ? 'bg-amber-500/20 text-amber-300'
                    : 'bg-rose-500/20 text-rose-300'
                }`}
              >
                Level: {currentQ.difficulty}
              </span>
            </div>

            {/* Question Text */}
            <h3 className="text-base sm:text-xl font-bold text-slate-100 leading-relaxed">
              {currentQ.question}
            </h3>

            {/* Hint Modal / Box if activated */}
            {showHintModal && (
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-1 animate-fade-in">
                <span className="font-bold flex items-center gap-1 text-amber-400">
                  <Lightbulb className="w-4 h-4" /> Petunjuk Hint:
                </span>
                <p className="leading-relaxed">{currentQ.hint}</p>
              </div>
            )}

            {/* Options Grid */}
            <div className="space-y-3 pt-2">
              {currentQ.options.map((opt, optIdx) => {
                const isHidden = hiddenOptions.includes(optIdx);
                if (isHidden) {
                  return (
                    <div
                      key={optIdx}
                      className="p-3.5 rounded-2xl bg-slate-950/30 border border-slate-800/40 text-slate-700 text-xs font-mono italic flex items-center gap-3"
                    >
                      <span className="w-6 h-6 rounded-lg bg-slate-900/40 text-slate-700 flex items-center justify-center">
                        {String.fromCharCode(65 + optIdx)}
                      </span>
                      <span>(Dieliminasi 50:50)</span>
                    </div>
                  );
                }

                const isChosen = selectedOption === optIdx;
                const isCorrectIndex = optIdx === currentQ.correctIndex;

                let btnStyle =
                  'bg-slate-950 hover:bg-slate-800/80 border-slate-800 hover:border-cyan-500/40 text-slate-200';

                if (isAnswered) {
                  if (isCorrectIndex) {
                    btnStyle = 'bg-emerald-500/20 border-emerald-500 text-emerald-200 font-bold';
                  } else if (isChosen && !isCorrectIndex) {
                    btnStyle = 'bg-rose-500/20 border-rose-500 text-rose-200 font-bold';
                  } else {
                    btnStyle = 'bg-slate-950/40 border-slate-800/40 text-slate-500 opacity-50';
                  }
                }

                return (
                  <button
                    key={optIdx}
                    type="button"
                    disabled={isAnswered}
                    onClick={() => handleSelectOption(optIdx)}
                    className={`w-full p-4 rounded-2xl border text-left transition cursor-pointer flex items-center justify-between gap-3 text-xs sm:text-sm ${btnStyle}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-7 h-7 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center font-mono text-xs font-bold text-slate-300 shrink-0">
                        {String.fromCharCode(65 + optIdx)}
                      </span>
                      <span>{opt}</span>
                    </div>

                    {isAnswered && isCorrectIndex && (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    )}
                    {isAnswered && isChosen && !isCorrectIndex && (
                      <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Explanation Section */}
            {isAnswered && (
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 animate-fade-in text-xs">
                <span className="font-bold text-cyan-400 block uppercase font-mono text-[11px]">
                  Pembahasan ChemQuest:
                </span>
                <p className="text-slate-300 leading-relaxed">{currentQ.explanation}</p>
              </div>
            )}

            {/* Action Bottom Control */}
            {isAnswered && (
              <div className="pt-3 border-t border-slate-800 flex justify-end">
                <button
                  type="button"
                  onClick={handleNextQuestion}
                  className="px-6 py-3 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs shadow-lg shadow-cyan-500/25 transition cursor-pointer flex items-center gap-2"
                >
                  <span>{currentIndex >= activeQuestions.length - 1 ? 'Selesaikan Game ➔' : 'Soal Berikutnya ➔'}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 3. VICTORY / VICTORY SUMMARY                             */}
      {/* ======================================================== */}
      {stage === 'victory' && (
        <div className="p-8 rounded-3xl bg-slate-900 border-[3px] border-amber-500/50 text-center space-y-6 shadow-2xl animate-fade-in">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto">
            <Trophy className="w-9 h-9" />
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl sm:text-3xl font-black text-white">Misi ChemQuest Selesai! 🎉</h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto">
              Luar biasa! Kamu berhasil menuntaskan tantangan <span className="text-cyan-300 font-bold">{selectedBab} ({selectedKelas})</span> dengan sisa {lives} Nyawa!
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 max-w-md mx-auto text-xs font-mono">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-slate-500 block">Total Skor</span>
              <span className="text-2xl font-black text-amber-400">{score} PTS</span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-slate-500 block">Bonus XP Diperoleh</span>
              <span className="text-2xl font-black text-cyan-400">+{Math.round(score / 2)} XP</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => setStage('setup')}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-400 to-teal-300 text-slate-950 font-black text-xs shadow-lg shadow-cyan-500/20 cursor-pointer flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Main Sesi Lain</span>
            </button>
            <button
              type="button"
              onClick={onBack}
              className="px-6 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs cursor-pointer"
            >
              Kembali ke Dashboard
            </button>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 4. GAME OVER SUMMARY                                     */}
      {/* ======================================================== */}
      {stage === 'gameover' && (
        <div className="p-8 rounded-3xl bg-slate-900 border-[3px] border-rose-500/50 text-center space-y-6 shadow-2xl animate-fade-in">
          <div className="w-16 h-16 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
            <Heart className="w-9 h-9 fill-current" />
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl sm:text-3xl font-black text-white">Nyawa Habis! (Game Over) 💔</h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto">
              Jangan berkecil hati! Pelajari kembali materi <span className="text-cyan-300 font-bold">{selectedBab}</span> dan coba lagi untuk mengumpulkan poin maksimal.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 max-w-xs mx-auto font-mono text-xs">
            <span className="text-slate-500 block">Skor Terkumpul:</span>
            <span className="text-xl font-black text-amber-400">{score} PTS</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={handleStartGame}
              className="px-6 py-3 rounded-2xl bg-rose-500 hover:bg-rose-400 text-slate-950 font-black text-xs shadow-lg shadow-rose-500/20 cursor-pointer flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Coba Lagi (3 Nyawa Baru)</span>
            </button>
            <button
              type="button"
              onClick={() => setStage('setup')}
              className="px-6 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs cursor-pointer"
            >
              Ubah Pengaturan Bab
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
