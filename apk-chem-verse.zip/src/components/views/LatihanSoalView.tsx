import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, XCircle, Lightbulb, RotateCcw, Award, ChevronRight } from 'lucide-react';
import confetti from 'canvas-confetti';
import { LATIHAN_QUESTIONS } from '../../data/chemistryData';
import { auth } from '../../lib/firebase';
import { saveQuizResult, saveQuizAttempt } from '../../services/firestoreService';
import { useActivityTracker } from '../../hooks/useActivityTracker';
import ActivityTrackerBadge from '../common/ActivityTrackerBadge';

interface LatihanSoalViewProps {
  onBack: () => void;
  onAddXP?: (amount: number) => void;
}

export default function LatihanSoalView({ onBack, onAddXP }: LatihanSoalViewProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showExplanation, setShowExplanation] = useState<Record<number, boolean>>({});
  const [showHint, setShowHint] = useState<Record<number, boolean>>({});
  const [isFinished, setIsFinished] = useState(false);
  const startTimeRef = React.useRef<string>(new Date().toISOString());

  // Real-time Activity Tracker for Quiz session
  const quizTracker = useActivityTracker({
    studentId: auth.currentUser?.uid,
    type: 'quiz',
    refId: 'latihan_soal_mandiri',
    refTitle: 'Latihan Soal Mandiri Kimia SMA',
  });

  const currentQ = LATIHAN_QUESTIONS[currentIndex];
  const totalQuestions = LATIHAN_QUESTIONS.length;
  const currentSelected = selectedAnswers[currentIndex];
  const isAnswered = currentSelected !== undefined;

  const handleSelectOption = (optIndex: number) => {
    if (isAnswered) return;
    const isCorrect = optIndex === currentQ.correctIndex;

    setSelectedAnswers((prev) => ({ ...prev, [currentIndex]: optIndex }));
    setShowExplanation((prev) => ({ ...prev, [currentIndex]: true }));

    // Record quiz result into Firestore collection `quiz_results`
    try {
      saveQuizResult({
        userId: auth.currentUser?.uid || 'anon_siswa',
        namaSiswa: auth.currentUser?.displayName || 'Siswa',
        topik: currentQ.topic || 'Kimia SMA',
        soalId: currentQ.id || `latihan_${currentIndex + 1}`,
        teksSoal: currentQ.question,
        jawabanSiswa: currentQ.options[optIndex],
        jawabanBenar: currentQ.options[currentQ.correctIndex],
        isBenar: isCorrect,
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.warn('Failed saving quiz result:', err);
    }

    if (isCorrect) {
      if (onAddXP) onAddXP(30);
      try {
        confetti({
          particleCount: 40,
          spread: 60,
          origin: { y: 0.7 },
        });
      } catch {
        // Safe fallback
      }
    }
  };

  const calculateScore = () => {
    let correct = 0;
    LATIHAN_QUESTIONS.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        correct++;
      }
    });
    return {
      correct,
      total: totalQuestions,
      percentage: Math.round((correct / totalQuestions) * 100),
      totalXP: correct * 30,
    };
  };

  const handleNext = () => {
    if (currentIndex < totalQuestions - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setIsFinished(true);
      const finalScore = calculateScore();
      try {
        saveQuizAttempt({
          student_id: auth.currentUser?.uid || 'anon_siswa',
          quiz_id: 'latihan_soal_mandiri',
          quiz_title: 'Latihan Soal Mandiri Kimia SMA',
          score: finalScore.percentage,
          max_score: 100,
          correct: finalScore.correct,
          wrong: totalQuestions - finalScore.correct,
          started_at: startTimeRef.current,
          submitted_at: new Date().toISOString(),
          duration_sec: quizTracker.activeSeconds || 60,
        });
      } catch (err) {
        console.warn('saveQuizAttempt error:', err);
      }
      try {
        confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
      } catch {
        // Safe fallback
      }
    }
  };

  const handleReset = () => {
    setSelectedAnswers({});
    setShowExplanation({});
    setShowHint({});
    setCurrentIndex(0);
    setIsFinished(false);
  };

  const scoreData = calculateScore();

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
      {/* Top Bar */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-emerald-500/50 text-sm font-medium transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali ke Dashboard
        </button>

        <div className="flex items-center gap-3">
          <ActivityTrackerBadge tracker={quizTracker} label="Mencatat durasi kuis" />
          <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-3 py-1 rounded-full">
            Soal {currentIndex + 1} dari {totalQuestions}
          </span>
        </div>
      </div>

      {!isFinished ? (
        <div className="space-y-6">
          {/* Progress Bar */}
          <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400 transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / totalQuestions) * 100}%` }}
            />
          </div>

          {/* Question Card */}
          <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 uppercase">
                {currentQ.topic} • {currentQ.classLevel}
              </span>
              <span className="text-xs font-mono text-slate-400 px-2 py-0.5 rounded bg-slate-800">
                Tingkat: {currentQ.difficulty}
              </span>
            </div>

            <div className="text-base sm:text-lg font-semibold text-slate-100 whitespace-pre-line leading-relaxed">
              {currentQ.question}
            </div>

            {/* Hint Button */}
            {!isAnswered && (
              <div>
                <button
                  onClick={() => setShowHint((p) => ({ ...p, [currentIndex]: !p[currentIndex] }))}
                  className="text-xs font-medium text-amber-400 hover:text-amber-300 inline-flex items-center gap-1.5 cursor-pointer bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-lg"
                >
                  <Lightbulb className="w-3.5 h-3.5" />
                  {showHint[currentIndex] ? 'Sembunyikan Petunjuk' : 'Lihat Petunjuk'}
                </button>
                {showHint[currentIndex] && (
                  <p className="mt-2 text-xs text-amber-200/90 bg-amber-950/40 border border-amber-900/60 p-3 rounded-xl italic">
                    💡 Petunjuk: {currentQ.hint}
                  </p>
                )}
              </div>
            )}

            {/* Options List */}
            <div className="space-y-3">
              {currentQ.options.map((option, idx) => {
                const isChosen = currentSelected === idx;
                const isCorrect = idx === currentQ.correctIndex;
                let optStyle =
                  'bg-slate-950/60 border-slate-800 text-slate-200 hover:bg-slate-800/80 hover:border-slate-700';

                if (isAnswered) {
                  if (isCorrect) {
                    optStyle = 'bg-emerald-500/20 border-emerald-500 text-emerald-200 font-bold';
                  } else if (isChosen && !isCorrect) {
                    optStyle = 'bg-rose-500/20 border-rose-500 text-rose-200';
                  } else {
                    optStyle = 'bg-slate-950/40 border-slate-800/50 text-slate-500';
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={isAnswered}
                    onClick={() => handleSelectOption(idx)}
                    className={`w-full p-4 rounded-xl border text-left transition flex items-center justify-between gap-4 cursor-pointer disabled:cursor-default ${optStyle}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center font-mono text-xs font-bold shrink-0">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span className="text-sm">{option}</span>
                    </div>

                    {isAnswered && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
                    {isAnswered && isChosen && !isCorrect && <XCircle className="w-5 h-5 text-rose-400 shrink-0" />}
                  </button>
                );
              })}
            </div>

            {/* Pembahasan / Explanation */}
            {showExplanation[currentIndex] && (
              <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2 animate-fade-in">
                <div className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Pembahasan Lengkap:
                </div>
                <p className="text-xs sm:text-sm text-slate-300 whitespace-pre-line leading-relaxed">
                  {currentQ.explanation}
                </p>
              </div>
            )}

            {/* Next Button */}
            {isAnswered && (
              <div className="flex justify-end pt-2">
                <button
                  onClick={handleNext}
                  className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/20 transition"
                >
                  {currentIndex < totalQuestions - 1 ? 'Soal Berikutnya' : 'Lihat Hasil Latihan'}
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Results View */
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-8 text-center space-y-6">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
            <Award className="w-8 h-8" />
          </div>

          <div>
            <h3 className="text-2xl font-extrabold text-white">Latihan Selesai!</h3>
            <p className="text-slate-400 text-sm mt-1">Kerja bagus dalam memperdalam materi kimia SMA.</p>
          </div>

          <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">Skor Akhir</span>
              <span className="text-2xl font-black text-emerald-400 font-mono">{scoreData.percentage}%</span>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">Benar</span>
              <span className="text-2xl font-black text-white font-mono">
                {scoreData.correct} / {scoreData.total}
              </span>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-xs text-slate-400 block mb-1">XP Diperoleh</span>
              <span className="text-2xl font-black text-cyan-400 font-mono">+{scoreData.totalXP}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <button
              onClick={handleReset}
              className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer transition"
            >
              <RotateCcw className="w-4 h-4" />
              Ulangi Latihan
            </button>
            <button
              onClick={onBack}
              className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm cursor-pointer transition shadow-lg shadow-emerald-500/20"
            >
              Kembali ke Menu Utama
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
