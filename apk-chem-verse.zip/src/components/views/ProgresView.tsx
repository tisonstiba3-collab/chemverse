import React from 'react';
import { ArrowLeft, Award, Zap, CheckCircle2, TrendingUp, BookOpen, Star, Flame, Trophy } from 'lucide-react';
import { StudentProfile } from '../../types/chemistry';

interface ProgresViewProps {
  student: StudentProfile;
  onBack: () => void;
}

export default function ProgresView({ student, onBack }: ProgresViewProps) {
  const currentXP = student.xp ?? 320;
  const level = Math.floor(currentXP / 150) + 1;
  const xpInCurrentLevel = currentXP % 150;
  const xpPercent = Math.min(100, Math.round((xpInCurrentLevel / 150) * 100));

  const competencies = [
    { name: 'Struktur Atom & VSEPR 3D', percent: 90, grade: 'Sangat Baik' },
    { name: 'Tata Nama & Stoikiometri', percent: 75, grade: 'Baik' },
    { name: 'Termokimia & Entalpi', percent: 65, grade: 'Cukup' },
    { name: 'Asam, Basa & Larutan Buffer', percent: 60, grade: 'Cukup' },
    { name: 'Reaksi Redoks & Elektrokimia', percent: 45, grade: 'Perlu Latihan' },
  ];

  const badges = [
    { title: 'Penjelajah 3D', desc: 'Mengeksplorasi visualisasi molekul 3D', icon: Star, unlocked: true },
    { title: 'Penyeimbang Reaksi', desc: 'Menyetarakan reaksi hidrokarbon', icon: Flame, unlocked: true },
    { title: 'Pejuang TKA HOTS', desc: 'Menyelesaikan simulasi UTBK Kimia', icon: Trophy, unlocked: (student.solvedProblemsCount ?? 0) >= 3 },
    { title: 'Siswa Rajin Catat', desc: 'Menuliskan refleksi di jurnal belajar', icon: BookOpen, unlocked: true },
  ];

  return (
    <div className="space-y-6 animate-fade-in max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-cyan-500/50 text-sm font-medium transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali ke Dashboard
        </button>

        <span className="text-xs font-mono uppercase text-cyan-400 bg-cyan-950/60 border border-cyan-800/60 px-3 py-1 rounded-full">
          Laporan Perkembangan Akademik Siswa
        </span>
      </div>

      {/* Hero Student Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-cyan-500/20 p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 shadow-lg shadow-cyan-500/25">
            <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center text-2xl font-black text-cyan-300 font-mono">
              {student.namaLengkap.charAt(0)}
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl font-bold text-white">{student.namaLengkap}</h2>
              <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 font-mono text-xs font-bold">
                Level {level}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              {student.kelas} • <span className="text-slate-300 font-medium">{student.sekolah}</span>
            </p>
          </div>
        </div>

        {/* XP Progress Capsule */}
        <div className="w-full md:w-64 bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              Total XP
            </span>
            <span className="text-white font-bold">{currentXP} XP</span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-500"
              style={{ width: `${xpPercent}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] font-mono text-slate-500">
            <span>Level {level}</span>
            <span>{150 - xpInCurrentLevel} XP menuju Level {level + 1}</span>
          </div>
        </div>
      </div>

      {/* Grid: Competencies vs Badges */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Competencies Mastery */}
        <div className="lg:col-span-7 rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-cyan-400" />
            Penguasaan Kompetensi Kimia SMA
          </h3>

          <div className="space-y-4">
            {competencies.map((comp, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200">{comp.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-slate-400 text-[11px]">{comp.grade}</span>
                    <span className="font-mono font-bold text-cyan-400">{comp.percent}%</span>
                  </div>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 rounded-full"
                    style={{ width: `${comp.percent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Badges & Achievements */}
        <div className="lg:col-span-5 rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            Lencana Prestasi Siswa
          </h3>

          <div className="space-y-3">
            {badges.map((b, idx) => {
              const Icon = b.icon;
              return (
                <div
                  key={idx}
                  className={`p-3.5 rounded-xl border flex items-center gap-3.5 transition ${
                    b.unlocked
                      ? 'bg-slate-950 border-amber-500/30'
                      : 'bg-slate-950/40 border-slate-800/60 opacity-50'
                  }`}
                >
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      b.unlocked
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h5 className="font-bold text-xs text-white flex items-center gap-1.5">
                      {b.title}
                      {b.unlocked && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                    </h5>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">{b.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
