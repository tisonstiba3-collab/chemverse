import React, { useState, useMemo } from 'react';
import {
  ArrowLeft,
  Search,
  Filter,
  BookOpen,
  Calculator,
  Image as ImageIcon,
  Copy,
  Check,
  Sparkles,
  ChevronRight,
  HelpCircle,
  X,
  ExternalLink,
  Zap,
  Info,
  Flame,
  Scale,
} from 'lucide-react';
import { KUMPULAN_RUMUS_TKA, RumusItem } from '../../data/kumpulanRumusData';
import KaTeXFormula from '../chemistry/KaTeXFormula';
import ActivityTrackerBadge from '../common/ActivityTrackerBadge';
import { useActivityTracker } from '../../hooks/useActivityTracker';
import { auth } from '../../lib/firebase';

interface KumpulanRumusViewProps {
  onBack: () => void;
}

export default function KumpulanRumusView({ onBack }: KumpulanRumusViewProps) {
  const [selectedGrade, setSelectedGrade] = useState<'Semua' | 'X' | 'XI' | 'XII'>('Semua');
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeCalcItem, setActiveCalcItem] = useState<RumusItem | null>(null);
  const [isOriginalImageOpen, setIsOriginalImageOpen] = useState<boolean>(false);
  const [copiedFormulaId, setCopiedFormulaId] = useState<string | null>(null);

  // Real-time activity tracker for formula reading session
  const rumusTracker = useActivityTracker({
    studentId: auth.currentUser?.uid,
    type: 'reading',
    refId: 'kumpulan_rumus_tka_kimia',
    refTitle: 'Kumpulan Rumus Kimia SMA & TKA',
  });

  // Calculation State for Interactive Calculator Modal
  const [calcInputs, setCalcInputs] = useState<{
    val1: number | string;
    val2: number | string;
    val3: number | string;
  }>({ val1: '', val2: '', val3: '' });

  // Get list of unique categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    set.add('Semua');
    KUMPULAN_RUMUS_TKA.forEach((item) => {
      if (item.kategori) set.add(item.kategori);
    });
    return Array.from(set);
  }, []);

  // Filtered Formula List
  const filteredRumus = useMemo(() => {
    return KUMPULAN_RUMUS_TKA.filter((item) => {
      // Grade filter
      if (selectedGrade !== 'Semua' && item.kelas !== selectedGrade) {
        return false;
      }
      // Category filter
      if (selectedCategory !== 'Semua' && item.kategori !== selectedCategory) {
        return false;
      }
      // Search query
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        const inJudul = item.judul.toLowerCase().includes(q);
        const inBab = item.nomorBab.toLowerCase().includes(q);
        const inKonsep = item.ringkasanKonsep.toLowerCase().includes(q);
        const inRumus = item.rumusUtama.some(
          (r) => r.nama.toLowerCase().includes(q) || r.latex.toLowerCase().includes(q)
        );
        if (!inJudul && !inBab && !inKonsep && !inRumus) return false;
      }
      return true;
    });
  }, [selectedGrade, selectedCategory, searchQuery]);

  const handleCopyLatex = (id: string, latex: string) => {
    navigator.clipboard.writeText(latex);
    setCopiedFormulaId(id);
    setTimeout(() => setCopiedFormulaId(null), 2000);
  };

  // Helper calculation output
  const renderCalculatorResult = (type?: string) => {
    const v1 = parseFloat(String(calcInputs.val1));
    const v2 = parseFloat(String(calcInputs.val2));
    const v3 = parseFloat(String(calcInputs.val3));

    if (type === 'kadar') {
      if (!isNaN(v1) && !isNaN(v2) && v2 > 0) {
        const persenMassa = (v1 / (v1 + v2)) * 100;
        return (
          <div className="p-4 rounded-2xl bg-cyan-950/60 border border-cyan-500/40 text-cyan-200 space-y-1">
            <span className="text-[11px] font-mono text-cyan-400 font-bold block">Hasil Kadar % Massa:</span>
            <div className="text-2xl font-black text-white font-mono">{percentFormat(persenMassa)}%</div>
            <p className="text-xs text-slate-300">
              Massa Total Larutan = {v1 + v2} gram (Zat Terlarut {v1}g + Pelarut {v2}g)
            </p>
          </div>
        );
      }
      return <p className="text-xs text-slate-400 italic">Masukkan massa zat terlarut dan massa pelarut (gram).</p>;
    }

    if (type === 'mol') {
      if (!isNaN(v1) && !isNaN(v2) && v2 > 0) {
        const mol = v1 / v2;
        const volumeSTP = mol * 22.4;
        const partikel = mol * 6.02;
        return (
          <div className="p-4 rounded-2xl bg-cyan-950/60 border border-cyan-500/40 text-cyan-200 space-y-2">
            <span className="text-[11px] font-mono text-cyan-400 font-bold block">Hasil Konversi Mol:</span>
            <div className="text-2xl font-black text-white font-mono">{percentFormat(mol)} mol</div>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1 border-t border-cyan-500/30">
              <div>Volume STP (0°C, 1atm): <span className="text-cyan-300 font-bold">{percentFormat(volumeSTP)} L</span></div>
              <div>Jumlah Partikel: <span className="text-cyan-300 font-bold">{percentFormat(partikel)} × 10²³</span></div>
            </div>
          </div>
        );
      }
      return <p className="text-xs text-slate-400 italic">Masukkan massa (gram) dan Ar / Mr senyawa.</p>;
    }

    if (type === 'ph') {
      if (!isNaN(v1) && v1 > 0) {
        const pH = -Math.log10(v1);
        const pOH = 14 - pH;
        return (
          <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 space-y-2">
            <span className="text-[11px] font-mono text-emerald-400 font-bold block">Hasil Derajat Keasaman (pH):</span>
            <div className="text-3xl font-black text-white font-mono">pH = {percentFormat(pH)}</div>
            <div className="text-xs font-mono text-emerald-300">
              pOH = {percentFormat(pOH)} • Sifat Larutan: <span className="font-bold text-white">{pH < 7 ? 'Asam' : pH > 7 ? 'Basa' : 'Netral'}</span>
            </div>
          </div>
        );
      }
      return <p className="text-xs text-slate-400 italic">Masukkan konsentrasi ion [H+] atau [OH-] (Molar).</p>;
    }

    if (type === 'sel-volta') {
      if (!isNaN(v1) && !isNaN(v2)) {
        const Esel = v1 - v2;
        return (
          <div className="p-4 rounded-2xl bg-teal-950/60 border border-teal-500/40 text-teal-200 space-y-2">
            <span className="text-[11px] font-mono text-teal-400 font-bold block">Hasil Potensial Sel Standar (E°sel):</span>
            <div className="text-3xl font-black text-white font-mono">{Esel >= 0 ? `+${percentFormat(Esel)}` : percentFormat(Esel)} Volt</div>
            <div className="text-xs font-mono text-teal-300">
              Reaksi berlangsung <span className="font-black text-white">{Esel > 0 ? 'SPONTAN (+)' : 'TIDAK SPONTAN (-)'}</span>
            </div>
          </div>
        );
      }
      return <p className="text-xs text-slate-400 italic">Masukkan E° reduksi Katoda dan E° reduksi Anoda (Volt).</p>;
    }

    if (type === 'kalor') {
      if (!isNaN(v1) && !isNaN(v2) && !isNaN(v3)) {
        const qJoule = v1 * v2 * v3;
        const qKJ = qJoule / 1000;
        return (
          <div className="p-4 rounded-2xl bg-amber-950/60 border border-amber-500/40 text-amber-200 space-y-2">
            <span className="text-[11px] font-mono text-amber-400 font-bold block">Hasil Perhitungan Kalor (q):</span>
            <div className="text-2xl font-black text-white font-mono">{percentFormat(qJoule)} Joule ({percentFormat(qKJ)} kJ)</div>
            <p className="text-xs text-slate-300">q = m × c × ΔT ({v1}g × {v2} J/g°C × {v3}°C)</p>
          </div>
        );
      }
      return <p className="text-xs text-slate-400 italic">Masukkan massa larutan (g), kalor jenis c (J/g°C), dan ΔT (°C).</p>;
    }

    if (type === 'faraday') {
      if (!isNaN(v1) && !isNaN(v2) && !isNaN(v3) && v1 > 0) {
        // m = (e * I * t) / 96500 where e = Ar / n (assume e = v1, v2 = I, v3 = t_sekon)
        const massaGram = (v1 * v2 * v3) / 96500;
        return (
          <div className="p-4 rounded-2xl bg-purple-950/60 border border-purple-500/40 text-purple-200 space-y-2">
            <span className="text-[11px] font-mono text-purple-400 font-bold block">Hasil Massa Endapan (w):</span>
            <div className="text-2xl font-black text-white font-mono">{percentFormat(massaGram)} gram</div>
            <p className="text-xs text-slate-300">w = (e × I × t) / 96500</p>
          </div>
        );
      }
      return <p className="text-xs text-slate-400 italic">Masukkan massa ekuivalen e (Ar/valensi), Kuat Arus I (A), dan Waktu t (sekon).</p>;
    }

    return null;
  };

  const percentFormat = (val: number) => {
    if (Number.isInteger(val)) return val.toString();
    return val.toFixed(3);
  };

  return (
    <div className="space-y-6 sm:space-y-8 max-w-7xl mx-auto px-3 sm:px-6 py-4 animate-fade-in text-left">
      {/* 1. Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onBack}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-slate-300 hover:text-white text-xs sm:text-sm font-semibold transition cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Dashboard</span>
            </button>
            <ActivityTrackerBadge tracker={rumusTracker} label="Mencatat durasi baca" />
          </div>

          <div>
            <h1
              className="text-2xl sm:text-4xl font-black text-white tracking-tight flex items-center gap-3 mt-2"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              <BookOpen className="w-7 h-7 sm:w-9 sm:h-9 text-cyan-400 shrink-0" />
              <span>Kumpulan Rumus Kimia SMA</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Ensiklopedia lengkap rumus kimia, persamaan stoikiometri, reaksi redoks, dan kalkulator interaktif untuk siswa SMA Kelas 10, 11, dan 12.
            </p>
          </div>
        </div>

        {/* Action Toggle Buttons */}
        <div className="flex items-center gap-2.5 self-start md:self-end">
          <button
            onClick={() => setIsOriginalImageOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 hover:to-orange-500/30 border border-amber-500/40 text-amber-300 font-bold text-xs shadow-md shadow-amber-500/10 cursor-pointer transition active:scale-95"
            title="Lihat lembar rangkuman tulisan tangan asli TKA"
          >
            <ImageIcon className="w-4 h-4 text-amber-400" />
            <span>Mode Catatan Asli TKA</span>
          </button>
        </div>
      </div>

      {/* 2. Filter & Search Controls Bar */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-lg">
        {/* Row 1: Search & Grade Buttons */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
          {/* Live Search Bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari rumus, bab, atau kata kunci (contoh: 'mol', 'pH', 'Faraday', 'Hess')..."
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-950 border border-slate-700/80 text-white placeholder-slate-500 text-xs sm:text-sm font-medium focus:outline-none focus:border-cyan-400 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white text-xs"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Filter Grade Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0">
            <span className="text-xs font-mono text-slate-400 font-bold shrink-0 mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-cyan-400" /> Kelas:
            </span>
            {(['Semua', 'X', 'XI', 'XII'] as const).map((grade) => (
              <button
                key={grade}
                onClick={() => setSelectedGrade(grade)}
                className={`px-3.5 py-1.5 rounded-xl border text-xs font-mono font-black transition cursor-pointer shrink-0 ${
                  selectedGrade === grade
                    ? 'bg-cyan-500 text-slate-950 border-cyan-300 shadow-md shadow-cyan-500/20'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                {grade === 'Semua' ? 'Semua Kelas' : `Kelas ${grade}`}
              </button>
            ))}
          </div>
        </div>

        {/* Row 2: Category Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pt-2 border-t border-slate-800/80 pb-1">
          <span className="text-xs font-mono text-slate-400 shrink-0 font-bold">Kategori:</span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-xl text-xs font-mono transition cursor-pointer shrink-0 border ${
                selectedCategory === cat
                  ? 'bg-slate-800 border-cyan-400/80 text-cyan-300 font-bold'
                  : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* 3. Formula Cards Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between text-xs font-mono text-slate-400 px-1">
          <span>Menampilkan <strong className="text-cyan-300 font-black">{filteredRumus.length}</strong> topik rumus</span>
          <span>Klik tombol <strong className="text-amber-400">Kalkulator Mini</strong> untuk menghitung otomatis</span>
        </div>

        {filteredRumus.length === 0 ? (
          <div className="p-12 text-center rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
            <Info className="w-10 h-10 text-slate-500 mx-auto" />
            <h3 className="text-base font-bold text-slate-300">Rumus tidak ditemukan</h3>
            <p className="text-xs text-slate-500">Coba ubah kata kunci pencarian atau sesuaikan filter kelas.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedGrade('Semua');
                setSelectedCategory('Semua');
              }}
              className="px-4 py-2 rounded-xl bg-cyan-500/20 text-cyan-300 text-xs font-bold border border-cyan-500/30 cursor-pointer"
            >
              Reset Filter
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredRumus.map((item) => (
              <div
                key={item.id}
                className="rounded-3xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 p-5 sm:p-6 space-y-5 shadow-lg transition-all duration-300 flex flex-col justify-between group relative overflow-hidden"
              >
                {/* Accent Top Bar */}
                <div
                  className="absolute top-0 inset-x-0 h-1"
                  style={{ backgroundColor: item.accentColor || '#38BDF8' }}
                />

                <div className="space-y-4">
                  {/* Card Badges */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span
                        className="px-2.5 py-1 rounded-lg text-[10px] font-mono font-extrabold uppercase border"
                        style={{
                          backgroundColor: `${item.accentColor || '#38BDF8'}18`,
                          borderColor: `${item.accentColor || '#38BDF8'}40`,
                          color: item.accentColor || '#38BDF8',
                        }}
                      >
                        {item.nomorBab} • {item.kartuNumbers}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-mono font-bold text-slate-300">
                        Kelas {item.kelas} ({item.fase})
                      </span>
                    </div>

                    {item.interaktifCalcType && (
                      <button
                        onClick={() => {
                          setActiveCalcItem(item);
                          setCalcInputs({ val1: '', val2: '', val3: '' });
                        }}
                        className="px-2.5 py-1 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-[11px] font-mono font-bold flex items-center gap-1 cursor-pointer transition shadow-sm"
                        title="Buka kalkulator interaktif untuk rumus ini"
                      >
                        <Calculator className="w-3.5 h-3.5 text-amber-400" />
                        <span>Kalkulator Mini</span>
                      </button>
                    )}
                  </div>

                  {/* Title & Concept Summary */}
                  <div>
                    <h3
                      className="text-lg sm:text-xl font-bold text-white group-hover:text-cyan-300 transition-colors"
                      style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                    >
                      {item.judul}
                    </h3>
                    <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                      {item.ringkasanKonsep}
                    </p>
                  </div>

                  {/* Formulasi Utama (LaTeX with KaTeX) */}
                  <div className="space-y-2.5 pt-1">
                    <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-cyan-400 block">
                      Persamaan / Rumus Utama:
                    </span>
                    {item.rumusUtama.map((r, rIdx) => (
                      <div
                        key={rIdx}
                        className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/90 space-y-2 relative group/formula"
                      >
                        <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-1.5">
                          <span className="text-xs font-bold text-slate-200">{r.nama}</span>
                          <button
                            onClick={() => handleCopyLatex(`${item.id}-${rIdx}`, r.latex)}
                            className="text-slate-500 hover:text-cyan-300 p-1 rounded-md hover:bg-slate-800 transition cursor-pointer"
                            title="Salin LaTeX rumus"
                          >
                            {copiedFormulaId === `${item.id}-${rIdx}` ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>

                        {/* KaTeX Renderer */}
                        <KaTeXFormula formula={r.latex} className="text-center my-1" />

                        <p className="text-[11px] text-slate-400 leading-snug">
                          {r.keterangan}
                        </p>
                      </div>
                    ))}
                  </div>

                  {/* Key Points */}
                  {item.poinKunci && item.poinKunci.length > 0 && (
                    <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-1.5">
                      <span className="text-[11px] font-mono font-bold text-emerald-400 block uppercase">
                        Poin Kunci & Tips Ujian:
                      </span>
                      <ul className="space-y-1 text-xs text-slate-300">
                        {item.poinKunci.map((pk, pkIdx) => (
                          <li key={pkIdx} className="flex items-start gap-2">
                            <span className="text-emerald-400 font-bold">•</span>
                            <span>{pk}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Contoh Penerapan Soal */}
                  {item.contohPenerapan && (
                    <div className="p-3.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/20 space-y-2 text-xs">
                      <span className="font-mono font-bold text-cyan-300 uppercase block text-[11px]">
                        Contoh Penerapan Soal:
                      </span>
                      <p className="text-slate-200 font-medium">{item.contohPenerapan.kasus}</p>
                      <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
                        <div className="text-[11px] text-slate-400">Langkah: {item.contohPenerapan.langkahPenyelesaian}</div>
                        <div className="font-bold text-cyan-300 font-mono">Hasil: {item.contohPenerapan.jawabanAkhir}</div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Card Footer Button */}
                {item.interaktifCalcType && (
                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400">Tersedia kalkulator hitung cepat</span>
                    <button
                      onClick={() => {
                        setActiveCalcItem(item);
                        setCalcInputs({ val1: '', val2: '', val3: '' });
                      }}
                      className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-cyan-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <Calculator className="w-3.5 h-3.5" />
                      <span>Hitung Sekarang</span>
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 4. MODAL KALKULATOR INTERAKTIF */}
      {activeCalcItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border-[3px] border-cyan-500/50 p-6 space-y-5 text-left relative shadow-2xl">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-bold">
                  <Calculator className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">{activeCalcItem.judul}</h3>
                  <span className="text-xs text-amber-400 font-mono">Kalkulator Otomatis TKA</span>
                </div>
              </div>
              <button
                onClick={() => setActiveCalcItem(null)}
                className="w-8 h-8 rounded-xl bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Dynamic Input Fields Based on Calculator Type */}
            <div className="space-y-4">
              {activeCalcItem.interaktifCalcType === 'kadar' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-mono text-slate-300 mb-1">Massa Zat Terlarut (gram):</label>
                    <input
                      type="number"
                      value={calcInputs.val1}
                      onChange={(e) => setCalcInputs((p) => ({ ...p, val1: e.target.value }))}
                      placeholder="Contoh: 25"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-slate-300 mb-1">Massa Pelarut Air (gram):</label>
                    <input
                      type="number"
                      value={calcInputs.val2}
                      onChange={(e) => setCalcInputs((p) => ({ ...p, val2: e.target.value }))}
                      placeholder="Contoh: 225"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>
              )}

              {activeCalcItem.interaktifCalcType === 'mol' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-mono text-slate-300 mb-1">Massa Senyawa (gram):</label>
                    <input
                      type="number"
                      value={calcInputs.val1}
                      onChange={(e) => setCalcInputs((p) => ({ ...p, val1: e.target.value }))}
                      placeholder="Contoh: 18"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-slate-300 mb-1">Massa Molar (Ar/Mr g/mol):</label>
                    <input
                      type="number"
                      value={calcInputs.val2}
                      onChange={(e) => setCalcInputs((p) => ({ ...p, val2: e.target.value }))}
                      placeholder="Contoh: 18 (H2O)"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>
              )}

              {activeCalcItem.interaktifCalcType === 'ph' && (
                <div>
                  <label className="block text-xs font-mono text-slate-300 mb-1">Konsentrasi Ion [H+] atau [OH-] (Molar):</label>
                  <input
                    type="number"
                    step="any"
                    value={calcInputs.val1}
                    onChange={(e) => setCalcInputs((p) => ({ ...p, val1: e.target.value }))}
                    placeholder="Contoh: 0.001 (atau 1e-3)"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400 font-mono"
                  />
                </div>
              )}

              {activeCalcItem.interaktifCalcType === 'sel-volta' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-mono text-slate-300 mb-1">E° Katoda (Reduksi) Volt:</label>
                    <input
                      type="number"
                      step="any"
                      value={calcInputs.val1}
                      onChange={(e) => setCalcInputs((p) => ({ ...p, val1: e.target.value }))}
                      placeholder="Contoh: +0.34 (Cu)"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-teal-400 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-slate-300 mb-1">E° Anoda (Oksidasi) Volt:</label>
                    <input
                      type="number"
                      step="any"
                      value={calcInputs.val2}
                      onChange={(e) => setCalcInputs((p) => ({ ...p, val2: e.target.value }))}
                      placeholder="Contoh: -0.76 (Zn)"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-teal-400 font-mono"
                    />
                  </div>
                </div>
              )}

              {activeCalcItem.interaktifCalcType === 'kalor' && (
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[11px] font-mono text-slate-300 mb-1">Massa m (gram):</label>
                    <input
                      type="number"
                      value={calcInputs.val1}
                      onChange={(e) => setCalcInputs((p) => ({ ...p, val1: e.target.value }))}
                      placeholder="100"
                      className="w-full px-2.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono text-slate-300 mb-1">Kalor c (J/g°C):</label>
                    <input
                      type="number"
                      step="any"
                      value={calcInputs.val2}
                      onChange={(e) => setCalcInputs((p) => ({ ...p, val2: e.target.value }))}
                      placeholder="4.18"
                      className="w-full px-2.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono text-slate-300 mb-1">Suhu ΔT (°C):</label>
                    <input
                      type="number"
                      value={calcInputs.val3}
                      onChange={(e) => setCalcInputs((p) => ({ ...p, val3: e.target.value }))}
                      placeholder="10"
                      className="w-full px-2.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs"
                    />
                  </div>
                </div>
              )}

              {/* Output Component */}
              <div className="pt-2">
                {renderCalculatorResult(activeCalcItem.interaktifCalcType)}
              </div>
            </div>

            {/* Footer */}
            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setActiveCalcItem(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-white text-xs font-bold cursor-pointer"
              >
                Tutup Kalkulator
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. MODAL CATATAN TANGAN ASLI TKA */}
      {isOriginalImageOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 backdrop-blur-xl animate-fade-in overflow-y-auto">
          <div className="w-full max-w-5xl rounded-3xl bg-slate-900 border-[3px] border-amber-500/50 p-4 sm:p-6 space-y-4 text-left relative my-auto shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <ImageIcon className="w-5 h-5 text-amber-400" />
                <h3 className="text-base sm:text-lg font-bold text-white">
                  Lembar Rangkuman Rumus TKA Asli (Tulisan Tangan)
                </h3>
              </div>
              <button
                onClick={() => setIsOriginalImageOpen(false)}
                className="w-8 h-8 rounded-xl bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="rounded-2xl bg-slate-950 border border-slate-800 p-2 overflow-auto max-h-[75vh] flex justify-center">
              <img
                src="/assets/aistudio/kumpulan_rumus_TKA_ac006f43.png"
                alt="Lembar Kumpulan Rumus TKA Kimia Asli"
                className="max-w-full h-auto rounded-xl shadow-lg object-contain"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono text-slate-400 pt-2 border-t border-slate-800">
              <span>*Gambar ini berisi ringkasan rumus tulisan tangan autentik TKA Kimia SMA.</span>
              <a
                href="/assets/aistudio/kumpulan_rumus_TKA_ac006f43.png"
                target="_blank"
                rel="noreferrer"
                className="text-amber-400 hover:underline flex items-center gap-1 font-bold"
              >
                <span>Buka Gambar Ukuran Penuh</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
