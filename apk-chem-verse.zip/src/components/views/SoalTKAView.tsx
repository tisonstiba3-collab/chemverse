import React, { useState, useEffect } from 'react';
import { ArrowLeft, Clock, Award, CheckCircle2, XCircle, AlertCircle, RotateCcw, ChevronRight, ChevronLeft } from 'lucide-react';
import confetti from 'canvas-confetti';
import { TKA_QUESTIONS } from '../../data/chemistryData';
import { auth } from '../../lib/firebase';
import { saveQuizAttempt } from '../../services/firestoreService';
import { useActivityTracker } from '../../hooks/useActivityTracker';
import ActivityTrackerBadge from '../common/ActivityTrackerBadge';

interface SoalTKAViewProps {
  onBack: () => void;
  onAddXP?: (amount: number) => void;
}

export default function SoalTKAView({ onBack, onAddXP }: SoalTKAViewProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [markedDoubt, setMarkedDoubt] = useState<Record<number, boolean>>({});
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes
  const [isSubmitted, setIsSubmitted] = useState(false);
  const startTimeRef = React.useRef<string>(new Date().toISOString());

  // Real-time Activity Tracker for TKA Examination session
  const tkaTracker = useActivityTracker({
    studentId: auth.currentUser?.uid,
    type: 'quiz',
    refId: 'evaluasi_tka_kimia',
    refTitle: 'Evaluasi TKA & UTBK Kimia SMA',
  });

  useEffect(() => {
    if (isSubmitted || timeLeft <= 0) return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setIsSubmitted(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isSubmitted, timeLeft]);

  const currentQ = TKA_QUESTIONS[currentIndex];
  const totalQ = TKA_QUESTIONS.length;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSelectOption = (idx: number) => {
    if (isSubmitted) return;
    setAnswers((prev) => ({ ...prev, [currentIndex]: idx }));
  };

  const toggleDoubt = () => {
    if (isSubmitted) return;
    setMarkedDoubt((prev) => ({ ...prev, [currentIndex]: !prev[currentIndex] }));
  };

  const handleSubmit = () => {
    setIsSubmitted(true);
    let correct = 0;
    TKA_QUESTIONS.forEach((q, idx) => {
      if (answers[idx] === q.correctIndex) correct++;
    });
    if (onAddXP) onAddXP(correct * 50);

    // Save quiz attempt record to Firestore
    try {
      const percentage = Math.round((correct / totalQ) * 100);
      saveQuizAttempt({
        student_id: auth.currentUser?.uid || 'anon_siswa',
        quiz_id: 'evaluasi_tka_kimia',
        quiz_title: 'Evaluasi TKA & UTBK Kimia SMA',
        score: percentage,
        max_score: 100,
        correct,
        wrong: totalQ - correct,
        started_at: startTimeRef.current,
        submitted_at: new Date().toISOString(),
        duration_sec: tkaTracker.activeSeconds || (600 - timeLeft),
      });
    } catch (err) {
      console.warn('saveQuizAttempt error:', err);
    }

    try {
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    } catch {
      // Safe fallback
    }
  };

  const handleReset = () => {
    setAnswers({});
    setMarkedDoubt({});
    setTimeLeft(600);
    setCurrentIndex(0);
    setIsSubmitted(false);
  };

  const scoreData = (() => {
    let correct = 0;
    TKA_QUESTIONS.forEach((q, idx) => {
      if (answers[idx] === q.correctIndex) correct++;
    });
    const percentage = Math.round((correct / totalQ) * 100);
    return { correct, total: totalQ, percentage, earnedXP: correct * 50 };
  })();

  return (
    <div className="space-y-6 animate-fade-in max-w-5xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-amber-500/50 text-sm font-medium transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali ke Dashboard
        </button>

        {/* Timer & Tracker Badge Pill */}
        <div className="flex items-center gap-3">
          <ActivityTrackerBadge tracker={tkaTracker} label="Mencatat durasi ujian" />
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-900 border border-amber-500/30 text-amber-300 font-mono text-sm font-bold shadow-md">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>Sisa Waktu: {formatTime(timeLeft)}</span>
          </div>

          {!isSubmitted && (
            <button
              onClick={handleSubmit}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs cursor-pointer shadow-lg shadow-amber-500/20 transition"
            >
              Kumpulkan Ujian
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: Left Question, Right Sheet */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Question Card */}
        <div className="lg:col-span-8 space-y-5">
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-mono font-bold px-3 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 uppercase">
                {currentQ.topic} • {currentQ.classLevel}
              </span>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                Soal {currentIndex + 1} dari {totalQ}
              </span>
            </div>

            <div className="text-base sm:text-lg font-semibold text-slate-100 whitespace-pre-line leading-relaxed">
              {currentQ.question}
            </div>

            {/* Multiple Choice Options */}
            <div className="space-y-3">
              {currentQ.options.map((option, idx) => {
                const isChosen = answers[currentIndex] === idx;
                const isCorrect = idx === currentQ.correctIndex;
                let optStyle =
                  'bg-slate-950/70 border-slate-800 text-slate-200 hover:bg-slate-800/80 hover:border-slate-700';

                if (isSubmitted) {
                  if (isCorrect) {
                    optStyle = 'bg-emerald-500/20 border-emerald-500 text-emerald-200 font-bold';
                  } else if (isChosen && !isCorrect) {
                    optStyle = 'bg-rose-500/20 border-rose-500 text-rose-200';
                  } else {
                    optStyle = 'bg-slate-950/40 border-slate-800/40 text-slate-500';
                  }
                } else if (isChosen) {
                  optStyle = 'bg-amber-500/20 border-amber-500 text-amber-200 font-bold';
                }

                return (
                  <button
                    key={idx}
                    disabled={isSubmitted}
                    onClick={() => handleSelectOption(idx)}
                    className={`w-full p-4 rounded-xl border text-left transition flex items-center justify-between gap-4 cursor-pointer disabled:cursor-default ${optStyle}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-7 h-7 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center font-mono text-xs font-bold shrink-0">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span className="text-sm">{option}</span>
                    </div>
                    {isSubmitted && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
                    {isSubmitted && isChosen && !isCorrect && <XCircle className="w-5 h-5 text-rose-400 shrink-0" />}
                  </button>
                );
              })}
            </div>

            {/* Discussion if Submitted */}
            {isSubmitted && (
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 animate-fade-in">
                <div className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Pembahasan Ujian TKA:
                </div>
                <p className="text-xs sm:text-sm text-slate-300 whitespace-pre-line leading-relaxed">
                  {currentQ.explanation}
                </p>
              </div>
            )}

            {/* Navigation Bottom Controls */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <button
                disabled={currentIndex === 0}
                onClick={() => setCurrentIndex((p) => p - 1)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed transition"
              >
                <ChevronLeft className="w-4 h-4" />
                Sebelumnya
              </button>

              {!isSubmitted && (
                <button
                  onClick={toggleDoubt}
                  className={`px-3 py-2 rounded-xl border text-xs font-semibold cursor-pointer transition flex items-center gap-1.5 ${
                    markedDoubt[currentIndex]
                      ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <AlertCircle className="w-3.5 h-3.5" />
                  {markedDoubt[currentIndex] ? 'Ragu-ragu (Ditandai)' : 'Tandai Ragu-ragu'}
                </button>
              )}

              <button
                disabled={currentIndex === totalQ - 1}
                onClick={() => setCurrentIndex((p) => p + 1)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed transition"
              >
                Berikutnya
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Right: Answer Sheet Grid & Results */}
        <div className="lg:col-span-4 space-y-5">
          {/* Answer Navigation Sheet */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">Lembar Jawaban Soal</h4>
            <div className="grid grid-cols-4 gap-2.5">
              {TKA_QUESTIONS.map((q, idx) => {
                const isAns = answers[idx] !== undefined;
                const isCur = currentIndex === idx;
                const isDoubt = markedDoubt[idx];
                const isCorr = isSubmitted && answers[idx] === q.correctIndex;

                let pillColor = 'bg-slate-950 text-slate-400 border-slate-800';
                if (isSubmitted) {
                  pillColor = isCorr
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500'
                    : 'bg-rose-500/20 text-rose-300 border-rose-500';
                } else if (isDoubt) {
                  pillColor = 'bg-amber-500/20 text-amber-300 border-amber-500';
                } else if (isAns) {
                  pillColor = 'bg-cyan-500/20 text-cyan-300 border-cyan-500';
                }

                return (
                  <button
                    key={idx}
                    onClick={() => setCurrentIndex(idx)}
                    className={`h-11 rounded-xl border font-mono font-bold text-sm flex items-center justify-center transition cursor-pointer ${pillColor} ${
                      isCur ? 'ring-2 ring-white scale-105' : ''
                    }`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>

            {/* Legend */}
            <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono space-y-1.5 text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                <span>Terjawab</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <span>Ragu-ragu</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-700" />
                <span>Belum Dijawab</span>
              </div>
            </div>
          </div>

          {/* Results Summary if Submitted */}
          {isSubmitted && (
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4 animate-fade-in text-center">
              <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto">
                <Award className="w-6 h-6" />
              </div>
              <h5 className="font-bold text-white text-base">Hasil Simulasi TKA</h5>
              <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 block mb-1">Skor TKA</span>
                  <span className="text-xl font-black text-amber-400">{scoreData.percentage}%</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 block mb-1">XP Diperoleh</span>
                  <span className="text-xl font-black text-cyan-400">+{scoreData.earnedXP}</span>
                </div>
              </div>
              <button
                onClick={handleReset}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Coba Simulasi Ulang
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
