import React, { useState } from 'react';
import { ArrowLeft, Gamepad2, Check, Sparkles, Plus, Minus, Trophy, RefreshCw, Flame, Swords, Zap } from 'lucide-react';
import confetti from 'canvas-confetti';
import { BALANCING_REACTIONS } from '../../data/chemistryData';
import { StudentProfile } from '../../types/chemistry';
import MultiplayerGameRoomView from '../chemistry/MultiplayerGameRoomView';
import ChemQuestGameView from '../chemistry/ChemQuestGameView';

interface GamesKimiaViewProps {
  student?: StudentProfile | null;
  onBack: () => void;
  onAddXP?: (amount: number) => void;
}

export default function GamesKimiaView({ student, onBack, onAddXP }: GamesKimiaViewProps) {
  const [activeGame, setActiveGame] = useState<'chemquest' | 'multiplayer' | 'balancer' | 'elements'>('chemquest');

  // Balancer Game State
  const [reactionIndex, setReactionIndex] = useState(0);
  const currentReaction = BALANCING_REACTIONS[reactionIndex] || BALANCING_REACTIONS[0];
  const [reactantCoeffs, setReactantCoeffs] = useState<number[]>(() =>
    currentReaction && currentReaction.reactants ? currentReaction.reactants.map(() => 1) : [1, 1]
  );
  const [productCoeffs, setProductCoeffs] = useState<number[]>(() =>
    currentReaction && currentReaction.products ? currentReaction.products.map(() => 1) : [1, 1]
  );
  const [balancerSolved, setBalancerSolved] = useState(false);

  // Periodic Table Guess Game State
  const ELEMENT_PUZZLES = [
    {
      clue: 'Unsur halogen paling elektronegatif di tabel periodik dengan nomor atom 9, digunakan untuk memperkuat email gigi.',
      answer: 'Fluorin (F)',
      options: ['Klorin (Cl)', 'Fluorin (F)', 'Bromin (Br)', 'Iodin (I)'],
      correct: 1,
      atomicNumber: 9,
      symbol: 'F',
    },
    {
      clue: 'Logam alkali periode 3 yang sangat reaktif dengan air, memiliki konfigurasi elektron [Ne] 3s¹.',
      answer: 'Natrium (Na)',
      options: ['Litium (Li)', 'Kalium (K)', 'Natrium (Na)', 'Magnesium (Mg)'],
      correct: 2,
      atomicNumber: 11,
      symbol: 'Na',
    },
    {
      clue: 'Unsur non-logam esensial bagi senyawa organik dengan kemampuan membentuk 4 ikatan kovalen stabil (katenasi).',
      answer: 'Karbon (C)',
      options: ['Silikon (Si)', 'Karbon (C)', 'Nitrogen (N)', 'Fosfor (P)'],
      correct: 1,
      atomicNumber: 6,
      symbol: 'C',
    },
  ];
  const [elementIndex, setElementIndex] = useState(0);
  const [selectedElementOpt, setSelectedElementOpt] = useState<number | null>(null);
  const [elementSolved, setElementSolved] = useState(false);

  // Check balance for current reaction
  const checkBalance = () => {
    const isCorrect =
      reactantCoeffs.every((c, i) => c === currentReaction.reactants[i].targetCoeff) &&
      productCoeffs.every((c, i) => c === currentReaction.products[i].targetCoeff);

    if (isCorrect && !balancerSolved) {
      setBalancerSolved(true);
      if (onAddXP) onAddXP(currentReaction.xpReward);
      try {
        confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
      } catch {
        // Safe fallback
      }
    }
  };

  const updateReactantCoeff = (idx: number, delta: number) => {
    if (balancerSolved) return;
    setReactantCoeffs((prev) => {
      const next = [...prev];
      next[idx] = Math.max(1, Math.min(10, next[idx] + delta));
      return next;
    });
  };

  const updateProductCoeff = (idx: number, delta: number) => {
    if (balancerSolved) return;
    setProductCoeffs((prev) => {
      const next = [...prev];
      next[idx] = Math.max(1, Math.min(10, next[idx] + delta));
      return next;
    });
  };

  const nextReaction = () => {
    const nextIdx = (reactionIndex + 1) % BALANCING_REACTIONS.length;
    setReactionIndex(nextIdx);
    setReactantCoeffs(BALANCING_REACTIONS[nextIdx].reactants.map(() => 1));
    setProductCoeffs(BALANCING_REACTIONS[nextIdx].products.map(() => 1));
    setBalancerSolved(false);
  };

  const handleElementAnswer = (optIndex: number) => {
    if (selectedElementOpt !== null) return;
    setSelectedElementOpt(optIndex);
    if (optIndex === ELEMENT_PUZZLES[elementIndex].correct) {
      setElementSolved(true);
      if (onAddXP) onAddXP(50);
      try {
        confetti({ particleCount: 40, spread: 60, origin: { y: 0.6 } });
      } catch {
        // Safe fallback
      }
    }
  };

  const nextElement = () => {
    setElementIndex((prev) => (prev + 1) % ELEMENT_PUZZLES.length);
    setSelectedElementOpt(null);
    setElementSolved(false);
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
      {/* Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-indigo-500/50 text-sm font-medium transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali ke Dashboard
        </button>

        {/* Game Switcher Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 bg-slate-900/80 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveGame('chemquest')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeGame === 'chemquest'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5 fill-current text-slate-950" />
            🧪 CHEMQUEST RPG
          </button>
          <button
            onClick={() => setActiveGame('multiplayer')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeGame === 'multiplayer'
                ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Swords className="w-3.5 h-3.5 text-cyan-300" />
            Duel Live
          </button>
          <button
            onClick={() => setActiveGame('balancer')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeGame === 'balancer'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            Penyetara Reaksi
          </button>
          <button
            onClick={() => setActiveGame('elements')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeGame === 'elements'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Trophy className="w-3.5 h-3.5 text-yellow-400" />
            Tebak Unsur
          </button>
        </div>
      </div>

      {activeGame === 'chemquest' ? (
        <ChemQuestGameView student={student} onAddXP={onAddXP} onBack={onBack} />
      ) : activeGame === 'multiplayer' ? (
        <MultiplayerGameRoomView student={student} onAddXP={onAddXP} onBack={onBack} />
      ) : activeGame === 'balancer' ? (
        /* Game 1: Chemical Equation Balancer */
        <div className="space-y-6">
          <div className="rounded-2xl bg-gradient-to-r from-indigo-950/60 to-slate-900 border border-indigo-500/30 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-mono font-bold text-indigo-400 uppercase tracking-wider">
                Misi #{reactionIndex + 1} • {currentReaction.title}
              </span>
              <h2 className="text-2xl font-black text-white mt-1">Penyetaraan Reaksi Kimia</h2>
              <p className="text-sm text-slate-300 mt-1 max-w-xl">{currentReaction.description}</p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-mono text-xs font-bold flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                +{currentReaction.xpReward} XP
              </span>
            </div>
          </div>

          {/* Interactive Stoichiometry Balancer Board */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 space-y-6">
            <div className="text-center text-xs font-mono text-slate-400 mb-2">
              Atur koefisien menggunakan tombol (+) dan (-) hingga jumlah atom kiri dan kanan setara
            </div>

            {/* Reaction Formula Display with Steppers */}
            <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4 p-6 rounded-2xl bg-slate-950/80 border border-slate-800/80 text-lg sm:text-xl font-bold font-mono">
              {/* Reactants */}
              {currentReaction.reactants.map((reactant, idx) => (
                <div key={`r-${idx}`} className="flex items-center gap-1.5">
                  <div className="flex flex-col items-center">
                    <button
                      onClick={() => updateReactantCoeff(idx, 1)}
                      className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-8 h-8 rounded-lg bg-indigo-950 border border-indigo-500/50 text-indigo-300 flex items-center justify-center text-base font-black">
                      {reactantCoeffs[idx]}
                    </span>
                    <button
                      onClick={() => updateReactantCoeff(idx, -1)}
                      className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <span className="text-white text-xl sm:text-2xl">{reactant.formula}</span>
                  {idx < currentReaction.reactants.length - 1 && (
                    <span className="text-indigo-400 px-1 text-xl">+</span>
                  )}
                </div>
              ))}

              {/* Reaction Arrow */}
              <div className="px-2 text-cyan-400 text-2xl font-black flex items-center justify-center">
                ➔
              </div>

              {/* Products */}
              {currentReaction.products.map((product, idx) => (
                <div key={`p-${idx}`} className="flex items-center gap-1.5">
                  <div className="flex flex-col items-center">
                    <button
                      onClick={() => updateProductCoeff(idx, 1)}
                      className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-8 h-8 rounded-lg bg-indigo-950 border border-indigo-500/50 text-indigo-300 flex items-center justify-center text-base font-black">
                      {productCoeffs[idx]}
                    </span>
                    <button
                      onClick={() => updateProductCoeff(idx, -1)}
                      className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <span className="text-white text-xl sm:text-2xl">{product.formula}</span>
                  {idx < currentReaction.products.length - 1 && (
                    <span className="text-indigo-400 px-1 text-xl">+</span>
                  )}
                </div>
              ))}
            </div>

            {/* Check Action & Victory Banner */}
            {balancerSolved ? (
              <div className="p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 flex flex-col sm:flex-row items-center justify-between gap-4 animate-fade-in">
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center font-bold">
                    ✓
                  </span>
                  <div>
                    <h4 className="font-bold text-sm">Hukum Kekekalan Massa Terpenuhi!</h4>
                    <p className="text-xs text-emerald-200/80">Jumlah atom sebelum dan sesudah reaksi tepat seimbang.</p>
                  </div>
                </div>
                <button
                  onClick={nextReaction}
                  className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer shadow-md transition"
                >
                  Tantangan Berikutnya ➔
                </button>
              </div>
            ) : (
              <div className="flex justify-center pt-2">
                <button
                  onClick={checkBalance}
                  className="px-8 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 cursor-pointer transition flex items-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  Periksa Kesetaraan Reaksi
                </button>
              </div>
            )}

            {/* Hints Section */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 text-xs space-y-1.5 text-slate-400">
              <span className="text-amber-400 font-bold block mb-1">💡 Tips Penyetaraan:</span>
              {currentReaction.hints.map((hint, i) => (
                <p key={i} className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                  {hint}
                </p>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* Game 2: Periodic Table Guessing Quest */
        <div className="space-y-6">
          <div className="rounded-2xl bg-gradient-to-r from-purple-950/60 to-slate-900 border border-purple-500/30 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-mono font-bold text-purple-400 uppercase tracking-wider">
                Misi #{elementIndex + 1} • Sistem Periodik Unsur
              </span>
              <h2 className="text-2xl font-black text-white mt-1">Tebak Unsur & Tabel Periodik</h2>
              <p className="text-sm text-slate-300 mt-1 max-w-xl">
                Tebak unsur kimia berdasarkan petunjuk sifat fisik, konfigurasi elektron, dan reaktivitasnya!
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-mono text-xs font-bold flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                +50 XP
              </span>
            </div>
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 space-y-6">
            {/* Clue Box */}
            <div className="p-6 rounded-2xl bg-slate-950 border border-purple-500/30 relative overflow-hidden">
              <div className="text-xs font-mono font-bold text-purple-400 mb-2 uppercase">Petunjuk Karakteristik:</div>
              <p className="text-base sm:text-lg text-slate-100 font-medium leading-relaxed">
                "{ELEMENT_PUZZLES[elementIndex].clue}"
              </p>
            </div>

            {/* Multiple Choice Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {ELEMENT_PUZZLES[elementIndex].options.map((option, idx) => {
                const isSelected = selectedElementOpt === idx;
                const isCorrect = idx === ELEMENT_PUZZLES[elementIndex].correct;
                let btnStyle =
                  'bg-slate-950/70 border-slate-800 text-slate-200 hover:bg-slate-800 hover:border-slate-700';

                if (selectedElementOpt !== null) {
                  if (isCorrect) {
                    btnStyle = 'bg-emerald-500/20 border-emerald-500 text-emerald-200 font-bold';
                  } else if (isSelected && !isCorrect) {
                    btnStyle = 'bg-rose-500/20 border-rose-500 text-rose-200';
                  } else {
                    btnStyle = 'bg-slate-950/40 border-slate-800/40 text-slate-500';
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={selectedElementOpt !== null}
                    onClick={() => handleElementAnswer(idx)}
                    className={`p-4 rounded-xl border text-left font-mono font-semibold transition cursor-pointer flex items-center justify-between ${btnStyle}`}
                  >
                    <span>{option}</span>
                    {selectedElementOpt !== null && isCorrect && (
                      <span className="text-xs font-bold text-emerald-400">BENAR ✓</span>
                    )}
                  </button>
                );
              })}
            </div>

            {elementSolved && (
              <div className="flex justify-end pt-2">
                <button
                  onClick={nextElement}
                  className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm cursor-pointer shadow-lg shadow-purple-600/30 transition flex items-center gap-2"
                >
                  Tebak Unsur Selanjutnya ➔
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
