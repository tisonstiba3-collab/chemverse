import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCcw,
  Volume2,
  VolumeX,
  BookOpen,
  Award,
  Bot,
  Loader2,
  Check,
  ChevronDown,
  Layers,
  Zap,
  Target,
  FileText,
  AlertTriangle,
  Lightbulb,
  ShieldCheck,
  BookmarkCheck,
} from 'lucide-react';
import {
  DiagnosticSet,
  DiagnosticQuestion,
  DiagnosticResult,
  StudentProfile,
  JawabanSoalSiswa,
} from '../../types/chemistry';
import {
  KAMUS_PRASYARAT,
  DAFTAR_TOPIK_PRASYARAT,
  cariPrasyaratTopik,
  formatKesiapanAnalysis,
  getProceduralPrerequisiteSet,
  PrasyaratMapping,
} from '../../data/kamusPrasyarat';
import { evaluateDiagnosticAnswers } from '../../../server/diagnosticGenerator';
import { saveDiagnosticResult, saveJawabanSoalBatch } from '../../services/firestoreService';

interface TesDiagnostikViewProps {
  student?: StudentProfile;
  initialTopic?: string;
  onBack: () => void;
  onNavigateToMateri?: (topicId: string) => void;
}

export default function TesDiagnostikView({
  student,
  initialTopic = 'Struktur Atom',
  onBack,
  onNavigateToMateri,
}: TesDiagnostikViewProps) {
  // Resolve initial topic to canonical topic from dictionary
  const [selectedTopicName, setSelectedTopicName] = useState<string>(() => {
    const mapping = cariPrasyaratTopik(initialTopic);
    return mapping.topik;
  });

  // Current active mapping from Kamus Prasyarat
  const activeMapping: PrasyaratMapping = cariPrasyaratTopik(selectedTopicName);

  // Test set generation state
  const [diagnosticSet, setDiagnosticSet] = useState<DiagnosticSet | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Student answers: question id -> selected option ('A' | 'B' | 'C' | 'D' | 'E', array, statement map, or pair map)
  const [userAnswers, setUserAnswers] = useState<Record<string, any>>({});
  const [selectedLeftId, setSelectedLeftId] = useState<string | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  // Result state
  const [isFinished, setIsFinished] = useState(false);
  const [evaluationResult, setEvaluationResult] = useState<ReturnType<
    typeof evaluateDiagnosticAnswers
  > | null>(null);
  const [showPembahasan, setShowPembahasan] = useState(false);

  // Voice narration (TTS)
  const [isVoicePlaying, setIsVoicePlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Stop audio on unmount
  useEffect(() => {
    return () => {
      stopAudio();
    };
  }, []);

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsVoicePlaying(false);
  };

  const speakText = async (text: string) => {
    stopAudio();
    try {
      const res = await fetch('/api/tutor/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.audio) {
          const snd = new Audio(`data:audio/wav;base64,${data.audio}`);
          audioRef.current = snd;
          setIsVoicePlaying(true);
          snd.onended = () => setIsVoicePlaying(false);
          snd.onerror = () => setIsVoicePlaying(false);
          snd.play().catch(() => setIsVoicePlaying(false));
          return;
        }
      }
    } catch {
      // Fallback to browser SpeechSynthesis
    }

    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'id-ID';
      utterance.rate = 1.0;
      utterance.onend = () => setIsVoicePlaying(false);
      utterance.onerror = () => setIsVoicePlaying(false);
      setIsVoicePlaying(true);
      window.speechSynthesis.speak(utterance);
    }
  };

  // Start / Generate 5 Prerequisite Multiple Choice Questions
  // Start / Load 5 Prerequisite Diagnostic Questions (Instant zero-lag response)
  const handleStartTest = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setUserAnswers({});
    setSelectedLeftId(null);
    setCurrentQuestionIndex(0);
    setIsFinished(false);
    setEvaluationResult(null);
    setShowPembahasan(false);

    // Instant load from verified catalog for immediate zero-lag response:
    const instantSet = getProceduralPrerequisiteSet(
      activeMapping.topik,
      `diag_${activeMapping.topik.replace(/\s+/g, '_').toLowerCase()}_${Date.now()}`
    );
    setDiagnosticSet(instantSet);
    setHasStarted(true);
    setIsLoading(false);

    const introTTS = `Halo ${student?.namaLengkap || 'Siswa'}! Ini adalah Asesmen Kesiapan Belajar untuk materi ${instantSet.materi_nama}. Kami menguji 5 butir soal pemantik dari materi prasyarat: ${activeMapping.prasyarat}. Selamat mengerjakan!`;
    speakText(introTTS);
  };

  // Answer handler for single choice (A-E)
  const handleAnswerSelect = (qId: string, optKey: string) => {
    if (isFinished) return;
    setUserAnswers((prev) => ({ ...prev, [qId]: optKey }));
  };

  // Answer handler for PG Kompleks (multi-select)
  const handlePGKToggle = (qId: string, optKey: string) => {
    if (isFinished) return;
    setUserAnswers((prev) => {
      const current = Array.isArray(prev[qId]) ? (prev[qId] as string[]) : [];
      const updated = current.includes(optKey)
        ? current.filter((k) => k !== optKey)
        : [...current, optKey].sort();
      return { ...prev, [qId]: updated };
    });
  };

  // Answer handler for Benar/Salah (statement table)
  const handleBSToggle = (qId: string, stId: number, val: 'B' | 'S') => {
    if (isFinished) return;
    setUserAnswers((prev) => {
      const current = (prev[qId] as Record<number, 'B' | 'S'>) || {};
      return {
        ...prev,
        [qId]: { ...current, [stId]: val },
      };
    });
  };

  // Answer handler for Menjodohkan (Matching)
  const handleMatchingConnect = (qId: string, leftId: string, rightId: string) => {
    if (isFinished) return;
    setUserAnswers((prev) => {
      const current = (prev[qId] as Record<string, string>) || {};
      return {
        ...prev,
        [qId]: { ...current, [leftId]: rightId },
      };
    });
    setSelectedLeftId(null);
  };

  const handleMatchingDisconnect = (qId: string, leftId: string) => {
    if (isFinished) return;
    setUserAnswers((prev) => {
      const current = { ...((prev[qId] as Record<string, string>) || {}) };
      delete current[leftId];
      return { ...prev, [qId]: current };
    });
  };

  // Submit test and analyze readiness
  const handleSubmitTest = async () => {
    if (!diagnosticSet || isFinished) return;
    setIsFinished(true);

    const evalResult = evaluateDiagnosticAnswers(diagnosticSet, userAnswers);
    setEvaluationResult(evalResult);

    // Save to Firestore under 'students/{uid}/diagnostics/{materiId}' & 'students/{uid}/jawaban_soal'
    if (student?.userId) {
      try {
        const fullResult: DiagnosticResult = {
          materiId: diagnosticSet.materi_id,
          materiNama: diagnosticSet.materi_nama,
          kelas: diagnosticSet.kelas,
          setId: diagnosticSet.set_id,
          score: evalResult.score,
          passed: evalResult.passed,
          totalCorrect: evalResult.totalCorrect,
          totalQuestions: evalResult.totalQuestions,
          attemptCount: 1,
          remedialCount: evalResult.passed ? 0 : 1,
          missedPrasyarat: evalResult.missedPrasyarat,
          levelBreakdown: evalResult.levelBreakdown,
          analysisFeedback: evalResult.analysisFeedback,
          answers: userAnswers,
          completedAt: new Date().toISOString(),
        };
        await saveDiagnosticResult(student.userId, fullResult);

        // Format individual question answers
        const itemizedAnswers: JawabanSoalSiswa[] = diagnosticSet.soal.map((q) => {
          const userAns = userAnswers[q.id];
          let isCorrect = false;
          let displayJawabanSiswa = '';
          let displayJawabanBenar = '';

          if (q.tipe === 'PGK') {
            const arrAns = Array.isArray(userAns) ? userAns : [];
            const arrKunci = Array.isArray(q.kunci) ? q.kunci : [];
            isCorrect = arrAns.length === arrKunci.length && arrAns.every((k: any) => arrKunci.includes(k));
            displayJawabanSiswa = arrAns.join(', ') || '-';
            displayJawabanBenar = arrKunci.join(', ');
          } else if (q.tipe === 'BS') {
            const bsAns = typeof userAns === 'object' && userAns !== null ? userAns : {};
            const sts = q.statements || [];
            isCorrect = sts.length > 0 && sts.every((st) => bsAns[st.id] === st.kunci);
            displayJawabanSiswa = Object.entries(bsAns).map(([id, val]) => `#${id}:${val}`).join(', ') || '-';
            displayJawabanBenar = sts.map((st) => `#${st.id}:${st.kunci}`).join(', ');
          } else if (q.tipe === 'MENJODOHKAN') {
            const pairAns = typeof userAns === 'object' && userAns !== null ? userAns : {};
            const pairKunci = (q.kunci as Record<string, string>) || {};
            const keys = Object.keys(pairKunci);
            isCorrect = keys.length > 0 && keys.every((k) => pairAns[k] === pairKunci[k]);
            displayJawabanSiswa = Object.entries(pairAns).map(([k, v]) => `${k}→${v}`).join(', ') || '-';
            displayJawabanBenar = Object.entries(pairKunci).map(([k, v]) => `${k}→${v}`).join(', ');
          } else {
            isCorrect = String(userAns || '').toUpperCase() === String(q.kunci).toUpperCase();
            displayJawabanSiswa = q.opsi?.[userAns] ? `${userAns}. ${q.opsi[userAns]}` : String(userAns || '-');
            displayJawabanBenar = q.opsi?.[q.kunci as string]
              ? `${q.kunci}. ${q.opsi[q.kunci as string]}`
              : String(q.kunci);
          }

          return {
            userId: student.userId,
            namaSiswa: student.namaLengkap || student.nama || 'Siswa',
            topik: diagnosticSet.materi_nama,
            soalId: q.id,
            teksSoal: q.soal,
            jawabanSiswa: displayJawabanSiswa,
            jawabanBenar: displayJawabanBenar,
            isBenar: isCorrect,
            timestamp: new Date().toISOString(),
          };
        });

        await saveJawabanSoalBatch(itemizedAnswers);
      } catch (err) {
        console.warn('Failed saving diagnostic result to Firestore:', err);
      }
    }

    if (evalResult.passed) {
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#22D3EE', '#10B981', '#FBBF24', '#A78BFA'],
        });
      } catch {}
    }

    // Audio narration of the exact analysis feedback
    const feedbackNarration = `${evalResult.analysisFeedback}`;
    speakText(feedbackNarration);
  };

  const currentQ = diagnosticSet?.soal[currentQuestionIndex];
  const answeredCount = diagnosticSet
    ? diagnosticSet.soal.filter((q) => !!userAnswers[q.id]).length
    : 0;

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in pb-20">
      {/* Top Header & Breadcrumb */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-cyan-500/50 text-xs sm:text-sm font-medium transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-cyan-400" />
          <span>Kembali ke Dashboard</span>
        </button>

        <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
          <span className="px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-bold flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span>Tes Kesiapan (Prerequisite Check)</span>
          </span>
          <span className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-bold">
            5 Soal Pilihan Ganda (A-E)
          </span>
        </div>
      </div>

      {/* TOPIC SELECTOR & TITLE CARD (Strictly titled as requested) */}
      <div className="rounded-3xl bg-slate-900/90 backdrop-blur-2xl border border-cyan-500/30 p-5 sm:p-7 shadow-[0_0_40px_rgba(34,211,238,0.12)] space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 uppercase tracking-wider">
                Kamus Prasyarat Kimia SMA
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Kelas {activeMapping.grade}
              </span>
            </div>

            {/* Title strictly formatted: "Asesmen Kesiapan Belajar untuk: [Topik Pilihan]" */}
            <h1
              className="text-xl sm:text-3xl font-extrabold text-white tracking-tight leading-snug"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Asesmen Kesiapan Belajar untuk:{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-300">
                {activeMapping.topik}
              </span>
            </h1>

            {/* Prerequisite disclosure */}
            <div className="pt-1 flex flex-wrap items-center gap-2 text-xs">
              <span className="text-slate-400 font-mono font-semibold">
                Materi Prasyarat dari Kamus:
              </span>
              <span className="px-3 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 font-bold flex items-center gap-1.5 shadow-sm">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>{activeMapping.prasyarat}</span>
              </span>
            </div>

            <p className="text-xs text-slate-400 pt-1 leading-relaxed max-w-2xl">
              Sesuai aturan utama, AI memetakan materi prasyarat di atas dan menyusun 5 butir soal pilihan ganda (A-E) yang <strong>HANYA menguji materi prasyarat tersebut</strong>. Dilarang membuat soal tentang materi baru ({activeMapping.topik}) agar kesiapan belajarmu terukur akurat.
            </p>
          </div>

          {/* Dropdown Selector & Action */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
            <div className="relative min-w-[240px]">
              <select
                disabled={isLoading}
                value={activeMapping.topik}
                onChange={(e) => {
                  setSelectedTopicName(e.target.value);
                  setHasStarted(false);
                  setIsFinished(false);
                  setDiagnosticSet(null);
                  stopAudio();
                }}
                className="w-full appearance-none px-4 py-3 rounded-2xl bg-slate-950 border border-slate-700/80 text-white font-medium text-xs sm:text-sm focus:outline-none focus:border-cyan-400 cursor-pointer pr-10"
              >
                <optgroup label="Kelas X (9 Bab Prasyarat Fondasi)">
                  <option value="Sifat Materi & Metode Ilmiah">1. Sifat Materi & Metode Ilmiah</option>
                  <option value="Struktur Atom">2. Struktur Atom</option>
                  <option value="Kimia Hijau">3. Kimia Hijau</option>
                  <option value="Pemanasan Global">4. Pemanasan Global</option>
                  <option value="Keselamatan Kerja di Laboratorium">5. Keselamatan Kerja di Laboratorium</option>
                  <option value="Konfigurasi Elektron dan Bilangan Kuantum">6. Konfigurasi Elektron dan Bilangan Kuantum</option>
                  <option value="Sistem Periodik Unsur">7. Sistem Periodik Unsur</option>
                  <option value="Ikatan Kimia">8. Ikatan Kimia</option>
                  <option value="Hukum Dasar Kimia dan Konsep Mol">9. Hukum Dasar Kimia dan Konsep Mol</option>
                </optgroup>
                <optgroup label="Kelas XI (9 Bab Prasyarat Reaksi & Larutan)">
                  <option value="Senyawa Hidrokarbon dan Minyak Bumi">10. Senyawa Hidrokarbon dan Minyak Bumi</option>
                  <option value="Termokimia">11. Termokimia</option>
                  <option value="Laju Reaksi dan Teori Tumbukan">12. Laju Reaksi dan Teori Tumbukan</option>
                  <option value="Kesetimbangan Kimia">13. Kesetimbangan Kimia</option>
                  <option value="Asam Basa dan Derajat Keasaman (pH)">14. Asam Basa dan Derajat Keasaman (pH)</option>
                  <option value="Titrasi Asam Basa">15. Titrasi Asam Basa</option>
                  <option value="Hidrolisis Garam">16. Hidrolisis Garam</option>
                  <option value="Larutan Penyangga (Buffer)">17. Larutan Penyangga (Buffer)</option>
                  <option value="Sistem Koloid">18. Sistem Koloid</option>
                </optgroup>
                <optgroup label="Kelas XII (6 Bab Prasyarat Lanjutan)">
                  <option value="Sifat Koligatif Larutan">19. Sifat Koligatif Larutan</option>
                  <option value="Reaksi Redoks dan Penyetaraan">20. Reaksi Redoks dan Penyetaraan</option>
                  <option value="Sel Volta, Elektrolisis, dan Korosi">21. Sel Volta, Elektrolisis, dan Korosi</option>
                  <option value="Kimia Unsur">22. Kimia Unsur</option>
                  <option value="Senyawa Karbon">23. Senyawa Karbon</option>
                  <option value="Makromolekul">24. Makromolekul</option>
                </optgroup>
              </select>
              <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            <button
              onClick={handleStartTest}
              disabled={isLoading}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 via-sky-400 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-slate-950 font-extrabold text-xs sm:text-sm shadow-lg shadow-cyan-500/25 transition cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                  <span>Menyusun 5 Soal AI...</span>
                </>
              ) : hasStarted ? (
                <>
                  <RotateCcw className="w-4 h-4 text-slate-950" />
                  <span>Acak Soal Baru</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  <span>Mulai Asesmen</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Quick Mapping Cards when not started */}
        {!hasStarted && !isLoading && (
          <div className="space-y-3 pt-2">
            <span className="text-xs font-mono text-slate-400 block font-semibold uppercase tracking-wider">
              Pilih Cepat 5 Topik Utama Sesuai Aturan:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {[
                { topik: 'Kimia Hijau', prasyarat: 'Konsep Limbah, Perubahan Fisika/Kimia, dan Reaksi Pembakaran' },
                { topik: 'Struktur Atom', prasyarat: 'Sifat Materi dan Partikel Penyusun Materi' },
                { topik: 'Ikatan Kimia', prasyarat: 'Konfigurasi Elektron dan Sistem Periodik Unsur' },
                { topik: 'Stoikiometri', prasyarat: 'Persamaan Reaksi dan Hukum Dasar Kimia' },
                { topik: 'Larutan Asam Basa', prasyarat: 'Konsep Mol dan Konsentrasi Larutan' },
              ].map((item) => {
                const isSelected = activeMapping.topik === item.topik;
                return (
                  <button
                    key={item.topik}
                    onClick={() => {
                      setSelectedTopicName(item.topik);
                      setHasStarted(false);
                      setIsFinished(false);
                      setDiagnosticSet(null);
                    }}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer space-y-1.5 ${
                      isSelected
                        ? 'bg-cyan-500/20 border-cyan-400 shadow-[0_0_20px_rgba(34,211,238,0.2)]'
                        : 'bg-white/[0.03] hover:bg-white/[0.06] border-white/10'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-xs sm:text-sm text-white font-mono">
                        {item.topik}
                      </span>
                      {isSelected && (
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-cyan-400 text-slate-950">
                          Aktif
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-emerald-300 leading-snug">
                      <strong className="text-slate-400 font-mono">Prasyarat:</strong> {item.prasyarat}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* LOADING STATE */}
      {isLoading && (
        <div className="py-20 rounded-3xl bg-slate-900/60 border border-slate-800 text-center space-y-4">
          <div className="relative mx-auto w-16 h-16">
            <div className="w-16 h-16 rounded-full border-4 border-cyan-500/20 border-t-cyan-400 animate-spin" />
            <Sparkles className="w-6 h-6 text-cyan-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
          </div>
          <div className="space-y-1 max-w-md mx-auto">
            <h3
              className="text-lg font-bold text-white tracking-tight"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Menyusun 5 Soal Prasyarat via Gemini AI...
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Memetakan materi prasyarat <strong className="text-emerald-300">"{activeMapping.prasyarat}"</strong> untuk materi target <strong className="text-cyan-300">"{activeMapping.topik}"</strong>.
            </p>
          </div>
        </div>
      )}

      {/* ERROR STATE */}
      {errorMessage && (
        <div className="p-6 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-center space-y-3">
          <AlertTriangle className="w-8 h-8 text-rose-400 mx-auto" />
          <p className="text-xs text-rose-200">{errorMessage}</p>
          <button
            onClick={handleStartTest}
            className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs"
          >
            Coba Lagi
          </button>
        </div>
      )}

      {/* TEST RUNNER INTERFACE (5 QUESTIONS MULTIPLE CHOICE A - E) */}
      {hasStarted && !isLoading && diagnosticSet && !isFinished && (
        <div className="space-y-6">
          {/* Top Progress & Navigation Tabs */}
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="flex items-center gap-1.5 text-slate-300">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
                <span>
                  Butir Soal <strong className="text-cyan-300">{currentQuestionIndex + 1}</strong> dari 5
                </span>
              </span>
              <span className="text-slate-400">
                Terjawab: <strong className="text-white">{answeredCount}</strong> / 5
              </span>
            </div>

            {/* 5 Question Selector Buttons */}
            <div className="grid grid-cols-5 gap-2">
              {diagnosticSet.soal.map((q, idx) => {
                const isCurrent = idx === currentQuestionIndex;
                const ans = userAnswers[q.id];
                let answered = false;
                let statusLabel = 'Belum';

                if (q.tipe === 'PG') {
                  answered = typeof ans === 'string' && ans.length > 0;
                  if (answered) statusLabel = `Opsi ${ans}`;
                } else if (q.tipe === 'PGK') {
                  answered = Array.isArray(ans) && ans.length > 0;
                  if (answered) statusLabel = `${ans.length} dipilih`;
                } else if (q.tipe === 'BS') {
                  answered = typeof ans === 'object' && ans !== null && Object.keys(ans).length > 0;
                  if (answered) statusLabel = `${Object.keys(ans).length}/${q.statements?.length || 3} st`;
                } else if (q.tipe === 'MENJODOHKAN') {
                  answered = typeof ans === 'object' && ans !== null && Object.keys(ans).length > 0;
                  if (answered) statusLabel = `${Object.keys(ans).length}/${q.matchingLeft?.length || 4} psg`;
                } else {
                  answered = !!ans;
                }

                return (
                  <button
                    key={q.id}
                    onClick={() => setCurrentQuestionIndex(idx)}
                    className={`py-2 px-1 rounded-xl border text-center transition cursor-pointer flex flex-col items-center gap-0.5 ${
                      isCurrent
                        ? 'bg-cyan-500/25 border-cyan-400 text-white shadow-[0_0_15px_rgba(34,211,238,0.25)]'
                        : answered
                        ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                        : 'bg-white/[0.03] border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="text-xs font-mono font-bold">Soal {idx + 1}</span>
                    <span className="text-[10px] font-mono truncate max-w-full px-1">
                      {statusLabel}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ACTIVE QUESTION CONTAINER */}
          {currentQ && (
            <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-700/80 shadow-2xl space-y-6">
              {/* Question Header */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-mono font-extrabold px-3 py-1 rounded-lg bg-emerald-500/20 border border-emerald-400 text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Target className="w-3.5 h-3.5" />
                    <span>Soal Prasyarat #{currentQuestionIndex + 1}</span>
                  </span>

                  {currentQ.tipe === 'PG' && (
                    <span className="text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg bg-cyan-500/15 border border-cyan-500/30 text-cyan-200">
                      Pilihan Ganda (A - E)
                    </span>
                  )}
                  {currentQ.tipe === 'PGK' && (
                    <span className="text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg bg-purple-500/15 border border-purple-500/30 text-purple-200">
                      Pilihan Ganda Kompleks (Multi-Jawaban)
                    </span>
                  )}
                  {currentQ.tipe === 'BS' && (
                    <span className="text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-200">
                      Benar / Salah (Tabel Pernyataan)
                    </span>
                  )}
                  {currentQ.tipe === 'MENJODOHKAN' && (
                    <span className="text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-200">
                      Menjodohkan (Sistem Tarik/Garis)
                    </span>
                  )}
                </div>

                {/* TTS Voice audio button */}
                <button
                  onClick={() => {
                    if (isVoicePlaying) {
                      stopAudio();
                    } else {
                      speakText(
                        `Soal nomor ${currentQuestionIndex + 1}. ${currentQ.soal}`
                      );
                    }
                  }}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-mono flex items-center gap-1.5 transition cursor-pointer ${
                    isVoicePlaying
                      ? 'bg-cyan-500/30 border-cyan-400 text-cyan-200 animate-pulse'
                      : 'bg-white/[0.04] border-white/10 text-slate-300 hover:text-white'
                  }`}
                  title="Dengarkan soal ini dibacakan Kak Kimi"
                >
                  {isVoicePlaying ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-cyan-400" />}
                  <span>{isVoicePlaying ? 'Hentikan' : 'Dengarkan'}</span>
                </button>
              </div>

              {/* Prasyarat Badge */}
              <div className="text-xs font-mono text-cyan-300/90 flex items-center gap-1.5">
                <Lightbulb className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>Indikator Prasyarat: {currentQ.indikator || activeMapping.prasyarat}</span>
              </div>

              {/* Question Text */}
              <div className="text-base sm:text-lg text-white font-semibold leading-relaxed whitespace-pre-line">
                {currentQ.soal}
              </div>

              {/* 1. TIPE: PG (Pilihan Ganda Biasa A-E) */}
              {currentQ.tipe === 'PG' && (
                <div className="space-y-2.5 pt-2">
                  {currentQ.opsi &&
                    Object.entries(currentQ.opsi).map(([optKey, optText]) => {
                      const isSelected = userAnswers[currentQ.id] === optKey;

                      return (
                        <button
                          key={optKey}
                          onClick={() => handleAnswerSelect(currentQ.id, optKey)}
                          className={`w-full text-left p-4 rounded-2xl border transition-all flex items-start gap-3.5 cursor-pointer ${
                            isSelected
                              ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_0_25px_rgba(34,211,238,0.2)] font-semibold ring-1 ring-cyan-400/50'
                              : 'bg-white/[0.02] hover:bg-white/[0.06] border-white/10 text-slate-300 hover:text-white'
                          }`}
                        >
                          <span
                            className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-mono font-bold shrink-0 border transition ${
                              isSelected
                                ? 'bg-cyan-400 text-slate-950 border-cyan-400 font-black'
                                : 'border-slate-700 text-slate-400 bg-slate-950'
                            }`}
                          >
                            {optKey}
                          </span>
                          <span className="text-xs sm:text-sm leading-relaxed pt-0.5">
                            {optText}
                          </span>
                        </button>
                      );
                    })}
                </div>
              )}

              {/* 2. TIPE: PGK (Pilihan Ganda Kompleks >1 Jawaban Benar) */}
              {currentQ.tipe === 'PGK' && (
                <div className="space-y-3 pt-2">
                  <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-200 text-xs font-mono font-semibold flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
                    <span>Petunjuk: {currentQ.instruksi || 'Pilih semua jawaban yang benar (jawaban boleh lebih dari 1)'}</span>
                  </div>

                  <div className="space-y-2.5">
                    {currentQ.opsi &&
                      Object.entries(currentQ.opsi).map(([optKey, optText]) => {
                        const selectedList: string[] = Array.isArray(userAnswers[currentQ.id])
                          ? userAnswers[currentQ.id]
                          : [];
                        const isSelected = selectedList.includes(optKey);

                        return (
                          <button
                            key={optKey}
                            onClick={() => handlePGKToggle(currentQ.id, optKey)}
                            className={`w-full text-left p-4 rounded-2xl border transition-all flex items-start gap-3.5 cursor-pointer ${
                              isSelected
                                ? 'bg-purple-500/20 border-purple-400 text-white shadow-[0_0_25px_rgba(168,85,247,0.2)] font-semibold ring-1 ring-purple-400/50'
                                : 'bg-white/[0.02] hover:bg-white/[0.06] border-white/10 text-slate-300 hover:text-white'
                            }`}
                          >
                            <span
                              className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-mono font-bold shrink-0 border transition ${
                                isSelected
                                  ? 'bg-purple-500 text-white border-purple-400'
                                  : 'border-slate-700 text-slate-400 bg-slate-950'
                              }`}
                            >
                              {isSelected ? '✓' : optKey}
                            </span>
                            <div className="flex-1">
                              <span className="text-xs font-mono text-purple-300 mr-2 font-bold">[{optKey}]</span>
                              <span className="text-xs sm:text-sm leading-relaxed">{optText}</span>
                            </div>
                          </button>
                        );
                      })}
                  </div>
                </div>
              )}

              {/* 3. TIPE: BS (Benar / Salah Tabel Pernyataan) */}
              {currentQ.tipe === 'BS' && (
                <div className="space-y-4 pt-2">
                  <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs font-mono font-semibold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Petunjuk: Tentukan status <strong>Benar (B)</strong> atau <strong>Salah (S)</strong> untuk setiap pernyataan di bawah ini.</span>
                  </div>

                  {/* Explicit & prominent display of question prompt */}
                  <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/30 space-y-1.5 shadow-inner">
                    <span className="text-[11px] font-mono font-bold text-amber-400 uppercase tracking-wider block">
                      📋 Pertanyaan & Instruksi Soal:
                    </span>
                    <p className="text-sm sm:text-base font-semibold text-white leading-relaxed">
                      {currentQ.soal}
                    </p>
                  </div>

                  <div className="overflow-x-auto rounded-2xl border border-slate-700/80 bg-slate-950/60">
                    <table className="w-full text-left text-xs sm:text-sm border-collapse">
                      <thead>
                        <tr className="border-b border-slate-800 bg-slate-900/80 text-slate-400 font-mono text-xs uppercase">
                          <th className="py-3 px-3 w-12 text-center">No</th>
                          <th className="py-3 px-4">Pernyataan Konsep Prasyarat</th>
                          <th className="py-3 px-3 w-28 text-center">Pilihan</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/80">
                        {(currentQ.statements || [
                          { id: 1, pernyataan: currentQ.soal || 'Pernyataan 1' }
                        ]).map((st) => {
                          const userBsMap: Record<number, 'B' | 'S'> =
                            userAnswers[currentQ.id] || {};
                          const userVal = userBsMap[st.id];

                          return (
                            <tr key={st.id} className="hover:bg-white/[0.02] transition">
                              <td className="py-3.5 px-3 text-center font-mono font-bold text-slate-400">
                                {st.id}
                              </td>
                              <td className="py-3.5 px-4 text-slate-200 leading-relaxed">
                                {st.pernyataan}
                              </td>
                              <td className="py-3.5 px-3">
                                <div className="flex items-center justify-center gap-1.5">
                                  <button
                                    onClick={() => handleBSToggle(currentQ.id, st.id, 'B')}
                                    className={`px-3 py-1.5 rounded-lg font-mono text-xs font-bold transition cursor-pointer border ${
                                      userVal === 'B'
                                        ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-md shadow-emerald-500/30'
                                        : 'bg-white/[0.04] border-white/10 text-slate-400 hover:text-white hover:border-emerald-500/50'
                                    }`}
                                  >
                                    B
                                  </button>
                                  <button
                                    onClick={() => handleBSToggle(currentQ.id, st.id, 'S')}
                                    className={`px-3 py-1.5 rounded-lg font-mono text-xs font-bold transition cursor-pointer border ${
                                      userVal === 'S'
                                        ? 'bg-rose-500 border-rose-400 text-white shadow-md shadow-rose-500/30'
                                        : 'bg-white/[0.04] border-white/10 text-slate-400 hover:text-white hover:border-rose-500/50'
                                    }`}
                                  >
                                    S
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* 4. TIPE: MENJODOHKAN (Sistem Hubungkan / Tarik Garis) */}
              {currentQ.tipe === 'MENJODOHKAN' && (
                <div className="space-y-4 pt-2">
                  <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-200 text-xs font-mono font-semibold flex items-center justify-between gap-2">
                    <span className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>
                        {selectedLeftId
                          ? `Item kiri terpilih! Sekarang klik pasangan yang tepat di Kolom Kanan.`
                          : `Langkah 1: Klik item di Kolom Kiri, lalu klik pasangannya di Kolom Kanan.`}
                      </span>
                    </span>
                    {selectedLeftId && (
                      <button
                        onClick={() => setSelectedLeftId(null)}
                        className="text-[11px] underline text-cyan-300 hover:text-white"
                      >
                        Batal Pilih
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Left Column (Premis) */}
                    <div className="space-y-2.5">
                      <div className="text-xs font-mono text-slate-400 font-bold uppercase tracking-wider flex items-center justify-between">
                        <span>Kolom Kiri (Premis)</span>
                        <span className="text-[11px] text-cyan-400 font-normal">Pilih salah satu</span>
                      </div>
                      {(currentQ.matchingLeft || []).map((leftItem) => {
                        const pairsMap: Record<string, string> = userAnswers[currentQ.id] || {};
                        const pairedRightId = pairsMap[leftItem.id];
                        const isSelected = selectedLeftId === leftItem.id;
                        const pairedRightItem = (currentQ.matchingRight || []).find(
                          (r) => r.id === pairedRightId
                        );

                        return (
                          <div
                            key={leftItem.id}
                            onClick={() => setSelectedLeftId(leftItem.id)}
                            className={`p-3.5 rounded-2xl border transition cursor-pointer relative ${
                              isSelected
                                ? 'bg-cyan-500/25 border-cyan-400 shadow-[0_0_20px_rgba(34,211,238,0.25)] ring-2 ring-cyan-400'
                                : pairedRightId
                                ? 'bg-emerald-500/10 border-emerald-500/40 text-white'
                                : 'bg-white/[0.03] border-white/10 hover:border-slate-500 text-slate-300'
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <span className="text-xs sm:text-sm font-semibold">
                                {leftItem.text}
                              </span>
                              {pairedRightId && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleMatchingDisconnect(currentQ.id, leftItem.id);
                                  }}
                                  className="text-slate-400 hover:text-rose-400 p-1 rounded hover:bg-white/5 transition"
                                  title="Lepas pasangan"
                                >
                                  ✕
                                </button>
                              )}
                            </div>

                            {pairedRightItem && (
                              <div className="mt-2 text-[11px] font-mono px-2 py-1 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5 truncate">
                                <span>➔ Terhubung: {pairedRightItem.text.slice(0, 35)}...</span>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Right Column (Respons / Pilihan Jawaban) */}
                    <div className="space-y-2.5">
                      <div className="text-xs font-mono text-slate-400 font-bold uppercase tracking-wider flex items-center justify-between">
                        <span>Kolom Kanan (Pilihan & Pengecoh)</span>
                        <span className="text-[11px] text-purple-400 font-normal">Klik untuk pasangkan</span>
                      </div>
                      {(currentQ.matchingRight || []).map((rightItem) => {
                        const pairsMap: Record<string, string> = userAnswers[currentQ.id] || {};
                        const isConnected = Object.values(pairsMap).includes(rightItem.id);

                        return (
                          <div
                            key={rightItem.id}
                            onClick={() => {
                              if (selectedLeftId) {
                                handleMatchingConnect(currentQ.id, selectedLeftId, rightItem.id);
                              }
                            }}
                            className={`p-3.5 rounded-2xl border transition ${
                              selectedLeftId
                                ? 'cursor-pointer hover:border-cyan-400 hover:bg-cyan-500/10 hover:shadow-lg'
                                : 'cursor-default'
                            } ${
                              isConnected
                                ? 'bg-emerald-500/10 border-emerald-500/40 text-white'
                                : 'bg-white/[0.03] border-white/10 text-slate-300'
                            }`}
                          >
                            <span className="text-xs sm:text-sm leading-relaxed block">
                              {rightItem.text}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* Navigation Controls */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800">
                <button
                  disabled={currentQuestionIndex === 0}
                  onClick={() => setCurrentQuestionIndex((prev) => Math.max(0, prev - 1))}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs font-bold text-slate-300 hover:text-white transition disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                >
                  ← Soal Sebelumnya
                </button>

                <div className="flex items-center gap-3 w-full sm:w-auto">
                  {currentQuestionIndex < diagnosticSet.soal.length - 1 ? (
                    <button
                      onClick={() => setCurrentQuestionIndex((prev) => prev + 1)}
                      className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-white/[0.08] hover:bg-white/[0.15] border border-white/20 text-xs font-bold text-white transition cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <span>Soal Berikutnya</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  ) : null}

                  {/* Selesai Button */}
                  <button
                    onClick={handleSubmitTest}
                    className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-sky-400 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-extrabold text-xs shadow-lg shadow-cyan-500/25 transition cursor-pointer flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Selesai & Analisis Kesiapan ({answeredCount}/5)</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* RESULT & ANALYSIS VIEW (Strictly formatted as required) */}
      {isFinished && evaluationResult && diagnosticSet && (
        <div className="space-y-6">
          <div
            className={`p-6 sm:p-8 rounded-3xl border shadow-2xl relative overflow-hidden text-center space-y-5 ${
              evaluationResult.passed
                ? 'bg-gradient-to-b from-emerald-950/40 via-slate-900/90 to-cyan-950/40 border-emerald-400/60 shadow-[0_0_60px_rgba(16,185,129,0.2)]'
                : 'bg-gradient-to-b from-rose-950/40 via-slate-900/90 to-amber-950/40 border-rose-400/50 shadow-[0_0_60px_rgba(244,63,94,0.18)]'
            }`}
          >
            {/* Status Badge */}
            <div className="flex items-center justify-center gap-2">
              <span
                className={`text-xs font-mono font-bold uppercase tracking-wider px-4 py-1 rounded-full border ${
                  evaluationResult.passed
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                }`}
              >
                {evaluationResult.passed ? 'Status: Kesiapan Belajar Terpenuhi (≥ 70%)' : 'Status: Perlu Penguatan Prasyarat (< 70%)'}
              </span>
            </div>

            {/* Score Display: "Kesiapan Anda: [Persentase]%" */}
            <div className="space-y-2">
              <span className="text-xs font-mono text-slate-400 uppercase tracking-wider block">
                Hasil Asesmen Kesiapan Belajar
              </span>
              <h2
                className="text-4xl sm:text-6xl font-black text-white"
                style={{ fontFamily: "'Space Grotesk', sans-serif" }}
              >
                {evaluationResult.kesiapanText}
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 font-mono">
                Menjawab benar <strong>{evaluationResult.totalCorrect}</strong> dari 5 butir soal pilihan ganda prasyarat.
              </p>
            </div>

            {/* ANALYSIS & SARAN TEXT (Rule #4) */}
            <div className={`p-4 sm:p-6 rounded-2xl border max-w-2xl mx-auto space-y-2 text-left ${
              evaluationResult.passed
                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-200'
                : 'bg-amber-950/40 border-amber-500/30 text-amber-200'
            }`}>
              <div className="flex items-center gap-2 text-xs font-mono font-bold">
                <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Analisis & Rekomendasi Belajar:</span>
              </div>
              <p className="text-sm sm:text-base font-semibold leading-relaxed">
                "{evaluationResult.saranText}"
              </p>
              <div className="pt-1 text-xs text-slate-300 font-mono">
                Topik Target: <strong className="text-white">{diagnosticSet.materi_nama}</strong> | Materi Prasyarat: <strong className="text-cyan-300">{activeMapping.prasyarat}</strong>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={handleStartTest}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs transition cursor-pointer flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Ulangi Asesmen (5 Soal Baru)</span>
              </button>

              <button
                onClick={() => setShowPembahasan(!showPembahasan)}
                className="px-5 py-3 rounded-2xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-slate-200 font-bold text-xs transition cursor-pointer flex items-center gap-2"
              >
                <FileText className="w-4 h-4 text-cyan-400" />
                <span>{showPembahasan ? 'Sembunyikan Pembahasan' : 'Lihat Pembahasan Lengkap'}</span>
              </button>

              {onNavigateToMateri && (
                <button
                  onClick={() => onNavigateToMateri(diagnosticSet.materi_id)}
                  className="px-6 py-3 rounded-2xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-200 font-bold text-xs transition cursor-pointer flex items-center gap-2"
                >
                  <BookOpen className="w-4 h-4 text-emerald-400" />
                  <span>Pelajari Materi "{diagnosticSet.materi_nama}"</span>
                </button>
              )}
            </div>
          </div>

          {/* PEMBAHASAN 5 SOAL */}
          {showPembahasan && (
            <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-cyan-400" />
                  <h3
                    className="text-lg font-bold text-white tracking-tight"
                    style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                  >
                    Pembahasan 5 Butir Soal Prasyarat: {activeMapping.prasyarat}
                  </h3>
                </div>
                <span className="text-xs font-mono text-slate-400">
                  Untuk Topik: {diagnosticSet.materi_nama}
                </span>
              </div>

              <div className="space-y-6">
                {diagnosticSet.soal.map((q, idx) => {
                  const userAns = userAnswers[q.id];
                  const qTipe = q.tipe || 'PG';
                  let isCorrect = false;

                  if (qTipe === 'PG') {
                    isCorrect =
                      typeof userAns === 'string' &&
                      userAns.trim().toUpperCase() === String(q.kunci).trim().toUpperCase();
                  } else if (qTipe === 'BS') {
                    if (q.statements && Array.isArray(q.statements)) {
                      if (typeof userAns === 'object' && userAns !== null && !Array.isArray(userAns)) {
                        isCorrect = q.statements.every((st) => userAns[st.id] === st.kunci);
                      }
                    } else {
                      isCorrect =
                        typeof userAns === 'string' &&
                        userAns.trim().toUpperCase() === String(q.kunci).trim().toUpperCase();
                    }
                  } else if (qTipe === 'PGK') {
                    const correctKeys = Array.isArray(q.kunci) ? [...q.kunci].sort() : [];
                    const userKeys = Array.isArray(userAns) ? [...userAns].sort() : [];
                    isCorrect =
                      correctKeys.length === userKeys.length &&
                      correctKeys.every((val, i) => val === userKeys[i]);
                  } else if (qTipe === 'MENJODOHKAN') {
                    const correctMap = (q.kunci as Record<string, string>) || {};
                    const userMap = (userAns as Record<string, string>) || {};
                    const keys = Object.keys(correctMap);
                    isCorrect =
                      keys.length > 0 && keys.every((k) => userMap[k] === correctMap[k]);
                  }

                  return (
                    <div
                      key={q.id}
                      className={`p-5 rounded-2xl border space-y-3 ${
                        isCorrect
                          ? 'bg-emerald-950/20 border-emerald-500/30'
                          : 'bg-rose-950/20 border-rose-500/30'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold ${
                              isCorrect
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : 'bg-rose-500/20 text-rose-300'
                            }`}
                          >
                            {idx + 1}
                          </span>
                          <span className="font-bold text-white">
                            Soal #{idx + 1} •{' '}
                            {qTipe === 'PG'
                              ? 'Pilihan Ganda'
                              : qTipe === 'PGK'
                              ? 'Pilihan Ganda Kompleks'
                              : qTipe === 'BS'
                              ? 'Benar / Salah'
                              : 'Menjodohkan'}
                          </span>
                        </div>

                        <span
                          className={`px-2.5 py-0.5 rounded font-bold ${
                            isCorrect
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-rose-500/20 text-rose-300'
                          }`}
                        >
                          {isCorrect ? '✓ Jawaban Tepat' : '✗ Belum Tepat'}
                        </span>
                      </div>

                      <div className="text-sm font-semibold text-slate-100">{q.soal}</div>

                      {/* Display answer comparison per question type */}
                      <div className="p-3.5 rounded-xl bg-slate-950/60 border border-white/5 space-y-2 text-xs font-mono">
                        {/* PG View */}
                        {qTipe === 'PG' && (
                          <>
                            <div>
                              <span className="text-slate-400">Jawaban Kamu: </span>
                              <span className={isCorrect ? 'text-emerald-300 font-bold' : 'text-rose-300 font-bold'}>
                                {userAns && q.opsi?.[userAns]
                                  ? `${userAns}. ${q.opsi[userAns]}`
                                  : userAns || 'Belum dijawab'}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400">Kunci Jawaban: </span>
                              <span className="text-cyan-300 font-bold">
                                {q.opsi?.[q.kunci as string]
                                  ? `${q.kunci}. ${q.opsi[q.kunci as string]}`
                                  : String(q.kunci)}
                              </span>
                            </div>
                          </>
                        )}

                        {/* PGK View */}
                        {qTipe === 'PGK' && (
                          <>
                            <div>
                              <span className="text-slate-400">Pilihan Kamu: </span>
                              <span className={isCorrect ? 'text-emerald-300 font-bold' : 'text-rose-300 font-bold'}>
                                {Array.isArray(userAns) && userAns.length > 0
                                  ? userAns.join(', ')
                                  : 'Belum memilih'}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400">Kunci Jawaban: </span>
                              <span className="text-purple-300 font-bold">
                                {Array.isArray(q.kunci) ? q.kunci.join(', ') : String(q.kunci)}
                              </span>
                            </div>
                          </>
                        )}

                        {/* BS View */}
                        {qTipe === 'BS' && (
                          <div className="space-y-2.5">
                            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/25 space-y-1">
                              <span className="text-[11px] font-mono font-bold text-amber-300 block">
                                📋 Pertanyaan & Instruksi Soal:
                              </span>
                              <p className="text-xs text-slate-100 font-medium leading-relaxed">{q.soal}</p>
                            </div>
                            <span className="text-slate-300 block font-bold text-xs pt-1">
                              Evaluasi & Kunci Jawaban Tiap Pernyataan:
                            </span>
                            {(q.statements || []).map((st) => {
                              const userBs = (userAns as Record<number, 'B' | 'S'>)?.[st.id];
                              const isStCorrect = userBs === st.kunci;
                              return (
                                <div key={st.id} className="p-3 rounded-xl bg-slate-900/80 border border-white/5 space-y-2 text-xs">
                                  <div className="text-slate-200 font-medium leading-relaxed">
                                    <span className="text-amber-400 font-bold font-mono mr-1.5">{st.id}.</span>
                                    {st.pernyataan}
                                  </div>
                                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-white/5 font-mono text-[11px]">
                                    <div className="flex items-center gap-2">
                                      <span className="text-slate-400">Pilihanmu:</span>
                                      <span className={`font-bold px-2 py-0.5 rounded ${
                                        userBs === 'B'
                                          ? 'bg-emerald-500/20 text-emerald-300'
                                          : userBs === 'S'
                                          ? 'bg-rose-500/20 text-rose-300'
                                          : 'bg-slate-800 text-slate-400'
                                      }`}>
                                        {userBs ? (userBs === 'B' ? 'BENAR (B)' : 'SALAH (S)') : 'Kosong'}
                                      </span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <span className="text-slate-400">Kunci:</span>
                                      <span className="font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                                        {st.kunci === 'B' ? 'BENAR (B)' : 'SALAH (S)'}
                                      </span>
                                      <span className={isStCorrect ? 'text-emerald-400 font-bold ml-1' : 'text-rose-400 font-bold ml-1'}>
                                        {isStCorrect ? '✓ Tepat' : '✗ Belum Tepat'}
                                      </span>
                                    </div>
                                  </div>
                                  {st.pembahasan && (
                                    <p className="text-[11px] text-slate-300 bg-white/[0.02] p-2 rounded-lg italic">
                                      💡 {st.pembahasan}
                                    </p>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {/* Menjodohkan View */}
                        {qTipe === 'MENJODOHKAN' && (
                          <div className="space-y-1.5">
                            <span className="text-slate-400 block font-bold">Pasangan yang Terhubung:</span>
                            {(q.matchingLeft || []).map((left) => {
                              const rightId = (userAns as Record<string, string>)?.[left.id];
                              const correctRightId = (q.kunci as Record<string, string>)?.[left.id];
                              const matchedRight = (q.matchingRight || []).find((r) => r.id === rightId);
                              const correctRight = (q.matchingRight || []).find((r) => r.id === correctRightId);
                              const isMatchCorrect = rightId === correctRightId;

                              return (
                                <div key={left.id} className="text-[11px] py-1 border-b border-white/5 last:border-0 space-y-0.5">
                                  <div className="text-slate-200 font-semibold">{left.text}</div>
                                  <div className="flex flex-wrap items-center gap-2 pl-2">
                                    <span className="text-slate-400">Pasangan kamu:</span>
                                    <span className={isMatchCorrect ? 'text-emerald-300' : 'text-rose-300'}>
                                      {matchedRight ? matchedRight.text : 'Belum dihubungkan'}
                                    </span>
                                  </div>
                                  {!isMatchCorrect && correctRight && (
                                    <div className="flex flex-wrap items-center gap-2 pl-2">
                                      <span className="text-slate-400">Kunci tepat:</span>
                                      <span className="text-cyan-300 font-bold">{correctRight.text}</span>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>

                      {/* Explanation */}
                      <div className="text-xs text-slate-300 leading-relaxed bg-white/[0.02] p-3 rounded-xl border border-white/5">
                        <strong className="text-cyan-400 font-mono block pb-1">Pembahasan Ilmiah:</strong>
                        {q.pembahasan}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
