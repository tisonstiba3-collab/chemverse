import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import {
  Search,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  BookOpen,
  Sparkles,
  ChevronDown,
  Layers,
  Award,
  Zap,
  Bookmark,
  BookmarkCheck,
  Bot,
  Flame,
  Battery,
  FlaskConical,
  X,
  ExternalLink,
  HelpCircle,
  Lightbulb,
  Lock,
  Unlock,
  RotateCcw,
} from 'lucide-react';
import {
  CurriculumTopic,
  CurriculumSection,
  GradeLevel,
  CurriculumCategory,
  StudentProfile,
  StudentTopicProgress,
  DiagnosticResult,
} from '../../types/chemistry';
import { CURRICULUM_DATA } from '../../data/curriculumData';
import { findPrerequisiteItem } from '../../data/diagnosticCurriculumData';
import TopicCard3D from '../3d/TopicCard3D';
import MiniSection3DCanvas from '../3d/MiniSection3DCanvas';
import KaTeXFormula from '../chemistry/KaTeXFormula';
import DiagnosticGateModal from '../chemistry/DiagnosticGateModal';
import InteractiveMateriLayout from '../chemistry/InteractiveMateriLayout';
import { useActivityTracker } from '../../hooks/useActivityTracker';
import ActivityTrackerBadge from '../common/ActivityTrackerBadge';
import { getTeacherContent } from '../../services/aiCommandService';
import {
  getCurriculumByGrade,
  clearCurriculumCache,
  saveTopicProgressSubcollection,
  subscribeStudentProgressSubcollection,
  saveBookmarks,
  subscribeBookmarks,
  subscribeStudentDiagnostics,
} from '../../services/firestoreService';

interface MateriKimiaViewProps {
  student?: StudentProfile;
  initialTopicId?: string | null;
  onBack: () => void;
  onNavigateToLatihan?: () => void;
  onCompleteTopic?: (topicName: string) => void;
}

const GRADE_INFO: Record<GradeLevel, { title: string; subtitle: string; icon: any; accentColor: string }> = {
  X: {
    title: 'Kelas X',
    subtitle: 'Fase E — Pondasi metode sains, keselamatan kerja, kimia hijau, struktur atom, dan stoikiometri dasar.',
    icon: FlaskConical,
    accentColor: '#22D3EE',
  },
  XI: {
    title: 'Kelas XI',
    subtitle: 'Fase F — Senyawa hidrokarbon, termokimia, laju reaksi, kesetimbangan, dan analisis asam-basa.',
    icon: Flame,
    accentColor: '#F97316',
  },
  XII: {
    title: 'Kelas XII',
    subtitle: 'Fase F — Sifat koligatif larutan, redoks & sel elektrokimia, kimia unsur, dan makromolekul organik.',
    icon: Battery,
    accentColor: '#10B981',
  },
};

const CATEGORIES: CurriculumCategory[] = [
  'Semua',
  'Dasar Kimia',
  'Fisik',
  'Analitik',
  'Organik',
];

// Circular SVG Progress Ring
function ProgressRing({
  percent,
  size = 40,
  strokeWidth = 3.5,
  color = '#22D3EE',
}: {
  percent: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
}) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percent / 100) * circumference;

  return (
    <div className="relative flex items-center justify-center shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform -rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          className="text-slate-800/80"
          fill="transparent"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className="transition-all duration-700 ease-out"
          fill="transparent"
        />
      </svg>
      <span className="absolute text-[10px] font-mono font-bold text-slate-200">
        {Math.round(percent)}%
      </span>
    </div>
  );
}

export default function MateriKimiaView({
  student,
  initialTopicId,
  onBack,
  onNavigateToLatihan,
  onCompleteTopic,
}: MateriKimiaViewProps) {
  // Active Grade Selector State
  const [activeGrade, setActiveGrade] = useState<GradeLevel>('X');
  const [selectedCategory, setSelectedCategory] = useState<CurriculumCategory>('Semua');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTopic, setSelectedTopic] = useState<CurriculumTopic | null>(null);

  // Curriculum Data from Firestore (with 24h localStorage TTL caching)
  const [topics, setTopics] = useState<CurriculumTopic[]>(() => CURRICULUM_DATA['X']);
  const [isLoadingCurriculum, setIsLoadingCurriculum] = useState(false);

  // Progress & Bookmarks State
  const [progressMap, setProgressMap] = useState<Record<string, StudentTopicProgress>>({});
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [openAccordions, setOpenAccordions] = useState<Record<string, boolean>>({});
  const [isMarkingComplete, setIsMarkingComplete] = useState(false);

  // Diagnostic Gate State
  const [diagnosticResultsMap, setDiagnosticResultsMap] = useState<Record<string, DiagnosticResult>>({});
  const [showDiagnosticModal, setShowDiagnosticModal] = useState(false);
  const [pendingTopicForDiagnostic, setPendingTopicForDiagnostic] = useState<CurriculumTopic | null>(null);

  // Official Reference & Admin Sync State
  const [showSourceModal, setShowSourceModal] = useState(false);
  const [isSyncingFirestore, setIsSyncingFirestore] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);

  // Detail View Interactive Concept Quiz State
  const [quizAnswer, setQuizAnswer] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [showLearningObjectives, setShowLearningObjectives] = useState(true);

  // Image Lightbox Modal State
  const [activeLightboxImage, setActiveLightboxImage] = useState<{ url: string; title: string; caption: string } | null>(null);

  // Card hover state for 3D rotation acceleration
  const [hoveredCardId, setHoveredCardId] = useState<string | null>(null);

  // Active learning tracker for reading current chemistry topic
  const readingTracker = useActivityTracker({
    studentId: student?.userId,
    type: 'reading',
    refId: selectedTopic?.id || 'none',
    refTitle: selectedTopic?.title || 'Materi Kimia',
  });

  // Reset interactive quiz when changing topics
  useEffect(() => {
    setQuizAnswer(null);
    setQuizSubmitted(false);
  }, [selectedTopic?.id]);

  // Cek apakah ada materi yang ditimpa / dikustomisasi oleh Guru untuk topik ini
  const teacherMateri = useMemo(() => {
    if (!selectedTopic) return null;
    try {
      const content = getTeacherContent();
      return (
        content.materi.find(
          (m) =>
            m.id === selectedTopic.id ||
            m.babId === selectedTopic.id ||
            (selectedTopic.id === 'struktur-atom-x' && (m.babId === 'bab_01_atom' || m.judul.toLowerCase().includes('atom'))) ||
            (selectedTopic.id === 'ikatan-kimia-x' && (m.babId === 'bab_02_ikatan' || m.judul.toLowerCase().includes('ikatan'))) ||
            (selectedTopic.id === 'stoikiometri-x' && (m.babId === 'bab_03_stoikiometri' || m.judul.toLowerCase().includes('stoikiometri'))) ||
            (selectedTopic.id === 'termokimia-xi' && (m.babId === 'bab_04_termokimia' || m.judul.toLowerCase().includes('termo'))) ||
            (selectedTopic.id === 'laju-reaksi-xi' && (m.babId === 'bab_05_laju' || m.judul.toLowerCase().includes('laju'))) ||
            m.judul.toLowerCase() === selectedTopic.title.toLowerCase()
        ) || null
      );
    } catch (e) {
      return null;
    }
  }, [selectedTopic]);

  // Load Curriculum for current activeGrade
  useEffect(() => {
    let isMounted = true;
    setIsLoadingCurriculum(true);
    clearCurriculumCache();


    getCurriculumByGrade(activeGrade)
      .then((data) => {
        if (isMounted) {
          setTopics(data);
          setIsLoadingCurriculum(false);
        }
      })
      .catch((err) => {
        console.warn('Error fetching curriculum:', err);
        if (isMounted) {
          setTopics(CURRICULUM_DATA[activeGrade] || []);
          setIsLoadingCurriculum(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [activeGrade]);

  // Support initialTopicId prop from Dashboard Coverflow & URL on mount
  useEffect(() => {
    const rawId =
      initialTopicId ||
      (typeof window !== 'undefined' && window.location.pathname.startsWith('/materi/')
        ? window.location.pathname.replace('/materi/', '')
        : null);
    if (!rawId) return;

    const TOPIC_ALIAS_MAP: Record<string, string> = {
      'struktur-atom': 'struktur-atom-x',
      'ikatan-kimia': 'ikatan-kimia-x',
      'termokimia': 'termokimia-xi',
      'laju-reaksi': 'laju-reaksi-xi',
      'kesetimbangan': 'kesetimbangan-kimia-xi',
      'asam-basa': 'asam-basa-xi',
      'redoks-elektrokimia': 'redoks-xii',
      'kimia-organik': 'senyawa-karbon-xii',
    };
    const targetId = TOPIC_ALIAS_MAP[rawId] || rawId;

    for (const grade of ['X', 'XI', 'XII'] as GradeLevel[]) {
      const found = CURRICULUM_DATA[grade]?.find(
        (t) =>
          t.id === targetId ||
          t.id === rawId ||
          t.id.startsWith(rawId) ||
          t.id.replace(/-x|-xi|-xii$/, '') === rawId.replace(/-x|-xi|-xii$/, '')
      );
      if (found) {
        setActiveGrade(grade);
        const prereq = findPrerequisiteItem(found.id);
        const diag = diagnosticResultsMap[prereq.code] || diagnosticResultsMap[found.id];
        if (diag && diag.passed) {
          setSelectedTopic(found);
        } else {
          setPendingTopicForDiagnostic(found);
          setShowDiagnosticModal(true);
        }
        break;
      }
    }
  }, [initialTopicId, diagnosticResultsMap]);

  // Sync with browser URL / popstate
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname;
      if (path.startsWith('/materi/')) {
        const topicId = path.replace('/materi/', '');
        for (const grade of ['X', 'XI', 'XII'] as GradeLevel[]) {
          const found = CURRICULUM_DATA[grade]?.find(
            (t) => t.id === topicId || t.id.replace(/-x|-xi|-xii$/, '') === topicId.replace(/-x|-xi|-xii$/, '')
          );
          if (found) {
            setActiveGrade(grade);
            const prereq = findPrerequisiteItem(found.id);
            const diag = diagnosticResultsMap[prereq.code] || diagnosticResultsMap[found.id];
            if (diag && diag.passed) {
              setSelectedTopic(found);
            } else {
              setPendingTopicForDiagnostic(found);
              setShowDiagnosticModal(true);
            }
            return;
          }
        }
      } else if (path === '/materi' || path === '/') {
        setSelectedTopic(null);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Check whether a topic is unlocked based on prasyarat array or diagnostic gate
  const isTopicUnlocked = (topic: CurriculumTopic) => {
    // If prasyarat is explicitly defined:
    if (Array.isArray(topic.prasyarat)) {
      if (topic.prasyarat.length === 0) {
        // Materi awal (tanpa prasyarat) -> selalu terbuka!
        return true;
      }
      // Check if all prerequisites are completed in student.progres_materi or progressMap
      const completedSet = new Set<string>([
        ...(student?.progres_materi || []),
        ...Object.keys(progressMap).filter((k) => progressMap[k]?.completed),
      ]);

      const allPrereqsDone = topic.prasyarat.every((p) => {
        const pLower = p.toLowerCase();
        return (
          completedSet.has(p) ||
          completedSet.has(p.replace(/_/g, '-')) ||
          completedSet.has(p.replace(/-/g, '_')) ||
          (pLower === 'sifat_materi' && (completedSet.has('hakikat-ilmu-kimia-x') || completedSet.has('sifat_materi'))) ||
          (pLower === 'struktur_atom' && (completedSet.has('struktur-atom-x') || completedSet.has('struktur_atom')))
        );
      });

      if (allPrereqsDone) return true;
    }

    // Diagnostic Gate check: if student passed adaptive diagnostic test for this topic/module
    const prereq = findPrerequisiteItem(topic.id);
    const diag = diagnosticResultsMap[prereq.code] || diagnosticResultsMap[topic.id];
    return !!(diag && diag.passed);
  };

  const handleSelectTopic = (topic: CurriculumTopic, forceReDiagnostic = false) => {
    const isUnlocked = isTopicUnlocked(topic);

    if (isUnlocked && !forceReDiagnostic) {
      setSelectedTopic(topic);
      try {
        window.history.pushState(null, '', `/materi/${topic.id}`);
      } catch (e) {
        // ignore
      }
    } else {
      // Diagnostic Gate: Topic is LOCKED until student passes diagnostic test or finishes prerequisites!
      setPendingTopicForDiagnostic(topic);
      setShowDiagnosticModal(true);
    }
  };

  const handleBackToList = () => {
    setSelectedTopic(null);
    try {
      window.history.pushState(null, '', '/materi');
    } catch (e) {
      // ignore
    }
  };

  // Firestore Real-Time Synchronization for student progress & diagnostics
  useEffect(() => {
    if (!student?.userId) return;

    const unsubProgress = subscribeStudentProgressSubcollection(
      student.userId,
      (remoteMap) => {
        setProgressMap(remoteMap);
      },
      (err) => console.warn('Progress subcollection listener warn:', err)
    );

    const unsubBookmarks = subscribeBookmarks(
      student.userId,
      (ids) => setBookmarkedIds(ids),
      (err) => console.warn('Bookmarks listener warn:', err)
    );

    const unsubDiagnostics = subscribeStudentDiagnostics(
      student.userId,
      (results) => setDiagnosticResultsMap(results),
      (err) => console.warn('Diagnostics listener warn:', err)
    );

    return () => {
      unsubProgress();
      unsubBookmarks();
      unsubDiagnostics();
    };
  }, [student?.userId]);

  // Filter topics client-side by category and search query, ordered by urutan (learning map order)
  const filteredTopics = useMemo(() => {
    return topics
      .filter((t) => {
        const matchCategory =
          selectedCategory === 'Semua' || t.category.toLowerCase() === selectedCategory.toLowerCase();
        const titleStr = t.judul || t.title;
        const descStr = t.deskripsi || t.description;
        const matchSearch =
          searchQuery.trim() === '' ||
          titleStr.toLowerCase().includes(searchQuery.toLowerCase()) ||
          descStr.toLowerCase().includes(searchQuery.toLowerCase());
        return matchCategory && matchSearch;
      })
      .sort((a, b) => (a.urutan ?? 999) - (b.urutan ?? 999));
  }, [topics, selectedCategory, searchQuery]);

  // Handle Mark as Complete with optimistic UI + Firestore write + Confetti
  const handleMarkComplete = async (topicId: string, topicTitle: string) => {
    if (isMarkingComplete) return;
    setIsMarkingComplete(true);

    // Optimistic UI update
    setProgressMap((prev) => ({
      ...prev,
      [topicId]: {
        completed: true,
        percent: 100,
        completedAt: new Date().toISOString(),
      },
    }));

    // Trigger celebratory confetti
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#22D3EE', '#A78BFA', '#FBBF24', '#10B981'],
    });

    if (student?.userId) {
      try {
        await saveTopicProgressSubcollection(student.userId, topicId, true);
        if (onCompleteTopic) {
          onCompleteTopic(topicTitle);
        }
      } catch (err) {
        console.warn('Failed to save topic progress to Firestore:', err);
      }
    }

    setIsMarkingComplete(false);
  };

  // Toggle Bookmark
  const handleToggleBookmark = async (e: React.MouseEvent, topicId: string) => {
    e.stopPropagation();
    const isBookmarked = bookmarkedIds.includes(topicId);
    const updated = isBookmarked
      ? bookmarkedIds.filter((id) => id !== topicId)
      : [...bookmarkedIds, topicId];

    setBookmarkedIds(updated);

    if (student?.userId) {
      try {
        await saveBookmarks(student.userId, updated);
      } catch (err) {
        console.warn('Failed to update bookmark:', err);
      }
    }
  };

  // Toggle Accordion
  const toggleAccordion = (sectionIdx: number) => {
    const key = `section-${sectionIdx}`;
    setOpenAccordions((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  // Sync with Firestore on demand for teachers / admins
  const handleSyncFirestore = async () => {
    try {
      setIsSyncingFirestore(true);
      setSyncFeedback(null);
      clearCurriculumCache();
      const updatedTopics = await getCurriculumByGrade(activeGrade);
      setTopics(updatedTopics);
      setSyncFeedback('Data kurikulum dari Cloud Firestore berhasil disinkronkan!');
      setTimeout(() => setSyncFeedback(null), 4000);
    } catch (err: any) {
      setSyncFeedback('Gagal menyinkronkan data dari Firestore.');
    } finally {
      setIsSyncingFirestore(false);
    }
  };

  // Ask AI Helper Trigger
  const handleAskAI = (contextText: string) => {
    window.dispatchEvent(
      new CustomEvent('CHEMIVERSE_OPEN_TUTOR_CHAT', {
        detail: {
          message: `Saya sedang mempelajari materi "${selectedTopic?.title}". Bisakah jelaskan lebih detail mengenai: ${contextText}?`,
        },
      })
    );
  };




  return (
    <div className="min-h-screen text-[#F8FAFC] relative overflow-hidden pb-16">
      {/* Background Aurora Blobs (pure CSS radial gradients + blur, zero canvas) */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden -z-10">
        <div className="absolute -top-32 left-1/4 w-[500px] h-[500px] rounded-full bg-[#22D3EE] opacity-[0.08] blur-[120px] will-change-transform animate-[auroraOne_18s_ease-in-out_infinite_alternate]" />
        <div className="absolute top-1/3 -right-20 w-[550px] h-[550px] rounded-full bg-[#A78BFA] opacity-[0.08] blur-[120px] will-change-transform animate-[auroraTwo_22s_ease-in-out_infinite_alternate]" />
        <div className="absolute -bottom-40 left-10 w-[450px] h-[450px] rounded-full bg-[#FBBF24] opacity-[0.07] blur-[120px] will-change-transform animate-[auroraThree_16s_ease-in-out_infinite_alternate]" />
      </div>

      {/* Subtle Grain Overlay at 4% opacity */}
      <div
        className="fixed inset-0 pointer-events-none opacity-[0.04] -z-10 bg-repeat"
        style={{
          backgroundImage:
            'radial-gradient(circle at center, #ffffff 1px, transparent 1px)',
          backgroundSize: '24px 24px',
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 space-y-8">
        {/* ======================================================= */}
        {/* TOP NAVIGATION / BREADCRUMB                             */}
        {/* ======================================================= */}
        <div className="flex items-center justify-between">
          <nav className="flex items-center gap-2 text-xs font-mono text-slate-400">
            <button
              onClick={() => {
                if (selectedTopic) {
                  handleBackToList();
                } else {
                  onBack();
                }
              }}
              className="hover:text-cyan-300 transition cursor-pointer flex items-center gap-1.5"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{selectedTopic ? 'Daftar Materi' : 'Dashboard'}</span>
            </button>
            <span>/</span>
            <span className="text-slate-300">Materi Kimia SMA</span>
            {selectedTopic && (
              <>
                <span>/</span>
                <span className="text-cyan-400 font-bold truncate max-w-[200px]">
                  {selectedTopic.title}
                </span>
              </>
            )}
          </nav>

          {/* Quick AI Help trigger */}
          <button
            onClick={() => handleAskAI('konsep dasar materi ini')}
            className="px-3.5 py-1.5 rounded-xl bg-white/[0.04] hover:bg-cyan-500/20 border border-white/10 hover:border-cyan-400/50 text-xs font-mono text-cyan-300 flex items-center gap-2 transition cursor-pointer shadow-sm"
          >
            <Bot className="w-3.5 h-3.5 text-cyan-400" />
            <span>Tanya AI Tutor</span>
          </button>
        </div>

        {/* ======================================================= */}
        {/* CONDITIONAL RENDERING: BROWSE vs DETAIL VIEW            */}
        {/* ======================================================= */}
        <AnimatePresence mode="wait">
          {!selectedTopic ? (
            /* =================================================== */
            /* 2. MATERI BROWSE PAGE (Grade Selector & Topic Grid) */
            /* =================================================== */
            <motion.div
              key="browse-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="space-y-8"
            >
              {/* Header Title */}
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Kurikulum Merdeka Kimia SMA Terpadu</span>
                </div>
                <h1
                  className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  Eksplorasi Materi Kimia
                </h1>
                <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
                  Pilih jenjang kelasmu untuk mempelajari konsep sains molekuler, struktur ikatan, dan reaksi kimiawi berstandar kurikulum nasional.
                </p>
              </div>

              {/* Official Sources & Document Sync Banner */}
              <div className="p-4 sm:p-5 rounded-2xl bg-white/[0.03] backdrop-blur-xl border border-white/10 shadow-[0_4px_25px_rgba(0,0,0,0.25)] space-y-3">

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center shrink-0">
                      <BookOpen className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                        <span>Penyusunan Materi Berbasis Sumber Referensi Resmi</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          Kemendikbud & BSNP
                        </span>
                      </h4>
                      <p className="text-[11px] text-slate-400 font-normal">
                        Materi diselaraskan dengan Capaian Pembelajaran Kurikulum Merdeka, E-Modul Kimia Hijau, data DLH Pemanasan Global, dan literatur Masuk-PTN.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => setShowSourceModal(true)}
                      className="px-3 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs text-cyan-300 font-semibold transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Status Dokumen & Drive</span>
                    </button>

                    <button
                      onClick={handleSyncFirestore}
                      disabled={isSyncingFirestore}
                      className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-xs text-cyan-200 font-semibold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      title="Sinkronkan data kurikulum dari Cloud Firestore"
                    >
                      <Sparkles className={`w-3.5 h-3.5 text-cyan-400 ${isSyncingFirestore ? 'animate-spin' : ''}`} />
                      <span>{isSyncingFirestore ? 'Menyinkronkan...' : 'Sinkronkan Firestore'}</span>
                    </button>
                  </div>
                </div>

                {/* 4 Source Chips */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 pt-1 text-[11px] font-mono">
                  <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 flex items-center justify-between">
                    <span className="truncate">📁 Sumber A: Google Drive</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 border border-amber-500/30 font-bold shrink-0">
                      Akses Khusus
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 flex items-center justify-between">
                    <span className="truncate">🔬 Sumber B: Hakikat Kimia</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/30 font-bold shrink-0">
                      Terverifikasi
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 flex items-center justify-between">
                    <span className="truncate">🌍 Sumber C: Pemanasan Global</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/30 font-bold shrink-0">
                      Terverifikasi
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 flex items-center justify-between">
                    <span className="truncate">🌿 Sumber D: E-Modul Hijau</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/30 font-bold shrink-0">
                      Terverifikasi
                    </span>
                  </div>
                </div>

                {syncFeedback && (
                  <div className="p-2 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-200 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span>{syncFeedback}</span>
                  </div>
                )}
              </div>

              {/* Grade Tabs: Three large, pill-shaped tabs with glowing gradient borders */}
              <div className="space-y-3">

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {(['X', 'XI', 'XII'] as GradeLevel[]).map((grade) => {
                    const info = GRADE_INFO[grade];
                    const isActive = activeGrade === grade;
                    const IconComp = info.icon;

                    return (
                      <button
                        key={grade}
                        onClick={() => setActiveGrade(grade)}
                        className={`group relative p-4 rounded-2xl border transition-all duration-300 cursor-pointer text-left flex items-center justify-between overflow-hidden ${
                          isActive
                            ? 'bg-white/[0.08] backdrop-blur-2xl border-cyan-400/60 shadow-[0_0_30px_rgba(34,211,238,0.2)]'
                            : 'bg-white/[0.03] backdrop-blur-xl border-white/10 hover:border-white/20 hover:bg-white/[0.05]'
                        }`}
                      >
                        {/* Glow indicator line */}
                        {isActive && (
                          <div
                            className="absolute top-0 inset-x-0 h-1"
                            style={{
                              background: `linear-gradient(to right, ${info.accentColor}, #A78BFA)`,
                            }}
                          />
                        )}

                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span
                              className="text-lg font-extrabold tracking-tight"
                              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                            >
                              {info.title}
                            </span>
                            {isActive && (
                              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                                Aktif
                              </span>
                            )}
                          </div>
                          <span className="text-xs text-slate-400 block font-mono">
                            {CURRICULUM_DATA[grade].length} Modul Pembelajaran
                          </span>
                        </div>

                        {/* 3D Grade Icon */}
                        <div
                          className={`w-10 h-10 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110 ${
                            isActive
                              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                              : 'bg-white/[0.05] text-slate-400 border border-white/10'
                          }`}
                        >
                          <IconComp className="w-5 h-5" />
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Grade Description (1 line) */}
                <div className="px-4 py-2.5 rounded-xl bg-white/[0.02] border border-white/5 flex items-center gap-2 text-xs text-slate-300 font-mono">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <span>{GRADE_INFO[activeGrade].subtitle}</span>
                </div>
              </div>

              {/* Filter Bar & Search Input */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pt-2">
                {/* Horizontal Category Pills */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-200 cursor-pointer ${
                        selectedCategory === cat
                          ? 'bg-cyan-500 text-slate-950 font-bold shadow-[0_0_20px_rgba(34,211,238,0.4)]'
                          : 'bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {/* Search Bar with glassmorphism */}
                <div className="relative w-full md:w-72">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Cari topik kimia..."
                    className="w-full pl-9 pr-4 py-2 rounded-xl bg-white/[0.04] backdrop-blur-2xl border border-white/10 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 transition"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Main Section: Topic Cards Grid (1 col mobile, 2 tablet, 3 desktop) */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-2">
                {filteredTopics.map((topic) => {
                  const progress = progressMap[topic.id]?.percent ?? (progressMap[topic.id]?.completed ? 100 : 0);
                  const isCompleted = progressMap[topic.id]?.completed || progress >= 100;
                  const isBookmarked = bookmarkedIds.includes(topic.id);
                  const isHovered = hoveredCardId === topic.id;
                  const prereq = findPrerequisiteItem(topic.id);
                  const diag = diagnosticResultsMap[prereq.code] || diagnosticResultsMap[topic.id];
                  const isDiagPassed = diag && diag.passed;
                  const isUnlocked = isTopicUnlocked(topic);
                  const isInitialTopic = Array.isArray(topic.prasyarat) && topic.prasyarat.length === 0;

                  return (
                    <motion.div
                      key={topic.id}
                      layoutId={`topic-card-${topic.id}`}
                      onClick={() => handleSelectTopic(topic)}
                      onMouseEnter={() => setHoveredCardId(topic.id)}
                      onMouseLeave={() => setHoveredCardId(null)}
                      className="group rounded-3xl bg-white/[0.04] backdrop-blur-2xl border border-white/10 shadow-[0_8px_40px_rgba(34,211,238,0.12)] hover:shadow-[0_16px_50px_rgba(34,211,238,0.22)] hover:border-cyan-400/50 p-5 flex flex-col justify-between relative overflow-hidden cursor-pointer transition-all duration-300 hover:-translate-y-2"
                      style={{
                        background: `linear-gradient(135deg, ${topic.fromColor}08, ${topic.toColor}15)`,
                      }}
                    >
                      {/* Top Badges & Bookmark Icon */}
                      <div className="relative z-10 flex items-center justify-between mb-3">
                        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                          {topic.urutan !== undefined && (
                            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                              #{topic.urutan}
                            </span>
                          )}
                          <span
                            className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg border uppercase tracking-wider backdrop-blur-md"
                            style={{
                              backgroundColor: `${topic.fromColor}18`,
                              borderColor: `${topic.fromColor}40`,
                              color: topic.fromColor,
                            }}
                          >
                            {topic.category}
                          </span>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/[0.05] border border-white/10 text-slate-300">
                            Kelas {topic.grade}
                          </span>
                          {/* Prerequisite and Diagnostic Gate Badge */}
                          {isInitialTopic ? (
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 flex items-center gap-1 font-bold">
                              <Sparkles className="w-2.5 h-2.5 text-emerald-400" />
                              <span>Materi Awal</span>
                            </span>
                          ) : isUnlocked ? (
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 flex items-center gap-1 font-bold">
                              <Unlock className="w-2.5 h-2.5 text-emerald-400" />
                              <span>{isDiagPassed ? `Lulus Diagnostik (${diag.score})` : 'Prasyarat Terpenuhi'}</span>
                            </span>
                          ) : (
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-amber-500/20 border border-amber-500/30 text-amber-300 flex items-center gap-1 font-semibold">
                              <Lock className="w-2.5 h-2.5 text-amber-400" />
                              <span>{topic.prasyarat && topic.prasyarat.length > 0 ? `Perlu: ${topic.prasyarat[0]}` : 'Wajib Diagnostik'}</span>
                            </span>
                          )}
                        </div>

                        <button
                          onClick={(e) => handleToggleBookmark(e, topic.id)}
                          aria-label={isBookmarked ? 'Hapus simpanan' : 'Simpan topik'}
                          className={`w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md border transition-all ${
                            isBookmarked
                              ? 'bg-amber-400/20 border-amber-400/60 text-amber-300'
                              : 'bg-black/30 border-white/10 text-slate-400 hover:text-white'
                          }`}
                        >
                          {isBookmarked ? (
                            <BookmarkCheck className="w-3.5 h-3.5 fill-amber-400 text-amber-300" />
                          ) : (
                            <Bookmark className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>

                      {/* Mini 3D Model with frameloop="demand" and lazy loading */}
                      <div className="relative z-10 w-full h-44 rounded-2xl bg-slate-950/40 border border-white/5 overflow-hidden my-2 flex items-center justify-center">
                        <TopicCard3D
                          modelType={topic.modelType}
                          accentColor={topic.fromColor}
                          isHovered={isHovered}
                          frameloop={isHovered ? 'always' : 'demand'}
                          className="h-full"
                        />
                      </div>

                      {/* Title & Description */}
                      <div className="relative z-10 space-y-1.5 mt-2">
                        <h3
                          className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-1"
                          style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                        >
                          {topic.judul || topic.title}
                        </h3>
                        <p className="text-xs text-slate-400 leading-relaxed line-clamp-2 font-normal">
                          {topic.deskripsi || topic.description}
                        </p>
                      </div>

                      {/* Bottom Row: Progress Ring & Action Button */}
                      <div className="relative z-10 mt-5 pt-4 border-t border-white/10 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <ProgressRing
                            percent={progress}
                            color={isCompleted ? '#10B981' : topic.fromColor}
                            size={34}
                          />
                          <div className="text-[10px] leading-tight font-mono">
                            <span className="text-slate-400 block">Progres</span>
                            <span className="font-bold text-slate-200">
                              {isCompleted ? 'Tuntas' : `${Math.round(progress)}%`}
                            </span>
                          </div>
                        </div>

                        <span className="px-3.5 py-1.5 rounded-xl bg-white/[0.06] group-hover:bg-cyan-500 group-hover:text-slate-950 border border-white/10 group-hover:border-cyan-400 text-xs font-bold text-slate-200 transition-all flex items-center gap-1.5">
                          {isUnlocked ? (
                            <>
                              <span>Mulai Belajar</span>
                              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                            </>
                          ) : (
                            <>
                              <Lock className="w-3 h-3 text-amber-400 group-hover:text-slate-950" />
                              <span>Ikuti Diagnostik</span>
                            </>
                          )}
                        </span>
                      </div>
                    </motion.div>
                  );
                })}
              </div>

              {filteredTopics.length === 0 && (
                <div className="p-12 text-center rounded-3xl bg-white/[0.02] border border-white/10 space-y-3 max-w-xl mx-auto shadow-lg">
                  <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto mb-2">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <h4 className="text-lg font-bold text-white" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                    {topics.length === 0
                      ? `Materi Kelas ${activeGrade} Telah Dikosongkan`
                      : 'Tidak ada topik yang sesuai pencarian'}
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                    {topics.length === 0
                      ? 'Seluruh materi lama dan struktur penjelasan telah dihapus dari database. Sistem siap menerima daftar materi dan struktur baru yang akan Anda susun.'
                      : 'Coba ubah kata kunci atau pilih kategori "Semua" untuk melihat topik pembelajaran lainnya.'}
                  </p>
                </div>
              )}
            </motion.div>
          ) : (
            /* =================================================== */
            /* 3. MATERI DETAIL PAGE (Split Screen 60/40)         */
            /* =================================================== */
            <motion.div
              key={`detail-${selectedTopic.id}`}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.35 }}
              className="space-y-6"
            >
              {/* Back button */}
              <button
                onClick={handleBackToList}
                className="px-4 py-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-xs font-bold text-slate-300 hover:text-white transition cursor-pointer flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>← Kembali ke Daftar Materi Kelas {selectedTopic.grade}</span>
              </button>

              {/* Full-width Centered Reading Layout for All Chapters */}
              <div className="max-w-4xl mx-auto space-y-6">
                {/* Header: Topic Title, category pill, grade badge, progress ring */}
                  <div className="p-6 rounded-3xl bg-white/[0.04] backdrop-blur-2xl border border-white/10 shadow-[0_8px_40px_rgba(34,211,238,0.12)] space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span
                          className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-lg border uppercase tracking-wider"
                          style={{
                            backgroundColor: `${selectedTopic.fromColor}18`,
                            borderColor: `${selectedTopic.fromColor}40`,
                            color: selectedTopic.fromColor,
                          }}
                        >
                          {selectedTopic.category}
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/[0.06] border border-white/10 text-slate-300">
                          Kelas {selectedTopic.grade} SMA
                        </span>
                      </div>

                      {/* Progress ring & Live Activity Tracker Badge */}
                      <div className="flex items-center gap-3">
                        <ActivityTrackerBadge tracker={readingTracker} label="Mencatat aktivitas membaca" />
                        <ProgressRing
                          percent={
                            progressMap[selectedTopic.id]?.completed
                              ? 100
                              : progressMap[selectedTopic.id]?.percent ?? 0
                          }
                          color={selectedTopic.fromColor}
                          size={42}
                        />
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      {selectedTopic.urutan !== undefined && (
                        <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                          Urutan #{selectedTopic.urutan}
                        </span>
                      )}
                      {Array.isArray(selectedTopic.prasyarat) && selectedTopic.prasyarat.length === 0 && (
                        <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-emerald-400" />
                          <span>Materi Awal</span>
                        </span>
                      )}
                    </div>

                    <h2
                      className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight"
                      style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                    >
                      {selectedTopic.judul || selectedTopic.title}
                    </h2>

                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                      {selectedTopic.deskripsi || selectedTopic.description}
                    </p>

                    {/* TUGAS 2: Conditional Rendering Tata Letak Materi (Standard, Flipbook, Presentation, PDF Viewer) */}
                    <div className="pt-2 pb-2">
                      <InteractiveMateriLayout
                        layoutType={teacherMateri?.layoutType || selectedTopic.layoutType || 'standard'}
                        contentPages={teacherMateri?.contentPages || selectedTopic.contentPages}
                        contentHtml={teacherMateri?.isi || selectedTopic.konten_materi}
                        attachmentUrl={teacherMateri?.attachmentUrl || selectedTopic.attachmentUrl}
                        topicTitle={teacherMateri?.judul || selectedTopic.judul || selectedTopic.title}
                        topicCategory={selectedTopic.category}
                      />
                    </div>

                    {/* Diagnostic Gate Pass Badge & Re-diagnostic trigger */}
                    {(() => {
                      const prereq = findPrerequisiteItem(selectedTopic.id);
                      const diag = diagnosticResultsMap[prereq.code] || diagnosticResultsMap[selectedTopic.id];
                      const scoreVal = diag?.score ?? 85;

                      return (
                        <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-between gap-3 text-xs">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
                              <Unlock className="w-4 h-4" />
                            </div>
                            <div>
                              <span className="font-bold text-white block flex items-center gap-1.5">
                                <span>Prasyarat Terpenuhi: Lulus Diagnostik</span>
                                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                                  Skor {scoreVal}/100
                                </span>
                              </span>
                              <span className="text-[11px] text-slate-400 font-mono">
                                Modul: {prereq.code} • Ambang Batas Lulus ≥ 70
                              </span>
                            </div>
                          </div>

                          <button
                            onClick={() => handleSelectTopic(selectedTopic, true)}
                            className="px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/30 border border-cyan-500/40 text-[11px] font-mono text-cyan-200 transition flex items-center gap-1.5 cursor-pointer shrink-0"
                            title="Ulangi tes diagnostik dengan 9 soal paralel baru"
                          >
                            <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
                            <span>Re-Diagnostik Baru</span>
                          </button>
                        </div>
                      );
                    })()}

                    {/* Official Source Badge */}
                    {selectedTopic.sourceInfo && (
                      <div className="pt-3 border-t border-white/10 flex flex-col gap-1.5 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                            <BookOpen className="w-3.5 h-3.5" />
                            <span>Sumber Referensi Resmi</span>
                          </span>
                          {selectedTopic.sourceInfo.url && (
                            <a
                              href={selectedTopic.sourceInfo.url}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[11px] text-cyan-300 hover:text-white hover:underline flex items-center gap-1 font-mono"
                            >
                              <span>Buka Dokumen</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                        <div className="text-slate-200 font-semibold text-xs">
                          {selectedTopic.sourceInfo.name}
                        </div>
                        {selectedTopic.sourceInfo.note && (
                          <p className="text-[11px] text-slate-400 font-normal leading-relaxed">
                            {selectedTopic.sourceInfo.note}
                          </p>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Capaian Pembelajaran & Tujuan Pembelajaran Card */}
                  {(selectedTopic.capaianPembelajaran || selectedTopic.tujuanPembelajaran) && (
                    <div className="p-5 rounded-3xl bg-white/[0.03] backdrop-blur-2xl border border-white/10 shadow-[0_4px_25px_rgba(0,0,0,0.2)] space-y-3">
                      <div
                        onClick={() => setShowLearningObjectives(!showLearningObjectives)}
                        className="flex items-center justify-between cursor-pointer group"
                      >
                        <div className="flex items-center gap-2 text-cyan-300">
                          <Award className="w-4 h-4 text-cyan-400" />
                          <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-cyan-300 transition">
                            Capaian & Tujuan Pembelajaran (Fase {selectedTopic.grade === 'X' ? 'E' : 'F'})
                          </h4>
                        </div>
                        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-300 ${showLearningObjectives ? 'rotate-180' : ''}`} />
                      </div>

                      {showLearningObjectives && (
                        <div className="space-y-3 pt-2 text-xs text-slate-300 border-t border-white/5 font-normal">
                          {selectedTopic.capaianPembelajaran && (
                            <div className="p-3 rounded-xl bg-cyan-500/5 border border-cyan-500/20">
                              <span className="text-[10px] font-mono text-cyan-400 font-bold block mb-1 uppercase tracking-wider">
                                Capaian Pembelajaran (CP):
                              </span>
                              <p className="leading-relaxed">{selectedTopic.capaianPembelajaran}</p>
                            </div>
                          )}

                          {selectedTopic.tujuanPembelajaran && selectedTopic.tujuanPembelajaran.length > 0 && (
                            <div className="space-y-1.5">
                              <span className="text-[10px] font-mono text-slate-400 font-bold block uppercase tracking-wider">
                                Tujuan Pembelajaran (TP):
                              </span>
                              <ul className="space-y-1">
                                {selectedTopic.tujuanPembelajaran.map((tp, idx) => (
                                  <li key={idx} className="flex items-start gap-2">
                                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                                    <span>{tp}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Render sections in exact order (excluding removed visualization) */}
                  {selectedTopic.sections
                    .filter((s) => !s.title?.toLowerCase().includes('alur sistematis metode ilmiah'))
                    .map((section, idx) => {
                    // 2. Pendahuluan Section: styled intro box with subtle left border & CSS drop-cap
                    if (section.type === 'pendahuluan') {
                      return (
                        <div
                          key={idx}
                          className="p-6 rounded-3xl bg-white/[0.03] backdrop-blur-2xl border-l-4 shadow-[0_8px_30px_rgba(0,0,0,0.2)] border-r border-t border-b border-white/10"
                          style={{ borderLeftColor: selectedTopic.fromColor }}
                        >
                          <span className="text-[11px] font-mono font-bold text-cyan-400 uppercase tracking-wider block mb-2">
                            Pendahuluan Materi
                          </span>
                          <p className="text-sm text-slate-200 leading-relaxed first-letter:text-4xl first-letter:font-bold first-letter:float-left first-letter:mr-2.5 first-letter:text-cyan-400 font-normal">
                            {section.content}
                          </p>
                        </div>
                      );
                    }

                    // 3. Definisi Section: Card with title, content, and KaTeX centered block
                    if (section.type === 'definisi') {
                      return (
                        <div
                          key={idx}
                          className="p-6 rounded-3xl bg-white/[0.04] backdrop-blur-2xl border border-white/10 shadow-[0_8px_30px_rgba(0,0,0,0.2)] space-y-3"
                        >
                          <div className="flex items-center gap-2 text-cyan-300">
                            <BookOpen className="w-4 h-4 text-cyan-400" />
                            <h3
                              className="text-lg font-bold text-white tracking-tight"
                              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                            >
                              {section.title || 'Definisi & Konsep Kunci'}
                            </h3>
                          </div>

                          <div className="text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-line font-normal">
                            {section.content}
                          </div>

                          {/* Centered KaTeX formula with soft background */}
                          {section.formula && (
                            <div className="p-4 rounded-2xl bg-slate-950/70 border border-white/10 text-center my-3 shadow-inner">
                              <span className="text-[10px] font-mono text-cyan-400 block mb-1">
                                Rumus & Hubungan Matematis
                              </span>
                              <KaTeXFormula formula={section.formula} displayMode={true} />
                            </div>
                          )}
                        </div>
                      );
                    }

                    // 4. Contoh Soal Section: Accordion with problem & smooth solution toggle
                    if (section.type === 'contoh-soal') {
                      const isOpen = !!openAccordions[`section-${idx}`];

                      return (
                        <div
                          key={idx}
                          className="rounded-3xl bg-white/[0.04] backdrop-blur-2xl border border-white/10 shadow-[0_8px_30px_rgba(0,0,0,0.2)] overflow-hidden"
                        >
                          <div className="p-6 space-y-3">
                            <div className="flex items-center gap-2 text-amber-300">
                              <Lightbulb className="w-4 h-4 text-amber-400" />
                              <h3
                                className="text-base font-bold text-white"
                                style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                              >
                                {section.title || 'Contoh Soal & Analisis'}
                              </h3>
                            </div>

                            <div className="p-4 rounded-2xl bg-amber-500/5 border border-amber-500/20 text-xs sm:text-sm text-slate-200 leading-relaxed font-normal">
                              {section.problem}
                            </div>

                            <button
                              onClick={() => toggleAccordion(idx)}
                              className="w-full py-2.5 px-4 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs font-bold text-cyan-300 hover:text-white transition flex items-center justify-between cursor-pointer"
                            >
                              <span>{isOpen ? 'Sembunyikan Pembahasan' : 'Lihat Pembahasan Lengkap'}</span>
                              <ChevronDown
                                className={`w-4 h-4 transition-transform duration-300 ${
                                  isOpen ? 'rotate-180 text-cyan-400' : ''
                                }`}
                              />
                            </button>
                          </div>

                          {/* Smooth Accordion Expansion */}
                          <AnimatePresence>
                            {isOpen && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                exit={{ opacity: 0, height: 0 }}
                                transition={{ duration: 0.3 }}
                                className="px-6 pb-6 pt-1 border-t border-white/10 bg-slate-950/60"
                              >
                                <span className="text-[10px] font-mono text-emerald-400 font-bold block mb-2 uppercase tracking-wider">
                                  Langkah Penyelesaian Terurai:
                                </span>
                                <div className="text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-line font-mono bg-white/[0.02] p-4 rounded-xl border border-white/5">
                                  {section.solution}
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    }

                    // 5. Gambar Section: 3D canvas embed / static diagram with lightbox zoom
                    if (section.type === 'gambar') {
                      const is3D =
                        section.animationType === '3d-molecule' ||
                        section.animationType === '3d-reaction' ||
                        section.animationType === 'particle-system';

                      return (
                        <div
                          key={idx}
                          className="p-5 rounded-3xl bg-white/[0.04] backdrop-blur-2xl border border-white/10 shadow-[0_8px_30px_rgba(0,0,0,0.2)] space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider block">
                              Visualisasi: {section.title || 'Diagram & Model Materi'}
                            </span>
                            {is3D && (
                              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                                3D Canvas
                              </span>
                            )}
                          </div>

                          {is3D ? (
                            <MiniSection3DCanvas
                              animationType={section.animationType}
                              modelType={selectedTopic.modelType}
                              accentColor={selectedTopic.fromColor}
                            />
                          ) : section.imageUrl ? (
                            <div
                              onClick={() =>
                                setActiveLightboxImage({
                                  url: section.imageUrl || '',
                                  title: section.title || '',
                                  caption: section.caption || '',
                                })
                              }
                              className="relative rounded-2xl overflow-hidden group cursor-zoom-in border border-white/10 max-h-60"
                            >
                              <img
                                src={section.imageUrl}
                                alt={section.title || 'Diagram Kimia'}
                                className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-3">
                                <span className="text-[11px] font-mono text-slate-300 flex items-center gap-1.5">
                                  <span>🔍 Klik untuk memperbesar diagram</span>
                                </span>
                              </div>
                            </div>
                          ) : null}

                          {section.caption && (
                            <p className="text-xs text-slate-400 italic leading-relaxed">
                              {section.caption}
                            </p>
                          )}
                        </div>
                      );
                    }

                    // 6. Fakta Menarik Section: Highlighted callout box with sparkle icon
                    if (section.type === 'fakta-menarik') {
                      return (
                        <div
                          key={idx}
                          className="p-5 rounded-3xl bg-gradient-to-r from-amber-500/10 via-purple-500/10 to-cyan-500/10 backdrop-blur-2xl border border-amber-500/30 shadow-[0_8px_30px_rgba(251,191,36,0.1)] space-y-2 relative overflow-hidden"
                        >
                          <div className="flex items-center gap-2 text-amber-300">
                            <Sparkles className="w-4 h-4 text-amber-400 animate-spin" style={{ animationDuration: '8s' }} />
                            <span
                              className="text-xs font-bold uppercase tracking-wider"
                              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                            >
                              Fakta Menarik Sains
                            </span>
                          </div>
                          <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-semibold">
                            {section.content}
                          </p>
                        </div>
                      );
                    }

                    return null;
                  })}

                  {/* Interactive Quick Concept Check */}
                  <div className="p-6 rounded-3xl bg-gradient-to-r from-blue-950/40 via-slate-900/80 to-cyan-950/40 backdrop-blur-2xl border border-cyan-500/30 shadow-[0_8px_30px_rgba(34,211,238,0.15)] space-y-4">
                    <div className="flex items-center gap-2 text-cyan-300">
                      <Sparkles className="w-4 h-4 text-cyan-400" />
                      <h4 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                        Cek Pemahaman Konsep (Interaktif)
                      </h4>
                    </div>

                    <p className="text-xs text-slate-300 font-medium leading-relaxed">
                      {selectedTopic.id.includes('pemanasan-global')
                        ? 'Manakah pernyataan yang paling tepat mengenai perbedaan efek rumah kaca alami dan peningkatan efek rumah kaca antropogenik?'
                        : selectedTopic.id.includes('kimia-hijau')
                        ? 'Prinsip kimia hijau nomor 2 (Ekonomi Atom) menekankan hal apa dalam proses sintesis?'
                        : selectedTopic.id.includes('hakikat')
                        ? 'Dalam metode ilmiah kimia, faktor yang sengaja diubah-ubah oleh peneliti untuk melihat pengaruhnya disebut sebagai:'
                        : `Berdasarkan konsep materi ${selectedTopic.title}, pemahaman konsep esensial apa yang menjadi kunci utama?`}
                    </p>

                    <div className="space-y-2">
                      {(selectedTopic.id.includes('pemanasan-global')
                        ? [
                            { text: 'Efek rumah kaca alami mempertahankan suhu bumi +15°C, sedangkan emisi antropogenik berlebih memicu pemanasan global berbahaya', correct: true },
                            { text: 'Efek rumah kaca alami hanya terjadi di kutub, sedangkan antropogenik terjadi di khatulistiwa', correct: false },
                            { text: 'Semua gas rumah kaca diciptakan oleh pabrik manusia dan tidak ada yang alami', correct: false },
                          ]
                        : selectedTopic.id.includes('kimia-hijau')
                        ? [
                            { text: 'Memaksimalkan proporsi massa semua atom reaktan agar menyatu ke dalam produk akhir yang diinginkan', correct: true },
                            { text: 'Menghasilkan limbah sebanyak mungkin lalu menyaringnya dengan filter mahal', correct: false },
                            { text: 'Menggunakan pelarut organik volatil sebanyak-banyaknya', correct: false },
                          ]
                        : selectedTopic.id.includes('hakikat')
                        ? [
                            { text: 'Variabel Bebas (Manipulasi)', correct: true },
                            { text: 'Variabel Terikat (Respons)', correct: false },
                            { text: 'Variabel Kontrol', correct: false },
                          ]
                        : [
                            { text: 'Materi dipahami dari interaksi partikel mikroskopis, perubahan energi, dan perhitungannya', correct: true },
                            { text: 'Reaksi kimia terjadi secara kebetulan tanpa hukum kekekalan materi', correct: false },
                            { text: 'Ilmu kimia tidak memiliki keterkaitan dengan cabang sains lainnya', correct: false },
                          ]
                      ).map((opt, optIdx) => {
                        const isSelected = quizAnswer === optIdx;
                        return (
                          <button
                            key={optIdx}
                            disabled={quizSubmitted}
                            onClick={() => setQuizAnswer(optIdx)}
                            className={`w-full text-left p-3 rounded-xl border text-xs transition flex items-start gap-2.5 cursor-pointer ${
                              quizSubmitted
                                ? opt.correct
                                  ? 'bg-emerald-500/20 border-emerald-400/60 text-emerald-200 font-bold'
                                  : isSelected
                                  ? 'bg-rose-500/20 border-rose-400/60 text-rose-200 font-semibold'
                                  : 'bg-white/[0.02] border-white/5 text-slate-400 opacity-60'
                                : isSelected
                                ? 'bg-cyan-500/20 border-cyan-400 text-white font-semibold'
                                : 'bg-white/[0.03] hover:bg-white/[0.07] border-white/10 text-slate-300'
                            }`}
                          >
                            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-mono shrink-0 border ${
                              quizSubmitted && opt.correct
                                ? 'bg-emerald-500 text-slate-950 font-bold border-emerald-400'
                                : isSelected
                                ? 'bg-cyan-400 text-slate-950 font-bold border-cyan-400'
                                : 'border-slate-600 text-slate-400'
                            }`}>
                              {String.fromCharCode(65 + optIdx)}
                            </span>
                            <span className="leading-relaxed">{opt.text}</span>
                          </button>
                        );
                      })}
                    </div>

                    {!quizSubmitted ? (
                      <button
                        onClick={() => {
                          if (quizAnswer !== null) {
                            setQuizSubmitted(true);
                            if (quizAnswer === 0) {
                              confetti({ particleCount: 40, spread: 50, origin: { y: 0.7 } });
                            }
                          }
                        }}
                        disabled={quizAnswer === null}
                        className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition cursor-pointer disabled:opacity-40"
                      >
                        Periksa Jawaban
                      </button>
                    ) : (
                      <div className="p-3 rounded-xl bg-white/[0.04] border border-white/10 text-xs space-y-1">
                        <span className={`font-bold block ${quizAnswer === 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                          {quizAnswer === 0 ? '🎉 Benar sekali!' : '💡 Kurang tepat.'}
                        </span>
                        <p className="text-slate-300 leading-relaxed font-normal">
                          {quizAnswer === 0
                            ? 'Konsep esensial telah kamu pahami dengan tepat sesuai literatur resmi.'
                            : 'Pelajari kembali bagian Definisi dan Contoh Soal di atas untuk memperkuat konsepmu.'}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* 7. Footer CTA: "Tandai Selesai" + "Latihan Soal Terkait →" link */}
                  <div className="p-6 rounded-3xl bg-gradient-to-r from-cyan-950/40 via-slate-900/90 to-blue-950/40 backdrop-blur-2xl border border-cyan-500/30 shadow-[0_12px_40px_rgba(34,211,238,0.18)] space-y-4">

                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-[10px] font-mono text-cyan-300 uppercase tracking-wider block font-bold">
                          Evaluasi Pembelajaran
                        </span>
                        <h4
                          className="text-base font-bold text-white"
                          style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                        >
                          Sudah Paham Konsep Ini?
                        </h4>
                      </div>

                      {progressMap[selectedTopic.id]?.completed && (
                        <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          Modul Selesai
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed font-normal">
                      Tandai materi ini sebagai selesai untuk mencatat progres ke Cloud Firestore dan menambah poin XP belajarmu.
                    </p>

                    <div className="flex flex-col sm:flex-row items-center gap-3 pt-1">
                      <button
                        onClick={() => handleMarkComplete(selectedTopic.id, selectedTopic.title)}
                        disabled={isMarkingComplete || progressMap[selectedTopic.id]?.completed}
                        className={`w-full sm:w-auto px-6 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg active:scale-95 ${
                          progressMap[selectedTopic.id]?.completed
                            ? 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 cursor-default'
                            : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-cyan-500/25'
                        }`}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>
                          {progressMap[selectedTopic.id]?.completed
                            ? 'Tuntas Dipelajari'
                            : 'Tandai Selesai & Klaim XP'}
                        </span>
                      </button>

                      {onNavigateToLatihan && (
                        <button
                          onClick={onNavigateToLatihan}
                          className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-xs font-bold text-cyan-300 hover:text-white transition flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <span>Latihan Soal Terkait</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ======================================================= */}
      {/* LIGHTBOX MODAL FOR STATIC DIAGRAMS                      */}
      {/* ======================================================= */}
      <AnimatePresence>
        {activeLightboxImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActiveLightboxImage(null)}
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-4xl w-full rounded-3xl bg-slate-900 border border-white/20 p-4 overflow-hidden shadow-2xl space-y-3"
            >
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-sm font-bold text-white font-mono">
                  {activeLightboxImage.title}
                </span>
                <button
                  onClick={() => setActiveLightboxImage(null)}
                  className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <img
                src={activeLightboxImage.url}
                alt={activeLightboxImage.title}
                className="w-full max-h-[70vh] object-contain rounded-2xl"
              />

              <p className="text-xs text-slate-300 italic pt-2">
                {activeLightboxImage.caption}
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ======================================================= */}
      {/* OFFICIAL SOURCES & GOOGLE DRIVE ADMIN MODAL             */}
      {/* ======================================================= */}
      <AnimatePresence>

        {showSourceModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowSourceModal(false)}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 10 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-2xl w-full rounded-3xl bg-slate-900/95 border border-white/20 p-6 sm:p-7 overflow-hidden shadow-2xl space-y-5 text-slate-200"
            >
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white tracking-tight" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                      Status Integrasi Sumber Referensi Resmi
                    </h3>
                    <p className="text-[11px] text-slate-400 font-mono">
                      Kurikulum Merdeka SMA • Verifikasi & Sinkronisasi Dokumen
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setShowSourceModal(false)}
                  className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Notice for Administrator on Google Drive access */}
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2">
                <div className="flex items-center gap-2 text-amber-300 font-bold text-xs uppercase tracking-wider font-mono">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>Pemberitahuan Administrator: Sumber A (Google Drive)</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed font-normal">
                  Folder Google Drive materi Kemendikbud (<span className="text-cyan-300 font-mono text-[11px]">materi kemendikbud</span>) saat ini memerlukan otorisasi akses publik (&quot;Anyone with the link can view&quot;) atau unggah file modul mandiri oleh pengajar. Sesuai prinsip integritas akademik, kami tidak mengarang isi berkas yang belum dapat diakses secara otomatis.
                </p>
                <div className="pt-1 flex flex-wrap items-center gap-2">
                  <a
                    href="https://drive.google.com/drive/folders/1cVR3gSxq4IhbV-GONHMtwFOubttye2gF?usp=drive_link"
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <span>Buka Folder Google Drive</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Pastikan hak akses folder disetel ke publik untuk sinkronisasi otomatis.
                  </span>
                </div>
              </div>

              {/* Status List for 4 Mandatory Sources */}
              <div className="space-y-2.5 text-xs">
                <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block">
                  Daftar Referensi Utama yang Digunakan:
                </span>

                <div className="space-y-2">
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10 flex items-start justify-between gap-3">
                    <div className="space-y-0.5">
                      <div className="font-bold text-white flex items-center gap-2">
                        <span>Sumber A: Folder Google Drive Materi Kemendikbud</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono">
                          Menunggu Akses Publik
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">
                        Dokumen silabus, capaian pembelajaran (CP), dan tujuan pembelajaran (TP) kurikulum nasional.
                      </p>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-white/[0.03] border border-emerald-500/20 flex items-start justify-between gap-3">
                    <div className="space-y-0.5">
                      <div className="font-bold text-white flex items-center gap-2">
                        <span>Sumber B: Hakikat Ilmu Kimia Kelas X (Masuk-PTN)</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono">
                          Aktif & Terverifikasi
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">
                        Mencakup hakikat kimia, klasifikasi materi, metode ilmiah, dan peranan kimia dalam kehidupan sehari-hari.
                      </p>
                    </div>
                    <a
                      href="https://masuk-ptn.com/materi/hakikat-ilmu-kimia-materi-kimia-kelas-10"
                      target="_blank"
                      rel="noreferrer"
                      className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-cyan-300 shrink-0"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>

                  <div className="p-3 rounded-xl bg-white/[0.03] border border-emerald-500/20 flex items-start justify-between gap-3">
                    <div className="space-y-0.5">
                      <div className="font-bold text-white flex items-center gap-2">
                        <span>Sumber C: Pemanasan Global (DLH Buleleng & BMKG)</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono">
                          Aktif & Terverifikasi
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">
                        Mekanisme efek rumah kaca alami vs antropogenik, gas rumah kaca ($CO_2, CH_4$), dan aksi mitigasi iklim.
                      </p>
                    </div>
                    <a
                      href="https://dlh.bulelengkab.go.id/informasi/detail/artikel/pemanasan-global-global-warming-76"
                      target="_blank"
                      rel="noreferrer"
                      className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-cyan-300 shrink-0"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>

                  <div className="p-3 rounded-xl bg-white/[0.03] border border-emerald-500/20 flex items-start justify-between gap-3">
                    <div className="space-y-0.5">
                      <div className="font-bold text-white flex items-center gap-2">
                        <span>Sumber D: E-Modul Kimia Hijau Kelas X (Kemendikbud)</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono">
                          Aktif & Terverifikasi
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">
                        Definisi kimia hijau, 12 prinsip Paul Anastas & John Warner, ekonomi atom, dan circular economy.
                      </p>
                    </div>
                    <a
                      href="https://cdnc.heyzine.com/files/uploaded/v2/91eab39045ff551cd2de2c4f2229dc23dec86249.pdf"
                      target="_blank"
                      rel="noreferrer"
                      className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-cyan-300 shrink-0"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </div>

              {/* Footer Modal CTA */}
              <div className="pt-2 border-t border-white/10 flex items-center justify-between">
                <span className="text-[11px] text-slate-400 font-mono">
                  Database Firestore: 24 Modul Kimia Terstruktur
                </span>
                <button
                  onClick={() => setShowSourceModal(false)}
                  className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition cursor-pointer"
                >
                  Tutup Informasi
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ======================================================= */}
      {/* 4. DYNAMIC DIAGNOSTIC GATE MODAL (Pre-requisite Lock)   */}
      {/* ======================================================= */}
      {pendingTopicForDiagnostic && (
        <DiagnosticGateModal
          isOpen={showDiagnosticModal}
          materiId={pendingTopicForDiagnostic.id}
          materiTitle={pendingTopicForDiagnostic.title}
          grade={pendingTopicForDiagnostic.grade}
          student={student}
          existingResult={
            diagnosticResultsMap[findPrerequisiteItem(pendingTopicForDiagnostic.id).code] ||
            diagnosticResultsMap[pendingTopicForDiagnostic.id] ||
            null
          }
          onPass={(result) => {
            // Update local state map
            setDiagnosticResultsMap((prev) => ({
              ...prev,
              [result.materiId]: result,
              [pendingTopicForDiagnostic.id]: result,
            }));

            // Unlock and open materi detail view!
            setSelectedTopic(pendingTopicForDiagnostic);
            setShowDiagnosticModal(false);
            setPendingTopicForDiagnostic(null);

            try {
              window.history.pushState(null, '', `/materi/${pendingTopicForDiagnostic.id}`);
            } catch (e) {
              // ignore
            }
          }}
          onClose={() => {
            setShowDiagnosticModal(false);
            setPendingTopicForDiagnostic(null);
          }}
          onOpenTutorForHelp={(topicName, questionContext) => {
            window.dispatchEvent(
              new CustomEvent('CHEMIVERSE_OPEN_TUTOR_CHAT', {
                detail: {
                  message:
                    questionContext ||
                    `Halo Kak Kimi, saya sedang mempelajari prasyarat untuk materi ${topicName}. Bisakah jelaskan konsep kunci yang perlu saya kuasai?`,
                },
              })
            );
          }}
        />
      )}
    </div>
  );
}

