import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Send,
  History,
  AlertCircle,
  Plus,
  Trash2,
  Edit3,
  BookOpen,
  HelpCircle,
  Layers,
  Search,
  CheckCircle2,
  ChevronRight,
  ShieldAlert,
  Bell,
  Paperclip,
  X,
} from 'lucide-react';
import AIPlanPreviewPanel from '../teacher/AIPlanPreviewPanel';
import CommandHistoryModal from '../teacher/CommandHistoryModal';
import {
  getTeacherContent,
  saveTeacherContent,
  parseCommand,
  checkRateLimit,
  AIPlan,
  ExecutionResult,
  TeacherContentData,
} from '../../services/aiCommandService';

interface KelolaKontenViewProps {
  userRole?: 'siswa' | 'guru';
}

export default function KelolaKontenView({ userRole }: KelolaKontenViewProps) {
  // Guard role: Ambil dari prop atau localStorage sesi guru
  const currentRole = userRole || (() => {
    try {
      const saved = localStorage.getItem('chemiverse_active_student');
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed?.role;
      }
    } catch (e) {
      // ignore
    }
    return undefined;
  })();

  const isGuru = currentRole === 'guru';

  // AI Command State
  const [aiPrompt, setAiPrompt] = useState('');
  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);
  const [activePlan, setActivePlan] = useState<AIPlan | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  // File Attachment State (TUGAS 1: Upload File Referensi)
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Toast feedback state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Manual Editor State (2 Kolom)
  const [selectedGrade, setSelectedGrade] = useState<'10' | '11' | '12'>('10');
  const [selectedBab, setSelectedBab] = useState<string>('bab_01_atom');
  const [contentData, setContentData] = useState<TeacherContentData>(() => getTeacherContent());

  // Muat data terbaru saat mount
  useEffect(() => {
    setContentData(getTeacherContent());
  }, []);

  const handleAiSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiPrompt.trim()) return;

    // Tugas C — Cek Rate Limit (Anti-Spam: max 10/jam)
    const rateCheck = checkRateLimit();
    if (!rateCheck.allowed) {
      alert(rateCheck.message || 'Terlalu banyak perintah AI. Tunggu 1 jam atau gunakan menu manual.');
      return;
    }

    setIsGeneratingPlan(true);
    try {
      // Panggil parseCommand untuk menerjemahkan perintah ke AIPlan beserta file referensi (TUGAS 2)
      const plan = await parseCommand(
        aiPrompt,
        {
          selectedGrade,
          selectedBab,
        },
        attachedFile
      );
      setActivePlan(plan);
      setIsPreviewOpen(true);
    } catch (err) {
      console.error('[AI Parse Error]:', err);
      alert('Gagal menyusun rencana AI. Silakan coba perintah yang lebih spesifik.');
    } finally {
      setIsGeneratingPlan(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setAttachedFile(e.target.files[0]);
    }
  };

  const handleRemoveFile = () => {
    setAttachedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleApplyExample = (exampleText: string) => {
    setAiPrompt(exampleText);
  };

  // Re-fetch data setelah eksekusi berhasil dan tampilkan toast (TUGAS C.3 & C.4)
  const handleExecutionSuccess = (result: ExecutionResult) => {
    const msg = `✅ ${result.executed} operasi berhasil. ${result.failed} gagal.`;
    setToastMessage(msg);

    // Bersihkan file lampiran setelah dieksekusi
    setAttachedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }

    // Re-fetch data segar
    const freshData = getTeacherContent();
    setContentData(freshData);

    console.log('[AI Executor Success Log]:', result);

    // Auto-dismiss toast setelah 4 detik
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  // Manual Delete
  const handleManualDeleteSoal = (id: string) => {
    if (confirm('Hapus butir soal ini? Data akan dipindahkan ke Sampah.')) {
      const target = contentData.soal.find((s) => s.id === id);
      if (target) {
        const updated: TeacherContentData = {
          ...contentData,
          soal: contentData.soal.filter((s) => s.id !== id),
          sampah: [
            ...(contentData.sampah || []),
            {
              id: target.id,
              type: 'soal',
              data: target,
              deletedAt: new Date().toISOString(),
            },
          ],
        };
        saveTeacherContent(updated);
        setContentData(updated);
        setToastMessage('✅ 1 butir soal berhasil dihapus secara manual.');
        setTimeout(() => setToastMessage(null), 3500);
      }
    }
  };

  // Manual Add Soal Form Dummy
  const handleManualAddSoal = () => {
    const promptText = prompt('Masukkan pertanyaan soal kimia baru:');
    if (promptText && promptText.trim()) {
      const answerText = prompt('Masukkan jawaban benar:') || 'Jawaban Benar';
      const newSoal = {
        id: `soal_${Date.now()}`,
        babId: selectedBab,
        pertanyaan: promptText.trim(),
        jawaban: answerText.trim(),
        pembahasan: 'Ditambahkan secara manual oleh Guru Kimia.',
        tingkatKesulitan: 'Sedang',
      };
      const updated: TeacherContentData = {
        ...contentData,
        soal: [newSoal, ...contentData.soal],
      };
      saveTeacherContent(updated);
      setContentData(updated);
      setToastMessage('✅ 1 butir soal berhasil ditambahkan secara manual.');
      setTimeout(() => setToastMessage(null), 3500);
    }
  };

  const currentBabSoal = contentData.soal.filter((s) => s.babId === selectedBab);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16 text-slate-100 font-sans animate-fade-in relative">
      {/* Toast Notification (Tugas C.3) */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-slate-900 border border-emerald-500/40 text-emerald-300 shadow-2xl flex items-center gap-3 text-xs font-mono font-bold animate-bounce-subtle backdrop-blur-xl">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ======================================================== */}
      {/* 1. AI COMMAND INPUT BAR (GUARD: KHUSUS GURU)             */}
      {/* ======================================================== */}
      {isGuru ? (
        <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-indigo-950/70 via-slate-900/90 to-purple-950/50 border border-indigo-500/30 shadow-xl backdrop-blur-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center justify-center font-bold text-base shadow-sm">
                🤖
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-black text-white tracking-tight flex items-center gap-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  <span>Perintah AI (AI Command)</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono">
                    Khusus Guru
                  </span>
                </h2>
                <p className="text-xs text-slate-400">
                  Ketik perintah dalam bahasa alami. AI akan merancang <em>plan</em> untuk ditinjau guru sebelum dieksekusi.
                </p>
              </div>
            </div>

            {/* Riwayat Button (Tugas A & B) */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsHistoryOpen(true)}
                className="px-3.5 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white text-xs font-mono font-semibold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <History className="w-3.5 h-3.5 text-indigo-400" />
                <span>Riwayat Perintah</span>
              </button>
            </div>
          </div>

          {/* Form Input Textarea */}
          <form onSubmit={handleAiSubmit} className="space-y-3">
            {/* Hidden File Input for PDF / DOC / Images (TUGAS 1.2) */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png"
              className="hidden"
            />

            <div className="relative">
              <textarea
                rows={2}
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="Contoh: Tolong rangkum file PDF ini dan ganti materi bab 1 kelas 10 menjadi flipbook interaktif..."
                className="w-full px-4 pt-3 pb-12 sm:pb-3 sm:pr-72 rounded-2xl bg-slate-950/90 border border-indigo-500/30 text-white placeholder-slate-500 text-xs sm:text-sm font-sans focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition resize-none leading-relaxed"
              />

              <div className="absolute bottom-2.5 right-3 flex items-center gap-2">
                {/* Tombol Lampirkan File (TUGAS 1.1) */}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer border ${
                    attachedFile
                      ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-300 shadow-sm shadow-cyan-500/20'
                      : 'bg-white/[0.06] hover:bg-white/[0.12] border-white/10 text-slate-300 hover:text-white'
                  }`}
                  title="Lampirkan dokumen atau gambar (.pdf, .doc, .docx, .txt, .jpg, .png)"
                >
                  <Paperclip className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{attachedFile ? 'Ganti File' : 'Lampirkan File'}</span>
                </button>

                {/* Tombol Kirim */}
                <button
                  type="submit"
                  disabled={isGeneratingPlan || !aiPrompt.trim()}
                  className={`px-4 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 shadow-md cursor-pointer ${
                    isGeneratingPlan || !aiPrompt.trim()
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
                  }`}
                >
                  {isGeneratingPlan ? (
                    <>
                      <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Menyusun plan...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Kirim</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Chip Lampiran File (TUGAS 1.3) */}
            {attachedFile && (
              <div className="flex flex-wrap items-center gap-2 pt-0.5 animate-fade-in">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-cyan-950/70 border border-cyan-500/40 text-cyan-200 text-xs font-mono shadow-sm">
                  <span className="text-sm">📄</span>
                  <span className="font-semibold text-white max-w-[280px] truncate" title={attachedFile.name}>
                    {attachedFile.name}
                  </span>
                  <span className="text-[10px] text-cyan-400 font-sans">
                    ({(attachedFile.size / 1024).toFixed(1)} KB)
                  </span>
                  <button
                    type="button"
                    onClick={handleRemoveFile}
                    className="ml-1 p-0.5 rounded-md hover:bg-white/15 text-cyan-300 hover:text-rose-300 transition cursor-pointer"
                    title="Hapus / Batalkan lampiran"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <span className="text-[11px] text-cyan-400/80 font-sans flex items-center gap-1">
                  <span>📎</span>
                  <span>File referensi aktif. AI akan menjadikannya <em>Source of Truth</em>.</span>
                </span>
              </div>
            )}

            {/* Helper Text / Contoh Perintah Termasuk Smart Overwrite & Flipbook */}
            <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
              <span className="font-mono text-slate-500">Contoh perintah:</span>
              <button
                type="button"
                onClick={() => handleApplyExample("Tolong ganti materi bab 1 dengan materi dari PDF ini, tapi buat tampilannya seperti flipbook yang bisa dibalik halaman per halaman.")}
                className="px-2.5 py-1 rounded-lg bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 hover:text-purple-200 border border-purple-500/30 transition cursor-pointer text-left font-medium flex items-center gap-1"
              >
                <span>📖</span>
                <span>"Ganti materi bab 1 dengan PDF, buat jadi flipbook"</span>
              </button>
              <button
                type="button"
                onClick={() => handleApplyExample("Tolong buat ringkasan dari PDF ini, dan timpa materi 'Ikatan Kimia' di bab 2 kelas 10 dengan ringkasan ini.")}
                className="px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 hover:text-amber-200 border border-amber-500/30 transition cursor-pointer text-left font-medium"
              >
                ⚡ "Timpa materi 'Ikatan Kimia' bab 2 dengan ringkasan PDF ini"
              </button>
              <button
                type="button"
                onClick={() => handleApplyExample('Buat 5 soal pilihan ganda tentang ikatan kovalen untuk kelas 10 bab 3')}
                className="px-2.5 py-1 rounded-lg bg-white/[0.04] hover:bg-indigo-500/20 text-slate-300 hover:text-indigo-200 border border-white/5 transition cursor-pointer text-left"
              >
                💡 "Buat 5 soal pilihan ganda ikatan kovalen bab 3"
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* Guard: Jika siswa mengakses */
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Akses Terbatas: Menu Kelola Konten & AI Command hanya dapat diakses oleh Akun Pendidik (Guru).</span>
        </div>
      )}

      {/* ======================================================== */}
      {/* 2. LAYOUT 2 KOLOM PENGELOLAAN MANUAL (MANUAL MODE TETAP ADA)*/}
      {/* ======================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Kolom Kiri: Navigasi Kelas & Bab (4 Kolom) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                <span>Pilih Kelas SMA</span>
              </h3>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {(['10', '11', '12'] as const).map((grade) => (
                <button
                  key={grade}
                  onClick={() => setSelectedGrade(grade)}
                  className={`py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer border ${
                    selectedGrade === grade
                      ? 'bg-indigo-600 border-indigo-400 text-white shadow-md shadow-indigo-600/30'
                      : 'bg-white/[0.03] border-white/5 text-slate-400 hover:text-white hover:bg-white/[0.06]'
                  }`}
                >
                  Kelas {grade}
                </button>
              ))}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                <span>Daftar Bab / Materi</span>
              </h3>
            </div>

            <div className="space-y-1.5">
              {contentData.bab
                .filter((b) => b.grade === selectedGrade)
                .map((bab) => {
                  const isSelected = selectedBab === bab.id;
                  const count = contentData.soal.filter((s) => s.babId === bab.id).length;
                  return (
                    <button
                      key={bab.id}
                      onClick={() => setSelectedBab(bab.id)}
                      className={`w-full p-3 rounded-xl border text-left transition flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-500/20 border-indigo-400 text-white shadow-sm'
                          : 'bg-white/[0.02] border-white/5 text-slate-300 hover:bg-white/[0.05]'
                      }`}
                    >
                      <div className="space-y-0.5">
                        <span className="text-xs font-bold block">{bab.title}</span>
                        <span className="text-[10px] font-mono text-slate-400">
                          {count} Soal Tersedia
                        </span>
                      </div>
                      <ChevronRight className={`w-4 h-4 ${isSelected ? 'text-cyan-400' : 'text-slate-600'}`} />
                    </button>
                  );
                })}
            </div>
          </div>

          {/* Pengumuman Card (Jika Ada) */}
          {contentData.pengumuman?.length > 0 && (
            <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-mono font-bold text-indigo-300">
                <Bell className="w-3.5 h-3.5 text-indigo-400" />
                <span>Pengumuman Aktif Guru:</span>
              </div>
              {contentData.pengumuman.slice(0, 2).map((p) => (
                <div key={p.id} className="p-2.5 rounded-xl bg-black/30 border border-white/5 text-xs space-y-1">
                  <div className="font-bold text-white">{p.judul}</div>
                  <div className="text-[11px] text-slate-400">{p.isi}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Kolom Kanan: Detail & Aksi Manual Konten (8 Kolom) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="p-4 sm:p-5 rounded-2xl bg-white/[0.03] border border-white/10 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/5">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <span>Konten Latihan Soal Bab Terpilih</span>
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-white/[0.05] text-cyan-300">
                    {currentBabSoal.length} Butir Soal
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  Kelola secara manual per butir soal atau gunakan AI Command di atas untuk operasi massal.
                </p>
              </div>

              <button
                onClick={handleManualAddSoal}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-emerald-600/20 self-start sm:self-auto"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Tambah Soal Manual</span>
              </button>
            </div>

            {/* List Butir Soal */}
            <div className="space-y-3">
              {currentBabSoal.map((soal, idx) => (
                <div
                  key={soal.id}
                  className="p-4 rounded-xl bg-white/[0.02] border border-white/5 hover:border-white/10 transition space-y-2.5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <span className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-300 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                        {idx + 1}
                      </span>
                      <div>
                        <p className="text-xs sm:text-sm font-semibold text-slate-100 leading-relaxed">
                          {soal.pertanyaan}
                        </p>
                        <div className="mt-1.5 text-xs text-emerald-400 font-mono">
                          Kunci Jawaban: <span className="font-bold">{soal.jawaban}</span>
                        </div>
                        {soal.pembahasan && (
                          <p className="mt-1 text-[11px] text-slate-400 font-sans italic">
                            Pembahasan: {soal.pembahasan}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Manual Action Buttons */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => {
                          const updatedPertanyaan = prompt('Edit pertanyaan soal:', soal.pertanyaan);
                          if (updatedPertanyaan) {
                            const updatedSoal = contentData.soal.map((s) =>
                              s.id === soal.id ? { ...s, pertanyaan: updatedPertanyaan } : s
                            );
                            const updated = { ...contentData, soal: updatedSoal };
                            saveTeacherContent(updated);
                            setContentData(updated);
                            setToastMessage('✅ Soal berhasil diperbarui secara manual.');
                            setTimeout(() => setToastMessage(null), 3500);
                          }
                        }}
                        className="p-1.5 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-slate-400 hover:text-white transition cursor-pointer"
                        title="Edit Soal Manual"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleManualDeleteSoal(soal.id)}
                        className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 transition cursor-pointer"
                        title="Hapus Soal Manual"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              {currentBabSoal.length === 0 && (
                <div className="p-8 text-center rounded-xl bg-white/[0.01] border border-dashed border-white/10 space-y-2">
                  <p className="text-xs text-slate-400 font-mono">
                    Belum ada soal pada bab ini.
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Ketik perintah di atas: <em>"Buat 5 soal pilihan ganda untuk bab ini"</em> atau klik "Tambah Soal Manual".
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 3. PANEL PREVIEW PLAN (SLIDE-IN KHUSUS GURU)             */}
      {/* ======================================================== */}
      <AIPlanPreviewPanel
        isOpen={isPreviewOpen}
        onClose={() => setIsPreviewOpen(false)}
        plan={activePlan}
        userPrompt={aiPrompt}
        attachedFileName={attachedFile?.name}
        onSuccess={handleExecutionSuccess}
      />

      {/* ======================================================== */}
      {/* 4. MODAL RIWAYAT PERINTAH & UNDO (KHUSUS GURU)           */}
      {/* ======================================================== */}
      <CommandHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onUndoSuccess={(msg) => {
          // Re-fetch data segar setelah undo
          setContentData(getTeacherContent());
          setToastMessage(`↩️ ${msg}`);
          setTimeout(() => setToastMessage(null), 4500);
        }}
      />
    </div>
  );
}
