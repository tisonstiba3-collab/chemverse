import React, { useState } from 'react';
import {
  ArrowLeft,
  BookOpen,
  Plus,
  Calendar,
  Clock,
  Sparkles,
  CheckCircle2,
  Bookmark,
  Loader2,
  Cloud,
} from 'lucide-react';
import { JournalEntry } from '../../types/chemistry';

interface JurnalViewProps {
  entries: JournalEntry[];
  onAddEntry: (entry: {
    topic: string;
    content: string;
    understandingLevel: 'Paham' | 'Cukup' | 'Perlu Diulang';
    durationMinutes: number;
    notes?: string;
    formulasLearned?: string[];
  }) => Promise<void>;
  onBack: () => void;
  isLoading?: boolean;
}

export default function JurnalView({
  entries,
  onAddEntry,
  onBack,
  isLoading = false,
}: JurnalViewProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [topic, setTopic] = useState('');
  const [content, setContent] = useState('');
  const [understandingLevel, setUnderstandingLevel] = useState<'Paham' | 'Cukup' | 'Perlu Diulang'>('Paham');
  const [durationMinutes, setDurationMinutes] = useState(45);
  const [formulaInput, setFormulaInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim() || !content.trim()) {
      setError('Silakan isi topik dan teks isi jurnal Anda.');
      return;
    }

    const formulas = formulaInput
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    try {
      setIsSubmitting(true);
      setError(null);
      await onAddEntry({
        topic: topic.trim(),
        content: content.trim(),
        notes: content.trim(),
        understandingLevel,
        durationMinutes,
        formulasLearned: formulas.length ? formulas : ['Konsep Dasar Reaksi Kimia'],
      });

      setTopic('');
      setContent('');
      setFormulaInput('');
      setIsAdding(false);
    } catch (err: any) {
      setError(err?.message || 'Gagal menyimpan entri jurnal ke Firestore.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatTimestamp = (isoString?: string) => {
    if (!isoString) return '';
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return isoString;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
      {/* Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:border-teal-500/50 text-sm font-medium transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali ke Dashboard
        </button>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-teal-500/30 text-teal-300 text-xs font-mono">
            <Cloud className="w-3.5 h-3.5 text-teal-400" />
            <span>Koleksi "journals" Firestore</span>
          </div>

          <button
            onClick={() => setIsAdding(!isAdding)}
            className="px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-teal-500/20 transition"
          >
            <Plus className="w-4 h-4" />
            {isAdding ? 'Tutup Formulir' : 'Tulis Jurnal Baru'}
          </button>
        </div>
      </div>

      {/* Header Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-teal-950/60 to-slate-900 border border-teal-500/30 p-6 flex items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono font-bold text-teal-400 uppercase tracking-wider">
            Refleksi & Log Belajar Siswa • Cloud Firestore
          </span>
          <h2 className="text-2xl font-black text-white mt-1">Jurnal Perkembangan Kimia</h2>
          <p className="text-sm text-slate-300 mt-1 max-w-xl">
            Tuliskan hasil belajar, refleksi materi, rumus penting, dan durasi studi. Semua catatan tersimpan secara realtime di Cloud Firestore.
          </p>
        </div>
        <div className="w-12 h-12 rounded-xl bg-teal-500/20 text-teal-300 border border-teal-500/30 hidden sm:flex items-center justify-center shrink-0">
          <BookOpen className="w-6 h-6" />
        </div>
      </div>

      {/* Add New Entry Form Modal/Accordion */}
      {isAdding && (
        <form
          onSubmit={handleSubmit}
          className="rounded-2xl bg-slate-900 border border-teal-500/40 p-6 sm:p-7 space-y-4 animate-fade-in shadow-xl shadow-teal-950/40"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Bookmark className="w-4 h-4 text-teal-400" />
              Tulis Entri Jurnal Belajar Baru
            </h3>
            <span className="text-xs font-mono text-teal-400">Timestamp otomatis tersemat</span>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Topik Materi Kimia</label>
              <input
                type="text"
                required
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="Contoh: Titrasi Asam Kuat - Basa Lemah & Kurva pH"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-teal-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Tingkat Pemahaman</label>
              <select
                value={understandingLevel}
                onChange={(e) => setUnderstandingLevel(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-teal-400 cursor-pointer"
              >
                <option value="Paham">Paham (Menguasai Konsep)</option>
                <option value="Cukup">Cukup (Perlu Latihan Tambahan)</option>
                <option value="Perlu Diulang">Perlu Diulang (Belum Menguasai)</option>
              </select>
            </div>
          </div>

          {/* Text Content Area for the Journal Entry */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Isi Catatan Jurnal & Refleksi Belajar (Text Content)
            </label>
            <textarea
              required
              rows={4}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Tuliskan pemahaman kamu hari ini, analisis konsep kimia yang dipelajari, tantangan yang dihadapi, dan kesimpulan..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-teal-400 resize-none placeholder-slate-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Rumus / Poin Kunci (Pisahkan dengan koma)
              </label>
              <input
                type="text"
                value={formulaInput}
                onChange={(e) => setFormulaInput(e.target.value)}
                placeholder="Contoh: Ma x Va x a = Mb x Vb x b, pH = -log[H+]"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-teal-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Durasi Belajar (Menit)</label>
              <input
                type="number"
                min={5}
                max={300}
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-teal-400"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-bold cursor-pointer shadow-md transition flex items-center gap-2 disabled:opacity-60"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Menyimpan ke Firestore...</span>
                </>
              ) : (
                <>
                  <span>Simpan ke Firestore</span>
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* Journal Entries List */}
      <div className="space-y-4">
        {isLoading && (
          <div className="p-8 text-center text-slate-400 flex items-center justify-center gap-2">
            <Loader2 className="w-5 h-5 animate-spin text-teal-400" />
            <span className="text-sm">Memuat jurnal dari Firestore...</span>
          </div>
        )}

        {!isLoading && entries.length === 0 && (
          <div className="p-12 text-center rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <BookOpen className="w-10 h-10 text-slate-600 mx-auto" />
            <h4 className="text-base font-bold text-white">Belum Ada Catatan Jurnal</h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Mulai tuliskan refleksi belajarmu hari ini untuk memantau pemahaman materi kimia di Cloud Firestore.
            </p>
            <button
              onClick={() => setIsAdding(true)}
              className="px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer shadow"
            >
              <Plus className="w-3.5 h-3.5" />
              Tulis Jurnal Pertama
            </button>
          </div>
        )}

        {entries.map((entry) => {
          let badgeColor = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
          if (entry.understandingLevel === 'Cukup') {
            badgeColor = 'bg-amber-500/20 text-amber-300 border-amber-500/40';
          } else if (entry.understandingLevel === 'Perlu Diulang') {
            badgeColor = 'bg-rose-500/20 text-rose-300 border-rose-500/40';
          }

          const displayContent = entry.content || entry.notes || '';

          return (
            <div
              key={entry.id}
              className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4 hover:border-slate-700 transition"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <span className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-teal-400">
                    <BookOpen className="w-5 h-5" />
                  </span>
                  <div>
                    <h4 className="text-base font-bold text-white">{entry.topic}</h4>
                    <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 font-mono">
                      <span className="flex items-center gap-1 text-slate-300">
                        <Clock className="w-3.5 h-3.5 text-teal-400" />
                        {entry.createdAt ? formatTimestamp(entry.createdAt) : entry.date}
                      </span>
                      <span>•</span>
                      <span>{entry.durationMinutes ?? 30} Menit</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold border ${badgeColor}`}>
                    {entry.understandingLevel}
                  </span>
                </div>
              </div>

              {/* Text content */}
              <div className="text-sm text-slate-200 leading-relaxed bg-slate-950/60 p-4 rounded-xl border border-slate-800/80 whitespace-pre-line">
                {displayContent}
              </div>

              {entry.formulasLearned && entry.formulasLearned.length > 0 && (
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <span className="text-xs font-mono text-slate-400 mr-1">Rumus Kunci:</span>
                  {entry.formulasLearned.map((f, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-teal-300"
                    >
                      {f}
                    </span>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
