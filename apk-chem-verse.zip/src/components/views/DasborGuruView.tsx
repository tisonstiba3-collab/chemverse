import React, { useState, useEffect, useMemo } from 'react';
import {
  Users,
  GraduationCap,
  Sparkles,
  ArrowLeft,
  Search,
  Filter,
  Download,
  Clock,
  Award,
  BookOpen,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  TrendingUp,
  Flame,
  Activity,
  Layers,
  HelpCircle,
  RefreshCw,
  FileText,
  UserCheck,
  UserX,
} from 'lucide-react';
import {
  TeacherClassSummary,
  StudentActivitySummary,
  QuizAttempt,
} from '../../types/chemistry';
import {
  getTeacherClassesSummary,
  getClassStudentsSummary,
  getStudentActivityDetail,
  exportClassToCSV,
} from '../../services/firestoreService';
import CaraKerjaModal from '../common/CaraKerjaModal';
import KelolaKontenView from './KelolaKontenView';

interface DasborGuruViewProps {
  onBackToStudentView?: () => void;
}

type DashboardLevel = 'classes' | 'class_recap' | 'student_detail';
type DateRange = '7d' | '30d' | 'all';

export default function DasborGuruView({ onBackToStudentView }: DasborGuruViewProps) {
  // Navigation hierarchy: classes -> class_recap -> student_detail
  const [level, setLevel] = useState<DashboardLevel>('classes');
  const [selectedClass, setSelectedClass] = useState<TeacherClassSummary | null>(null);
  const [selectedStudent, setSelectedStudent] = useState<StudentActivitySummary | null>(null);

  // Filter & Data States
  const [dateRange, setDateRange] = useState<DateRange>('7d');
  const [searchQuery, setSearchQuery] = useState('');
  const [classesList, setClassesList] = useState<TeacherClassSummary[]>([]);
  const [studentsList, setStudentsList] = useState<StudentActivitySummary[]>([]);
  const [studentDetail, setStudentDetail] = useState<any | null>(null);

  // UI state
  const [teacherSection, setTeacherSection] = useState<'monitoring' | 'kelola_konten'>('monitoring');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [showCaraKerjaModal, setShowCaraKerjaModal] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'aktivitas' | 'miskonsepsi'>('aktivitas');

  // Hover state for interactive charts
  const [hoveredBarIndex, setHoveredBarIndex] = useState<number | null>(null);
  const [hoveredHeatmapCell, setHoveredHeatmapCell] = useState<{ day: string; hour: number; minutes: number } | null>(null);

  // Load Level 1: Classes Summary
  const loadClassesData = async () => {
    setIsLoading(true);
    try {
      const data = await getTeacherClassesSummary();
      setClassesList(data);
    } catch (err) {
      console.warn('Gagal memuat data kelas guru:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadClassesData();
  }, []);

  // Load Level 2: Students in selected class
  useEffect(() => {
    if (level === 'class_recap' && selectedClass) {
      setIsLoading(true);
      getClassStudentsSummary(selectedClass.name, dateRange)
        .then((data) => {
          setStudentsList(data);
          setIsLoading(false);
        })
        .catch(() => setIsLoading(false));
    }
  }, [level, selectedClass, dateRange]);

  // Load Level 3: In-depth student detail
  useEffect(() => {
    if (level === 'student_detail' && selectedStudent) {
      setIsLoading(true);
      getStudentActivityDetail(selectedStudent.studentId, dateRange === 'all' ? '30d' : dateRange)
        .then((detail) => {
          setStudentDetail(detail);
          setIsLoading(false);
        })
        .catch(() => setIsLoading(false));
    }
  }, [level, selectedStudent, dateRange]);

  // Handle drill-down actions
  const handleSelectClass = (cls: TeacherClassSummary) => {
    setSelectedClass(cls);
    setLevel('class_recap');
  };

  const handleSelectStudent = (student: StudentActivitySummary) => {
    setSelectedStudent(student);
    setLevel('student_detail');
  };

  const handleBackToClasses = () => {
    setLevel('classes');
    setSelectedClass(null);
    setSelectedStudent(null);
  };

  const handleBackToClassRecap = () => {
    setLevel('class_recap');
    setSelectedStudent(null);
  };

  // CSV Export
  const handleExportCSV = () => {
    if (!selectedClass || studentsList.length === 0) return;
    setIsExporting(true);
    try {
      exportClassToCSV(selectedClass.name, studentsList);
    } finally {
      setTimeout(() => setIsExporting(false), 500);
    }
  };

  // Filtered students by search
  const filteredStudents = useMemo(() => {
    if (!searchQuery.trim()) return studentsList;
    const q = searchQuery.toLowerCase();
    return studentsList.filter(
      (s) => s.nama.toLowerCase().includes(q) || s.email?.toLowerCase().includes(q)
    );
  }, [studentsList, searchQuery]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16 animate-fade-in text-slate-100 font-sans">
      {/* ======================================================== */}
      {/* 1. TOP BREADCRUMB & CONTEXTUAL HEADER                    */}
      {/* ======================================================== */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white/[0.03] backdrop-blur-xl border border-white/10 shadow-lg">
        {/* Breadcrumb Hierarchy */}
        <nav className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <button
            onClick={handleBackToClasses}
            className={`flex items-center gap-1.5 transition cursor-pointer ${
              level === 'classes' ? 'text-indigo-400 font-bold' : 'hover:text-slate-200'
            }`}
          >
            <GraduationCap className="w-4 h-4 text-indigo-400" />
            <span>Dasbor Guru</span>
          </button>

          {selectedClass && (
            <>
              <span className="text-slate-600">/</span>
              <button
                onClick={handleBackToClassRecap}
                className={`transition cursor-pointer ${
                  level === 'class_recap' ? 'text-cyan-400 font-bold' : 'hover:text-slate-200'
                }`}
              >
                {selectedClass.name}
              </button>
            </>
          )}

          {selectedStudent && (
            <>
              <span className="text-slate-600">/</span>
              <span className="text-emerald-400 font-bold truncate max-w-[200px]">
                {selectedStudent.nama}
              </span>
            </>
          )}
        </nav>

        {/* Global Controls & Cara Kerja Help Modal Trigger */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => setShowCaraKerjaModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs font-semibold text-cyan-300 hover:text-white transition flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
            <span>Cara Kerja Aplikasi</span>
          </button>

          {onBackToStudentView && (
            <button
              onClick={onBackToStudentView}
              className="px-3.5 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-xs font-semibold text-indigo-200 transition flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-indigo-400" />
              <span>Kembali ke Beranda Siswa</span>
            </button>
          )}
        </div>
      </div>

      {/* Sub-menu Toggle: Pemantauan vs Kelola Konten & AI Command */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-white/[0.03] border border-white/10 w-fit backdrop-blur-xl">
        <button
          onClick={() => setTeacherSection('monitoring')}
          className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition cursor-pointer flex items-center gap-2 ${
            teacherSection === 'monitoring'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Pemantauan Aktivitas Kelas</span>
        </button>

        <button
          onClick={() => setTeacherSection('kelola_konten')}
          className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition cursor-pointer flex items-center gap-2 ${
            teacherSection === 'kelola_konten'
              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-purple-600/30'
              : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'
          }`}
        >
          <span>🤖</span>
          <span>Kelola Konten & AI Command</span>
        </button>
      </div>

      {teacherSection === 'kelola_konten' ? (
        <KelolaKontenView userRole="guru" />
      ) : (
        <>
          {/* LEVEL 1: DAFTAR KELAS (GURU) */}
          {level === 'classes' && (
        <div className="space-y-6">
          {/* Hero Banner */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/80 to-slate-900 border border-indigo-500/30 p-6 sm:p-8 shadow-2xl space-y-3">
            <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-mono font-bold">
                  <Activity className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Pelacakan Aktivitas Belajar Nyata • Fase 3</span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  Pemantauan Aktivitas Belajar Kimia
                </h1>
                <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                  Pantau kehadiran aktif siswa per detik, durasi membaca modul kimia, performa pengerjaan soal latihan, serta kebiasaan belajar mingguan.
                </p>
              </div>

              <button
                onClick={loadClassesData}
                disabled={isLoading}
                className="px-4 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs text-slate-300 hover:text-white transition flex items-center gap-2 cursor-pointer self-start md:self-center"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isLoading ? 'animate-spin' : ''}`} />
                <span>Segarkan Data</span>
              </button>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-1">
              <span className="text-[11px] font-mono text-slate-400 block">Total Kelas Diampu</span>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-extrabold text-white font-mono">{classesList.length}</span>
                <Layers className="w-5 h-5 text-indigo-400" />
              </div>
              <span className="text-[10px] text-indigo-300 font-mono">Kelas X, XI, XII SMA</span>
            </div>

            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-1">
              <span className="text-[11px] font-mono text-slate-400 block">Total Siswa Terdaftar</span>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-extrabold text-white font-mono">
                  {classesList.reduce((acc, c) => acc + c.totalStudents, 0)}
                </span>
                <Users className="w-5 h-5 text-cyan-400" />
              </div>
              <span className="text-[10px] text-cyan-300 font-mono">Akun Sekolah Aktif</span>
            </div>

            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-1">
              <span className="text-[11px] font-mono text-slate-400 block">Siswa Aktif Hari Ini</span>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-extrabold text-emerald-400 font-mono">
                  {classesList.reduce((acc, c) => acc + c.activeStudentsToday, 0)}
                </span>
                <UserCheck className="w-5 h-5 text-emerald-400" />
              </div>
              <span className="text-[10px] text-emerald-300 font-mono">Terdeteksi Berinteraksi</span>
            </div>

            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-1">
              <span className="text-[11px] font-mono text-slate-400 block">Rata-rata Skor Kuis</span>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-extrabold text-amber-400 font-mono">85%</span>
                <Award className="w-5 h-5 text-amber-400" />
              </div>
              <span className="text-[10px] text-amber-300 font-mono">Evaluasi Seluruh Topik</span>
            </div>
          </div>

          {/* Cards of Classes */}
          <div className="space-y-3">
            <h2 className="text-sm font-bold uppercase tracking-wider font-mono text-slate-400 flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-cyan-400" />
              <span>Daftar Kelas yang Anda Ampu — Klik untuk Membuka Rekap</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {classesList.map((cls) => {
                const gradeColor = cls.grade === 'X' ? '#22D3EE' : cls.grade === 'XI' ? '#F97316' : '#10B981';

                return (
                  <div
                    key={cls.id}
                    onClick={() => handleSelectClass(cls)}
                    className="group relative p-6 rounded-3xl bg-white/[0.04] hover:bg-white/[0.08] backdrop-blur-2xl border border-white/10 hover:border-cyan-400/50 shadow-xl transition-all duration-300 cursor-pointer space-y-5"
                  >
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <span
                          className="text-[10px] font-mono font-bold px-2.5 py-1 rounded-lg border uppercase tracking-wider"
                          style={{
                            backgroundColor: `${gradeColor}18`,
                            borderColor: `${gradeColor}40`,
                            color: gradeColor,
                          }}
                        >
                          Fase {cls.grade === 'X' ? 'E' : 'F'} • Kelas {cls.grade}
                        </span>
                        <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition tracking-tight">
                          {cls.name}
                        </h3>
                      </div>

                      <div className="w-10 h-10 rounded-2xl bg-white/[0.05] border border-white/10 flex items-center justify-center text-slate-300 group-hover:scale-110 group-hover:text-cyan-400 transition">
                        <ChevronRight className="w-5 h-5" />
                      </div>
                    </div>

                    {/* Stats inside card */}
                    <div className="grid grid-cols-2 gap-3 pt-2 border-t border-white/10 text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono block">Total Siswa</span>
                        <span className="text-sm font-bold text-white font-mono">{cls.totalStudents} Siswa</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono block">Aktif Hari Ini</span>
                        <span className="text-sm font-bold text-emerald-400 font-mono">{cls.activeStudentsToday} Siswa</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono block">Rata-rata Belajar</span>
                        <span className="text-sm font-bold text-cyan-300 font-mono">{cls.averageReadMinutes} menit</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono block">Rata-rata Nilai</span>
                        <span className="text-sm font-bold text-amber-300 font-mono">{cls.averageQuizScore}%</span>
                      </div>
                    </div>

                    <button className="w-full py-2.5 rounded-xl bg-white/[0.06] group-hover:bg-cyan-500/20 border border-white/10 group-hover:border-cyan-400/40 text-xs font-bold text-cyan-300 transition flex items-center justify-center gap-1.5">
                      <span>Buka Rekap Kelas & Aktivitas Siswa</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* LEVEL 2: REKAP KELAS (TABEL SISWA + FILTER + EXPORT)     */}
      {/* ======================================================== */}
      {level === 'class_recap' && selectedClass && (
        <div className="space-y-6">
          {/* Level 2 Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-white/10 shadow-xl">
            <div className="space-y-1">
              <button
                onClick={handleBackToClasses}
                className="text-xs font-mono text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer mb-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Kembali ke Daftar Kelas</span>
              </button>
              <h2 className="text-2xl font-extrabold text-white tracking-tight" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Rekap Aktivitas: {selectedClass.name}
              </h2>
              <p className="text-xs text-slate-300">
                Data durasi membaca materi kimia murni, durasi pengerjaan soal, dan alarm siswa tidak aktif lebih dari 7 hari.
              </p>
            </div>

            {/* Actions: Export CSV */}
            <div className="flex items-center gap-3">
              <button
                onClick={handleExportCSV}
                disabled={isExporting || studentsList.length === 0}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs flex items-center gap-2 transition cursor-pointer shadow-lg shadow-emerald-600/30 disabled:opacity-50"
              >
                <Download className="w-4 h-4" />
                <span>{isExporting ? 'Mengunduh...' : 'Export Rekap CSV'}</span>
              </button>
            </div>
          </div>

          {/* Filter Bar & Search */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl bg-white/[0.03] border border-white/10">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari nama siswa atau email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 rounded-xl bg-white/[0.05] border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400/60"
              />
            </div>

            {/* Date Range Selector */}
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-white/[0.04] border border-white/10 text-xs font-mono">
              <span className="px-2 text-slate-400 flex items-center gap-1 text-[11px]">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>Rentang:</span>
              </span>
              {(['7d', '30d', 'all'] as DateRange[]).map((r) => (
                <button
                  key={r}
                  onClick={() => setDateRange(r)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    dateRange === r
                      ? 'bg-cyan-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {r === '7d' ? '7 Hari Terakhir' : r === '30d' ? '30 Hari Terakhir' : 'Semua Waktu'}
                </button>
              ))}
            </div>
          </div>

          {/* Students Table */}
          <div className="rounded-3xl bg-white/[0.03] backdrop-blur-2xl border border-white/10 shadow-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-white/10 bg-white/[0.02] text-slate-400 font-mono uppercase text-[11px] tracking-wider">
                    <th className="py-4 px-6">Nama Siswa</th>
                    <th className="py-4 px-4">Menit Belajar (Materi)</th>
                    <th className="py-4 px-4">Menit Soal (Kuis)</th>
                    <th className="py-4 px-4">Rata-rata Nilai</th>
                    <th className="py-4 px-4">Terakhir Aktif</th>
                    <th className="py-4 px-4">Status</th>
                    <th className="py-4 px-6 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredStudents.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-slate-400">
                        Tidak ada siswa yang sesuai dengan filter pencarian.
                      </td>
                    </tr>
                  ) : (
                    filteredStudents.map((student) => {
                      return (
                        <tr
                          key={student.studentId}
                          className="hover:bg-white/[0.03] transition-colors group"
                        >
                          {/* Nama Siswa */}
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center justify-center font-bold font-mono text-sm shrink-0">
                                {student.nama.charAt(0)}
                              </div>
                              <div>
                                <span className="font-bold text-white block text-sm group-hover:text-cyan-300 transition">
                                  {student.nama}
                                </span>
                                <span className="text-[11px] text-slate-400 font-mono">
                                  {student.email}
                                </span>
                              </div>
                            </div>
                          </td>

                          {/* Menit Belajar */}
                          <td className="py-4 px-4 font-mono font-bold text-slate-200">
                            <span className="flex items-center gap-1.5 text-cyan-300">
                              <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
                              <span>{student.totalReadMinutes} m</span>
                            </span>
                          </td>

                          {/* Menit Soal */}
                          <td className="py-4 px-4 font-mono font-bold text-slate-200">
                            <span className="flex items-center gap-1.5 text-purple-300">
                              <Clock className="w-3.5 h-3.5 text-purple-400" />
                              <span>{student.totalQuizMinutes} m</span>
                            </span>
                          </td>

                          {/* Rata-rata Nilai */}
                          <td className="py-4 px-4">
                            <span
                              className={`px-2.5 py-1 rounded-lg font-mono font-bold text-xs inline-block ${
                                student.averageQuizScore >= 80
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                  : student.averageQuizScore >= 65
                                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                  : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                              }`}
                            >
                              {student.averageQuizScore}%
                            </span>
                          </td>

                          {/* Terakhir Aktif */}
                          <td className="py-4 px-4 text-slate-300 font-mono text-[11px]">
                            {student.lastActiveRelative}
                          </td>

                          {/* Status Aktif / Tidak Aktif (> 7 hari) */}
                          <td className="py-4 px-4">
                            {student.isActiveRecent ? (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono font-bold">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                                <span>Aktif</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-mono font-bold shadow-sm">
                                <AlertTriangle className="w-3 h-3 text-rose-400 shrink-0" />
                                <span>Tidak Aktif (&gt; 7 Hari)</span>
                              </span>
                            )}
                          </td>

                          {/* Aksi */}
                          <td className="py-4 px-6 text-right">
                            <button
                              onClick={() => handleSelectStudent(student)}
                              className="px-3.5 py-1.5 rounded-xl bg-white/[0.05] hover:bg-cyan-500/20 border border-white/10 hover:border-cyan-400/40 text-xs font-bold text-cyan-300 hover:text-white transition cursor-pointer inline-flex items-center gap-1"
                            >
                              <span>Detail Siswa</span>
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* LEVEL 3: DETAIL SISWA (GRAFIK + HEATMAP + TIMELINE)      */}
      {/* ======================================================== */}
      {level === 'student_detail' && selectedStudent && (
        <div className="space-y-6">
          {/* Header & Back Button */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 border border-white/10 shadow-xl">
            <div className="space-y-2">
              <button
                onClick={handleBackToClassRecap}
                className="text-xs font-mono text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>← Kembali ke Rekap {selectedClass?.name || 'Kelas'}</span>
              </button>

              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center justify-center font-extrabold text-xl font-mono">
                  {selectedStudent.nama.charAt(0)}
                </div>
                <div>
                  <h2 className="text-2xl font-extrabold text-white tracking-tight" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                    {selectedStudent.nama}
                  </h2>
                  <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
                    <span>{selectedStudent.kelas}</span>
                    <span>•</span>
                    <span className="text-slate-400">{selectedStudent.email}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Status indicator */}
            <div className="flex items-center gap-3">
              {selectedStudent.isActiveRecent ? (
                <span className="px-3 py-1.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-mono font-bold flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Aktif ({selectedStudent.lastActiveRelative})</span>
                </span>
              ) : (
                <span className="px-3 py-1.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-mono font-bold flex items-center gap-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                  <span>Tidak Aktif (&gt; 7 Hari)</span>
                </span>
              )}
            </div>
          </div>

          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 space-y-1">
              <span className="text-[11px] font-mono text-slate-400 block">Total Waktu Membaca</span>
              <span className="text-2xl font-extrabold text-cyan-400 font-mono">
                {studentDetail?.totalReadMinutes ?? selectedStudent.totalReadMinutes} m
              </span>
              <span className="text-[10px] text-slate-400 block">Durasi murni materi aktif</span>
            </div>

            <div className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 space-y-1">
              <span className="text-[11px] font-mono text-slate-400 block">Waktu Mengerjakan Kuis</span>
              <span className="text-2xl font-extrabold text-purple-400 font-mono">
                {studentDetail?.totalQuizMinutes ?? selectedStudent.totalQuizMinutes} m
              </span>
              <span className="text-[10px] text-slate-400 block">Latihan & evaluasi TKA</span>
            </div>

            <div className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 space-y-1">
              <span className="text-[11px] font-mono text-slate-400 block">Rata-rata Nilai</span>
              <span className="text-2xl font-extrabold text-amber-400 font-mono">
                {studentDetail?.avgQuizScore ?? selectedStudent.averageQuizScore}%
              </span>
              <span className="text-[10px] text-slate-400 block">Dari seluruh kuis</span>
            </div>

            <div className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 space-y-1">
              <span className="text-[11px] font-mono text-slate-400 block">Kuis Terselesaikan</span>
              <span className="text-2xl font-extrabold text-emerald-400 font-mono">
                {studentDetail?.totalQuizzes ?? selectedStudent.totalQuizzesTaken}
              </span>
              <span className="text-[10px] text-slate-400 block">Percobaan terverifikasi</span>
            </div>
          </div>

          {/* ======================================================== */}
          {/* SECTION 1: GRAFIK BATANG (MENIT BELAJAR PER HARI)        */}
          {/* ======================================================== */}
          <div className="p-6 rounded-3xl bg-white/[0.03] backdrop-blur-2xl border border-white/10 shadow-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-cyan-400" />
                  <span>Grafik Menit Belajar per Hari</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Pembagian waktu antara membaca konsep materi kimia dan menyelesaikan kuis.
                </p>
              </div>

              {/* Legend */}
              <div className="flex items-center gap-4 text-xs font-mono">
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-cyan-400 inline-block" />
                  <span>Membaca Materi</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-purple-500 inline-block" />
                  <span>Latihan Soal</span>
                </span>
              </div>
            </div>

            {/* Interactive SVG Bar Chart with Hover Tooltip */}
            <div className="pt-4 pb-2">
              <div className="h-56 w-full flex items-end gap-2 sm:gap-4 relative pt-6 border-b border-white/10">
                {/* Horizontal reference grid lines */}
                <div className="absolute inset-x-0 top-0 border-b border-white/5 pointer-events-none" />
                <div className="absolute inset-x-0 top-1/2 border-b border-white/5 pointer-events-none" />

                {(studentDetail?.dailyData || []).map((dayItem: any, idx: number) => {
                  const maxMinutes = 60; // scale cap for clean visualization
                  const readHeight = Math.min(100, (dayItem.readMinutes / maxMinutes) * 100);
                  const quizHeight = Math.min(100, (dayItem.quizMinutes / maxMinutes) * 100);
                  const isHovered = hoveredBarIndex === idx;

                  return (
                    <div
                      key={idx}
                      className="flex-1 flex flex-col items-center h-full justify-end relative group cursor-pointer"
                      onMouseEnter={() => setHoveredBarIndex(idx)}
                      onMouseLeave={() => setHoveredBarIndex(null)}
                    >
                      {/* Floating tooltip */}
                      {isHovered && (
                        <div className="absolute bottom-full mb-2 z-30 p-2.5 rounded-xl bg-slate-900 border border-cyan-400/60 shadow-xl text-[11px] font-mono whitespace-nowrap pointer-events-none text-slate-200">
                          <span className="font-bold text-white block pb-1 border-b border-white/10">
                            {dayItem.dayLabel}
                          </span>
                          <span className="text-cyan-300 block">Membaca: {dayItem.readMinutes} menit</span>
                          <span className="text-purple-300 block">Kuis: {dayItem.quizMinutes} menit</span>
                          <span className="text-white font-bold block pt-0.5">Total: {dayItem.totalMinutes} menit</span>
                        </div>
                      )}

                      {/* Stacked bar container */}
                      <div className="w-full max-w-[42px] flex flex-col justify-end rounded-t-xl overflow-hidden transition-all duration-300 group-hover:scale-105">
                        {/* Quiz portion (purple) */}
                        <div
                          style={{ height: `${quizHeight}%` }}
                          className="w-full bg-purple-500/80 group-hover:bg-purple-400 transition-colors"
                        />
                        {/* Reading portion (cyan) */}
                        <div
                          style={{ height: `${readHeight}%` }}
                          className="w-full bg-cyan-500/80 group-hover:bg-cyan-400 transition-colors"
                        />
                      </div>

                      {/* Day Label */}
                      <span className="text-[10px] font-mono text-slate-400 pt-2 truncate max-w-full">
                        {dayItem.dayLabel.split(',')[0]}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* ======================================================== */}
          {/* SECTION 2: HEATMAP HARI x JAM (KEBIASAAN BELAJAR)        */}
          {/* ======================================================== */}
          <div className="p-6 rounded-3xl bg-white/[0.03] backdrop-blur-2xl border border-white/10 shadow-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Clock className="w-4 h-4 text-emerald-400" />
                  <span>Heatmap Kebiasaan Waktu Belajar (Hari × Jam)</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Warna lebih terang menunjukkan intensitas belajar tertinggi siswa pada jam tersebut.
                </p>
              </div>

              {/* Intensity Scale Indicator */}
              <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                <span>Santai</span>
                <span className="w-3 h-3 rounded bg-white/[0.03] border border-white/5" />
                <span className="w-3 h-3 rounded bg-emerald-950/80 border border-emerald-800" />
                <span className="w-3 h-3 rounded bg-emerald-700" />
                <span className="w-3 h-3 rounded bg-emerald-500" />
                <span className="w-3 h-3 rounded bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.5)]" />
                <span>Puncak Aktif</span>
              </div>
            </div>

            {/* Highlighted Pattern Callout */}
            <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-xs text-cyan-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>
                <strong>Pola Terbanyak:</strong> Siswa ini paling rajin dan konsisten belajar pada <strong>Senin s.d. Kamis malam (pukul 19.00 – 21.00 WIB)</strong>.
              </span>
            </div>

            {/* Heatmap Grid */}
            <div className="overflow-x-auto pb-2">
              <div className="min-w-[700px] space-y-1.5 font-mono">
                {/* Hours row header */}
                <div className="flex items-center text-[10px] text-slate-500 pl-16">
                  {Array.from({ length: 24 }, (_, h) => (
                    <div key={h} className="flex-1 text-center">
                      {h % 3 === 0 ? `${h < 10 ? '0' : ''}${h}` : ''}
                    </div>
                  ))}
                </div>

                {/* Days rows */}
                {(studentDetail?.heatmapData || []).map((row: any) => (
                  <div key={row.day} className="flex items-center gap-2">
                    <span className="w-14 text-xs font-semibold text-slate-300 shrink-0 text-right pr-2">
                      {row.day}
                    </span>

                    <div className="flex-1 flex items-center gap-1">
                      {row.hours.map((cell: any) => {
                        let cellBg = 'bg-white/[0.03] border-white/5';
                        if (cell.intensity === 1) cellBg = 'bg-emerald-950/70 border-emerald-900/60';
                        if (cell.intensity === 2) cellBg = 'bg-emerald-800 border-emerald-700';
                        if (cell.intensity === 3) cellBg = 'bg-emerald-500 text-slate-950';
                        if (cell.intensity === 4) cellBg = 'bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.6)] text-slate-950';

                        return (
                          <div
                            key={cell.hour}
                            onMouseEnter={() => setHoveredHeatmapCell({ day: row.day, hour: cell.hour, minutes: cell.minutes })}
                            onMouseLeave={() => setHoveredHeatmapCell(null)}
                            className={`flex-1 h-6 rounded-md border transition-transform hover:scale-125 hover:z-20 cursor-pointer ${cellBg}`}
                            title={`${row.day} ${cell.hour}:00 - ${cell.minutes} menit`}
                          />
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Hovered cell info */}
            {hoveredHeatmapCell && (
              <div className="text-xs font-mono text-cyan-300 pt-1">
                📅 {hoveredHeatmapCell.day} jam {hoveredHeatmapCell.hour}:00 – {hoveredHeatmapCell.hour + 1}:00: <strong>{hoveredHeatmapCell.minutes} menit belajar aktif</strong>
              </div>
            )}
          </div>

          {/* ======================================================== */}
          {/* SECTION 3: TIMELINE SESI AKTIVITAS & DAFTAR KUIS         */}
          {/* ======================================================== */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Timeline Sesi Aktivitas Belajar */}
            <div className="p-6 rounded-3xl bg-white/[0.03] backdrop-blur-2xl border border-white/10 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <span>Timeline Sesi Belajar Real-Time</span>
                </h3>
                <span className="text-[10px] font-mono text-slate-400">Tersinkronisasi 30s</span>
              </div>

              <div className="space-y-3">
                {(studentDetail?.timelineEntries || []).map((tl: any) => (
                  <div
                    key={tl.id}
                    className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/5 hover:border-white/20 transition space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-slate-300">
                        {tl.dayDateStr} ({tl.timeRange} WIB)
                      </span>
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                        {tl.durationMinutes} menit
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                          tl.type === 'reading'
                            ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                            : 'bg-purple-500/15 text-purple-300 border border-purple-500/30'
                        }`}
                      >
                        {tl.typeLabel}
                      </span>
                      <span className="text-xs font-semibold text-white truncate">
                        {tl.title}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Riwayat Kuis & Skor */}
            <div className="p-6 rounded-3xl bg-white/[0.03] backdrop-blur-2xl border border-white/10 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Award className="w-4 h-4 text-amber-400" />
                  <span>Daftar Kuis yang Dikerjakan</span>
                </h3>
                <span className="text-[10px] font-mono text-slate-400">Hasil Otomatis</span>
              </div>

              <div className="space-y-3">
                {(studentDetail?.quizAttempts || []).map((attempt: QuizAttempt) => (
                  <div
                    key={attempt.id}
                    className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/5 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white truncate">
                        {attempt.quiz_title}
                      </span>
                      <span className="text-sm font-mono font-extrabold text-amber-300">
                        {attempt.score}/{attempt.max_score}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-white/5">
                      <span className="text-emerald-400">{attempt.correct} Benar</span>
                      <span className="text-rose-400">{attempt.wrong} Salah</span>
                      <span>Durasi: {Math.round(attempt.duration_sec / 60)} m</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
      </>
      )}

      {/* ======================================================== */}
      {/* CARA KERJA MODAL                                         */}
      {/* ======================================================== */}
      <CaraKerjaModal
        isOpen={showCaraKerjaModal}
        onClose={() => setShowCaraKerjaModal(false)}
      />
    </div>
  );
}
