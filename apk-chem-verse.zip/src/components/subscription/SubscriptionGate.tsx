import React, { useState, useEffect } from 'react';
import {
  Key,
  AlertTriangle,
  CheckCircle2,
  Lock,
  RefreshCw,
  Clock,
  UserCheck,
  UserX,
  Sparkles,
} from 'lucide-react';
import {
  UserSubscriptionRecord,
  checkStudentSubscriptionStatus,
  adminVerifyStudent,
} from '../../services/supabaseService';
import OnboardingIdentityView from '../onboarding/OnboardingIdentityView';
import OnboardingPaymentView from '../onboarding/OnboardingPaymentView';
import OnboardingPendingView from '../onboarding/OnboardingPendingView';

interface SubscriptionGateProps {
  onAccessGranted: (record: UserSubscriptionRecord) => void;
}

export default function SubscriptionGate({ onAccessGranted }: SubscriptionGateProps) {
  // Step navigation: 'identity' | 'payment' | 'pending' | 'admin_panel'
  const [step, setStep] = useState<'identity' | 'payment' | 'pending' | 'admin_panel'>('identity');

  // Admin Verification State (when URL contains ?admin_verify=...)
  const [adminVerifyId, setAdminVerifyId] = useState<string | null>(null);
  const [adminToken, setAdminToken] = useState<string | null>(null);
  const [adminStudentDoc, setAdminStudentDoc] = useState<UserSubscriptionRecord | null>(null);
  const [adminActionMsg, setAdminActionMsg] = useState<string | null>(null);
  const [isAdminActionLoading, setIsAdminActionLoading] = useState(false);
  const [adminFetchLoading, setAdminFetchLoading] = useState(false);
  const [adminFetchError, setAdminFetchError] = useState<string | null>(null);

  // Admin Password Gate State (Default: 121215)
  const ADMIN_PASSWORD = '121215';
  const [isAdminVerified, setIsAdminVerified] = useState<boolean>(
    () => sessionStorage.getItem('chemverse_admin_verified') === 'true'
  );
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [adminPasswordError, setAdminPasswordError] = useState<string | null>(null);

  // Function to load student details for admin panel
  const loadAdminStudentData = async (verifyId: string) => {
    setAdminFetchLoading(true);
    setAdminFetchError(null);

    try {
      const fetchPromise = checkStudentSubscriptionStatus(verifyId);
      const timeoutPromise = new Promise<null>((_, reject) =>
        setTimeout(() => reject(new Error('Koneksi ke Supabase Cloud batas waktu (8s).')), 8000)
      );

      const record = await Promise.race([fetchPromise, timeoutPromise]);

      setAdminFetchLoading(false);
      if (record) {
        setAdminStudentDoc(record);
        setAdminFetchError(null);
      } else {
        setAdminFetchError(
          `Data siswa dengan ID "${verifyId}" tidak ditemukan di database Supabase Cloud maupun penyimpanan lokal.`
        );
      }
    } catch (err: any) {
      setAdminFetchLoading(false);
      setAdminFetchError(
        `Gagal memuat data dari Supabase: ${err?.message || 'Error jaringan'}.`
      );
    }
  };

  const handleAdminPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPasswordInput.trim() === ADMIN_PASSWORD) {
      setIsAdminVerified(true);
      sessionStorage.setItem('chemverse_admin_verified', 'true');
      setAdminPasswordError(null);
      if (adminVerifyId) {
        loadAdminStudentData(adminVerifyId);
      }
    } else {
      setAdminPasswordError('Akses Ditolak! Anda bukan Admin.');
    }
  };

  // 1. Initial Load & Magic Link Detection
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const verifyId = params.get('admin_verify');
    const token = params.get('token');

    if (verifyId) {
      setAdminVerifyId(verifyId);
      setAdminToken(token || '');
      setStep('admin_panel');
      if (sessionStorage.getItem('chemverse_admin_verified') === 'true') {
        setIsAdminVerified(true);
        loadAdminStudentData(verifyId);
      }
      return;
    }

    // Cek apakah siswa sudah memiliki identitas atau status pending
    const savedSubId = localStorage.getItem('chemverse_student_sub_id');
    const savedIdentity = localStorage.getItem('chemverse_student_identity');

    if (savedSubId) {
      checkStudentSubscriptionStatus(savedSubId).then((rec) => {
        if (rec) {
          if (rec.status === 'active') {
            onAccessGranted(rec);
          } else {
            setStep('pending');
          }
        } else if (savedIdentity) {
          setStep('payment');
        } else {
          setStep('identity');
        }
      });
    } else if (savedIdentity) {
      setStep('payment');
    } else {
      setStep('identity');
    }
  }, [onAccessGranted]);

  // Handle Admin Action (Activate or Lock)
  const handleAdminAction = async (action: 'activate' | 'lock') => {
    if (!adminVerifyId) return;
    setIsAdminActionLoading(true);
    setAdminActionMsg(null);

    try {
      const res = await adminVerifyStudent(adminVerifyId, adminToken || '', action);
      setAdminActionMsg(res.message);
      if (res.record) {
        setAdminStudentDoc(res.record);
      }
    } catch (e: any) {
      setAdminActionMsg(`Gagal memproses aksi admin: ${e?.message || 'Error'}`);
    } finally {
      setIsAdminActionLoading(false);
    }
  };

  // ========================================================
  // ROUTING: HALAMAN 1 (IDENTITAS)
  // ========================================================
  if (step === 'identity') {
    return (
      <OnboardingIdentityView
        onNext={() => setStep('payment')}
      />
    );
  }

  // ========================================================
  // ROUTING: HALAMAN 2 (SISTEM PEMBAYARAN & WHATSAPP)
  // ========================================================
  if (step === 'payment') {
    return (
      <OnboardingPaymentView
        onBack={() => setStep('identity')}
        onPaid={() => setStep('pending')}
      />
    );
  }

  // ========================================================
  // ROUTING: HALAMAN 3 (PENDING GATE + POLLING 3 DETIK)
  // ========================================================
  if (step === 'pending') {
    return (
      <OnboardingPendingView
        onEditIdentity={() => setStep('identity')}
        onVerified={(record) => onAccessGranted(record)}
      />
    );
  }

  // ========================================================
  // ROUTING: HALAMAN PANEL ADMIN (MAGIC LINK DARI WHATSAPP)
  // ========================================================
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#040714]/95 backdrop-blur-xl overflow-y-auto animate-fade-in text-left font-sans">
      <div className="w-full max-w-xl rounded-3xl bg-slate-900 border-2 border-purple-500/50 p-6 sm:p-8 space-y-6 shadow-2xl relative my-auto">
        <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/60 to-slate-900 border border-purple-500/40 space-y-1">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-purple-300 uppercase">
            <Key className="w-4 h-4 text-purple-400" />
            <span>Panel Verifikasi Admin Chemverse</span>
          </div>
          <p className="text-xs text-slate-300">
            Terdeteksi link verifikasi pembayaran dari WhatsApp Admin (+62 821-4575-0970).
          </p>
        </div>

        {/* 🔒 Gerbang Password Admin (121215) */}
        {!isAdminVerified ? (
          <div className="p-6 rounded-3xl bg-slate-950 border-2 border-purple-500/50 space-y-4 text-left shadow-2xl animate-fade-in">
            <div className="flex items-center gap-3 border-b border-purple-500/30 pb-3">
              <div className="w-10 h-10 rounded-2xl bg-purple-500/20 border border-purple-400/40 flex items-center justify-center text-purple-300 font-bold shrink-0">
                <Key className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white">Gerbang Password Admin</h3>
                <p className="text-[11px] text-purple-300 font-mono">Verifikasi Keamanan Akses Magic Link</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Masukkan Password Admin untuk melanjutkan verifikasi dan melihat data siswa.
            </p>

            {adminPasswordError && (
              <div className="p-3.5 rounded-2xl bg-rose-500/20 border-2 border-rose-500/50 text-rose-300 text-xs font-mono font-bold flex items-center gap-2 animate-fade-in">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{adminPasswordError}</span>
              </div>
            )}

            <form onSubmit={handleAdminPasswordSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-mono font-bold text-slate-300 mb-1">
                  Password Admin Rahasia:
                </label>
                <input
                  type="password"
                  required
                  autoFocus
                  value={adminPasswordInput}
                  onChange={(e) => setAdminPasswordInput(e.target.value)}
                  placeholder="Ketik password admin..."
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-purple-500/40 text-white font-mono text-sm focus:outline-none focus:border-purple-400"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs tracking-wider uppercase transition cursor-pointer shadow-lg shadow-purple-600/30"
              >
                Buka Panel Admin
              </button>
            </form>
          </div>
        ) : (
          /* Setelah Password Terverifikasi: Tampilkan Data & Tombol Aktivasi */
          <div className="space-y-4">
            {adminFetchLoading ? (
              <div className="p-8 text-center space-y-3">
                <RefreshCw className="w-8 h-8 text-purple-400 animate-spin mx-auto" />
                <p className="text-xs font-mono text-slate-400">Menghubungkan ke Supabase Cloud...</p>
              </div>
            ) : adminFetchError ? (
              <div className="p-4 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-200 text-xs space-y-3">
                <div className="flex items-center gap-2 font-bold font-mono">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>Gagal Memuat Data Siswa:</span>
                </div>
                <p className="font-sans leading-relaxed">{adminFetchError}</p>
                <button
                  onClick={() => adminVerifyId && loadAdminStudentData(adminVerifyId)}
                  className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs transition cursor-pointer"
                >
                  Coba Muat Ulang
                </button>
              </div>
            ) : adminStudentDoc ? (
              <div className="p-5 rounded-2xl bg-slate-950 border border-purple-500/30 space-y-4 text-xs">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <span className="font-mono text-slate-400">Status Saat Ini:</span>
                  <span
                    className={`px-3 py-1 rounded-full font-mono font-bold text-xs ${
                      adminStudentDoc.status === 'active'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : adminStudentDoc.status === 'locked'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    }`}
                  >
                    {adminStudentDoc.status.toUpperCase()}
                  </span>
                </div>

                <div className="space-y-2 font-mono">
                  <p><span className="text-slate-400">Nama Siswa:</span> <strong className="text-white font-sans text-sm">{adminStudentDoc.nama}</strong></p>
                  <p><span className="text-slate-400">Kelas:</span> <strong className="text-white">{adminStudentDoc.kelas}</strong></p>
                  <p><span className="text-slate-400">Sekolah:</span> <strong className="text-white">{adminStudentDoc.sekolah}</strong></p>
                  <p><span className="text-slate-400">ID Siswa:</span> <span className="text-purple-300">{adminStudentDoc.id}</span></p>
                  {adminStudentDoc.expires_at && (
                    <p><span className="text-slate-400">Masa Aktif:</span> <span className="text-emerald-300">{new Date(adminStudentDoc.expires_at).toLocaleDateString('id-ID')}</span></p>
                  )}
                </div>

                {adminActionMsg && (
                  <div className="p-3.5 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-200 text-xs font-mono font-bold animate-fade-in">
                    {adminActionMsg}
                  </div>
                )}

                <div className="pt-2 flex flex-col sm:flex-row gap-3">
                  <button
                    onClick={() => handleAdminAction('activate')}
                    disabled={isAdminActionLoading}
                    className="flex-1 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs font-mono tracking-wide transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-600/30"
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>Aktifkan Akses Siswa (60 Hari)</span>
                  </button>

                  <button
                    onClick={() => handleAdminAction('lock')}
                    disabled={isAdminActionLoading}
                    className="px-4 py-3 rounded-xl bg-rose-950/70 hover:bg-rose-900 border border-rose-500/40 text-rose-300 font-bold text-xs font-mono transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <UserX className="w-4 h-4" />
                    <span>Kunci Akses</span>
                  </button>
                </div>
              </div>
            ) : null}

            <div className="flex justify-between items-center pt-2">
              <button
                onClick={() => setStep('identity')}
                className="text-xs text-slate-400 hover:text-white font-mono transition cursor-pointer"
              >
                ← Kembali ke Halaman Siswa
              </button>
              <button
                onClick={() => {
                  sessionStorage.removeItem('chemverse_admin_verified');
                  setIsAdminVerified(false);
                }}
                className="text-xs text-rose-400 hover:text-rose-300 font-mono transition cursor-pointer"
              >
                Kunci Ulang Panel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
