/**
 * @file src/services/studentVerificationStore.ts
 * @description Store manajemen akun siswa, tautan verifikasi admin, dan jejak aktivasi (ActivationLog).
 */

import { StudentAccount, ActivationLog } from '../shared/types';
import { db as firestoreDb } from '../lib/firebase';
import { doc, getDoc, setDoc, collection, query, where, getDocs } from 'firebase/firestore';
import {
  queryStudentFromSupabaseByVerifyParams,
  syncStudentToSupabaseWithVerifyTokens,
  updateStudentStatusInSupabase,
} from './supabaseService';

const STORAGE_KEYS = {
  ACCOUNTS: 'chemverse_student_accounts',
  LOGS: 'chemverse_activation_logs',
};

/**
 * Generate UUID v4 standar untuk parameter admin_verify
 */
export function generateAdminVerifyId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Generate 20 karakter alfanumerik acak [a-z0-9] untuk token aktivasi
 */
export function generateActivationToken(): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let token = '';
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const bytes = new Uint8Array(20);
    crypto.getRandomValues(bytes);
    for (let i = 0; i < 20; i++) {
      token += chars[bytes[i] % chars.length];
    }
    return token;
  }
  for (let i = 0; i < 20; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
}

/**
 * Mengambil semua akun siswa yang tersimpan di localStorage
 */
export function getAllStudentAccounts(): StudentAccount[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (err) {
    console.warn('Gagal membaca student accounts dari localStorage:', err);
  }
  return [];
}

/**
 * Menyimpan seluruh daftar akun siswa ke localStorage
 */
export function saveAllStudentAccounts(accounts: StudentAccount[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));
  } catch (err) {
    console.warn('Gagal menyimpan student accounts ke localStorage:', err);
  }
}

/**
 * Menyimpan atau memperbarui satu akun siswa
 */
export function saveStudentAccount(account: StudentAccount): void {
  const accounts = getAllStudentAccounts();
  const index = accounts.findIndex((a) => a.id === account.id || a.adminVerifyId === account.adminVerifyId);

  // Pastikan field alias tetap sinkron
  const synchronizedAccount: StudentAccount = {
    ...account,
    nama: account.name || account.nama,
    kelas: account.classId || account.kelas,
    sekolah: account.school || account.sekolah,
  };

  if (index >= 0) {
    accounts[index] = synchronizedAccount;
  } else {
    accounts.push(synchronizedAccount);
  }
  saveAllStudentAccounts(accounts);

  // Sinkronisasi backward-compatibility dengan legacy key
  try {
    localStorage.setItem(`chemverse_sub_${synchronizedAccount.id}`, JSON.stringify({
      id: synchronizedAccount.id,
      nama: synchronizedAccount.name,
      kelas: synchronizedAccount.classId,
      sekolah: synchronizedAccount.school,
      status: synchronizedAccount.status,
      token: synchronizedAccount.activationToken,
      adminVerifyId: synchronizedAccount.adminVerifyId,
      activationToken: synchronizedAccount.activationToken,
      verifyDecision: synchronizedAccount.verifyDecision,
      adminVerifyUsedAt: synchronizedAccount.adminVerifyUsedAt,
    }));
  } catch (e) {
    // ignore
  }

  // 1. Sinkronisasi ke Supabase Remote (memastikan admin di HP / perangkat berbeda dapat membaca data siswa)
  try {
    syncStudentToSupabaseWithVerifyTokens(synchronizedAccount).catch((err) => {
      console.warn('Background sync ke Supabase dilewati:', err);
    });
  } catch (e) {
    // ignore
  }

  // 2. Sinkronisasi ke Firestore
  try {
    const studentRef = doc(firestoreDb, 'students', synchronizedAccount.id);
    setDoc(studentRef, {
      id: synchronizedAccount.id,
      userId: synchronizedAccount.id,
      name: synchronizedAccount.name,
      namaLengkap: synchronizedAccount.name,
      nama: synchronizedAccount.name,
      classId: synchronizedAccount.classId,
      kelas: synchronizedAccount.classId,
      school: synchronizedAccount.school,
      sekolah: synchronizedAccount.school,
      email: synchronizedAccount.email || '',
      whatsapp: synchronizedAccount.whatsapp || '',
      status: synchronizedAccount.status,
      adminVerifyId: synchronizedAccount.adminVerifyId,
      activationToken: synchronizedAccount.activationToken,
      adminVerifyCreatedAt: synchronizedAccount.adminVerifyCreatedAt,
      adminVerifyUsedAt: synchronizedAccount.adminVerifyUsedAt || null,
      verifyDecision: synchronizedAccount.verifyDecision || null,
      rejectedReason: synchronizedAccount.rejectedReason || '',
      paymentProofSentAt: synchronizedAccount.paymentProofSentAt || null,
      updatedAt: new Date().toISOString(),
    }, { merge: true }).catch((err) => {
      console.warn('Background sync ke Firestore dilewati:', err);
    });
  } catch (e) {
    // ignore
  }
}

/**
 * Mencari siswa secara lokal dari localStorage (sinkron)
 */
export function findStudentByVerifyParamsLocal(
  adminVerifyId: string | null | undefined,
  token: string | null | undefined
): StudentAccount | null {
  if (!adminVerifyId || !token) {
    return null;
  }

  const cleanVerifyId = adminVerifyId.trim();
  const cleanToken = token.trim();

  if (!cleanVerifyId || !cleanToken) {
    return null;
  }

  // 1. Cari dari daftar akun terkelola
  const accounts = getAllStudentAccounts();
  const found = accounts.find(
    (acc) =>
      acc.adminVerifyId === cleanVerifyId &&
      acc.activationToken === cleanToken
  );

  if (found) {
    return found;
  }

  // 2. Fallback pemeriksaan di legacy storage jika akun tersimpan sebelum update
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('chemverse_sub_') || key === 'chemverse_student_identity')) {
        const val = localStorage.getItem(key);
        if (val) {
          const parsed = JSON.parse(val);
          // Cek kecocokan KEDUA parameter secara mutlak
          const matchesVerify =
            parsed.adminVerifyId === cleanVerifyId ||
            parsed.id === cleanVerifyId;
          const matchesToken =
            parsed.activationToken === cleanToken ||
            parsed.token === cleanToken;

          if (matchesVerify && matchesToken) {
            const mappedAccount: StudentAccount = {
              id: parsed.id || cleanVerifyId,
              name: parsed.nama || parsed.name || 'Siswa',
              classId: parsed.kelas || parsed.classId || 'Kelas 11 SMA',
              school: parsed.sekolah || parsed.school || 'SMA',
              nama: parsed.nama || parsed.name,
              kelas: parsed.kelas || parsed.classId,
              sekolah: parsed.sekolah || parsed.school,
              email: parsed.email,
              whatsapp: parsed.whatsapp,
              status: parsed.status === 'active' ? 'active' : parsed.status === 'rejected' ? 'rejected' : 'pending_verify',
              registeredAt: parsed.registeredAt || Date.now(),
              activatedAt: parsed.activatedAt,
              adminVerifyId: cleanVerifyId,
              activationToken: cleanToken,
              adminVerifyCreatedAt: parsed.adminVerifyCreatedAt || Date.now(),
              adminVerifyUsedAt: parsed.adminVerifyUsedAt,
              verifyDecision: parsed.verifyDecision || null,
              rejectedReason: parsed.rejectedReason,
              paymentProofSentAt: parsed.paymentProofSentAt,
            };
            saveStudentAccount(mappedAccount);
            return mappedAccount;
          }
        }
      }
    }
  } catch (err) {
    console.warn('Kesalahan saat memeriksa local storage:', err);
  }

  return null;
}

/**
 * Mencari siswa berdasarkan adminVerifyId DAN token.
 * Sesuai Permintaan Bugfix 2: Membaca langsung dari database Supabase (cross-device verification).
 */
export async function findStudentByVerifyParams(
  adminVerifyId: string | null | undefined,
  token: string | null | undefined
): Promise<StudentAccount | null> {
  return fetchStudentByVerifyParams(adminVerifyId, token);
}

/**
 * Pencarian async student dengan pembacaan database Supabase & Firestore jika dibuka dari HP admin
 */
export async function fetchStudentByVerifyParams(
  adminVerifyId: string | null | undefined,
  token: string | null | undefined
): Promise<StudentAccount | null> {
  if (!adminVerifyId || !token) return null;
  const cleanVerifyId = adminVerifyId.trim();
  const cleanToken = token.trim();
  if (!cleanVerifyId || !cleanToken) return null;

  // 1. Query ke Supabase remote langsung via RPC verify_student_token (Prioritas utama cross-device)
  try {
    const supabaseStudent = await queryStudentFromSupabaseByVerifyParams(cleanVerifyId, cleanToken);
    if (supabaseStudent) {
      saveStudentAccount(supabaseStudent);
      return supabaseStudent;
    }
  } catch (err) {
    console.warn('Gagal membaca Supabase remote untuk verifikasi:', err);
  }

  // 2. Coba pencarian lokal sinkron jika di browser yang sama
  const local = findStudentByVerifyParamsLocal(cleanVerifyId, cleanToken);
  if (local) return local;

  // 3. Coba Firestore remote sebagai fallback
  try {
    const studentsCol = collection(firestoreDb, 'students');
    const q = query(
      studentsCol,
      where('adminVerifyId', '==', cleanVerifyId),
      where('activationToken', '==', cleanToken)
    );
    const snap = await getDocs(q);
    if (!snap.empty) {
      const docData = snap.docs[0].data();
      const mappedAccount: StudentAccount = {
        id: snap.docs[0].id || cleanVerifyId,
        name: docData.name || docData.namaLengkap || docData.nama || 'Siswa',
        classId: docData.classId || docData.kelas || 'Kelas 11 SMA',
        school: docData.school || docData.sekolah || 'SMA',
        nama: docData.namaLengkap || docData.nama,
        kelas: docData.kelas || docData.classId,
        sekolah: docData.sekolah || docData.school,
        email: docData.email,
        whatsapp: docData.whatsapp,
        status: docData.status || 'pending_verify',
        registeredAt: docData.registeredAt || Date.now(),
        activatedAt: docData.activatedAt,
        adminVerifyId: cleanVerifyId,
        activationToken: cleanToken,
        adminVerifyCreatedAt: docData.adminVerifyCreatedAt || Date.now(),
        adminVerifyUsedAt: docData.adminVerifyUsedAt,
        verifyDecision: docData.verifyDecision || null,
        rejectedReason: docData.rejectedReason,
        paymentProofSentAt: docData.paymentProofSentAt,
      };
      saveStudentAccount(mappedAccount);
      return mappedAccount;
    }
  } catch (err) {
    console.warn('Gagal membaca Firestore remote untuk verifikasi:', err);
  }

  return null;
}

/**
 * Mencatat bahwa tautan verifikasi telah dipakai oleh admin dengan keputusan tertentu
 */
export function markVerifyUsed(
  studentId: string,
  decision: 'active' | 'rejected'
): StudentAccount | null {
  const accounts = getAllStudentAccounts();
  const index = accounts.findIndex((a) => a.id === studentId || a.adminVerifyId === studentId);
  if (index === -1) return null;

  const now = Date.now();
  accounts[index] = {
    ...accounts[index],
    adminVerifyUsedAt: now,
    verifyDecision: decision,
  };

  saveAllStudentAccounts(accounts);
  saveStudentAccount(accounts[index]);
  return accounts[index];
}

/**
 * Regenerasi token aktivasi baru (untuk mereset tautan verifikasi jika diperlukan)
 */
export function setVerifyToken(studentId: string): StudentAccount | null {
  const accounts = getAllStudentAccounts();
  const index = accounts.findIndex((a) => a.id === studentId || a.adminVerifyId === studentId);
  if (index === -1) return null;

  const newToken = generateActivationToken();
  accounts[index] = {
    ...accounts[index],
    activationToken: newToken,
    adminVerifyCreatedAt: Date.now(),
    adminVerifyUsedAt: undefined,
    verifyDecision: null,
  };

  saveAllStudentAccounts(accounts);
  saveStudentAccount(accounts[index]);
  return accounts[index];
}

/**
 * Memperbarui status akun siswa dan menambahkan catatan ActivationLog
 */
export function updateStudentStatus(
  studentId: string,
  status: StudentAccount['status'],
  by: string,
  note?: string
): StudentAccount | null {
  const accounts = getAllStudentAccounts();
  const index = accounts.findIndex((a) => a.id === studentId || a.adminVerifyId === studentId);
  if (index === -1) return null;

  const now = Date.now();
  const updated: StudentAccount = {
    ...accounts[index],
    status,
    activatedAt: status === 'active' ? now : accounts[index].activatedAt,
  };

  accounts[index] = updated;
  saveAllStudentAccounts(accounts);
  saveStudentAccount(updated);

  // Update status langsung ke database Supabase (tabel public.students)
  updateStudentStatusInSupabase(studentId, status, {
    token: updated.activationToken,
    verifyDecision: status === 'active' ? 'active' : status === 'rejected' ? 'rejected' : null,
    rejectedReason: note,
  }).catch((err) => {
    console.warn('Background Supabase status update error:', err);
  });

  const actionMap: Record<string, ActivationLog['action']> = {
    active: 'activated',
    rejected: 'rejected',
    pending_verify: 'submitted',
    pending_payment: 'created',
  };

  appendActivationLog({
    id: generateAdminVerifyId(),
    studentId,
    action: actionMap[status] || 'submitted',
    by,
    at: now,
    note,
  });

  return updated;
}

/**
 * Menambahkan catatan riwayat aktivasi / penolakan
 */
export function appendActivationLog(log: ActivationLog): void {
  if (typeof window === 'undefined') return;
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LOGS);
    const logs: ActivationLog[] = raw ? JSON.parse(raw) : [];
    logs.push(log);
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(logs));
  } catch (err) {
    console.warn('Gagal menambahkan activation log:', err);
  }
}

/**
 * Mengambil riwayat log aktivasi
 */
export function getActivationLogs(studentId?: string): ActivationLog[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LOGS);
    if (!raw) return [];
    const logs: ActivationLog[] = JSON.parse(raw);
    if (studentId) {
      return logs.filter((l) => l.studentId === studentId);
    }
    return logs;
  } catch (err) {
    return [];
  }
}

/**
 * Mendaftarkan akun siswa baru dengan UUID v4 dan token 20 digit acak sekaligus
 */
export function registerNewStudentAccount(params: {
  id?: string;
  name: string;
  classId: string;
  school: string;
  email?: string;
  whatsapp?: string;
}): StudentAccount {
  const studentId = params.id || generateAdminVerifyId();
  const adminVerifyId = generateAdminVerifyId();
  const activationToken = generateActivationToken();
  const now = Date.now();

  const newAccount: StudentAccount = {
    id: studentId,
    name: params.name,
    classId: params.classId,
    school: params.school,
    nama: params.name,
    kelas: params.classId,
    sekolah: params.school,
    email: params.email,
    whatsapp: params.whatsapp,
    status: 'pending_payment',
    registeredAt: now,
    adminVerifyId,
    activationToken,
    adminVerifyCreatedAt: now,
    verifyDecision: null,
  };

  saveStudentAccount(newAccount);

  appendActivationLog({
    id: generateAdminVerifyId(),
    studentId: newAccount.id,
    action: 'created',
    by: 'system',
    at: now,
    note: 'Pendaftaran akun siswa baru dibuat dengan link verifikasi admin.',
  });

  return newAccount;
}

/**
 * Memeriksa apakah status pendaftaran siswa kedaluwarsa.
 * ATURAN (BAGIAN 3 UX Update):
 * - Status 'pending_verify' (sudah kirim konfirmasi WA) TIDAK BOLEH expired. Biarkan menggantung menunggu admin.
 * - Status 'active' dan 'rejected' tidak berstatus expired.
 * - HANYA status 'pending_payment' yang boleh expired (setelah 24 jam belum kirim bukti).
 */
export function isAccountExpired(account: StudentAccount): boolean {
  // Siswa yang sudah kirim WA (pending_verify) TIDAK BOLEH expired!
  if (account.status === 'pending_verify') {
    return false;
  }
  if (account.status === 'active' || account.status === 'rejected') {
    return false;
  }
  if (account.status === 'pending_payment') {
    const PAYMENT_TIMEOUT_MS = 24 * 60 * 60 * 1000; // 24 jam batas waktu pembayaran
    if (account.registeredAt && Date.now() - account.registeredAt > PAYMENT_TIMEOUT_MS) {
      return true;
    }
  }
  return false;
}

/**
 * Mengambil akun siswa berdasarkan ID
 */
export function getStudentAccountById(studentId: string): StudentAccount | null {
  if (!studentId) return null;
  const accounts = getAllStudentAccounts();
  const found = accounts.find((a) => a.id === studentId || a.adminVerifyId === studentId);
  if (found) return found;

  // Fallback ke localStorage legacy jika ada
  try {
    const raw = localStorage.getItem(`chemverse_sub_${studentId}`) || localStorage.getItem('chemverse_student_identity');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.id === studentId || !parsed.id) {
        return {
          id: studentId,
          name: parsed.nama || parsed.name || 'Siswa',
          classId: parsed.kelas || parsed.classId || 'Kelas 11 SMA',
          school: parsed.sekolah || parsed.school || 'SMA',
          status: parsed.status || 'pending_payment',
          adminVerifyId: parsed.adminVerifyId || generateAdminVerifyId(),
          activationToken: parsed.activationToken || parsed.token || generateActivationToken(),
          adminVerifyCreatedAt: parsed.adminVerifyCreatedAt || Date.now(),
          adminVerifyUsedAt: parsed.adminVerifyUsedAt,
          verifyDecision: parsed.verifyDecision,
          rejectedReason: parsed.rejectedReason,
          paymentProofSentAt: parsed.paymentProofSentAt,
        };
      }
    }
  } catch (e) {
    // ignore
  }

  return null;
}

/**
 * Mengambil atau mendaftarkan akun siswa baru jika belum ada
 */
export function getOrCreateStudentAccount(params: {
  id?: string;
  name: string;
  classId: string;
  school: string;
  email?: string;
  whatsapp?: string;
}): StudentAccount {
  if (params.id) {
    const existing = getStudentAccountById(params.id);
    if (existing) {
      // Pastikan name/classId/school ter-update jika berubah
      const updated: StudentAccount = {
        ...existing,
        name: params.name || existing.name,
        classId: params.classId || existing.classId,
        school: params.school || existing.school,
        nama: params.name || existing.name,
        kelas: params.classId || existing.classId,
        sekolah: params.school || existing.school,
      };
      saveStudentAccount(updated);
      return updated;
    }
  }
  return registerNewStudentAccount(params);
}
