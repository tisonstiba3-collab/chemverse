import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { db as firestoreDb } from '../lib/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { StudentAccount } from '../shared/types';

// =========================================================================
// TUGAS 5 — KEAMANAN SUPABASE
// URL dan ANON_KEY diambil langsung dari environment variable (.env)
// Tidak dapat diubah dari antarmuka pengguna (UI)
// =========================================================================

export const DEFAULT_SUPABASE_URL = 'https://xyzcompany.supabase.co';
export const DEFAULT_SUPABASE_ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh5emNvbXBhbnkiLCJyb2xlIjoiYW5vbiIsImlhdCI6MTY3MDAwMDAwMCwiZXhwIjoxOTgwMDAwMDAwfQ.demo_key_hash';

// Ambil dari .env (Vite client env: VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY)
const ENV_SUPABASE_URL =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL) ||
  DEFAULT_SUPABASE_URL;

const ENV_SUPABASE_ANON_KEY =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_ANON_KEY) ||
  DEFAULT_SUPABASE_ANON_KEY;

let cachedClient: SupabaseClient | null = null;

export const getSupabaseClient = (): SupabaseClient => {
  if (cachedClient) return cachedClient;
  cachedClient = createClient(ENV_SUPABASE_URL, ENV_SUPABASE_ANON_KEY);
  return cachedClient;
};

export const getSupabaseCredentials = () => {
  return {
    url: ENV_SUPABASE_URL,
    anonKey: ENV_SUPABASE_ANON_KEY,
  };
};

export interface UserSubscriptionRecord {
  id: string;
  nama: string;
  kelas: string;
  sekolah: string;
  status: 'pending' | 'active' | 'locked';
  token: string;
  expires_at: string | null;
  created_at?: string;
  updated_at?: string;
}

export const ADMIN_WHATSAPP_PHONE = '6282145750970';

/**
 * 1. Mendaftarkan siswa baru ke Supabase database (Tabel "students")
 */
export async function registerStudentToSupabase(studentData: {
  id?: string;
  nama: string;
  kelas: string;
  sekolah: string;
}): Promise<UserSubscriptionRecord> {
  const client = getSupabaseClient();

  const randomToken =
    Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
  const studentId =
    studentData.id ||
    (typeof crypto !== 'undefined' && crypto.randomUUID
      ? crypto.randomUUID()
      : `std_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`);

  const newRecord: UserSubscriptionRecord = {
    id: studentId,
    nama: studentData.nama.trim(),
    kelas: studentData.kelas.trim(),
    sekolah: studentData.sekolah.trim(),
    status: 'pending',
    token: randomToken,
    expires_at: null,
    created_at: new Date().toISOString(),
  };

  try {
    // Coba insert ke tabel 'students' (sesuai spesifikasi Tugas 4)
    const { data, error } = await client
      .from('students')
      .insert([newRecord])
      .select()
      .single();

    if (error) {
      // Fallback ke tabel 'users' jika tabel 'students' belum dimigrasikan di remote
      const userRes = await client.from('users').insert([newRecord]).select().single();
      if (!userRes.error && userRes.data) {
        syncLocalStorageRecord(newRecord);
        return userRes.data as UserSubscriptionRecord;
      }

      console.warn('Supabase insert fallback ke penyimpanan lokal:', error.message);
      syncLocalStorageRecord(newRecord);
      return newRecord;
    }

    syncLocalStorageRecord(data as UserSubscriptionRecord);
    return data as UserSubscriptionRecord;
  } catch (err) {
    console.warn('Supabase offline / network fallback active:', err);
    syncLocalStorageRecord(newRecord);
    return newRecord;
  }
}

/**
 * Helper untuk menyinkronkan data siswa ke localStorage
 */
function syncLocalStorageRecord(record: UserSubscriptionRecord) {
  try {
    localStorage.setItem(`chemverse_sub_${record.id}`, JSON.stringify(record));
    localStorage.setItem('chemverse_student_sub_id', record.id);
    localStorage.setItem(
      'chemverse_student_identity',
      JSON.stringify({
        id: record.id,
        nama: record.nama,
        kelas: record.kelas,
        sekolah: record.sekolah,
        status: record.status,
      })
    );
    localStorage.setItem('chemverse_nama', record.nama);
    localStorage.setItem('chemverse_kelas', record.kelas);
    localStorage.setItem('chemverse_sekolah', record.sekolah);
  } catch (e) {
    console.warn('Gagal menyimpan cache lokal:', e);
  }
}

/**
 * 2. Mengubah status siswa menjadi 'pending' (dipanggil saat tombol "Saya Sudah Bayar" diklik)
 */
export async function setStudentStatusPending(
  studentId: string,
  identity?: { nama: string; kelas: string; sekolah: string }
): Promise<UserSubscriptionRecord> {
  const client = getSupabaseClient();
  const existingLocal = getLocalStudentSubscription(studentId);

  const updatedRecord: UserSubscriptionRecord = {
    id: studentId,
    nama: identity?.nama || existingLocal?.nama || 'Siswa Chemverse',
    kelas: identity?.kelas || existingLocal?.kelas || 'Kelas 11 SMA',
    sekolah: identity?.sekolah || existingLocal?.sekolah || 'SMA Negeri',
    status: 'pending',
    token: existingLocal?.token || `token_${studentId}`,
    expires_at: null,
    updated_at: new Date().toISOString(),
  };

  try {
    // 1. Coba update ke tabel 'students'
    const { data: stdData, error: stdErr } = await client
      .from('students')
      .update({ status: 'pending', updated_at: new Date().toISOString() })
      .eq('id', studentId)
      .select()
      .single();

    if (!stdErr && stdData) {
      syncLocalStorageRecord(stdData as UserSubscriptionRecord);
      return stdData as UserSubscriptionRecord;
    }

    // 2. Coba update ke tabel 'users'
    const { data: usrData, error: usrErr } = await client
      .from('users')
      .update({ status: 'pending', updated_at: new Date().toISOString() })
      .eq('id', studentId)
      .select()
      .single();

    if (!usrErr && usrData) {
      syncLocalStorageRecord(usrData as UserSubscriptionRecord);
      return usrData as UserSubscriptionRecord;
    }

    // Jika record belum ada di database, coba lakukan insert/upsert
    await client.from('students').upsert([updatedRecord]);
  } catch (err) {
    console.warn('Gagal update status pending ke cloud Supabase, menggunakan lokal:', err);
  }

  syncLocalStorageRecord(updatedRecord);
  return updatedRecord;
}

/**
 * 3. Cek Status Langganan Siswa (Tabel 'students' dengan polling realtime)
 */
export async function checkStudentSubscriptionStatus(
  studentId: string
): Promise<UserSubscriptionRecord | null> {
  if (!studentId) return null;

  // 1. Cek Firestore Cloud (real-time sync antar-perangkat saat admin aktifkan via HP)
  try {
    const fsSnap = await getDoc(doc(firestoreDb, 'students', studentId));
    if (fsSnap.exists()) {
      const fsData = fsSnap.data();
      if (fsData.status === 'active') {
        const activeRecord: UserSubscriptionRecord = {
          id: studentId,
          nama: fsData.name || fsData.namaLengkap || fsData.nama || 'Siswa Chemverse',
          kelas: fsData.classId || fsData.kelas || 'Kelas 11 SMA',
          sekolah: fsData.school || fsData.sekolah || 'SMA Negeri',
          status: 'active',
          token: fsData.activationToken || fsData.token || `token_${studentId}`,
          expires_at: fsData.expires_at || null,
        };
        syncLocalStorageRecord(activeRecord);
        return activeRecord;
      } else if (fsData.status === 'rejected') {
        const rejectedRecord: UserSubscriptionRecord = {
          id: studentId,
          nama: fsData.name || fsData.namaLengkap || fsData.nama || 'Siswa Chemverse',
          kelas: fsData.classId || fsData.kelas || 'Kelas 11 SMA',
          sekolah: fsData.school || fsData.sekolah || 'SMA Negeri',
          status: 'locked',
          token: fsData.activationToken || fsData.token || `token_${studentId}`,
          expires_at: null,
        };
        syncLocalStorageRecord(rejectedRecord);
        return rejectedRecord;
      }
    }
  } catch (err) {
    // abaikan jika offline
  }

  // 2. Cek database Supabase Remote
  const client = getSupabaseClient();
  try {
    const { data, error } = await client
      .from('students')
      .select('*')
      .eq('id', studentId)
      .single();

    if (!error && data) {
      const record = data as UserSubscriptionRecord;
      syncLocalStorageRecord(record);
      return record;
    }

    const { data: userData, error: userError } = await client
      .from('users')
      .select('*')
      .eq('id', studentId)
      .single();

    if (!userError && userData) {
      const record = userData as UserSubscriptionRecord;
      syncLocalStorageRecord(record);
      return record;
    }
  } catch (err) {
    // Fallback silent ke local storage
  }

  // 3. Fallback pemeriksaan dari localStorage & studentVerificationStore
  return getLocalStudentSubscription(studentId);
}

/**
 * Mengambil data siswa dari localStorage & daftar akun terkelola
 */
export function getLocalStudentSubscription(studentId: string): UserSubscriptionRecord | null {
  try {
    // Cek daftar akun di chemverse_student_accounts
    const accountsRaw = localStorage.getItem('chemverse_student_accounts');
    if (accountsRaw) {
      const accounts = JSON.parse(accountsRaw);
      const acc = accounts.find((a: any) => a.id === studentId || a.adminVerifyId === studentId);
      if (acc) {
        return {
          id: studentId,
          nama: acc.name || acc.nama || 'Siswa Chemverse',
          kelas: acc.classId || acc.kelas || 'Kelas 11 SMA',
          sekolah: acc.school || acc.sekolah || 'SMA Negeri',
          status: acc.status === 'active' ? 'active' : acc.status === 'rejected' ? 'locked' : 'pending',
          token: acc.activationToken || `token_${studentId}`,
          expires_at: null,
        };
      }
    }

    const raw = localStorage.getItem(`chemverse_sub_${studentId}`);
    if (raw) return JSON.parse(raw);

    const identityRaw = localStorage.getItem('chemverse_student_identity');
    if (identityRaw) {
      const parsed = JSON.parse(identityRaw);
      return {
        id: studentId,
        nama: parsed.nama || 'Siswa Chemverse',
        kelas: parsed.kelas || 'Kelas 11 SMA',
        sekolah: parsed.sekolah || 'SMA Negeri',
        status: parsed.status || 'pending',
        token: `token_${studentId}`,
        expires_at: null,
      };
    }
  } catch (e) {
    // ignore
  }
  return null;
}

/**
 * 4. Verifikasi Siswa oleh Admin (Aktifkan 60 Hari / Kunci)
 */
export async function adminVerifyStudent(
  studentId: string,
  token: string,
  action: 'activate' | 'lock'
): Promise<{ success: boolean; record?: UserSubscriptionRecord; message: string }> {
  const client = getSupabaseClient();
  const newStatus = action === 'activate' ? 'active' : 'locked';
  const expiresAt =
    action === 'activate'
      ? new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString()
      : null;

  try {
    // Coba update pada tabel 'students'
    const { data: updatedStd, error: errStd } = await client
      .from('students')
      .update({
        status: newStatus,
        expires_at: expiresAt,
        updated_at: new Date().toISOString(),
      })
      .eq('id', studentId)
      .select()
      .single();

    if (!errStd && updatedStd) {
      syncLocalStorageRecord(updatedStd as UserSubscriptionRecord);
      return {
        success: true,
        record: updatedStd as UserSubscriptionRecord,
        message:
          action === 'activate'
            ? `Status Siswa ${(updatedStd as any).nama} BERHASIL DIAKTIFKAN selama 60 Hari!`
            : `Akses Siswa ${(updatedStd as any).nama} BERHASIL DIKUNCI!`,
      };
    }

    // Fallback update tabel 'users'
    const { data: updatedUsr } = await client
      .from('users')
      .update({
        status: newStatus,
        expires_at: expiresAt,
        updated_at: new Date().toISOString(),
      })
      .eq('id', studentId)
      .select()
      .single();

    if (updatedUsr) {
      syncLocalStorageRecord(updatedUsr as UserSubscriptionRecord);
      return {
        success: true,
        record: updatedUsr as UserSubscriptionRecord,
        message:
          action === 'activate'
            ? `Status Siswa ${(updatedUsr as any).nama} BERHASIL DIAKTIFKAN selama 60 Hari!`
            : `Akses Siswa ${(updatedUsr as any).nama} BERHASIL DIKUNCI!`,
      };
    }
  } catch (e) {
    console.warn('Gagal menghubungi remote database Supabase:', e);
  }

  // Fallback lokal
  const local = getLocalStudentSubscription(studentId);
  const updated: UserSubscriptionRecord = {
    id: studentId,
    nama: local?.nama || localStorage.getItem('chemverse_nama') || 'Siswa Chemverse',
    kelas: local?.kelas || localStorage.getItem('chemverse_kelas') || 'Kelas 11 SMA',
    sekolah: local?.sekolah || localStorage.getItem('chemverse_sekolah') || 'SMA Negeri',
    status: newStatus,
    token: token || 'token_adm',
    expires_at: expiresAt,
    updated_at: new Date().toISOString(),
  };

  syncLocalStorageRecord(updated);

  return {
    success: true,
    record: updated,
    message:
      action === 'activate'
        ? `Status Siswa ${updated.nama} BERHASIL DIAKTIFKAN selama 60 Hari!`
        : `Akses Siswa ${updated.nama} BERHASIL DIKUNCI!`,
  };
}

/**
 * 5. URL WhatsApp Admin Resmi (6282145750970)
 */
export function getAdminWhatsAppUrl(namaSiswa: string): string {
  const sanitizedNama = (namaSiswa || 'Siswa').trim();
  const rawIdentity = typeof window !== 'undefined' ? localStorage.getItem('chemverse_student_identity') : null;
  const parsed = rawIdentity ? JSON.parse(rawIdentity) : null;
  const studentId = typeof window !== 'undefined' ? localStorage.getItem('chemverse_student_sub_id') || '' : '';
  const accountsRaw = typeof window !== 'undefined' ? localStorage.getItem('chemverse_student_accounts') : null;
  const accounts = accountsRaw ? JSON.parse(accountsRaw) : [];
  const found = accounts.find((a: any) => a.id === studentId || a.name === sanitizedNama);

  const adminVerifyId = found?.adminVerifyId || 'f4f78249-8d02-4cd7-acd0-57b820b3e6e7';
  const token = found?.activationToken || found?.token || '9avfehalmvk519lwn';
  const kelas = found?.classId || found?.kelas || parsed?.kelas || 'Kelas 11 SMA (Fase F)';
  const sekolah = found?.school || found?.sekolah || parsed?.sekolah || 'SMA';
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const link = `${baseUrl}/?admin_verify=${adminVerifyId}&token=${token}`;

  const text = `Halo Admin, saya ${sanitizedNama}, Kelas ${kelas}, Sekolah ${sekolah}, sudah bayar langganan Chemverse. Mohon cek mutasi. Ini bukti pembayaran saya. Admin, klik link ini untuk verifikasi: ${link}`;
  return `https://wa.me/${ADMIN_WHATSAPP_PHONE}?text=${encodeURIComponent(text)}`;
}

export function getAdminWhatsAppFollowUpUrl(namaSiswa: string): string {
  return getAdminWhatsAppUrl(namaSiswa);
}

export function generateWhatsAppMessage(
  student: { id: string; nama: string; kelas: string; sekolah: string; token: string; adminVerifyId?: string; activationToken?: string },
  baseUrl: string
): string {
  const verifyId = student.adminVerifyId || student.id;
  const token = student.activationToken || student.token;
  const magicLink = `${baseUrl}/?admin_verify=${verifyId}&token=${token}`;
  const messageText = `Halo Admin, saya ${student.nama}, Kelas ${student.kelas}, Sekolah ${student.sekolah}, sudah bayar langganan Chemverse. Mohon cek mutasi. Ini bukti pembayaran saya. Admin, klik link ini untuk verifikasi: ${magicLink}`;
  return `https://wa.me/${ADMIN_WHATSAPP_PHONE}?text=${encodeURIComponent(messageText)}`;
}

/**
 * 6. Sinkronisasi data akun siswa baru / update ke tabel public.students di Supabase
 */
export async function syncStudentToSupabaseWithVerifyTokens(account: StudentAccount): Promise<void> {
  const client = getSupabaseClient();
  const payload: any = {
    id: account.id,
    nama: account.name || account.nama || 'Siswa',
    kelas: account.classId || account.kelas || 'Kelas 11 SMA',
    sekolah: account.school || account.sekolah || 'SMA Negeri',
    status: account.status,
    token: account.activationToken,
    admin_verify: account.adminVerifyId,
    admin_verify_used_at: account.adminVerifyUsedAt ? new Date(account.adminVerifyUsedAt).toISOString() : null,
    verify_decision: account.verifyDecision || null,
    rejected_reason: account.rejectedReason || null,
    payment_proof_sent_at: account.paymentProofSentAt ? new Date(account.paymentProofSentAt).toISOString() : null,
    created_at: account.registeredAt ? new Date(account.registeredAt).toISOString() : new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  try {
    const { data, error } = await client.from('students').upsert([payload], { onConflict: 'id' }).select();
    if (error) {
      console.warn('⚠️ [Supabase] Upsert ke public.students warning:', error.message);
      // Fallback tanpa kolom tambahan jika skema lebih sederhana
      try {
        await client.from('students').upsert([{
          id: account.id,
          nama: payload.nama,
          kelas: payload.kelas,
          sekolah: payload.sekolah,
          status: account.status,
          token: account.activationToken,
          updated_at: new Date().toISOString(),
        }]);
      } catch {
        // ignore
      }
    } else {
      console.log('✅ [Supabase] Siswa berhasil disinkronkan ke public.students:', payload.nama, payload.id);
    }
  } catch (e) {
    console.warn('⚠️ [Supabase] Error sync ke public.students:', e);
  }
}

/**
 * 7. Query Supabase untuk mencari siswa berdasarkan admin_verify DAN token
 * Mengimplementasikan pemanggilan RPC verify_student_token (Bypass RLS) serta direct SELECT fallback.
 */
export async function queryStudentFromSupabaseByVerifyParams(
  adminVerifyId: string,
  token: string
): Promise<StudentAccount | null> {
  const client = getSupabaseClient();
  const cleanVerify = adminVerifyId.trim();
  const cleanToken = token.trim();

  console.log('🔍 [Chemverse Verify] Memulai pencarian di Supabase untuk:', {
    adminVerifyId: cleanVerify,
    token: cleanToken,
  });

  // 1. Coba RPC Supabase verify_student_token (Bypass RLS via SECURITY DEFINER)
  try {
    const { data: rpcData, error: rpcError } = await client.rpc('verify_student_token', {
      p_verify_id: cleanVerify,
      p_token: cleanToken,
    });

    if (rpcError) {
      console.warn('🔍 [Chemverse Verify] RPC error verify_student_token:', rpcError.message);
    } else if (rpcData) {
      // Hasil RPC SETOF public.students berupa array record atau single object
      const rows = Array.isArray(rpcData) ? rpcData : [rpcData];
      if (rows.length > 0 && rows[0] && rows[0].id) {
        console.log('✅ [Chemverse Verify] Siswa ditemukan via RPC Supabase verify_student_token:', rows[0]);
        return mapRowToStudentAccount(rows[0], cleanVerify, cleanToken);
      }
    }
  } catch (rpcErr) {
    console.warn('🔍 [Chemverse Verify] Exception saat RPC verify_student_token:', rpcErr);
  }

  // 2. Query langsung ke tabel public.students
  try {
    // 2a. admin_verify & token
    const q1 = await client
      .from('students')
      .select('*')
      .eq('admin_verify', cleanVerify)
      .eq('token', cleanToken)
      .maybeSingle();

    if (!q1.error && q1.data) {
      console.log('✅ [Chemverse Verify] Siswa ditemukan di public.students (admin_verify & token):', q1.data);
      return mapRowToStudentAccount(q1.data, cleanVerify, cleanToken);
    }

    // 2b. id & token
    const q2 = await client
      .from('students')
      .select('*')
      .eq('id', cleanVerify)
      .eq('token', cleanToken)
      .maybeSingle();

    if (!q2.error && q2.data) {
      console.log('✅ [Chemverse Verify] Siswa ditemukan di public.students (id & token):', q2.data);
      return mapRowToStudentAccount(q2.data, cleanVerify, cleanToken);
    }
  } catch (err) {
    console.warn('🔍 [Chemverse Verify] Error query tabel students di Supabase:', err);
  }

  // 3. Fallback tabel 'users' jika ada migrasi lama
  try {
    const qUser = await client
      .from('users')
      .select('*')
      .eq('id', cleanVerify)
      .eq('token', cleanToken)
      .maybeSingle();

    if (!qUser.error && qUser.data) {
      console.log('✅ [Chemverse Verify] Siswa ditemukan di public.users:', qUser.data);
      return mapRowToStudentAccount(qUser.data, cleanVerify, cleanToken);
    }
  } catch (err) {
    // ignore
  }

  console.log('🔍 [Chemverse Verify] Hasil pencarian dari Supabase: null');
  return null;
}

/**
 * 8. Update status siswa (Aktif / Nonaktif) di tabel public.students Supabase berdasarkan ID atau token
 */
export async function updateStudentStatusInSupabase(
  studentId: string,
  status: StudentAccount['status'],
  options?: {
    token?: string;
    verifyDecision?: 'active' | 'rejected' | null;
    rejectedReason?: string;
  }
): Promise<boolean> {
  const client = getSupabaseClient();
  const updatePayload: any = {
    status,
    verify_decision: options?.verifyDecision || (status === 'active' ? 'active' : status === 'rejected' ? 'rejected' : null),
    admin_verify_used_at: status === 'active' || status === 'rejected' ? new Date().toISOString() : null,
    updated_at: new Date().toISOString(),
  };

  if (status === 'active') {
    // Masa aktif 60 hari
    updatePayload.expires_at = new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString();
  }

  if (options?.rejectedReason) {
    updatePayload.rejected_reason = options.rejectedReason;
  }

  try {
    // 1. Eksekusi UPDATE ke public.students dengan filter id ATAU token
    let query = client.from('students').update(updatePayload);
    if (options?.token) {
      query = query.or(`id.eq.${studentId},token.eq.${options.token}`);
    } else {
      query = query.eq('id', studentId);
    }

    const { data, error } = await query.select();

    if (error) {
      console.warn('⚠️ [Supabase] Update status tabel students warning:', error.message);
      // Fallback update sederhana via eq('id')
      const resFallback = await client.from('students').update(updatePayload).eq('id', studentId);
      if (resFallback.error) {
        console.warn('⚠️ [Supabase] Fallback update via id error:', resFallback.error.message);
        return false;
      }
      console.log('✅ [Supabase] Status siswa berhasil di-UPDATE di public.students via fallback id:', status);
      return true;
    }

    console.log('✅ [Supabase] Status siswa berhasil di-UPDATE di public.students:', status, data);
    return true;
  } catch (err) {
    console.warn('⚠️ [Supabase] Exception saat UPDATE status ke students:', err);
    return false;
  }
}

function mapRowToStudentAccount(row: any, verifyId: string, token: string): StudentAccount {
  let statusMapped: StudentAccount['status'] = 'pending_verify';
  if (row.status === 'active') {
    statusMapped = 'active';
  } else if (row.status === 'rejected' || row.status === 'locked') {
    statusMapped = 'rejected';
  } else if (row.status === 'pending_payment') {
    statusMapped = 'pending_payment';
  } else {
    statusMapped = 'pending_verify';
  }

  return {
    id: row.id || verifyId,
    name: row.nama || row.name || 'Siswa',
    classId: row.kelas || row.classId || 'Kelas 11 SMA',
    school: row.sekolah || row.school || 'SMA',
    nama: row.nama || row.name,
    kelas: row.kelas || row.classId,
    sekolah: row.sekolah || row.school,
    email: row.email,
    whatsapp: row.whatsapp,
    status: statusMapped,
    registeredAt: row.created_at ? new Date(row.created_at).getTime() : Date.now(),
    activatedAt: statusMapped === 'active' ? (row.expires_at ? new Date(row.expires_at).getTime() : Date.now()) : undefined,
    adminVerifyId: row.admin_verify || row.admin_verify_id || verifyId,
    activationToken: row.token || row.activation_token || token,
    adminVerifyCreatedAt: row.created_at ? new Date(row.created_at).getTime() : Date.now(),
    adminVerifyUsedAt: row.admin_verify_used_at ? new Date(row.admin_verify_used_at).getTime() : undefined,
    verifyDecision: row.verify_decision || (statusMapped === 'active' ? 'active' : statusMapped === 'rejected' ? 'rejected' : null),
    rejectedReason: row.rejected_reason || row.rejectedReason,
    paymentProofSentAt: row.payment_proof_sent_at ? new Date(row.payment_proof_sent_at).getTime() : undefined,
  };
}
