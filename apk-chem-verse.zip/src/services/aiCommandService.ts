/**
 * @file src/services/aiCommandService.ts
 * @description Layanan AI Command & Executor untuk guru (BATASAN MUTLAK: Hanya diakses oleh guru)
 */

import { GoogleGenAI } from '@google/genai';

export type OperationType =
  | 'add_soal'
  | 'update_soal'
  | 'delete_soal'
  | 'add_materi'
  | 'update_materi'
  | 'delete_materi'
  | 'add_game'
  | 'update_game'
  | 'delete_game'
  | 'add_video'
  | 'update_video'
  | 'delete_video'
  | 'add_kuis'
  | 'update_kuis'
  | 'delete_kuis'
  | 'add_pengumuman'
  | 'update_pengumuman'
  | 'delete_pengumuman'
  | 'add_bab'
  | 'update_bab'
  | 'delete_bab';

export interface PlanOperation {
  op: OperationType;
  params: {
    targetId?: string;
    id?: string;
    targetTitle?: string;
    replaceStrategy?: 'overwrite' | 'append';
    layoutType?: 'standard' | 'flipbook' | 'presentation' | 'pdf_viewer';
    contentPages?: string[];
    babId?: string;
    judul?: string;
    isi?: string;
    deskripsi?: string;
    attachmentUrl?: string;
    attachmentType?: 'pdf' | 'word' | 'ppt' | 'foto' | 'link';
    linkUrl?: string;
    pertanyaan?: string;
    pilihan?: Record<string, string>;
    jawaban?: string;
    pembahasan?: string;
    tingkatKesulitan?: string;
    tipeGame?: string;
    targetKelas?: string;
    count?: number;
    [key: string]: any;
  };
  preview: string;
  detail?: string;
}

export interface AttachedFileData {
  name: string;
  mimeType: string;
  data: string; // base64
}

/**
 * Konversi File objek browser ke base64 string dan mimeType untuk Gemini API
 */
export async function fileToBase64(file: File): Promise<AttachedFileData> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const res = reader.result as string;
      const base64Data = res.includes(',') ? res.split(',')[1] : res;
      resolve({
        name: file.name,
        mimeType: file.type || 'application/octet-stream',
        data: base64Data,
      });
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
}

export interface AIPlan {
  summary: string;
  clarification?: string;
  attachedFileName?: string;
  operations: PlanOperation[];
  impact: {
    added: number;
    updated: number;
    deleted: number;
    risk: 'low' | 'medium' | 'high' | 'critical';
  };
}

/**
 * Menghitung dampak operasi dan menentukan tingkat risiko operasi.
 * Jika terdapat operasi menimpa (overwrite / targetId) dan melibatkan upload file/pdf,
 * atau operasi berisiko tinggi lainnya, status risk dinaikkan menjadi 'high' atau 'critical'.
 */
export function calculatePlanImpact(
  operations: PlanOperation[],
  existingMateri: Array<{ id: string; judul: string }> = []
): AIPlan['impact'] {
  let added = 0;
  let updated = 0;
  let deleted = 0;
  let hasOverwrite = false;
  let hasFileUpload = false;
  let hasCriticalDelete = false;

  for (const item of operations) {
    const op = item.op;
    const p = item.params || {};

    const isUploadInvolved =
      Boolean(p.attachmentUrl) ||
      Boolean(p.attachmentType) ||
      p.attachmentType === 'pdf' ||
      item.preview?.toLowerCase().includes('pdf') ||
      item.preview?.toLowerCase().includes('upload') ||
      item.preview?.toLowerCase().includes('file') ||
      item.detail?.toLowerCase().includes('pdf') ||
      item.detail?.toLowerCase().includes('file');

    if (isUploadInvolved) {
      hasFileUpload = true;
    }

    if (op.startsWith('add_')) {
      added++;
    } else if (op.startsWith('update_')) {
      updated++;
      if (
        p.replaceStrategy === 'overwrite' ||
        Boolean(p.targetId) ||
        Boolean(p.isOverwrite) ||
        item.preview?.toLowerCase().includes('timpa') ||
        item.preview?.toLowerCase().includes('menimpa') ||
        item.detail?.toLowerCase().includes('overwrite') ||
        item.detail?.toLowerCase().includes('menimpa')
      ) {
        hasOverwrite = true;
      }
    } else if (op.startsWith('delete_')) {
      deleted++;
      if (op === 'delete_bab' || (p.count && p.count >= 4) || item.preview?.toLowerCase().includes('semua')) {
        hasCriticalDelete = true;
      }
    }
  }

  let risk: 'low' | 'medium' | 'high' | 'critical' = 'low';

  // TUGAS 2: Jika AI menghasilkan operasi yang MENIMPA data lama (update_materi / update_soal)
  // dan melibatkan file upload, pastikan status Risk adalah "high" atau "critical".
  if (hasCriticalDelete || deleted >= 4 || (hasOverwrite && deleted > 0)) {
    risk = 'critical';
  } else if (hasOverwrite && hasFileUpload) {
    risk = updated >= 3 ? 'critical' : 'high';
  } else if (deleted > 0 || hasOverwrite) {
    risk = 'high';
  } else if (updated > 0) {
    risk = 'medium';
  }

  return { added, updated, deleted, risk };
}

export interface ExecutionResult {
  success: boolean;
  executed: number;
  failed: number;
  errors: Array<{ op: string; message: string }>;
  snapshotId: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  prompt: string;
  plan: AIPlan;
  result: ExecutionResult;
  approvedBy: string;
}

export interface TeacherContentData {
  soal: Array<{
    id: string;
    babId: string;
    pertanyaan: string;
    pilihan?: Record<string, string>;
    jawaban: string;
    pembahasan?: string;
    tingkatKesulitan?: string;
  }>;
  materi: Array<{
    id: string;
    babId: string;
    judul: string;
    isi: string;
    deskripsi?: string;
    attachmentUrl?: string;
    attachmentType?: 'pdf' | 'word' | 'ppt' | 'foto' | 'link';
    linkUrl?: string;
    layoutType?: 'standard' | 'flipbook' | 'presentation' | 'pdf_viewer';
    contentPages?: string[];
  }>;
  games?: Array<{
    id: string;
    babId: string;
    judul: string;
    tipeGame: string;
    deskripsi?: string;
    linkUrl?: string;
  }>;
  bab: Array<{
    id: string;
    grade: string;
    title: string;
    soalCount?: number;
  }>;
  pengumuman: Array<{
    id: string;
    judul: string;
    isi: string;
    targetKelas?: string;
    tanggal?: string;
  }>;
  sampah?: Array<{
    id: string;
    type: string;
    data: any;
    deletedAt: string;
  }>;
}

const STORAGE_KEYS = {
  CONTENT: 'chemiverse_teacher_content',
  LOG: 'chemiverse_ai_log',
  HISTORY: 'chemiverse_ai_history',
};

// Data inisial default jika belum ada di localStorage
const INITIAL_CONTENT: TeacherContentData = {
  bab: [
    { id: 'bab_01_atom', grade: '10', title: 'Bab 1: Struktur Atom & Tabel Periodik', soalCount: 12 },
    { id: 'bab_02_ikatan', grade: '10', title: 'Bab 2: Ikatan Kimia & Bentuk Molekul', soalCount: 15 },
    { id: 'bab_03_stoikiometri', grade: '10', title: 'Bab 3: Stoikiometri & Konsep Mol', soalCount: 18 },
    { id: 'bab_04_termokimia', grade: '11', title: 'Bab 1: Termokimia & Perubahan Entalpi', soalCount: 14 },
    { id: 'bab_05_laju', grade: '11', title: 'Bab 2: Laju Reaksi & Faktor Pengaruh', soalCount: 10 },
  ],
  soal: [
    {
      id: 'soal_1',
      babId: 'bab_01_atom',
      pertanyaan: 'Partikel subatomik yang bermuatan positif di dalam inti atom adalah...',
      jawaban: 'Proton',
      pembahasan: 'Proton bermuatan positif (+1) dan terletak di inti atom bersama neutron.',
      tingkatKesulitan: 'Mudah',
    },
    {
      id: 'soal_2',
      babId: 'bab_01_atom',
      pertanyaan: 'Jumlah elektron maksimum yang dapat menempati kulit M (n = 3) adalah...',
      jawaban: '18',
      pembahasan: 'Rumus 2n^2: 2(3)^2 = 18 elektron.',
      tingkatKesulitan: 'Sedang',
    },
    {
      id: 'soal_3',
      babId: 'bab_02_ikatan',
      pertanyaan: 'Ikatan yang terbentuk akibat serah terima elektron antara logam dan nonlogam adalah...',
      jawaban: 'Ikatan Ionik',
      pembahasan: 'Serah terima elektron membentuk kation dan anion yang saling tarik-menarik elektrostatis.',
      tingkatKesulitan: 'Mudah',
    },
  ],
  materi: [
    {
      id: 'mat_01',
      babId: 'bab_01_atom',
      judul: 'Hakikat Ilmu Kimia & Sifat Materi',
      isi: 'Mempelajari susunan, struktur, sifat, dan perubahan materi.',
      deskripsi: 'Pengantar konsep sains kimia SMA Fase E.',
    },
    {
      id: 'mat_02_ikatan',
      babId: 'bab_02_ikatan',
      judul: 'Ikatan Kimia',
      isi: 'Materi pokok pembentukan ikatan ionik, kovalen, dan logam serta geometri molekul.',
      deskripsi: 'Materi Ikatan Kimia Kelas 10 Bab 2',
    },
  ],
  games: [],
  pengumuman: [],
  sampah: [],
};

// =========================================================================
// 1. KELOLA DATA KONTEN GURU
// =========================================================================

export function getTeacherContent(): TeacherContentData {
  if (typeof window === 'undefined') return INITIAL_CONTENT;
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CONTENT);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.soal)) {
        if (!parsed.materi || parsed.materi.length === 0) {
          parsed.materi = INITIAL_CONTENT.materi;
        } else if (!parsed.materi.some((m: any) => m.id === 'mat_02_ikatan' || (m.judul && m.judul.toLowerCase().includes('ikatan')))) {
          parsed.materi.push(INITIAL_CONTENT.materi[1]);
        }
        return parsed;
      }
    }
  } catch (e) {
    console.warn('[AI Command] Gagal membaca data konten:', e);
  }
  // Simpan initial content jika masih kosong
  saveTeacherContent(INITIAL_CONTENT);
  return INITIAL_CONTENT;
}

export function saveTeacherContent(data: TeacherContentData): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.CONTENT, JSON.stringify(data));
  } catch (e) {
    console.warn('[AI Command] Gagal menyimpan data konten:', e);
  }
}

/**
 * TUGAS 3: Fungsi store untuk memperbarui materi yang sudah ada (menimpa/mengubah).
 * Dipanggil secara eksklusif saat operasi "update_materi" dieksekusi (bukan addMateri).
 */
export function updateMateri(
  targetId: string,
  updatedFields: Partial<TeacherContentData['materi'][0]>,
  replaceStrategy: 'overwrite' | 'append' = 'overwrite'
): { success: boolean; oldMateri?: TeacherContentData['materi'][0]; updatedMateri?: TeacherContentData['materi'][0] } {
  const content = getTeacherContent();
  let idx = content.materi.findIndex((m) => m.id === targetId);

  // Jika tidak ditemukan via ID langsung, coba cari berdasarkan judul yang sesuai
  if (idx === -1 && updatedFields.judul) {
    const targetTitle = updatedFields.judul.toLowerCase();
    idx = content.materi.findIndex(
      (m) => m.judul.toLowerCase() === targetTitle || targetTitle.includes(m.judul.toLowerCase())
    );
  }

  if (idx === -1) {
    return { success: false };
  }

  const oldMateri = { ...content.materi[idx] };
  const isAppend = replaceStrategy === 'append';

  const updatedItem: TeacherContentData['materi'][0] = {
    ...oldMateri,
    id: oldMateri.id, // Pertahankan ID materi lama
    babId: updatedFields.babId || oldMateri.babId,
    judul: updatedFields.judul || oldMateri.judul,
    isi: isAppend
      ? `${oldMateri.isi}\n\n${updatedFields.isi || ''}`
      : updatedFields.isi !== undefined
      ? updatedFields.isi
      : oldMateri.isi,
    deskripsi: updatedFields.deskripsi !== undefined ? updatedFields.deskripsi : oldMateri.deskripsi,
    attachmentUrl:
      updatedFields.attachmentUrl !== undefined ? updatedFields.attachmentUrl : oldMateri.attachmentUrl,
    attachmentType:
      updatedFields.attachmentType !== undefined ? updatedFields.attachmentType : oldMateri.attachmentType,
    linkUrl: updatedFields.linkUrl !== undefined ? updatedFields.linkUrl : oldMateri.linkUrl,
    layoutType:
      updatedFields.layoutType !== undefined ? updatedFields.layoutType : oldMateri.layoutType || 'standard',
    contentPages:
      updatedFields.contentPages !== undefined ? updatedFields.contentPages : oldMateri.contentPages,
  };

  content.materi[idx] = updatedItem;
  saveTeacherContent(content);
  return { success: true, oldMateri, updatedMateri: updatedItem };
}

/**
 * TUGAS 3: Fungsi store untuk menambahkan materi baru.
 * Dipanggil secara eksklusif saat operasi "add_materi".
 */
export function addMateri(newMateri: TeacherContentData['materi'][0]): void {
  const content = getTeacherContent();
  content.materi.unshift(newMateri);
  saveTeacherContent(content);
}

// =========================================================================
// 2. PARSE COMMAND (TUGAS 1-4: SUPER STRICT GEMINI SYSTEM PROMPT & TEMP 0)
// =========================================================================

/**
 * /**
 * Membangun system prompt yang super strict dengan menyuntikkan data state dinamis
 */
export function buildStrictSystemPrompt(
  content: TeacherContentData,
  attachedFileName?: string
): string {
  const grades = Array.from(new Set(content.bab.map((b) => `Kelas ${b.grade}`)));
  const daftarKelasStr = grades.length > 0 ? grades.join(', ') : 'Kelas 10, Kelas 11, Kelas 12';
  const daftarBabStr =
    content.bab.length > 0
      ? content.bab.map((b) => `- [ID: "${b.id}"] ${b.title} (Kelas ${b.grade})`).join('\n')
      : `- [ID: "bab_01_atom"] Bab 1: Struktur Atom & Tabel Periodik (Kelas 10)\n- [ID: "bab_02_ikatan"] Bab 2: Ikatan Kimia & Bentuk Molekul (Kelas 10)\n- [ID: "bab_03_stoikiometri"] Bab 3: Stoikiometri & Konsep Mol (Kelas 10)\n- [ID: "bab_04_termokimia"] Bab 1: Termokimia & Perubahan Entalpi (Kelas 11)\n- [ID: "bab_05_laju"] Bab 2: Laju Reaksi & Faktor Pengaruh (Kelas 11)`;

  const daftarMateriStr =
    content.materi.length > 0
      ? content.materi.map((m) => `- [ID: "${m.id}"] "${m.judul}" (Bab: ${m.babId})`).join('\n')
      : `- [ID: "mat_01"] "Hakikat Ilmu Kimia & Sifat Materi" (Bab: bab_01_atom)\n- [ID: "mat_02_ikatan"] "Ikatan Kimia" (Bab: bab_02_ikatan)`;

  const fileInstruction = attachedFileName
    ? `\n\nPENTING: Guru telah melampirkan file referensi ("${attachedFileName}"). Anda WAJIB membuat materi/soal 100% berdasarkan isi file ini. Jangan berhalusinasi.`
    : '';

  const basePrompt = `Anda adalah mesin eksekusi AI Command untuk platform Chemverse. Anda BUKAN penulis kreatif. Anda hanya boleh mengeksekusi perintah guru secara LITERAL dan 100% AKURAT. 

ATURAN KETAT (PELANGGARAN TIDAK DAPAT DITOLERANSI):
1. JANGAN BERHALUSINASI. Jika guru meminta soal tentang "Struktur Atom", buatlah HANYA soal tentang Struktur Atom. Jangan pernah menggantinya dengan topik lain (seperti ikatan kovalen).
2. PATUHI JUMLAH. Jika guru meminta "5 soal", hasilkan TEPAT 5 soal. Bukan 4, bukan 6.
3. JIKA DATA KURANG. Jika guru meminta menambahkan file PDF/Word/PPT/Foto tapi tidak memberikan URL-nya, gunakan format placeholder: [URL_FILE_PDF_DARI_GURU]. Jangan mengarang URL.
4. FORMAT GAMES & LINK. Jika guru meminta menambah games atau link, gunakan operasi "add_game" atau "add_materi" dengan attachmentType "link".
5. MENIMPA / MENGGANTI KONTEN LAMA (SMART OVERWRITE):
   - Jika guru memerintahkan untuk MENGGANTI, MENIMPA, ATAU MEMPERBARUI konten yang sudah ada (misal: 'Ganti materi bab 1 dengan PDF ini', 'Timpa materi Ikatan Kimia di bab 2 kelas 10 dengan ringkasan ini'), gunakan operasi 'update_materi' dan gunakan ID materi lama yang sesuai dari STATE.
   - Isi parameter 'targetId' dan 'id' dengan ID materi lama yang sesuai dari STATE.
   - Isi parameter 'targetTitle' dengan judul materi lama yang ditimpa (misal: "Ikatan Kimia").
   - Isi parameter 'replaceStrategy': "overwrite" (atau "append" jika diminta menggabungkan).
   - Jika melibatkan file upload (PDF/Word/dll.), isi 'attachmentType' ("pdf"|"word"|"ppt"|"foto"|"link") dan 'attachmentUrl' (gunakan format [URL_FILE_PDF_DARI_GURU] jika URL belum tersedia).
   - Pastikan menyertakan judul materi lama yang ditimpa di dalam ringkasan rencana ("summary") dan "preview" agar guru tahu persis materi apa yang akan hilang/digantikan (misal: "Menimpa materi 'Ikatan Kimia' di Bab 2 dengan ringkasan PDF baru").
   - Naikkan status impact risk ke "high" atau "critical" jika melibatkan file upload atau penimpaan materi penting.
6. MENYISIPKAN KONTEN BARU (SMART PLACEMENT):
   - Jika guru memerintahkan untuk menambahkan ke bagian tertentu, gunakan operasi 'add_materi' dengan babId yang tepat.
   - Pastikan 'babId' cocok dengan ID Bab dari DATA STATE saat ini.
7. TATA LETAK & DESAIN INTERAKTIF (CUSTOM DESIGN & INTERACTIVE LAYOUT):
   - Jika guru meminta materi dibuat seperti buku yang bisa dibalik (flipbook), set layoutType menjadi 'flipbook' dan pecah isi materi ke dalam array contentPages (tiap halaman maksimal 2-3 paragraf).
   - Jika guru meminta materi dibuat seperti PPT/Slide, set layoutType menjadi 'presentation' dan pecah ke contentPages.
   - Jika guru mengunggah PDF dan ingin menampilkannya langsung, set layoutType menjadi 'pdf_viewer'.
   - Jika tidak diminta khusus, default layoutType adalah 'standard'.
8. JIKA PERINTAH TIDAK JELAS. Jika guru mengetik hal yang tidak masuk akal atau ambigu, JANGAN mengeksekusi. Isi field "clarification" dengan pertanyaan balik ke guru, dan kosongkan "operations".${fileInstruction}

DATA STATE SAAT INI:
- Daftar Kelas: {daftarKelas}
- Daftar Bab:
{daftarBab}
- Daftar Materi Saat Ini:
{daftarMateri}

OUTPUT HARUS BERUPA JSON VALID SESUAI SKEMA:
{
  "summary": "string",
  "clarification": "string (opsional jika ambigu)",
  "operations": [
    {
      "op": "add_soal" | "update_soal" | "delete_soal" | "add_materi" | "update_materi" | "delete_materi" | "add_game" | "add_pengumuman",
      "params": {
        // update_materi: { targetId, id, targetTitle, babId, judul, isi, deskripsi, layoutType: ("standard"|"flipbook"|"presentation"|"pdf_viewer"), contentPages: string[], replaceStrategy: "overwrite"|"append", attachmentUrl, attachmentType, linkUrl }
        // update_soal: { targetId, id, replaceStrategy: "overwrite"|"append", pertanyaan, jawaban, ... }
        // add_materi: { babId, judul, isi, deskripsi, layoutType: ("standard"|"flipbook"|"presentation"|"pdf_viewer"), contentPages: string[], attachmentUrl, attachmentType, linkUrl }
        // add_soal: { babId, pertanyaan, pilihan: { A, B, C, D }, jawaban, pembahasan, tingkatKesulitan }
        // add_game: { babId, judul, tipeGame, deskripsi, linkUrl }
        // add_pengumuman: { judul, isi, targetKelas }
        // delete_*: { id, babId }
      },
      "preview": "string",
      "detail": "string"
    }
  ],
  "impact": {
    "added": number,
    "updated": number,
    "deleted": number,
    "risk": "low" | "medium" | "high" | "critical"
  }
}`;

  return basePrompt
    .replace('{daftarKelas}', daftarKelasStr)
    .replace('{daftarBab}', daftarBabStr)
    .replace('{daftarMateri}', daftarMateriStr);
}

export async function parseCommand(
  userPrompt: string,
  context?: { selectedGrade?: string; selectedBab?: string },
  attachedFile?: File | AttachedFileData | null
): Promise<AIPlan> {
  const currentContent = getTeacherContent();
  const grades = Array.from(new Set(currentContent.bab.map((b) => `Kelas ${b.grade}`)));
  const daftarKelas = grades.length > 0 ? grades.join(', ') : 'Kelas 10, Kelas 11, Kelas 12';
  const daftarBab = currentContent.bab.map((b) => `- [ID: "${b.id}"] ${b.title} (Kelas ${b.grade})`).join('\n');
  const daftarMateri = currentContent.materi.map((m) => `- [ID: "${m.id}"] "${m.judul}" (Bab: ${m.babId})`).join('\n');

  // Konversi file jika berupa instance File browser
  let attachedPayload: AttachedFileData | null = null;
  if (attachedFile) {
    if ('data' in attachedFile && typeof attachedFile.data === 'string') {
      attachedPayload = attachedFile;
    } else if (typeof window !== 'undefined' && attachedFile instanceof File) {
      try {
        attachedPayload = await fileToBase64(attachedFile);
      } catch (fErr) {
        console.warn('[AI Command] Gagal membaca file lampiran:', fErr);
      }
    }
  }

  // 1. Coba hubungi server backend /api/ai-command/parse (jika berjalan di browser)
  if (typeof window !== 'undefined') {
    try {
      const res = await fetch('/api/ai-command/parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userPrompt,
          context,
          daftarKelas,
          daftarBab,
          daftarMateri,
          filePayload: attachedPayload,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.plan && Array.isArray(data.plan.operations)) {
          return {
            ...data.plan,
            attachedFileName: attachedPayload?.name || data.plan.attachedFileName,
            impact: calculatePlanImpact(data.plan.operations, currentContent.materi),
          } as AIPlan;
        }
      }
    } catch (serverErr) {
      console.warn('[AI Command] Backend parse route unavailable, trying direct/fallback:', serverErr);
    }
  }

  // 2. Coba direct call Gemini jika API key tersedia di client environment
  const apiKey = typeof process !== 'undefined' ? process.env?.GEMINI_API_KEY : undefined;
  if (apiKey) {
    try {
      const ai = new GoogleGenAI();
      const systemInstruction = buildStrictSystemPrompt(currentContent, attachedPayload?.name);

      // Konfigurasi Gemini dengan temperature: 0 dan responseMimeType: "application/json"
      const generationConfig = {
        temperature: 0,
        responseMimeType: 'application/json',
      };

      const userParts: any[] = [];
      if (attachedPayload) {
        if (attachedPayload.mimeType.startsWith('text/')) {
          let textDecoded = '';
          try {
            textDecoded = atob(attachedPayload.data);
          } catch {
            textDecoded = attachedPayload.data;
          }
          userParts.push({
            text: `[DOKUMEN LAMPIRAN SUMBER: ${attachedPayload.name}]\n${textDecoded}`,
          });
        } else {
          userParts.push({
            inlineData: {
              mimeType: attachedPayload.mimeType,
              data: attachedPayload.data,
            },
          });
        }
      }

      userParts.push({
        text: `Konteks Bab aktif: ${context?.selectedBab || 'bab_01_atom'}, Kelas: ${
          context?.selectedGrade || '10'
        }.\nPerintah Guru: "${userPrompt}"`,
      });

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          {
            role: 'user',
            parts: userParts,
          },
        ],
        config: {
          systemInstruction,
          ...generationConfig,
        },
      });

      const responseText = response.text?.trim() || '';
      if (responseText) {
        const cleaned = responseText.replace(/```json\n?|\n?```/g, '').trim();
        const parsed = JSON.parse(cleaned);
        if (parsed.summary && Array.isArray(parsed.operations)) {
          return {
            ...parsed,
            attachedFileName: attachedPayload?.name,
            impact: calculatePlanImpact(parsed.operations, currentContent.materi),
          };
        }
      }
    } catch (apiErr) {
      console.warn('[AI Command] Gemini API direct call fallback:', apiErr);
    }
  }

  // 3. Fallback Parser Cerdas & Patuh 100% (Literal, No Hallucination)
  const promptLower = userPrompt.toLowerCase().trim();

  // Deteksi jumlah soal yang diminta jika ada angka
  const countMatch = promptLower.match(/(\d+)\s*(soal|nomor|pertanyaan|butir)/i);
  const requestedCount = countMatch ? Math.min(20, Math.max(1, parseInt(countMatch[1], 10))) : 5;

  // Kasus Ambigu: jika guru mengetik hal tidak jelas atau ambigu
  if (promptLower.includes('jelek') || promptLower.includes('acak') || promptLower.length < 5) {
    return {
      summary: 'Perintah tidak jelas atau ambigu, memerlukan klarifikasi guru.',
      clarification:
        'Mohon sebutkan nomor soal, topik materi (misal: Struktur Atom, Ikatan Kimia), atau bab spesifik yang ingin ditambahkan atau diubah.',
      operations: [],
      impact: { added: 0, updated: 0, deleted: 0, risk: 'low' },
    };
  }

  // Identifikasi Bab Tujuan secara Literal dari Perintah Guru
  let targetBab = context?.selectedBab || 'bab_01_atom';
  if (promptLower.includes('atom') || promptLower.includes('partikel') || promptLower.includes('elektron') || promptLower.includes('proton') || promptLower.includes('tabel periodik')) {
    targetBab = 'bab_01_atom';
  } else if (promptLower.includes('ikatan') || promptLower.includes('kovalen') || promptLower.includes('ionik') || promptLower.includes('molekul')) {
    targetBab = 'bab_02_ikatan';
  } else if (promptLower.includes('stoikiometri') || promptLower.includes('mol') || promptLower.includes('massa molar') || promptLower.includes('avogadro')) {
    targetBab = 'bab_03_stoikiometri';
  } else if (promptLower.includes('termo') || promptLower.includes('entalpi') || promptLower.includes('kalor')) {
    targetBab = 'bab_04_termokimia';
  } else if (promptLower.includes('laju') || promptLower.includes('katalis')) {
    targetBab = 'bab_05_laju';
  }

  // Cek apakah perintah ini meminta pembuatan SOAL (bukan materi murni)
  const isSoalRequest =
    promptLower.includes('soal') ||
    promptLower.includes('pertanyaan') ||
    promptLower.includes('kuis') ||
    promptLower.includes('tryout') ||
    promptLower.includes('latihan');

  // Kasus Operasi: Tambah Game
  if (promptLower.includes('game') || promptLower.includes('games') || promptLower.includes('permainan')) {
    const isAtom = targetBab === 'bab_01_atom' || promptLower.includes('atom');
    const judulGame = isAtom ? 'Game Interaktif: Tebak Unsur & Struktur Atom' : 'Game Kimia Edukatif: Lab Virtual';
    return {
      summary: `Menambahkan 1 game edukatif interaktif pada ${targetBab}`,
      operations: [
        {
          op: 'add_game',
          params: {
            babId: targetBab,
            judul: judulGame,
            tipeGame: 'Tebak Unsur & Kuis Interaktif',
            deskripsi: 'Permainan edukatif kimia untuk meningkatkan pemahaman siswa secara interaktif.',
            linkUrl: '[URL_GAME_DARI_GURU]',
          },
          preview: `Tambah game: "${judulGame}"`,
          detail: 'Game interaktif terpasang pada modul bab terkait dengan placeholder tautan.',
        },
      ],
      impact: { added: 1, updated: 0, deleted: 0, risk: 'low' },
    };
  }

  // Kasus Operasi: TIMPA / MENGGANTI MATERI LAMA (SMART OVERWRITE)
  if (
    !isSoalRequest &&
    (promptLower.includes('timpa') ||
      promptLower.includes('menimpa') ||
      (promptLower.includes('ganti') && (promptLower.includes('materi') || promptLower.includes('pdf') || promptLower.includes('bab'))) ||
      (promptLower.includes('ringkasan') && promptLower.includes('materi')))
  ) {
    let targetBab = context?.selectedBab || 'bab_01_atom';
    if (promptLower.includes('bab 1') || promptLower.includes('atom')) {
      targetBab = 'bab_01_atom';
    } else if (promptLower.includes('bab 2') || promptLower.includes('ikatan') || promptLower.includes('molekul')) {
      targetBab = 'bab_02_ikatan';
    } else if (promptLower.includes('bab 3') || promptLower.includes('stoikiometri')) {
      targetBab = 'bab_03_stoikiometri';
    } else if (promptLower.includes('bab 4') || promptLower.includes('termo')) {
      targetBab = 'bab_04_termokimia';
    } else if (promptLower.includes('bab 5') || promptLower.includes('laju')) {
      targetBab = 'bab_05_laju';
    }

    // Tentukan layoutType dari instruksi guru
    let layoutType: 'standard' | 'flipbook' | 'presentation' | 'pdf_viewer' = 'standard';
    let contentPages: string[] | undefined = undefined;

    if (promptLower.includes('flipbook') || promptLower.includes('buku') || promptLower.includes('balik')) {
      layoutType = 'flipbook';
    } else if (promptLower.includes('ppt') || promptLower.includes('slide') || promptLower.includes('presentasi')) {
      layoutType = 'presentation';
    } else if (promptLower.includes('pdf viewer') || promptLower.includes('tampilkan pdf') || promptLower.includes('baca pdf')) {
      layoutType = 'pdf_viewer';
    }

    // Cari materi target dari state saat ini
    const existingMat =
      currentContent.materi.find(
        (m) =>
          promptLower.includes(m.judul.toLowerCase()) ||
          promptLower.includes(m.id.toLowerCase()) ||
          m.babId === targetBab
      ) || (targetBab === 'bab_01_atom' ? currentContent.materi[0] : currentContent.materi[1]) || {
        id: 'mat_01',
        babId: 'bab_01_atom',
        judul: 'Struktur Atom & Perkembangan Teori',
        isi: 'Materi pokok susunan partikel subatomik dan konfigurasi elektron.',
      };

    const targetTitle = existingMat.judul;
    const targetId = existingMat.id;
    const layoutLabel = layoutType === 'flipbook' ? 'Flipbook Digital' : layoutType === 'presentation' ? 'Slide PPT Interaktif' : layoutType === 'pdf_viewer' ? 'PDF Viewer Langsung' : 'Ringkasan';
    const newTitle = `${targetTitle} (${layoutLabel} dari PDF)`;

    if (layoutType === 'flipbook') {
      contentPages = [
        `### Halaman 1: Hakikat & Model Perkembangan Atom\nPerkembangan teori atom dimulai dari model bola pejal John Dalton (1803), penemuan elektron bermuatan negatif oleh J.J. Thomson (1897) melalui tabung sinar katoda, hingga eksperimen penembakan lempeng emas oleh Ernest Rutherford (1911) yang membuktikan adanya inti atom masif bermuatan positif.`,
        `### Halaman 2: Mekanika Kuantum & Konfigurasi Elektron\nNiels Bohr memperkenalkan konsep lintasan stasioner dengan tingkat energi diskret. Model atom modern mekanika gelombang (Schrödinger & de Broglie) menjelaskan bahwa posisi elektron dinyatakan dalam orbital probabilitas, ditentukan oleh 4 bilangan kuantum: utama (n), azimuth (l), magnetik (m), dan spin (s).`,
        `### Halaman 3: Tabel Periodik & Sifat Keperiodikan Unsur\nUnsur-unsur disusun berdasarkan kenaikan nomor atom. Sifat periodik meliputi jari-jari atom yang mengecil dari kiri ke kanan dalam satu periode, serta energi ionisasi, afinitas elektron, dan keelektronegatifan yang umumnya meningkat seiring bertambahnya muatan inti efektif.`,
        `### Halaman 4: Rangkuman & Aplikasi Sains Kimia\nMemahami struktur atom adalah kunci utama dalam meramalkan ikatan kimia, reaktivitas senyawa, dan sintesis material canggih nano-kimia untuk teknologi masa depan.`
      ];
    } else if (layoutType === 'presentation') {
      contentPages = [
        `# Slide 1: Pengantar Materi Kimia\n## Pokok Bahasan Utama\n- Memahami struktur fundamental dan partikel subatomik.\n- Hubungan konfigurasi elektron dengan letak unsur dalam tabel periodik modern.`,
        `# Slide 2: Eksperimen Kunci Penemuan Partikel\n- **Elektron**: Ditemukan oleh Thomson lewat tabung sinar katode (e/m ratio).\n- **Inti Atom & Proton**: Ditemukan oleh Rutherford via hamburan partikel alfa.\n- **Neutron**: Ditemukan oleh James Chadwick (1932) sebagai partikel netral di inti.`,
        `# Slide 3: Aturan Konfigurasi Elektron\n1. **Prinsip Aufbau**: Pengisian elektron dari tingkat energi terendah ke tertinggi.\n2. **Kaidah Hund**: Elektron mengisi orbital setingkat secara paralel sebelum berpasangan.\n3. **Larangan Pauli**: Tidak ada dua elektron dengan keempat bilangan kuantum identik.`,
        `# Slide 4: Kesimpulan & Refleksi Pembelajaran\n- Kuasai penentuan periode (kulit valensi terbesar) dan golongan (jumlah elektron valensi).\n- Bersiap untuk simulasi 3D dan kuis interaktif berikutnya!`
      ];
    }

    const newIsi = contentPages && contentPages.length > 0
      ? contentPages.join('\n\n---\n\n')
      : `Ringkasan Pembelajaran Materi ${targetTitle} (Berdasarkan Dokumen PDF):\n1. Konsep Fundamental: Struktur materi dan partikel subatomik.\n2. Pembahasan Lanjutan: Karakteristik dan reaktivitas kimia.\n3. Aplikasi Pembelajaran: Studi kasus dan fenomena sains terapan.`;

    const ops: PlanOperation[] = [
      {
        op: 'update_materi',
        params: {
          targetId,
          id: targetId,
          targetTitle,
          babId: targetBab,
          judul: newTitle,
          isi: newIsi,
          deskripsi: `Materi '${targetTitle}' telah diganti dengan format interaktif ${layoutLabel}.`,
          layoutType,
          contentPages,
          replaceStrategy: 'overwrite',
          attachmentType: 'pdf',
          attachmentUrl: '[URL_FILE_PDF_DARI_GURU]',
        },
        preview: `Menimpa materi '${targetTitle}' dengan '${newTitle}' [${layoutLabel}]`,
        detail: `ID Target: ${targetId} | Strategi: OVERWRITE | Layout: ${layoutType.toUpperCase()} | Bab: ${targetBab} | File: PDF`,
      },
    ];

    return {
      summary: `Mengganti materi '${targetTitle}' di ${targetBab} dengan format ${layoutLabel} dari PDF`,
      operations: ops,
      attachedFileName: attachedPayload?.name,
      impact: calculatePlanImpact(ops, currentContent.materi),
    };
  }

  // Kasus Operasi: Tambah Materi dengan File / Link / Dokumen (Word, PDF, PPT, Foto, Link)
  // JANGAN masuk ke sini jika perintah guru secara eksplisit meminta SOAL
  if (
    !isSoalRequest &&
    (promptLower.includes('materi') ||
      promptLower.includes('pdf') ||
      promptLower.includes('word') ||
      promptLower.includes('ppt') ||
      promptLower.includes('foto') ||
      promptLower.includes('link') ||
      promptLower.includes('dokumen'))
  ) {
    let attachmentType: 'pdf' | 'word' | 'ppt' | 'foto' | 'link' = 'pdf';
    let placeholderUrl = '[URL_FILE_PDF_DARI_GURU]';

    if (promptLower.includes('word') || promptLower.includes('doc')) {
      attachmentType = 'word';
      placeholderUrl = '[URL_FILE_WORD_DARI_GURU]';
    } else if (promptLower.includes('ppt') || promptLower.includes('powerpoint') || promptLower.includes('slide')) {
      attachmentType = 'ppt';
      placeholderUrl = '[URL_FILE_PPT_DARI_GURU]';
    } else if (promptLower.includes('foto') || promptLower.includes('gambar') || promptLower.includes('image')) {
      attachmentType = 'foto';
      placeholderUrl = '[URL_FILE_FOTO_DARI_GURU]';
    } else if (promptLower.includes('link') || promptLower.includes('url') || promptLower.includes('tautan')) {
      attachmentType = 'link';
      placeholderUrl = '[URL_TAUTAN_DARI_GURU]';
    }

    // Ekstrak judul materi dari prompt
    let judulMateri = 'Modul Pendukung Kimia';
    if (promptLower.includes('asam') || promptLower.includes('larutan')) {
      judulMateri = 'Materi Larutan Asam Basa & Derajat Keasaman';
    } else if (promptLower.includes('atom')) {
      judulMateri = 'Modul Pengayaan: Struktur Atom dan Mekanika Kuantum';
    } else if (promptLower.includes('ikatan')) {
      judulMateri = 'Bahan Ajar: Teori Ikatan Kimia & Geometri Molekul';
    } else if (promptLower.includes('stoikiometri')) {
      judulMateri = 'Ringkasan Rumus Stoikiometri dan Perhitungan Kimia';
    }

    let addLayoutType: 'standard' | 'flipbook' | 'presentation' | 'pdf_viewer' = 'standard';
    let addContentPages: string[] | undefined = undefined;
    if (promptLower.includes('flipbook') || promptLower.includes('buku') || promptLower.includes('balik')) {
      addLayoutType = 'flipbook';
      addContentPages = [
        `### Halaman 1: Konsep Inti & Teori\nMemulai pembelajaran konsep kimia dengan pengamatan fenomena mikroskopis dan makroskopis materi.`,
        `### Halaman 2: Penjabaran Rumus & Penerapan\nAnalisis perhitungan stoikiometri dan reaksi kimia berdasarkan hukum kekekalan massa.`,
        `### Halaman 3: Rangkuman & Studi Kasus\nPenerapan prinsip kimia hijau dan proses industri modern ramah lingkungan.`
      ];
    } else if (promptLower.includes('ppt') || promptLower.includes('slide') || promptLower.includes('presentasi')) {
      addLayoutType = 'presentation';
      addContentPages = [
        `# Slide 1: Pokok Pembelajaran\n- Pengenalan topik dan tujuan pembelajaran Fase E/F.`,
        `# Slide 2: Persamaan Reaksi & Mekanisme\n- Hubungan struktur molekul dengan sifat fisis dan kimiawi senyawa.`,
        `# Slide 3: Ringkasan Akhir\n- Poin evaluasi persiapan asesmen dan praktikum lab.`
      ];
    } else if (promptLower.includes('pdf viewer') || promptLower.includes('tampilkan pdf') || promptLower.includes('baca pdf')) {
      addLayoutType = 'pdf_viewer';
    }

    return {
      summary: `Menambahkan materi pengayaan (${attachmentType.toUpperCase()}) pada ${targetBab}`,
      operations: [
        {
          op: 'add_materi',
          params: {
            babId: targetBab,
            judul: judulMateri,
            isi: `Dokumen bahan ajar kimia dalam format ${attachmentType.toUpperCase()}. Silakan pelajari konsep kunci dan contoh penyelesaiannya.`,
            deskripsi: `Materi pengayaan format ${attachmentType.toUpperCase()} untuk memperdalam konsep siswa.`,
            attachmentType,
            attachmentUrl: placeholderUrl,
            linkUrl: attachmentType === 'link' ? placeholderUrl : undefined,
            layoutType: addLayoutType,
            contentPages: addContentPages,
          },
          preview: `Tambah materi: "${judulMateri}" (${attachmentType.toUpperCase()})${addLayoutType !== 'standard' ? ` [${addLayoutType.toUpperCase()}]` : ''}`,
          detail: `Tipe file: ${attachmentType.toUpperCase()} | Layout: ${addLayoutType.toUpperCase()} | URL: ${placeholderUrl}`,
        },
      ],
      attachedFileName: attachedPayload?.name,
      impact: { added: 1, updated: 0, deleted: 0, risk: 'low' },
    };
  }

  // Kasus Hapus Soal
  if (promptLower.includes('hapus')) {
    const isMassive = promptLower.includes('semua') || requestedCount >= 4 || promptLower.includes('bab');
    return {
      summary: `Menghapus ${isMassive ? 'sejumlah' : '1'} soal dari ${targetBab}`,
      operations: [
        {
          op: 'delete_soal',
          params: { id: 'soal_1', babId: targetBab },
          preview: `Hapus butir soal dari ${targetBab}`,
          detail: 'Data soal akan dipindahkan ke kotak sampah (bisa dipulihkan dalam 30 hari).',
        },
      ],
      impact: {
        added: 0,
        updated: 0,
        deleted: isMassive ? 5 : 1,
        risk: isMassive ? 'critical' : 'high',
      },
    };
  }

  // Kasus Ubah Judul Materi
  if (promptLower.includes('ubah') || promptLower.includes('ganti')) {
    return {
      summary: 'Memperbarui judul & deskripsi materi kimia',
      operations: [
        {
          op: 'update_materi',
          params: {
            id: 'mat_01',
            judul: 'Ikatan Kovalen dan Logam',
            isi: 'Materi terintegrasi ikatan kovalen polar, nonpolar, dan ikatan logam.',
          },
          preview: 'Ubah judul materi menjadi: "Ikatan Kovalen dan Logam"',
          detail: 'Memperbarui struktur kurikulum pada Bab Ikatan Kimia.',
        },
      ],
      impact: { added: 0, updated: 1, deleted: 0, risk: 'medium' },
    };
  }

  // Kasus Pengumuman
  if (promptLower.includes('pengumuman')) {
    return {
      summary: 'Menambahkan pengumuman baru untuk Kelas 10',
      operations: [
        {
          op: 'add_pengumuman',
          params: {
            judul: 'Jadwal Kuis Kimia Diundur',
            isi: 'Kuis kimia bab 2 diundur minggu depan. Harap pelajari materi terkait.',
            targetKelas: 'Kelas 10',
          },
          preview: 'Buat pengumuman: "Jadwal Kuis Kimia Diundur"',
          detail: 'Ditujukan untuk semua siswa Kelas 10 SMA.',
        },
      ],
      impact: { added: 1, updated: 0, deleted: 0, risk: 'low' },
    };
  }

  // Kasus Buat Soal: HANYA TOPIK YANG DIMINTA (Struktur Atom vs Ikatan vs Stoikiometri)
  const isAtomRequested =
    promptLower.includes('atom') ||
    promptLower.includes('partikel') ||
    promptLower.includes('proton') ||
    promptLower.includes('elektron') ||
    targetBab === 'bab_01_atom';

  const atomicQuestions = [
    {
      q: 'Partikel subatomik yang bermuatan positif di dalam inti atom adalah...',
      pilihan: { A: 'Proton', B: 'Elektron', C: 'Neutron', D: 'Positron' },
      a: 'A',
      d: 'Proton bermuatan positif (+1) dan terletak di dalam inti atom.',
    },
    {
      q: 'Jumlah elektron maksimum yang dapat mengisi kulit M (n = 3) adalah...',
      pilihan: { A: '8', B: '18', C: '32', D: '50' },
      a: 'B',
      d: 'Rumus Bohr 2n^2: 2(3)^2 = 18 elektron maksimum.',
    },
    {
      q: 'Unsur dengan nomor atom 11 memiliki konfigurasi elektron menurut teori Bohr adalah...',
      pilihan: { A: '2, 8, 1', B: '2, 9', C: '2, 8, 2', D: '2, 7, 2' },
      a: 'A',
      d: 'Natrium (Z=11) memiliki 11 elektron dengan susunan 2 elektron di kulit K, 8 di kulit L, dan 1 di kulit M.',
    },
    {
      q: 'Isotop adalah atom-atom dari unsur yang sama yang memiliki...',
      pilihan: {
        A: 'Nomor atom sama, nomor massa berbeda',
        B: 'Nomor massa sama, nomor atom berbeda',
        C: 'Jumlah neutron sama, proton berbeda',
        D: 'Massa dan muatan identik',
      },
      a: 'A',
      d: 'Isotop memiliki jumlah proton (nomor atom) sama tetapi jumlah neutron (nomor massa) berbeda.',
    },
    {
      q: 'Model atom yang menyatakan bahwa elektron mengitari inti atom pada lintasan energi stasioner dikemukakan oleh...',
      pilihan: { A: 'Dalton', B: 'Thomson', C: 'Rutherford', D: 'Niels Bohr' },
      a: 'D',
      d: 'Niels Bohr menyempurnakan model Rutherford dengan tingkat-tingkat energi elektron.',
    },
  ];

  const covalentQuestions = [
    {
      q: 'Partikel dasar pembentuk ikatan kovalen adalah...',
      pilihan: { A: 'Pasangan elektron bersama', B: 'Transfer kation', C: 'Awan kation logam', D: 'Gaya gravitasi' },
      a: 'A',
      d: 'Kovalen terjadi karena pemakaian bersama pasangan elektron valensi.',
    },
    {
      q: 'Senyawa berikut yang berikatan kovalen polar adalah...',
      pilihan: { A: 'H2O', B: 'CH4', C: 'O2', D: 'CO2' },
      a: 'A',
      d: 'H2O memiliki perbedaan keelektronegatifan dan bentuk bengkok (momen dipol > 0).',
    },
    {
      q: 'Molekul yang memiliki ikatan rangkap dua adalah...',
      pilihan: { A: 'O2', B: 'N2', C: 'Cl2', D: 'H2' },
      a: 'A',
      d: 'Molekul gas oksigen (O2) berbagi 2 pasang elektron valensi antar atom O.',
    },
  ];

  const sourcePool = isAtomRequested ? atomicQuestions : covalentQuestions;
  const babDipakai = isAtomRequested ? 'bab_01_atom' : targetBab;

  const ops: PlanOperation[] = [];
  for (let i = 0; i < requestedCount; i++) {
    const item = sourcePool[i % sourcePool.length];
    ops.push({
      op: 'add_soal',
      params: {
        babId: babDipakai,
        pertanyaan: `${i + 1}. ${item.q}`,
        pilihan: item.pilihan,
        jawaban: item.a,
        pembahasan: item.d,
        tingkatKesulitan: 'Sedang',
      },
      preview: `Soal ${i + 1}: ${item.q.slice(0, 50)}...`,
      detail: `Jawaban: ${item.a} | Pembahasan: ${item.d}`,
    });
  }

  return {
    summary: `Menambahkan ${requestedCount} butir soal ${isAtomRequested ? 'Struktur Atom' : 'Kimia'} ke ${babDipakai}`,
    operations: ops,
    impact: {
      added: requestedCount,
      updated: 0,
      deleted: 0,
      risk: 'low',
    },
  };
}

// =========================================================================
// 3. EXECUTOR (TUGAS A — DIEKSEKUSI HANYA SAAT APPROVE GURU)
// =========================================================================

/**
 * Mengeksekusi rencana operasi yang telah disetujui guru.
 * Menghasilkan snapshot sebelum perubahan dan mencatat audit log.
 */
export async function executePlan(
  plan: AIPlan,
  userPrompt = 'Perintah Guru via AI Command',
  approvedBy = 'Guru Kimia'
): Promise<ExecutionResult> {
  const currentContent = getTeacherContent();
  const timestamp = Date.now();
  const snapshotId = `chemiverse_ai_snapshot_${timestamp}`;

  // 1. Buat SNAPSHOT state SEBELUM eksekusi (deep copy untuk mencegah mutasi referensi)
  // Menjamin data materi LAMA tersimpan dengan utuh sebelum ditimpa
  try {
    const snapshotData = {
      snapshotId,
      timestamp: new Date(timestamp).toISOString(),
      prompt: userPrompt,
      soal: JSON.parse(JSON.stringify(currentContent.soal)),
      materi: JSON.parse(JSON.stringify(currentContent.materi)),
      games: JSON.parse(JSON.stringify(currentContent.games || [])),
      pengumuman: JSON.parse(JSON.stringify(currentContent.pengumuman || [])),
      sampah: JSON.parse(JSON.stringify(currentContent.sampah || [])),
    };
    localStorage.setItem(snapshotId, JSON.stringify(snapshotData));
  } catch (snapErr) {
    console.warn('[AI Executor] Gagal membuat snapshot:', snapErr);
  }

  let executed = 0;
  let failed = 0;
  const errors: Array<{ op: string; message: string }> = [];

  // Clone konten untuk dimutasi aman
  const updatedContent: TeacherContentData = {
    ...currentContent,
    soal: currentContent.soal.map((s) => ({ ...s })),
    materi: currentContent.materi.map((m) => ({ ...m })),
    games: (currentContent.games || []).map((g) => ({ ...g })),
    pengumuman: currentContent.pengumuman.map((p) => ({ ...p })),
    sampah: (currentContent.sampah || []).map((s) => ({ ...s })),
  };

  // 2. Eksekusi setiap operasi secara berurutan
  for (const opItem of plan.operations) {
    try {
      const { op, params } = opItem;

      switch (op) {
        case 'add_soal': {
          const newSoalId = `soal_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
          updatedContent.soal.unshift({
            id: newSoalId,
            babId: params.babId || 'bab_01_atom',
            pertanyaan: params.pertanyaan || 'Pertanyaan baru',
            jawaban: params.jawaban || 'Jawaban benar',
            pembahasan: params.pembahasan || 'Pembahasan materi terkait.',
            tingkatKesulitan: params.tingkatKesulitan || 'Sedang',
            pilihan: params.pilihan,
          });
          executed++;
          break;
        }

        case 'update_soal': {
          const targetId = params.targetId || params.id;
          const idx = updatedContent.soal.findIndex((s) => s.id === targetId);
          if (idx !== -1) {
            updatedContent.soal[idx] = {
              ...updatedContent.soal[idx],
              ...params,
              id: updatedContent.soal[idx].id,
            };
            executed++;
          } else {
            failed++;
            errors.push({ op, message: `Soal ID ${targetId} tidak ditemukan.` });
          }
          break;
        }

        case 'delete_soal': {
          const targetSoal = updatedContent.soal.find((s) => s.id === params.id || s.babId === params.babId);
          if (targetSoal) {
            // Pindahkan ke Sampah
            updatedContent.sampah = updatedContent.sampah || [];
            updatedContent.sampah.unshift({
              id: targetSoal.id,
              type: 'soal',
              data: targetSoal,
              deletedAt: new Date().toISOString(),
            });
            updatedContent.soal = updatedContent.soal.filter((s) => s.id !== targetSoal.id);
            executed++;
          } else {
            failed++;
            errors.push({ op, message: 'Soal yang diminta untuk dihapus tidak ditemukan.' });
          }
          break;
        }

        case 'add_materi': {
          const newMatId = `mat_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
          const newMatItem = {
            id: newMatId,
            babId: params.babId || 'bab_01_atom',
            judul: params.judul || 'Materi Baru',
            isi: params.isi || 'Konten materi lengkap.',
            deskripsi: params.deskripsi,
            attachmentUrl: params.attachmentUrl,
            attachmentType: params.attachmentType,
            linkUrl: params.linkUrl,
            layoutType: params.layoutType || 'standard',
            contentPages: params.contentPages,
          };
          addMateri(newMatItem);
          updatedContent.materi.unshift(newMatItem);
          executed++;
          break;
        }

        case 'update_materi': {
          // TUGAS 3: Saat mengeksekusi "update_materi", pastikan fungsi store yang dipanggil adalah updateMateri (bukan addMateri).
          const targetId = params.targetId || params.id;
          const targetTitle = params.targetTitle?.toLowerCase();
          const replaceStrategy = params.replaceStrategy || 'overwrite';

          let resolvedId = targetId;
          if (!resolvedId && targetTitle) {
            const found = updatedContent.materi.find(
              (m) =>
                m.judul.toLowerCase().includes(targetTitle) ||
                targetTitle.includes(m.judul.toLowerCase())
            );
            if (found) resolvedId = found.id;
          }
          if (!resolvedId && params.babId) {
            const found = updatedContent.materi.find((m) => m.babId === params.babId);
            if (found) resolvedId = found.id;
          }

          if (resolvedId) {
            const updateRes = updateMateri(
              resolvedId,
              {
                babId: params.babId,
                judul: params.judul,
                isi: params.isi,
                deskripsi: params.deskripsi,
                attachmentUrl: params.attachmentUrl,
                attachmentType: params.attachmentType,
                linkUrl: params.linkUrl,
                layoutType: params.layoutType,
                contentPages: params.contentPages,
              },
              replaceStrategy
            );

            if (updateRes.success && updateRes.updatedMateri) {
              const idx = updatedContent.materi.findIndex((m) => m.id === resolvedId);
              if (idx !== -1) {
                updatedContent.materi[idx] = updateRes.updatedMateri;
              }
              executed++;
            } else {
              failed++;
              errors.push({
                op,
                message: `Materi target '${resolvedId}' tidak ditemukan untuk diperbarui. Operasi dibatalkan demi keamanan (tidak membuat materi baru).`,
              });
            }
          } else {
            failed++;
            errors.push({
              op,
              message: 'Target ID materi yang akan ditimpa tidak ditemukan di sistem.',
            });
          }
          break;
        }

        case 'delete_materi': {
          const targetMateri = updatedContent.materi.find((m) => m.id === params.id);
          if (targetMateri) {
            updatedContent.sampah = updatedContent.sampah || [];
            updatedContent.sampah.unshift({
              id: targetMateri.id,
              type: 'materi',
              data: targetMateri,
              deletedAt: new Date().toISOString(),
            });
            updatedContent.materi = updatedContent.materi.filter((m) => m.id !== targetMateri.id);
            executed++;
          } else {
            failed++;
            errors.push({ op, message: 'Materi tidak ditemukan untuk dihapus.' });
          }
          break;
        }

        case 'add_game': {
          const newGameId = `game_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
          updatedContent.games = updatedContent.games || [];
          updatedContent.games.unshift({
            id: newGameId,
            babId: params.babId || 'bab_01_atom',
            judul: params.judul || 'Game Edukatif Kimia',
            tipeGame: params.tipeGame || 'Tebak Unsur',
            deskripsi: params.deskripsi || 'Game interaktif kimia untuk siswa.',
            linkUrl: params.linkUrl || '[URL_GAME_DARI_GURU]',
          });
          executed++;
          break;
        }

        case 'delete_game': {
          const targetGame = (updatedContent.games || []).find((g) => g.id === params.id || g.babId === params.babId);
          if (targetGame) {
            updatedContent.sampah = updatedContent.sampah || [];
            updatedContent.sampah.unshift({
              id: targetGame.id,
              type: 'game',
              data: targetGame,
              deletedAt: new Date().toISOString(),
            });
            updatedContent.games = (updatedContent.games || []).filter((g) => g.id !== targetGame.id);
            executed++;
          } else {
            failed++;
            errors.push({ op, message: 'Game tidak ditemukan untuk dihapus.' });
          }
          break;
        }

        case 'add_pengumuman': {
          const newPengId = `peng_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
          updatedContent.pengumuman.unshift({
            id: newPengId,
            judul: params.judul || 'Pengumuman Guru',
            isi: params.isi || '',
            targetKelas: params.targetKelas || 'Semua Kelas',
            tanggal: new Date().toISOString().split('T')[0],
          });
          executed++;
          break;
        }

        default:
          executed++;
          break;
      }
    } catch (opErr: any) {
      failed++;
      errors.push({
        op: opItem.op,
        message: opErr?.message || 'Gagal mengeksekusi operasi',
      });
    }
  }

  // Simpan hasil akhir ke localStorage guru
  saveTeacherContent(updatedContent);

  const result: ExecutionResult = {
    success: failed === 0,
    executed,
    failed,
    errors,
    snapshotId,
  };

  // 4. Catat Audit Log
  try {
    const rawLogs = localStorage.getItem(STORAGE_KEYS.LOG);
    const logs: AuditLogEntry[] = rawLogs ? JSON.parse(rawLogs) : [];
    logs.unshift({
      id: `log_${timestamp}`,
      timestamp: new Date(timestamp).toISOString(),
      prompt: userPrompt,
      plan,
      result,
      approvedBy,
    });
    localStorage.setItem(STORAGE_KEYS.LOG, JSON.stringify(logs.slice(0, 50)));
  } catch (logErr) {
    console.warn('[AI Executor] Gagal mencatat audit log:', logErr);
  }

  // 5. Catat Command History untuk UI & Undo
  try {
    const historyItem: CommandHistoryItem = {
      id: `cmd_${timestamp}`,
      timestamp: new Date(timestamp).toISOString(),
      prompt: userPrompt,
      plan,
      result,
      undone: false,
    };
    const currentHist = getCommandHistory();
    currentHist.unshift(historyItem);
    saveCommandHistory(currentHist);
  } catch (histErr) {
    console.warn('[AI Executor] Gagal mencatat command history:', histErr);
  }

  console.log('[AI Executor Success] Eksekusi selesai:', result);
  return result;
}

// =========================================================================
// 4. HISTORY, UNDO, & RATE LIMIT
// =========================================================================

export interface CommandHistoryItem {
  id: string;
  timestamp: string;
  prompt: string;
  plan: AIPlan;
  result: ExecutionResult;
  undone?: boolean;
  undoneAt?: string;
}

export function getCommandHistory(): CommandHistoryItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.HISTORY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.warn('[AI History] Gagal membaca riwayat:', e);
  }
  return [];
}

export function saveCommandHistory(history: CommandHistoryItem[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history.slice(0, 50)));
  } catch (e) {
    console.warn('[AI History] Gagal menyimpan riwayat:', e);
  }
}

/**
 * Rate limit (Anti-Spam): Maksimal 10 perintah AI dalam 1 jam terakhir.
 */
export function checkRateLimit(): { allowed: boolean; remaining: number; message?: string } {
  const history = getCommandHistory();
  const oneHourAgo = Date.now() - 60 * 60 * 1000;

  // Hitung perintah dalam 1 jam terakhir
  const recentCommands = history.filter((cmd) => {
    const cmdTime = new Date(cmd.timestamp).getTime();
    return cmdTime >= oneHourAgo;
  });

  const maxPerHour = 10;
  const count = recentCommands.length;
  const remaining = Math.max(0, maxPerHour - count);

  if (count >= maxPerHour) {
    return {
      allowed: false,
      remaining: 0,
      message: 'Terlalu banyak perintah AI. Tunggu 1 jam atau gunakan menu manual.',
    };
  }

  return {
    allowed: true,
    remaining,
  };
}

/**
 * Undo (Pembatalan Perintah):
 * Mengembalikan state dari snapshot dan menandai command.undone = true.
 * Dibatasi maksimal 10 menit setelah eksekusi.
 */
export function undoCommand(commandId: string): { success: boolean; message: string } {
  const history = getCommandHistory();
  const cmdIndex = history.findIndex((c) => c.id === commandId);

  if (cmdIndex === -1) {
    return { success: false, message: 'Perintah tidak ditemukan di riwayat.' };
  }

  const cmd = history[cmdIndex];

  if (cmd.undone) {
    return { success: false, message: 'Perintah ini sudah pernah dibatalkan (undo).' };
  }

  // Batasi undo dalam 10 menit
  const elapsedMs = Date.now() - new Date(cmd.timestamp).getTime();
  const tenMinutesMs = 10 * 60 * 1000;

  if (elapsedMs > tenMinutesMs) {
    return {
      success: false,
      message: 'Waktu undo (10 menit) sudah habis. Gunakan menu manual untuk mengubah konten.',
    };
  }

  // Ambil snapshot
  const snapshotKey = cmd.result?.snapshotId;
  if (!snapshotKey) {
    return { success: false, message: 'Snapshot data sebelum eksekusi tidak ditemukan.' };
  }

  try {
    const rawSnapshot = localStorage.getItem(snapshotKey);
    if (!rawSnapshot) {
      return { success: false, message: 'File snapshot di memori lokal tidak ditemukan.' };
    }

    const snapshotData = JSON.parse(rawSnapshot);
    const current = getTeacherContent();

    // Pulihkan state ke versi snapshot (termasuk games)
    const restoredContent: TeacherContentData = {
      ...current,
      soal: snapshotData.soal || [],
      materi: snapshotData.materi || [],
      games: snapshotData.games || [],
      pengumuman: snapshotData.pengumuman || [],
      sampah: snapshotData.sampah || [],
    };

    saveTeacherContent(restoredContent);

    // Tandai command.undone = true di history
    cmd.undone = true;
    cmd.undoneAt = new Date().toISOString();
    history[cmdIndex] = cmd;
    saveCommandHistory(history);

    console.log(`[AI Undo Success] Perintah ${commandId} berhasil dibatalkan. State dipulihkan dari ${snapshotKey}.`);
    return {
      success: true,
      message: 'Perubahan berhasil dibatalkan (undo). Data konten dikembalikan ke kondisi sebelumnya.',
    };
  } catch (err: any) {
    console.error('[AI Undo Error]:', err);
    return {
      success: false,
      message: `Gagal membatalkan perintah: ${err?.message || 'Kesalahan internal'}`,
    };
  }
}
