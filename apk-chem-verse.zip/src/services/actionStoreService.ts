/**
 * @file src/services/actionStoreService.ts
 * @description Service & LocalStorage/Firestore persistence untuk agentActions, studentFeed, & studentMastery
 */

import {
  AgentAction,
  StudentFeedItem,
  StudentMastery,
  ActionStatus,
} from '../shared/types';
import { db as firestoreDb } from '../lib/firebase';
import {
  collection,
  doc,
  setDoc,
  getDocs,
  query,
  where,
  addDoc,
  updateDoc,
} from 'firebase/firestore';

// TODO Fase 3: implement hydrate from Firestore on boot untuk student_feed dan agent_actions. Untuk student_mastery bisa regenerasi dari migrasi.

const STORAGE_KEYS = {
  AGENT_ACTIONS: 'chemiverse_agent_actions',
  STUDENT_FEED: 'chemiverse_student_feed',
  STUDENT_MASTERY: 'chemiverse_student_mastery',
};

// ==========================================
// 1. AGENT ACTIONS PERSISTENCE
// ==========================================

export function getAgentActions(filterStatus?: ActionStatus): AgentAction[] {
  let actions: AgentAction[] = [];
  try {
    const raw = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.AGENT_ACTIONS) : null;
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        actions = parsed;
      }
    }
  } catch (e) {
    console.warn('Gagal membaca agentActions dari localStorage:', e);
    actions = [];
  }

  if (filterStatus) {
    return actions.filter((a) => a.status === filterStatus);
  }
  return actions;
}

export async function saveAgentActions(actions: AgentAction[]): Promise<void> {
  const existing = getAgentActions();
  const map = new Map<string, AgentAction>();
  existing.forEach((a) => map.set(a.id, a));
  actions.forEach((a) => map.set(a.id, a));

  const updatedList = Array.from(map.values());
  localStorage.setItem(STORAGE_KEYS.AGENT_ACTIONS, JSON.stringify(updatedList));

  // Sync ke Firestore jika online
  // TODO: rules Firestore untuk collection ini perlu ditambahkan di Firebase Console sebelum sync cloud aktif.
  try {
    for (const action of actions) {
      const ref = doc(firestoreDb, 'agent_actions', action.id);
      await setDoc(ref, action, { merge: true });
    }
  } catch (err) {
    console.warn('[Firestore] Sync agent_actions opsional:', err);
  }
}

export async function updateAgentAction(action: Partial<AgentAction> & { id: string }): Promise<void> {
  const existing = getAgentActions();
  const idx = existing.findIndex((a) => a.id === action.id);
  if (idx !== -1) {
    existing[idx] = { ...existing[idx], ...action };
    localStorage.setItem(STORAGE_KEYS.AGENT_ACTIONS, JSON.stringify(existing));
  }

  // TODO: rules Firestore untuk collection ini perlu ditambahkan di Firebase Console sebelum sync cloud aktif.
  try {
    const ref = doc(firestoreDb, 'agent_actions', action.id);
    await updateDoc(ref, action);
  } catch (err) {
    console.warn('[Firestore] Update agent_actions opsional:', err);
  }
}

// ==========================================
// 2. STUDENT FEED PERSISTENCE
// ==========================================

export function getStudentFeed(studentId?: string): StudentFeedItem[] {
  let feed: StudentFeedItem[] = [];
  try {
    const raw = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.STUDENT_FEED) : null;
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        feed = parsed;
      }
    }
  } catch (e) {
    console.warn('Gagal membaca studentFeed dari localStorage:', e);
    feed = [];
  }

  if (studentId) {
    return feed.filter((item) => item.studentId === studentId);
  }
  return feed;
}

export async function appendStudentFeed(items: StudentFeedItem[]): Promise<void> {
  const existing = getStudentFeed();
  const map = new Map<string, StudentFeedItem>();
  existing.forEach((f) => map.set(f.id, f));
  items.forEach((f) => map.set(f.id, f));

  const updatedList = Array.from(map.values());
  localStorage.setItem(STORAGE_KEYS.STUDENT_FEED, JSON.stringify(updatedList));

  // TODO: rules Firestore untuk collection ini perlu ditambahkan di Firebase Console sebelum sync cloud aktif.
  try {
    for (const item of items) {
      const ref = doc(firestoreDb, 'student_feed', item.id);
      await setDoc(ref, item, { merge: true });
    }
  } catch (err) {
    console.warn('[Firestore] Sync student_feed opsional:', err);
  }
}

// ==========================================
// 3. STUDENT MASTERY PERSISTENCE
// ==========================================

export function getStudentMastery(studentId?: string): StudentMastery[] {
  let masteryList: StudentMastery[] = [];
  try {
    const raw = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.STUDENT_MASTERY) : null;
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        masteryList = parsed;
      }
    }
  } catch (e) {
    console.warn('Gagal membaca studentMastery dari localStorage:', e);
    masteryList = [];
  }

  if (studentId) {
    return masteryList.filter((m) => m.studentId === studentId);
  }
  return masteryList;
}

export async function saveStudentMastery(rows: StudentMastery[]): Promise<void> {
  const existing = getStudentMastery();
  const map = new Map<string, StudentMastery>();

  existing.forEach((m) => map.set(`${m.studentId}_${m.topicId}`, m));
  rows.forEach((m) => map.set(`${m.studentId}_${m.topicId}`, m));

  const updatedList = Array.from(map.values());
  localStorage.setItem(STORAGE_KEYS.STUDENT_MASTERY, JSON.stringify(updatedList));

  // TODO: rules Firestore untuk collection ini perlu ditambahkan di Firebase Console sebelum sync cloud aktif.
  try {
    for (const row of rows) {
      const docId = `${row.studentId}_${row.topicId}`;
      const ref = doc(firestoreDb, 'student_mastery', docId);
      await setDoc(ref, row, { merge: true });
    }
  } catch (err) {
    console.warn('[Firestore] Sync student_mastery opsional:', err);
  }
}

// ==========================================
// WINDOW GLOBAL DB BINDING (UNTUK PENGUJIAN CONSOLE)
// ==========================================

export const dbStore = {
  get agentActions() {
    return getAgentActions();
  },
  get studentFeed() {
    return getStudentFeed();
  },
  get studentMastery() {
    return getStudentMastery();
  },
  saveAgentActions,
  updateAgentAction,
  getAgentActions,
  appendStudentFeed,
  getStudentFeed,
  saveStudentMastery,
  getStudentMastery,
};

// Bind ke window object agar bisa diakses langsung via Console Browser (window.db)
if (typeof window !== 'undefined') {
  (window as any).db = dbStore;
}
