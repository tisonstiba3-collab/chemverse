/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { Loader2 } from 'lucide-react';
import ChemistryLoginBackground from './components/chemistry/ChemistryLoginBackground';
import IdentityForm from './components/IdentityForm';
import Dashboard from './components/Dashboard';
import SubscriptionGate from './components/subscription/SubscriptionGate';
import AdminVerificationView from './components/admin/AdminVerificationView';
import { StudentProfile } from './types/chemistry';
import { auth, signInWithGoogle, logOut, ensureAnonymousAuth } from './lib/firebase';
import {
  getStudentProfile,
  saveStudentProfile,
  getUserDocument,
  saveUserDocument,
  startSession,
  endSession,
} from './services/firestoreService';
import { checkStudentSubscriptionStatus, UserSubscriptionRecord } from './services/supabaseService';
import { extractVerifyParamsFromUrl } from './shared/urlUtils';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [student, setStudent] = useState<StudentProfile | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  // Mode Verifikasi Admin WhatsApp (Langkah 2.1: Wajib BOTH admin_verify DAN token)
  const [adminVerifyData, setAdminVerifyData] = useState<{
    adminVerifyId: string;
    token: string;
  } | null>(null);

  // Subscription Gate state
  const [isSubscribed, setIsSubscribed] = useState<boolean>(false);
  const [hasAdminParam, setHasAdminParam] = useState<boolean>(false);

  const applyGrantedAccess = (record: UserSubscriptionRecord) => {
    setIsSubscribed(true);
    setHasAdminParam(false);

    const activeProfile: StudentProfile = {
      userId: record.id,
      namaLengkap: record.nama,
      nama: record.nama,
      role: 'siswa',
      kelas: record.kelas,
      sekolah: record.sekolah,
      email: `${record.nama.toLowerCase().replace(/[^a-z0-9]/g, '')}@siswa.sma.belajar.id`,
      xp: 300,
      completedModules: ['Struktur Atom & Ikatan Kimia'],
      solvedProblemsCount: 5,
      progres_materi: ['Struktur Atom', 'Ikatan Kimia'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setStudent((prev) => prev || activeProfile);
    try {
      localStorage.setItem('chemiverse_active_student', JSON.stringify(activeProfile));
      localStorage.setItem('chemverse_student_sub_id', record.id);
    } catch {
      // ignore
    }
  };

  // Check URL parameters & subscription status on load
  useEffect(() => {
    // Langkah 2.1 & Bugfix 1: Ekstraksi URLSearchParams dari window.location.search, hash (#/?...), dan regex
    const extracted = extractVerifyParamsFromUrl();

    if (extracted.adminVerifyId && extracted.token) {
      setAdminVerifyData({
        adminVerifyId: extracted.adminVerifyId,
        token: extracted.token,
      });
      return;
    } else if (extracted.adminVerifyId && !extracted.token) {
      setHasAdminParam(true);
    }

    // UX Update: Auto-redirect saat refresh (F5) - langsung baca status aktif dari database
    const subId = localStorage.getItem('chemverse_student_sub_id');
    if (subId) {
      checkStudentSubscriptionStatus(subId).then((rec) => {
        if (rec && rec.status === 'active') {
          applyGrantedAccess(rec);
        }
      });
    }
  }, []);

  // Listen to Firebase Auth state or local student session
  useEffect(() => {
    // Attempt anonymous sign-in in background for smooth Firestore connectivity
    ensureAnonymousAuth();
    // 1. First check if a student session is stored locally (Name, Class, School login)
    try {
      const savedStudent = localStorage.getItem('chemiverse_active_student');
      if (savedStudent) {
        const parsed = JSON.parse(savedStudent);
        if (parsed && parsed.namaLengkap) {
          setStudent(parsed);
          setIsSubscribed(true); // Langsung set aktif agar tanpa layar login
          setIsAuthLoading(false);
          return;
        }
      }
    } catch (e) {
      console.warn('Could not read local student session:', e);
    }

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          const profile = await getStudentProfile(user.uid);
          const userDoc = await getUserDocument(user.uid);

          const isGuruByEmail =
            user.email?.endsWith('@guru.sma.belajar.id') ||
            user.email?.toLowerCase().includes('guru') ||
            false;

          if (profile) {
            if (userDoc?.role) {
              profile.role = userDoc.role;
            } else if (isGuruByEmail) {
              profile.role = 'guru';
            }
            if (userDoc) {
              profile.xp = userDoc.xp ?? profile.xp;
              profile.progres_materi = userDoc.progres_materi ?? profile.progres_materi;
            }
            setStudent(profile);
            localStorage.setItem('chemiverse_active_student', JSON.stringify(profile));
          } else if (userDoc) {
            const constructedProfile: StudentProfile = {
              userId: user.uid,
              namaLengkap: userDoc.nama || user.displayName || 'Pendidik',
              nama: userDoc.nama,
              role: userDoc.role || (isGuruByEmail ? 'guru' : 'siswa'),
              kelas: userDoc.kelas || 'Kelas 11 SMA (Fase F)',
              sekolah: 'SMA Negeri',
              email: user.email || '',
              xp: userDoc.xp || 250,
              progres_materi: userDoc.progres_materi || [],
              badges: userDoc.badges || [],
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };
            setStudent(constructedProfile);
            localStorage.setItem('chemiverse_active_student', JSON.stringify(constructedProfile));
          }
        } catch (err) {
          console.warn('Error fetching profile from Firestore:', err);
        }
      }
      setIsAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Manage student session record upon login
  useEffect(() => {
    if (student?.userId) {
      const existingSession = sessionStorage.getItem('chemiverse_session_id');
      if (!existingSession) {
        startSession(student.userId);
      }
    }
  }, [student?.userId]);

  const handleIdentitySubmit = async (data: {
    namaLengkap: string;
    kelas: string;
    sekolah: string;
    role?: 'siswa' | 'guru';
  }) => {
    setIsSaving(true);
    try {
      await ensureAnonymousAuth();
      const user = auth.currentUser;
      const isGuruByEmail =
        user?.email?.endsWith('@guru.sma.belajar.id') ||
        user?.email?.toLowerCase().includes('guru') ||
        false;
      const finalRole: 'siswa' | 'guru' = data.role || (isGuruByEmail ? 'guru' : 'siswa');
      const resolvedUid = user?.uid || `student_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const resolvedEmail = user?.email || `${data.namaLengkap.toLowerCase().replace(/[^a-z0-9]/g, '')}@siswa.sma.belajar.id`;

      const newProfile: StudentProfile = {
        userId: resolvedUid,
        namaLengkap: data.namaLengkap,
        nama: data.namaLengkap,
        role: finalRole,
        kelas: data.kelas,
        sekolah: data.sekolah,
        email: resolvedEmail,
        xp: finalRole === 'guru' ? 950 : 250,
        completedModules: ['Struktur Atom & Ikatan Kimia'],
        solvedProblemsCount: 5,
        progres_materi: ['Struktur Atom', 'Ikatan Kimia'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      try {
        localStorage.setItem('chemiverse_active_student', JSON.stringify(newProfile));
      } catch (storageErr) {
        console.warn('LocalStorage error:', storageErr);
      }

      try {
        await saveStudentProfile(newProfile);
        await saveUserDocument(resolvedUid, {
          userId: resolvedUid,
          nama: data.namaLengkap,
          role: finalRole,
          kelas: data.kelas,
          xp: newProfile.xp || 250,
          badges: ['ahli_atom', 'rajin_belajar'],
          progres_materi: ['Struktur Atom', 'Ikatan Kimia'],
        });
      } catch (firestoreErr) {
        console.warn('Firestore write warning:', firestoreErr);
      }

      setStudent(newProfile);
    } finally {
      setIsSaving(false);
    }
  };

  const handleAccessGranted = (record: UserSubscriptionRecord) => {
    applyGrantedAccess(record);
  };

  const handleLogout = async () => {
    try {
      const activeSession = sessionStorage.getItem('chemiverse_session_id');
      if (activeSession) {
        await endSession(activeSession);
      }
      localStorage.removeItem('chemiverse_active_student');
      localStorage.removeItem('chemverse_student_sub_id');
      localStorage.removeItem('chemverse_student_identity');
      await logOut();
    } catch (e) {
      console.warn('Logout error:', e);
    }
    setStudent(null);
    setCurrentUser(null);
    setIsSubscribed(false);
  };

  const handleGoHome = () => {
    setAdminVerifyData(null);
    setHasAdminParam(false);
    try {
      window.history.replaceState({}, '', window.location.pathname);
    } catch {
      // ignore
    }
  };

  // Langkah 2.1: Mode Admin Verification (Wajib BOTH admin_verify DAN token)
  if (adminVerifyData) {
    return (
      <AdminVerificationView
        adminVerifyId={adminVerifyData.adminVerifyId}
        token={adminVerifyData.token}
        onGoHome={handleGoHome}
      />
    );
  }

  if (isAuthLoading) {
    return (
      <div className="min-h-screen w-full bg-[#040714] flex flex-col items-center justify-center text-slate-100 gap-3">
        <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
        <span className="text-sm font-mono text-slate-400">Menghubungkan ke System Chemverse...</span>
      </div>
    );
  }

  // If legacy Admin URL parameter present or user is NOT subscribed yet, display Subscription Gate
  if (hasAdminParam || !isSubscribed) {
    return <SubscriptionGate onAccessGranted={handleAccessGranted} />;
  }

  return (
    <div className="min-h-screen w-full bg-[#040714] text-slate-100 font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {student ? (
        <Dashboard student={student} onLogout={handleLogout} />
      ) : (
        <main className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-[#040714]">
          <ChemistryLoginBackground />
          <IdentityForm
            onSubmit={handleIdentitySubmit}
            initialData={student}
            isSaving={isSaving}
          />
        </main>
      )}
    </div>
  );
}
