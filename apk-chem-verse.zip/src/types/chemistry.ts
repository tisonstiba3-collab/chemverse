export interface StudentProfile {
  userId: string;
  namaLengkap: string;
  nama?: string; // Alias for namaLengkap
  role?: 'siswa' | 'guru'; // Role: siswa or guru
  kelas: string;
  sekolah: string;
  email?: string;
  createdAt?: string;
  updatedAt?: string;
  xp?: number;
  badges?: string[]; // Array ID lencana
  progres_materi?: string[]; // Array ID materi yang sudah selesai
  completedModules?: string[];
  solvedProblemsCount?: number;
}

export type MenuKey =
  | 'peta'
  | 'materi'
  | 'diagnostik'
  | 'latihan'
  | 'games'
  | 'tka'
  | 'rumus'
  | 'progres'
  | 'jurnal'
  | 'guru';

export interface MenuItemData {
  key: MenuKey;
  title: string;
  subtitle: string;
  description: string;
  tag: string;
  color: string;
  accentBg: string;
  glowColor: string;
  statsLabel: string;
}

export interface MoleculeData {
  id: string;
  name: string;
  chemicalFormula: string;
  iupacName: string;
  molarMass: string;
  geometry: string;
  description: string;
  classLevel: string; // Kelas 10, 11, 12
  atoms: Array<{
    id: number;
    element: 'H' | 'C' | 'O' | 'N' | 'Na' | 'Cl' | 'S';
    position: [number, number, number];
    color: string;
    radius: number;
    label: string;
  }>;
  bonds: Array<{
    start: [number, number, number];
    end: [number, number, number];
    type: 'single' | 'double' | 'triple';
  }>;
  facts: string[];
}

export interface QuizQuestion {
  id: string;
  topic: string;
  classLevel: string;
  question: string;
  equation?: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  hint: string;
  difficulty: 'Mudah' | 'Sedang' | 'HOTS';
}

export interface BalancingReaction {
  id: string;
  title: string;
  description: string;
  reactants: Array<{ formula: string; defaultCoeff: number; targetCoeff: number }>;
  products: Array<{ formula: string; defaultCoeff: number; targetCoeff: number }>;
  hints: string[];
  xpReward: number;
}

export interface JournalEntry {
  id: string;
  studentId: string;
  studentName?: string;
  topic: string;
  content: string;
  understandingLevel: 'Paham' | 'Cukup' | 'Perlu Diulang';
  notes?: string;
  formulasLearned?: string[];
  durationMinutes?: number;
  date: string;
  createdAt: string;
}

export type TopicCategory =
  | 'Semua'
  | 'Stoikiometri'
  | 'Struktur Atom'
  | 'Ikatan Kimia'
  | 'Termokimia'
  | 'Laju Reaksi'
  | 'Kesetimbangan'
  | 'Asam-Basa'
  | 'Redoks & Elektrokimia'
  | 'Kimia Organik';

export type ModelType =
  | 'atom'
  | 'h2o'
  | 'beaker'
  | 'flame'
  | 'battery'
  | 'equilibrium'
  | 'kinetics'
  | 'organic'
  | 'clock'
  | 'balance';

export interface MiniQuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface TopicContentSection {
  id: string;
  heading: string;
  body: string;
  formula?: string; // LaTeX formatted string
  keyPoints?: string[];
  miniQuiz?: MiniQuizQuestion[];
}

export interface SimulationState {
  // Ikatan Kimia (VSEPR)
  showBonds?: boolean;
  showPEB?: boolean;
  bondAngle?: number; // 90 to 180 degrees
  // Asam-Basa
  pH?: number; // 0 to 14
  dropsAcid?: number;
  dropsBase?: number;
  indicatorType?: 'universal' | 'pp' | 'mm' | 'btb';
  // Termokimia
  temperature?: number;
  reactionType?: 'eksoterm' | 'endoterm';
  // Elektrokimia
  selectedMetalPair?: 'Zn-Cu' | 'Mg-Cu' | 'Fe-Cu';
  circuitClosed?: boolean;
  // Struktur Atom
  principalQuantumN?: number;
  orbitalType?: 's' | 'p' | 'd';
  // Laju Reaksi
  reactantConcentration?: number;
  reactionTemp?: number;
  catalystAdded?: boolean;
  // Kesetimbangan
  systemPressure?: number;
  equilibriumTemp?: number;
  // Kimia Organik
  selectedFunctionalGroup?: 'alkohol' | 'eter' | 'karboksilat' | 'ester';
  delocalizationActive?: boolean;
}

export interface ChemistryTopic {
  id: string;
  title: string;
  category: TopicCategory;
  description: string;
  modelType: ModelType;
  accentColor: string;
  glowColor: string;
  fromColor?: string;
  toColor?: string;
  difficulty: 'Kelas 10 (Fase E)' | 'Kelas 11 (Fase F)' | 'Kelas 12 (Fase F)';
  estimatedMinutes: number;
  xpReward: number;
  progressPercent?: number;
  lastAccessed?: string;
  contentSections: TopicContentSection[];
  summaryKeyTakeaways: string[];
  defaultSimulation?: SimulationState;
}

export interface StudentTopicProgress {
  completed: boolean;
  percent: number;
  completedAt?: string;
}

export type GradeLevel = 'X' | 'XI' | 'XII';

export type CurriculumCategory =
  | 'Semua'
  | 'Dasar Kimia'
  | 'Fisik'
  | 'Analitik'
  | 'Organik';

export type CurriculumModelType =
  | 'atom'
  | 'h2o'
  | 'beaker'
  | 'flame'
  | 'clock'
  | 'balance'
  | 'battery'
  | 'organic'
  | 'flask'
  | 'globe'
  | 'leaf'
  | 'thermometer'
  | 'factory';

export type SectionType =
  | 'pendahuluan'
  | 'definisi'
  | 'contoh-soal'
  | 'gambar'
  | 'fakta-menarik';

export interface CurriculumSection {
  type: SectionType;
  title?: string;
  content?: string;
  formula?: string; // LaTeX formula string
  problem?: string;
  solution?: string; // Step-by-step solution
  imageUrl?: string;
  caption?: string;
  animationType?: '3d-molecule' | '3d-reaction' | 'particle-system' | 'static';
  keyPoints?: string[];
  quizOptions?: string[];
  quizCorrectIndex?: number;
  quizExplanation?: string;
}

export interface CurriculumTopic {
  id: string;
  title: string;
  judul?: string; // Nama/judul materi
  grade: GradeLevel;
  category: string;
  description: string;
  deskripsi?: string; // Ringkasan deskripsi materi
  prasyarat?: string[]; // ID materi yang harus diselesaikan dulu. Jika kosong [], berarti materi awal.
  urutan?: number; // Untuk mengatur posisi di peta belajar (urutan 1, 2, 3...)
  konten_materi?: string; // HTML atau Markdown materi lengkap
  layoutType?: 'standard' | 'flipbook' | 'presentation' | 'pdf_viewer'; // Format tata letak tampilan
  contentPages?: string[]; // Array halaman untuk flipbook atau slide presentasi
  attachmentUrl?: string; // URL file PDF atau dokumen lampiran
  modelType: string;
  fromColor: string;
  toColor: string;
  sections: CurriculumSection[];
  sourceInfo?: {
    name: string;
    url?: string;
    note?: string;
  };
  tujuanPembelajaran?: string[];
  capaianPembelajaran?: string;
  materiCode?: string; // e.g. 'X.01', 'X.05'
}

export type DiagnosticQuestionType = 'PG' | 'PGK' | 'BS' | 'MENJODOHKAN';

export interface MatchingItem {
  id: string; // e.g. "L1", "L2", "L3" or "R1", "R2", "R3"
  text: string;
}

export interface StatementItem {
  id: number;
  pernyataan: string;
  kunci: 'B' | 'S';
  pembahasan?: string;
}

export interface DiagnosticQuestion {
  id: string;
  nomor?: number; // 1 to 5
  level: 1 | 2 | 3;
  levelLabel?: string; // e.g. "Level 1 (Mengingat/Memahami)", "Level 2 (Menerapkan/Menganalisis)", "Level 3 (HOTS/Mengevaluasi)"
  tipe: DiagnosticQuestionType;
  bloom: string;
  indikator: string;
  soal: string;
  instruksi?: string;
  opsi?: Record<string, string>; // { A: '...', B: '...', C: '...', D: '...', E: '...' }
  statements?: StatementItem[]; // For Benar/Salah (3-4 items)
  matchingLeft?: MatchingItem[]; // For Menjodohkan (3-4 items)
  matchingRight?: MatchingItem[]; // For Menjodohkan (3-5 items)
  kunci: string | string[] | Record<string, string>; // string for PG/BS, array for PGK, mapping object for Menjodohkan
  pembahasan: string;
  estimasi_detik?: number;
  prasyaratTerkait?: string;
}

export interface DiagnosticSet {
  materi_id: string;
  materi_nama: string;
  kelas: string;
  prasyarat: string[];
  judul_tes: string; // "Tes Diagnostik Prasyarat untuk: [materi_nama]"
  set_id: string;
  level_kesulitan: string;
  threshold: number; // default 70
  previous_set_ids?: string[];
  soal: DiagnosticQuestion[];
  metadata: {
    generated_at: string;
    uniqueness_score?: string;
    difficulty_match?: string;
    model_used?: string;
  };
}

export interface DiagnosticLevelScore {
  correct: number;
  total: number;
  percent: number;
}

export interface DiagnosticResult {
  materiId: string;
  materiNama: string;
  kelas: string;
  setId: string;
  score: number; // 0-100
  passed: boolean; // score >= 70
  totalCorrect: number;
  totalQuestions: number; // 5
  attemptCount: number;
  remedialCount: number;
  missedPrasyarat: string[];
  levelBreakdown?: {
    level1: DiagnosticLevelScore;
    level2: DiagnosticLevelScore;
    level3: DiagnosticLevelScore;
  };
  analysisFeedback?: string;
  answers: Record<string, any>;
  completedAt: string;
  teacherEscalated?: boolean;
}

export interface PrerequisiteCurriculumItem {
  code: string; // e.g. 'X.01'
  name: string;
  grade: 'X' | 'XI' | 'XII';
  prasyarat: string[];
  aliases: string[]; // e.g. ['hakikat-ilmu-kimia-x', 'pengukuran-metode-ilmiah']
  remedialSummary?: string;
  keyFormulas?: string[];
}

export interface JawabanSoalSiswa {
  id?: string;
  userId: string;
  namaSiswa: string;
  topik: string;
  soalId: string;
  teksSoal: string;
  jawabanSiswa: any; // string | string[] | Record<string, string>
  jawabanBenar: any; // string | string[] | Record<string, string>
  isBenar: boolean;
  timestamp: string;
}

export interface GameRoomPlayer {
  uid: string;
  nama: string;
  score: number;
  answeredCurrent?: boolean;
  selectedOption?: number | null;
  isReady?: boolean;
}

export interface GameRoomQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  topic?: string;
}

export interface GameRoom {
  id?: string;
  hostId: string; // "uid_guru_atau_siswa"
  status: 'waiting' | 'playing' | 'finished'; // "waiting" | "playing" | "finished"
  currentQuestionIndex: number;
  players: GameRoomPlayer[];
  roomCode?: string;
  title?: string;
  questions?: GameRoomQuestion[];
  createdAt?: string;
  updatedAt?: string;
}

export interface UserDocument {
  userId?: string;
  nama: string;
  role: 'siswa' | 'guru';
  kelas: string;
  xp: number;
  badges: string[];
  progres_materi: string[];
}

export interface MaterialDocument {
  id: string;
  judul: string;
  prasyarat: string[];
  urutan: number;
  konten_materi: string;
}

export interface QuizResultDocument {
  id?: string;
  userId: string;
  namaSiswa: string;
  topik: string;
  soalId: string;
  teksSoal: string;
  jawabanSiswa: string;
  jawabanBenar: string;
  isBenar: boolean;
  timestamp: string | any;
}

export interface SpacedRepetitionItem {
  id: string;
  userId: string;
  soalId: string;
  topik: string;
  teksSoal: string;
  options: string[];
  correctIndex: number;
  jawabanBenar?: string;
  jawabanSiswaTerakhir?: string;
  explanation?: string;
  tanggalSalah: string; // ISO string date
  lastWrongDate?: string;
  repetitionCount?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface SpacedRepetitionDueInfo {
  isDue: boolean;
  diffDays: number;
  stageLabel: string;
  intervalTag: 'H+3' | 'H+7' | 'H+14' | 'Overdue' | 'Upcoming';
  badgeColor: string;
  formattedWrongDate: string;
}

export interface SessionRecord {
  id: string;
  student_id: string;
  started_at: string;
  ended_at?: string;
  duration_sec: number;
  device: 'Mobile' | 'Tablet' | 'Desktop';
  user_agent: string;
}

export interface ActivityLog {
  id: string;
  student_id: string;
  session_id: string;
  type: 'reading' | 'quiz' | 'video' | 'login';
  ref_id: string;
  ref_title: string;
  duration_sec: number;
  occurred_at: string;
}

export interface QuizAttempt {
  id: string;
  student_id: string;
  quiz_id: string;
  quiz_title: string;
  score: number;
  max_score: number;
  correct: number;
  wrong: number;
  started_at: string;
  submitted_at: string;
  duration_sec: number;
}

export interface DailyActivitySummary {
  student_id: string;
  day: string; // YYYY-MM-DD
  read_sec: number;
  quiz_sec: number;
  total_sec: number;
  first_seen: string;
  last_seen: string;
}

export interface StudentActivitySummary {
  studentId: string;
  nama: string;
  kelas: string;
  email?: string;
  totalReadMinutes: number;
  totalQuizMinutes: number;
  averageQuizScore: number;
  totalQuizzesTaken: number;
  lastActive: string; // ISO string
  lastActiveRelative: string;
  isActiveRecent: boolean; // false if inactive > 7 days
}

export interface TeacherClassSummary {
  id: string;
  name: string; // e.g. Kelas 10 SMA (Fase E)
  grade: 'X' | 'XI' | 'XII';
  totalStudents: number;
  activeStudentsToday: number;
  averageReadMinutes: number;
  averageQuizScore: number;
}
