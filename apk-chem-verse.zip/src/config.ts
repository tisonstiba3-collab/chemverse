/**
 * @file src/config.ts
 * @description Konfigurasi global aplikasi Chemverse
 */

export const APP_NAME = 'Chemverse';

export const APP_BASE_URL =
  typeof window !== 'undefined' ? window.location.origin : '';

export const ADMIN_WA_NUMBER = '6282145750970';
