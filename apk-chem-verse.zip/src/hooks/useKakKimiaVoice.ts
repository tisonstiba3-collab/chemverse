import { useEffect, useRef, useState, useCallback } from 'react';

export interface KakKimiaVoiceOptions {
  isMuted?: boolean;
  rate?: number;   // Kecepatan bicara (default 1.08 - tegas dan tidak lambat)
  pitch?: number;  // Nada bicara (default 1.0 - wibawa dan jelas)
  volume?: number; // Volume suara (default 1.0 - maksimal dan jelas)
}

/**
 * Custom Hook useKakKimiaVoice
 * Asisten Suara otomatis "Kak Kimia" menggunakan Web Speech API (window.speechSynthesis).
 * - Suara tegas, lantang, dan lugas (rate: 1.08, volume: 1.0, pitch: 1.0).
 * - Menggunakan lang = 'id-ID' dengan pemilihan suara Indonesia yang jernih.
 * - Antisipasi Autoplay Policy: mendengarkan sentuhan/klik pengguna pertama kali.
 */
export function useKakKimiaVoice(
  text: string,
  optionsOrMuted: boolean | KakKimiaVoiceOptions = false
) {
  const isMuted = typeof optionsOrMuted === 'boolean' ? optionsOrMuted : !!optionsOrMuted?.isMuted;
  const targetRate = typeof optionsOrMuted === 'object' && optionsOrMuted.rate ? optionsOrMuted.rate : 1.08;
  const targetPitch = typeof optionsOrMuted === 'object' && optionsOrMuted.pitch ? optionsOrMuted.pitch : 1.0;
  const targetVolume = typeof optionsOrMuted === 'object' && optionsOrMuted.volume ? optionsOrMuted.volume : 1.0;

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isSupported, setIsSupported] = useState(true);
  const hasSpokenRef = useRef(false);
  const currentTextRef = useRef(text);
  const isMutedRef = useRef(isMuted);

  // Sync refs with latest props
  currentTextRef.current = text;
  isMutedRef.current = isMuted;

  // Pilih suara bahasa Indonesia yang tegas dan jernih
  const getIndonesianVoice = useCallback((): SpeechSynthesisVoice | null => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return null;

    const voices = window.speechSynthesis.getVoices();
    if (!voices || voices.length === 0) return null;

    // Filter semua suara beraksen Indonesia
    const idVoices = voices.filter((v) => {
      const code = (v.lang || '').toLowerCase().replace('_', '-');
      return code.startsWith('id') || code.includes('indonesia');
    });

    if (idVoices.length === 0) {
      const nameIdVoice = voices.find((v) =>
        v.name.toLowerCase().includes('indonesia')
      );
      if (nameIdVoice) return nameIdVoice;
      return null;
    }

    // Prioritaskan suara Google Bahasa Indonesia atau suara jernih
    const preferredId = idVoices.find((v) => {
      const name = (v.name || '').toLowerCase();
      return (
        name.includes('google') ||
        name.includes('gadis') ||
        name.includes('damayanti') ||
        name.includes('female') ||
        name.includes('indonesia')
      );
    });

    return preferredId || idVoices[0];
  }, []);

  // Fungsi untuk memutar suara dengan nada tegas dan volume lantang
  const speak = useCallback(
    (customText?: string) => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
        setIsSupported(false);
        return;
      }

      if (isMutedRef.current) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
        return;
      }

      const textToSpeak = customText || currentTextRef.current;
      if (!textToSpeak || !textToSpeak.trim()) return;

      try {
        window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(textToSpeak.trim());
        utterance.lang = 'id-ID';
        utterance.volume = targetVolume; // 1.0: Volume penuh, tidak pelan
        utterance.rate = targetRate;     // 1.08: Kecepatan tegas, lugas, tidak loyo
        utterance.pitch = targetPitch;   // 1.0: Mantap, tegas, jelas

        const selectedVoice = getIndonesianVoice();
        if (selectedVoice) {
          utterance.voice = selectedVoice;
        }

        utterance.onstart = () => {
          setIsSpeaking(true);
          hasSpokenRef.current = true;
        };

        utterance.onend = () => {
          setIsSpeaking(false);
        };

        utterance.onerror = (e) => {
          if (e.error !== 'canceled' && e.error !== 'interrupted') {
            console.warn('[Kak Kimia Speech Warning]:', e.error);
          }
          setIsSpeaking(false);
        };

        window.speechSynthesis.speak(utterance);
      } catch (err) {
        console.warn('[Kak Kimia Speech Error]:', err);
        setIsSpeaking(false);
      }
    },
    [getIndonesianVoice, targetVolume, targetRate, targetPitch]
  );

  const stop = useCallback(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  }, []);

  useEffect(() => {
    if (isMuted) {
      stop();
    }
  }, [isMuted, stop]);

  useEffect(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      setIsSupported(false);
      return;
    }

    hasSpokenRef.current = false;

    if (isMuted) {
      stop();
      return;
    }

    const handleFirstUserGesture = () => {
      if (!hasSpokenRef.current && !isMutedRef.current) {
        speak();
      }
      cleanupListeners();
    };

    const cleanupListeners = () => {
      window.removeEventListener('click', handleFirstUserGesture);
      window.removeEventListener('touchstart', handleFirstUserGesture);
      window.removeEventListener('keydown', handleFirstUserGesture);
    };

    window.addEventListener('click', handleFirstUserGesture, { once: true });
    window.addEventListener('touchstart', handleFirstUserGesture, { once: true });
    window.addEventListener('keydown', handleFirstUserGesture, { once: true });

    const timer = setTimeout(() => {
      if (!isMutedRef.current && !hasSpokenRef.current) {
        speak();
      }
    }, 250);

    const handleVoicesChanged = () => {
      if (!hasSpokenRef.current && !isMutedRef.current) {
        speak();
      }
    };

    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = handleVoicesChanged;
    }

    return () => {
      clearTimeout(timer);
      cleanupListeners();
      stop();
      if (window.speechSynthesis.onvoiceschanged !== undefined) {
        window.speechSynthesis.onvoiceschanged = null;
      }
    };
  }, [text, isMuted, speak, stop]);

  return {
    speak,
    stop,
    isSpeaking,
    isSupported,
  };
}
