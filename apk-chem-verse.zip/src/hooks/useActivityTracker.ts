import { useState, useEffect, useRef, useCallback } from 'react';
import { saveActivityLog, updateSessionDuration } from '../services/firestoreService';

export interface UseActivityTrackerProps {
  studentId?: string;
  sessionId?: string;
  type: 'reading' | 'quiz' | 'video' | 'login';
  refId: string;
  refTitle: string;
}

export interface ActivityTrackerState {
  activeSeconds: number;
  isTracking: boolean;
  isIdle: boolean;
  isTabVisible: boolean;
  lastFlushTime: Date | null;
  flushNow: () => Promise<void>;
}

const IDLE_TIMEOUT_MS = 2 * 60 * 1000; // 2 minutes idle limit
const FLUSH_INTERVAL_MS = 30 * 1000; // Flush to Firestore every 30 seconds
const MAX_TICK_DELTA_MS = 5000; // Ignore tick jumps > 5s (prevents tab sleep time counted)

/**
 * Custom hook to track real active learning time with idle detection & visibility check.
 * Strictly complies with learning analytics rules:
 * - Counted ONLY when document is visible
 * - Counted ONLY when student is not idle > 2 minutes
 * - Discards sleep intervals > 5s
 * - Flushes every 30s & on pagehide / beforeunload (via sendBeacon)
 */
export function useActivityTracker({
  studentId,
  sessionId,
  type,
  refId,
  refTitle,
}: UseActivityTrackerProps): ActivityTrackerState {
  const [activeSeconds, setActiveSeconds] = useState<number>(0);
  const [isIdle, setIsIdle] = useState<boolean>(false);
  const [isTabVisible, setIsTabVisible] = useState<boolean>(
    typeof document !== 'undefined' ? document.visibilityState === 'visible' : true
  );
  const [lastFlushTime, setLastFlushTime] = useState<Date | null>(null);

  // Mutable refs to persist across interval ticks without re-triggering effects
  const accumulatedUnsavedSecRef = useRef<number>(0);
  const totalActiveSecRef = useRef<number>(0);
  const lastActiveTimestampRef = useRef<number>(Date.now());
  const lastTickTimestampRef = useRef<number>(Date.now());
  const isFlushingRef = useRef<boolean>(false);

  // Resolve active session ID from prop or sessionStorage
  const effectiveSessionId =
    sessionId ||
    (typeof window !== 'undefined'
      ? sessionStorage.getItem('chemiverse_session_id') || `sess_${studentId || 'anon'}_active`
      : 'sess_unknown');

  const effectiveStudentId =
    studentId ||
    (typeof window !== 'undefined'
      ? (() => {
          try {
            const raw = localStorage.getItem('chemiverse_active_student');
            if (raw) return JSON.parse(raw)?.userId;
          } catch {}
          return 'siswa_anonim';
        })()
      : 'siswa_anonim');

  // Flush accumulated active time to server
  const flushNow = useCallback(async () => {
    const secToFlush = accumulatedUnsavedSecRef.current;
    if (secToFlush <= 0 || !effectiveStudentId || isFlushingRef.current) return;

    isFlushingRef.current = true;
    accumulatedUnsavedSecRef.current = 0; // reset buffer
    const nowIso = new Date().toISOString();

    try {
      await saveActivityLog({
        student_id: effectiveStudentId,
        session_id: effectiveSessionId,
        type,
        ref_id: refId,
        ref_title: refTitle,
        duration_sec: secToFlush,
        occurred_at: nowIso,
      });

      // Update parent session elapsed active time
      await updateSessionDuration(effectiveSessionId, totalActiveSecRef.current);
      setLastFlushTime(new Date());
    } catch (err) {
      console.warn('Activity tracker flush warning:', err);
      // Put back unsaved seconds on network error
      accumulatedUnsavedSecRef.current += secToFlush;
    } finally {
      isFlushingRef.current = false;
    }
  }, [effectiveStudentId, effectiveSessionId, type, refId, refTitle]);

  // 1. Activity & Idle Detection
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handleUserActivity = () => {
      lastActiveTimestampRef.current = Date.now();
      setIsIdle(false);
    };

    const handleVisibilityChange = () => {
      const visible = document.visibilityState === 'visible';
      setIsTabVisible(visible);
      if (!visible) {
        // Tab went to background: flush pending active time immediately
        flushNow();
      } else {
        lastActiveTimestampRef.current = Date.now();
        lastTickTimestampRef.current = Date.now();
      }
    };

    const activityEvents = ['mousemove', 'keydown', 'scroll', 'touchstart', 'click'];
    activityEvents.forEach((ev) => window.addEventListener(ev, handleUserActivity, { passive: true }));
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      activityEvents.forEach((ev) => window.removeEventListener(ev, handleUserActivity));
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [flushNow]);

  // 2. Heartbeat Timer (Every 1 second)
  useEffect(() => {
    if (!effectiveStudentId) return;

    lastTickTimestampRef.current = Date.now();
    lastActiveTimestampRef.current = Date.now();

    const timer = setInterval(() => {
      const now = Date.now();
      const tickDelta = now - lastTickTimestampRef.current;
      lastTickTimestampRef.current = now;

      // Rule: Ignore delta > 5 seconds (laptop sleep / background freeze)
      if (tickDelta > MAX_TICK_DELTA_MS) {
        return;
      }

      // Rule: Check visibility
      const isVisible = document.visibilityState === 'visible';
      setIsTabVisible(isVisible);
      if (!isVisible) return;

      // Rule: Check 2 minutes idle threshold
      const timeSinceActive = now - lastActiveTimestampRef.current;
      const userIsIdle = timeSinceActive > IDLE_TIMEOUT_MS;
      setIsIdle(userIsIdle);
      if (userIsIdle) return;

      // All criteria met: Add 1 active second
      accumulatedUnsavedSecRef.current += 1;
      totalActiveSecRef.current += 1;
      setActiveSeconds((prev) => prev + 1);

      // Rule: Auto-flush every 30 seconds
      if (accumulatedUnsavedSecRef.current >= 30) {
        flushNow();
      }
    }, 1000);

    return () => {
      clearInterval(timer);
      // Flush remaining seconds on unmount
      flushNow();
    };
  }, [effectiveStudentId, flushNow]);

  // 3. Pagehide / Beforeunload fallback with sendBeacon (for Safari iOS & tab close)
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handlePageHide = () => {
      const remainingSec = accumulatedUnsavedSecRef.current;
      if (remainingSec > 0 && effectiveStudentId) {
        const payload = JSON.stringify({
          student_id: effectiveStudentId,
          session_id: effectiveSessionId,
          type,
          ref_id: refId,
          ref_title: refTitle,
          duration_sec: remainingSec,
          occurred_at: new Date().toISOString(),
        });

        // Use sendBeacon if supported
        if (navigator.sendBeacon) {
          const blob = new Blob([payload], { type: 'application/json' });
          navigator.sendBeacon('/api/activity/beacon', blob);
        } else {
          // Synchronous/immediate fetch fallback
          fetch('/api/activity/beacon', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: payload,
            keepalive: true,
          }).catch(() => {});
        }
      }
    };

    window.addEventListener('pagehide', handlePageHide);
    window.addEventListener('beforeunload', handlePageHide);

    return () => {
      window.removeEventListener('pagehide', handlePageHide);
      window.removeEventListener('beforeunload', handlePageHide);
    };
  }, [effectiveStudentId, effectiveSessionId, type, refId, refTitle]);

  return {
    activeSeconds,
    isTracking: !isIdle && isTabVisible && !!effectiveStudentId,
    isIdle,
    isTabVisible,
    lastFlushTime,
    flushNow,
  };
}
