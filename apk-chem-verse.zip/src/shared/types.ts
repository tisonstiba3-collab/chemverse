/**
 * @file src/shared/types.ts
 * @description Tipe data standar untuk fitur "Actionable Progress" Chemverse
 */

/**
 * Representasi tingkat penguasaan (mastery) siswa per topik pembelajaran.
 */
export interface StudentMastery {
  studentId: string;
  topicId: string;
  score: number; // 0 - 100
  attempts: number; // Jumlah pengerjaan
  lastAttemptAt: string; // Timestamp ISO string
  level: 'red' | 'yellow' | 'green'; // Merah = Butuh Intervensi, Kuning = Cukup, Hijau = Kuasai
}

/**
 * Jenis tindakan yang disarankan oleh Agent / Guru.
 */
export type ActionType =
  | 'assign_remediation'
  | 'send_reminder'
  | 'open_retake_quiz'
  | 'send_material'
  | 'fix_question'
  | 'broadcast_message';

/**
 * Status siklus hidup sebuah tindakan agent.
 */
export type ActionStatus =
  | 'pending'
  | 'approved'
  | 'rejected'
  | 'executed'
  | 'expired';

/**
 * Entitas rekomendasi tindakan otomatis dari Agent untuk disetujui Guru.
 */
export interface AgentAction {
  id: string;
  type: ActionType;
  targetStudentIds: string[];
  topicId?: string;
  contentIds?: string[];
  reason: string; // Penjelasan ringkas untuk guru
  confidence: number; // 0 - 1
  priority: number; // Skor urgensi (mis. 1 - 5)
  payload: Record<string, unknown>; // Draft pesan, link remedi, quiz, dll.
  status: ActionStatus;
  createdBy: 'agent' | 'teacher';
  approvedBy?: string;
  createdAt: number;
  executedAt?: number;
  result?: { successRate: number };
}

/**
 * Item pemberitahuan / tugas khusus yang masuk ke linimasa (feed) siswa.
 */
export interface StudentFeedItem {
  id: string;
  studentId: string;
  kind: 'material' | 'quiz' | 'remedial' | 'reminder' | 'broadcast';
  title: string;
  description?: string;
  contentId?: string;
  deadline?: number;
  progress?: number; // 0 - 1
  createdAt: number;
}

/**
 * Ringkasan harian kondisi kelas untuk dasbor guru.
 */
export interface DailyBriefing {
  date: string;
  summary: string;
  topRisks: { label: string; count: number }[];
  pendingActions: number;
}

/**
 * Akun siswa terverifikasi dengan fitur link aktivasi WhatsApp Admin.
 */
export interface StudentAccount {
  id: string;
  name: string;
  nama?: string; // alias backwards compatibility
  classId: string;
  kelas?: string; // alias backwards compatibility
  school: string;
  sekolah?: string; // alias backwards compatibility
  email?: string;
  whatsapp?: string;
  status: 'pending_payment' | 'pending_verify' | 'active' | 'rejected' | 'locked';
  registeredAt?: number;
  activatedAt?: number;
  adminVerifyId: string; // UUID v4, dibuat saat pendaftaran
  activationToken: string; // 20 karakter alfanumerik acak [a-z0-9]
  adminVerifyCreatedAt: number;
  adminVerifyUsedAt?: number;
  verifyDecision?: 'active' | 'rejected' | null;
  rejectedReason?: string;
  paymentProofSentAt?: number;
}

/**
 * Log jejak siklus hidup pendaftaran dan verifikasi akun siswa.
 */
export interface ActivationLog {
  id: string;
  studentId: string;
  action: 'created' | 'submitted' | 'activated' | 'rejected' | 'expired';
  by: string;
  at: number;
  note?: string;
}
