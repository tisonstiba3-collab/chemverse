/**
 * @file src/shared/waTemplates.ts
 * @description Generator template pesan WhatsApp dan utilitas pengiriman WhatsApp
 */

import { StudentAccount } from './types';
import { APP_NAME, APP_BASE_URL } from '../config';

/**
 * Membentuk pesan WhatsApp konfirmasi pembayaran dari siswa ke Admin
 * dengan tautan verifikasi otomatis.
 */
export function buildVerificationMessage(s: StudentAccount): string {
  const link = `${APP_BASE_URL}/?admin_verify=${s.adminVerifyId}&token=${s.activationToken}`;
  return `Halo Admin, saya ${s.name}, Kelas ${s.classId}, Sekolah ${s.school}, sudah bayar langganan ${APP_NAME}. Mohon cek mutasi. Ini bukti pembayaran saya. Admin, klik link ini untuk verifikasi: ${link}`;
}

/**
 * Membentuk pesan WhatsApp konfirmasi aktivasi akun berhasil dari Admin ke siswa
 */
export function buildConfirmationMessage(s: StudentAccount): string {
  return `Halo ${s.name}, akun Anda sudah AKTIF di ${APP_NAME}. Selamat belajar! Login di: ${APP_BASE_URL}`;
}

/**
 * Membentuk pesan WhatsApp penolakan/pembatalan akun siswa dari Admin
 */
export function buildRejectionMessage(s: StudentAccount, alasan: string): string {
  return `Halo ${s.name}, pendaftaran Anda di ${APP_NAME} belum bisa kami aktifkan. Alasan: ${alasan}. Silakan hubungi admin kalau ada pertanyaan.`;
}

/**
 * Membuka tautan WhatsApp Web / Aplikasi WhatsApp secara aman
 */
export function openWA(phone: string, message: string) {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`, '_blank');
}
