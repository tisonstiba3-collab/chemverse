/**
 * @file src/shared/urlUtils.ts
 * @description Utilitas ekstraksi dan parsing parameter verifikasi URL
 */

export interface VerifyParams {
  adminVerifyId: string | null;
  token: string | null;
}

/**
 * Ekstraksi aman parameter admin_verify & token dari berbagai format URL WhatsApp / Browser:
 * - Search query standar: ?admin_verify=UUID&token=TOKEN
 * - Hash router: #/?admin_verify=UUID&token=TOKEN
 * - Trailing punctuation / slash yang ditambahkan oleh aplikasi pesan WhatsApp
 */
export function extractVerifyParamsFromUrl(): VerifyParams {
  if (typeof window === 'undefined') {
    return { adminVerifyId: null, token: null };
  }

  const fullUrl = window.location.href;
  let adminVerifyId: string | null = null;
  let token: string | null = null;

  // 1. Ekstrak dari window.location.search (?admin_verify=...&token=...)
  if (window.location.search) {
    const searchParams = new URLSearchParams(window.location.search);
    adminVerifyId = searchParams.get('admin_verify');
    token = searchParams.get('token');
  }

  // 2. Jika belum lengkap, periksa window.location.hash (#/?admin_verify=...)
  if ((!adminVerifyId || !token) && window.location.hash) {
    const hash = window.location.hash;
    const queryIndex = hash.indexOf('?');
    if (queryIndex !== -1) {
      const hashParams = new URLSearchParams(hash.substring(queryIndex));
      if (!adminVerifyId) adminVerifyId = hashParams.get('admin_verify');
      if (!token) token = hashParams.get('token');
    } else {
      const strippedHash = hash.replace(/^#\/?/, '');
      const hashParams = new URLSearchParams(strippedHash);
      if (!adminVerifyId) adminVerifyId = hashParams.get('admin_verify');
      if (!token) token = hashParams.get('token');
    }
  }

  // 3. Fallback ekstraksi regex langsung dari seluruh URL (mengantisipasi URL encoding WhatsApp)
  if (!adminVerifyId) {
    const match = fullUrl.match(/[?&#]admin_verify=([a-zA-Z0-9_-]+)/i);
    if (match && match[1]) {
      adminVerifyId = match[1];
    }
  }

  if (!token) {
    const match = fullUrl.match(/[?&#]token=([a-zA-Z0-9]+)/i);
    if (match && match[1]) {
      token = match[1];
    }
  }

  // Bersihkan tanda baca liar yang sering tertempel dari chat WhatsApp (titik, koma, dsb)
  if (adminVerifyId) {
    adminVerifyId = adminVerifyId.replace(/[^a-zA-Z0-9-]/g, '').trim();
  }
  if (token) {
    token = token.replace(/[^a-zA-Z0-9]/g, '').trim();
  }

  return {
    adminVerifyId: adminVerifyId && adminVerifyId.length > 0 ? adminVerifyId : null,
    token: token && token.length > 0 ? token : null,
  };
}
