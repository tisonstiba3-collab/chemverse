/**
 * @file src/shared/migration.ts
 * @description Modul migrasi data progres lama ke skema standar StudentMastery (FASE 1: Langkah 3 & 4)
 */

import { StudentMastery } from './types';
import { dbStore, saveStudentMastery } from '../services/actionStoreService';
import { db } from '../lib/firebase';
import { collection, getDocs, query, limit } from 'firebase/firestore';

/**
 * Normalisasi topicId dari berbagai format legacy (nama topik, materiId, quiz_id)
 * Menerapkan Opsi B (normalisasi slug berbasis materi / topik)
 */
export function normalizeTopicId(input: string): string {
  if (!input) return 'umum';
  return input
    .trim()
    .toLowerCase()
    .replace(/^latihan_|^kuis_|^quiz_|^tka_|^tes_|^mat_\d+_/i, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'umum';
}

/**
 * Fungsi migrasi murni (pure function):
 * Mengonversi seluruh riwayat data progres lama menjadi array StudentMastery
 *
 * Aturan:
 * 1. Skor rata-rata 0 - 100 (dibulatkan)
 * 2. Level: < 60 → 'red' | 60 - 79 → 'yellow' | >= 80 → 'green'
 * 3. Jika tidak ada attempt untuk suatu topik, TIDAK membuat baris mastery
 * 4. Idempotent: dipanggil berulang kali dengan data sama menghasilkan output yang sama
 * 5. Read-only terhadap input (tidak memutasi atau menghapus data lama)
 */
export function migrateToStudentMastery(oldData: any): StudentMastery[] {
  if (!oldData) return [];

  // 1. Kumpulkan seluruh record attempt mentah
  let rawItems: any[] = [];
  if (Array.isArray(oldData)) {
    rawItems = oldData;
  } else if (typeof oldData === 'object') {
    if (Array.isArray(oldData.attempts)) rawItems.push(...oldData.attempts);
    if (Array.isArray(oldData.quizResults)) rawItems.push(...oldData.quizResults);
    if (Array.isArray(oldData.diagnostics)) rawItems.push(...oldData.diagnostics);
    if (Array.isArray(oldData.progress)) rawItems.push(...oldData.progress);
    if (Array.isArray(oldData.rawItems)) rawItems.push(...oldData.rawItems);
  }

  // 2. Kelompokkan per (studentId, topicId)
  const groupMap = new Map<
    string,
    {
      studentId: string;
      topicId: string;
      scores: number[];
      timestamps: string[];
    }
  >();

  for (const item of rawItems) {
    if (!item || typeof item !== 'object') continue;

    const studentId = item.studentId || item.student_id || item.userId;
    if (!studentId || typeof studentId !== 'string') continue;

    // Normalisasi topicId
    const rawTopic =
      item.topicId ||
      item.materiId ||
      item.topik ||
      item.quiz_id ||
      item.quiz_title ||
      '';
    const topicId = normalizeTopicId(String(rawTopic));
    if (!topicId) continue;

    // Ekstraksi skor (0 - 100)
    let scoreNum: number | null = null;
    if (typeof item.score === 'number' && !isNaN(item.score)) {
      if (typeof item.max_score === 'number' && item.max_score > 0) {
        scoreNum = (item.score / item.max_score) * 100;
      } else {
        scoreNum = item.score;
      }
    } else if (typeof item.isBenar === 'boolean') {
      scoreNum = item.isBenar ? 100 : 0;
    } else if (typeof item.percent === 'number' && !isNaN(item.percent)) {
      scoreNum = item.percent;
    }

    if (scoreNum === null) continue;

    const clampedScore = Math.min(100, Math.max(0, scoreNum));

    // Ekstraksi timestamp
    const rawTime =
      item.submitted_at ||
      item.completedAt ||
      item.timestamp ||
      item.occurred_at ||
      item.started_at ||
      item.updatedAt ||
      new Date().toISOString();
    const isoTime = new Date(rawTime).toISOString();

    const key = `${studentId}:::${topicId}`;
    if (!groupMap.has(key)) {
      groupMap.set(key, {
        studentId,
        topicId,
        scores: [],
        timestamps: [],
      });
    }

    const group = groupMap.get(key)!;
    group.scores.push(clampedScore);
    group.timestamps.push(isoTime);
  }

  // 3. Bangun array StudentMastery
  const results: StudentMastery[] = [];

  for (const group of groupMap.values()) {
    if (group.scores.length === 0) continue;

    const totalScore = group.scores.reduce((a, b) => a + b, 0);
    const avgScore = Math.round(totalScore / group.scores.length);
    const attempts = group.scores.length;

    // Timestamp terbaru
    const sortedTimes = [...group.timestamps].sort(
      (a, b) => new Date(b).getTime() - new Date(a).getTime()
    );
    const lastAttemptAt = sortedTimes[0] || new Date().toISOString();

    // Aturan penentuan level
    let level: 'red' | 'yellow' | 'green' = 'red';
    if (avgScore >= 80) {
      level = 'green';
    } else if (avgScore >= 60) {
      level = 'yellow';
    }

    results.push({
      studentId: group.studentId,
      topicId: group.topicId,
      score: avgScore,
      attempts,
      lastAttemptAt,
      level,
    });
  }

  // 4. Pengurutan deterministik (Idempotent)
  results.sort((a, b) => {
    if (a.studentId !== b.studentId) {
      return a.studentId.localeCompare(b.studentId);
    }
    return a.topicId.localeCompare(b.topicId);
  });

  return results;
}

// =========================================================================
// MEMORI DATA UNTUK VERIFIKASI & PERBANDINGAN (DEV ONLY)
// =========================================================================
let _cachedOldData: any[] = [];
let _cachedMastery: StudentMastery[] = [];

/**
 * Mengambil data progres lama dari Firestore dan/atau fallback sample data
 */
export async function fetchAllOldProgressData(): Promise<any[]> {
  const aggregated: any[] = [];

  try {
    // 1. Ambil dari koleksi 'quiz_attempts'
    const qAttempts = query(collection(db, 'quiz_attempts'), limit(200));
    const snapAttempts = await getDocs(qAttempts);
    snapAttempts.forEach((docSnap) => {
      aggregated.push({ ...docSnap.data(), sourceCollection: 'quiz_attempts' });
    });
  } catch (e) {
    console.warn('[Migration] Read quiz_attempts warning:', e);
  }

  try {
    // 2. Ambil dari koleksi 'quiz_results'
    const qResults = query(collection(db, 'quiz_results'), limit(300));
    const snapResults = await getDocs(qResults);
    snapResults.forEach((docSnap) => {
      aggregated.push({ ...docSnap.data(), sourceCollection: 'quiz_results' });
    });
  } catch (e) {
    console.warn('[Migration] Read quiz_results warning:', e);
  }

  // 3. Jika data Firestore masih kosong, gunakan fallback data representatif siswa SMA
  if (aggregated.length === 0) {
    const now = Date.now();
    const mockLegacyData = [
      // Siswa 1: Ari Pratama
      { student_id: 'siswa_01_ari', quiz_id: 'stoikiometri', quiz_title: 'Stoikiometri', score: 45, max_score: 100, submitted_at: new Date(now - 86400000).toISOString() },
      { student_id: 'siswa_01_ari', quiz_id: 'stoikiometri', quiz_title: 'Stoikiometri', score: 55, max_score: 100, submitted_at: new Date(now - 43200000).toISOString() },
      { student_id: 'siswa_01_ari', quiz_id: 'struktur-atom', quiz_title: 'Struktur Atom', score: 75, max_score: 100, submitted_at: new Date(now - 120000000).toISOString() },
      { student_id: 'siswa_01_ari', quiz_id: 'ikatan-kimia', quiz_title: 'Ikatan Kimia', score: 85, max_score: 100, submitted_at: new Date(now - 70000000).toISOString() },

      // Siswa 2: Dinda Ayu Maharani
      { student_id: 'siswa_02_dinda', quiz_id: 'stoikiometri', quiz_title: 'Stoikiometri', score: 92, max_score: 100, submitted_at: new Date(now - 36000000).toISOString() },
      { student_id: 'siswa_02_dinda', quiz_id: 'struktur-atom', quiz_title: 'Struktur Atom', score: 88, max_score: 100, submitted_at: new Date(now - 50000000).toISOString() },
      { student_id: 'siswa_02_dinda', quiz_id: 'ikatan-kimia', quiz_title: 'Ikatan Kimia', score: 95, max_score: 100, submitted_at: new Date(now - 20000000).toISOString() },
      { student_id: 'siswa_02_dinda', quiz_id: 'larutan-asam-basa', quiz_title: 'Asam Basa', score: 82, max_score: 100, submitted_at: new Date(now - 10000000).toISOString() },

      // Siswa 3: Budi Santoso
      { student_id: 'siswa_03_budi', quiz_id: 'stoikiometri', quiz_title: 'Stoikiometri', score: 50, max_score: 100, submitted_at: new Date(now - 90000000).toISOString() },
      { student_id: 'siswa_03_budi', quiz_id: 'struktur-atom', quiz_title: 'Struktur Atom', score: 65, max_score: 100, submitted_at: new Date(now - 80000000).toISOString() },
      { student_id: 'siswa_03_budi', quiz_id: 'ikatan-kimia', quiz_title: 'Ikatan Kimia', score: 58, max_score: 100, submitted_at: new Date(now - 60000000).toISOString() },

      // Siswa 4: Citra Lestari
      { student_id: 'siswa_04_citra', quiz_id: 'stoikiometri', quiz_title: 'Stoikiometri', score: 70, max_score: 100, submitted_at: new Date(now - 45000000).toISOString() },
      { student_id: 'siswa_04_citra', quiz_id: 'stoikiometri', quiz_title: 'Stoikiometri', score: 78, max_score: 100, submitted_at: new Date(now - 25000000).toISOString() },
      { student_id: 'siswa_04_citra', quiz_id: 'struktur-atom', quiz_title: 'Struktur Atom', score: 90, max_score: 100, submitted_at: new Date(now - 95000000).toISOString() },
      { student_id: 'siswa_04_citra', quiz_id: 'ikatan-kimia', quiz_title: 'Ikatan Kimia', score: 84, max_score: 100, submitted_at: new Date(now - 30000000).toISOString() },

      // Siswa 5: Fajar Nugraha
      { student_id: 'siswa_05_fajar', quiz_id: 'stoikiometri', quiz_title: 'Stoikiometri', score: 40, max_score: 100, submitted_at: new Date(now - 60000000).toISOString() },
      { student_id: 'siswa_05_fajar', quiz_id: 'struktur-atom', quiz_title: 'Struktur Atom', score: 62, max_score: 100, submitted_at: new Date(now - 55000000).toISOString() },
      { student_id: 'siswa_05_fajar', quiz_id: 'ikatan-kimia', quiz_title: 'Ikatan Kimia', score: 50, max_score: 100, submitted_at: new Date(now - 35000000).toISOString() },
    ];
    aggregated.push(...mockLegacyData);
  }

  _cachedOldData = aggregated;
  return aggregated;
}

/**
 * 1. window.__runMigration()
 * Mengambil data progres lama → migrateToStudentMastery → simpan ke db.studentMastery → log verifikasi
 */
export async function runMigration(): Promise<any> {
  console.log('%c[MIGRATION] Memulai migrasi data progres lama ke StudentMastery...', 'color: #38bdf8; font-weight: bold;');

  const oldData = await fetchAllOldProgressData();
  const masteryList = migrateToStudentMastery(oldData);

  // Simpan ke storage (localStorage & Firestore student_mastery)
  await saveStudentMastery(masteryList);
  _cachedMastery = masteryList;

  // Analisis statistik hasil
  const uniqueStudents = new Set(masteryList.map((m) => m.studentId));
  const distribution = {
    red: masteryList.filter((m) => m.level === 'red').length,
    yellow: masteryList.filter((m) => m.level === 'yellow').length,
    green: masteryList.filter((m) => m.level === 'green').length,
  };

  // Pilih 5 contoh acak
  const shuffled = [...masteryList].sort(() => 0.5 - Math.random());
  const sampleRows = shuffled.slice(0, 5);

  console.log('%c[MIGRATION SUCCESS] Migrasi selesai!', 'color: #10b981; font-weight: bold;');
  console.log(`• Total siswa terdeteksi : ${uniqueStudents.size}`);
  console.log(`• Total baris StudentMastery : ${masteryList.length}`);
  console.log(`• Distribusi Level : Merah=${distribution.red}, Kuning=${distribution.yellow}, Hijau=${distribution.green}`);
  console.log('%c5 Contoh Baris StudentMastery (Acak):', 'color: #f59e0b; font-weight: bold;');
  console.table(sampleRows);

  return {
    status: 'success',
    totalStudents: uniqueStudents.size,
    totalMasteryRows: masteryList.length,
    distribution,
    sampleRows,
    masteryList,
  };
}

/**
 * 3. window.__compareWithOld()
 * Membandingkan 5 siswa acak antara skor mentah lama vs skor rata-rata di StudentMastery
 */
export function compareWithOld(): any {
  if (!_cachedMastery || _cachedMastery.length === 0) {
    _cachedMastery = dbStore.studentMastery;
  }

  if (!_cachedMastery || _cachedMastery.length === 0) {
    console.warn('[COMPARE] Belum ada data StudentMastery di db. Jalankan window.__runMigration() terlebih dahulu.');
    return;
  }

  console.log('%c[COMPARE] Membandingkan data mentah lama vs skor rata-rata StudentMastery...', 'color: #38bdf8; font-weight: bold;');

  // Pilih 5 siswa acak yang memiliki data mastery
  const studentIds = Array.from(new Set(_cachedMastery.map((m) => m.studentId)));
  const sampledStudents = studentIds.sort(() => 0.5 - Math.random()).slice(0, 5);

  const comparisonRows: any[] = [];

  for (const stId of sampledStudents) {
    const studentMasteries = _cachedMastery.filter((m) => m.studentId === stId);
    for (const m of studentMasteries) {
      // Cari raw items yang cocok
      const rawMatches = _cachedOldData.filter((raw) => {
        const sid = raw.studentId || raw.student_id || raw.userId;
        const topic = normalizeTopicId(raw.topicId || raw.materiId || raw.topik || raw.quiz_id || raw.quiz_title || '');
        return sid === stId && topic === m.topicId;
      });

      const rawScores = rawMatches.map((r) => {
        if (typeof r.score === 'number') {
          return r.max_score ? Math.round((r.score / r.max_score) * 100) : r.score;
        }
        if (typeof r.isBenar === 'boolean') return r.isBenar ? 100 : 0;
        return r.percent || 0;
      });

      const expectedAvg = rawScores.length > 0
        ? Math.round(rawScores.reduce((a, b) => a + b, 0) / rawScores.length)
        : m.score;

      comparisonRows.push({
        Siswa: m.studentId,
        Topik: m.topicId,
        'Skor Lama': rawScores.length > 0 ? JSON.stringify(rawScores) : `[${m.score}]`,
        'Skor Rata-rata Mastery': m.score,
        'Expected Avg': expectedAvg,
        Level: m.level,
        'Status Cocok?': m.score === expectedAvg ? 'VALID ✅' : 'MISMATCH ❌',
      });
    }
  }

  // Tampilkan 5 baris pertama dari sampel
  const displaySlice = comparisonRows.slice(0, 5);
  console.table(displaySlice);

  return displaySlice;
}

// Daftarkan ke window (developer console SEMENTARA, akan dihapus di Fase 9)
if (typeof window !== 'undefined') {
  (window as any).__runMigration = runMigration;
  (window as any).__compareWithOld = compareWithOld;
}
