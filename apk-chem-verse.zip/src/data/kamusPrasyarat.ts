/**
 * KAMUS PRASYARAT KIMIA SMA (Prerequisite Dictionary)
 *
 * ATURAN UTAMA:
 * Sebelum membuat soal, sistem AI WAJIB memetakan dan mencari tahu apa
 * "Materi Prasyarat" dari topik yang dipilih oleh siswa.
 * Soal yang dibuat HARUS berdasarkan materi prasyaratnya, BUKAN materi barunya.
 */

import { DiagnosticQuestion, DiagnosticSet } from '../types/chemistry';
import { getDiagnosticQuestionsForTopic, COMPLETE_24_TOPICS_DIAGNOSTIC_SETS } from './diagnosticCatalogData';

export interface PrasyaratMapping {
  topik: string;
  prasyarat: string;
  grade: 'X' | 'XI' | 'XII';
  deskripsiPrasyarat?: string;
  alasanPrasyarat?: string;
}

// 1. PEMETAAN PRASYARAT (KAMUS) RESMI 24 BAB KIMIA SMA
export const KAMUS_PRASYARAT: Record<string, string> = {
  // Bab 1-8:
  'Sifat Materi & Metode Ilmiah': 'Besaran & Satuan Standar SI, Wujud Zat, dan Variabel Penelitian Ilmiah',
  'Struktur Atom': 'Perkembangan Teori Atom (Model Dalton, Thomson, Rutherford, Bohr)',
  'Kimia Hijau': 'Konsep Limbah, Perubahan Fisika/Kimia, dan Reaksi Pembakaran',
  'Pemanasan Global': 'Radiasi Termal Inframerah, Siklus Karbon, dan Efek Rumah Kaca Alami',
  'Keselamatan Kerja di Laboratorium': 'Simbol Piktogram GHS, Sifat Bahaya Bahan Kimia, dan Prosedur APD',
  'Konfigurasi Elektron dan Bilangan Kuantum': 'Struktur Atom dan Model Atom Bohr (Jumlah Proton & Elektron)',
  'Sistem Periodik Unsur': 'Konfigurasi Elektron Dasar dan Nomor Atom (Z)',
  'Ikatan Kimia': 'Konfigurasi Elektron dan Kestabilan Gas Mulia (Kaidah Duplet & Oktet)',

  // Bab 9-16:
  'Hukum Dasar Kimia dan Konsep Mol': 'Persamaan Reaksi Sederhana, Hukum Lavoisier, dan Massa Atom Relatif (Ar/Mr)',
  'Senyawa Hidrokarbon dan Minyak Bumi': 'Ikatan Kovalen Karbon (Valensi 4 C) dan Prinsip Pemisahan Distilasi',
  'Termokimia': 'Kalor dan Suhu (q = mcΔT), Hukum Kekekalan Energi, dan Reaksi Eksoterm/Endoterm',
  'Laju Reaksi dan Teori Tumbukan': 'Konsentrasi Molaritas (M = n/V), Energi Kinetik, dan Luas Bidang Sentuh',
  'Kesetimbangan Kimia': 'Laju Reaksi Maju dan Balik serta Konsep Reaksi Reversibel (⇌)',
  'Asam Basa dan Derajat Keasaman (pH)': 'Ionisasi dalam Air, Ion H⁺ & OH⁻, dan Operasi Logaritma Dasar',
  'Titrasi Asam Basa': 'Stoikiometri Larutan (n = M × V) dan Konsep Titik Ekivalen Mol H⁺ = Mol OH⁻',
  'Hidrolisis Garam': 'Kekuatan Asam/Basa (Kuat vs Lemah) dan Pasangan Asam-Basa Konjugasi',

  // Bab 17-24:
  'Larutan Penyangga (Buffer)': 'Teori Asam-Basa Brønsted-Lowry dan Pasangan Asam/Basa Konjugasi',
  'Sistem Koloid': 'Campuran Homogen (Larutan) vs Heterogen (Suspensi) dan Hamburan Cahaya',
  'Sifat Koligatif Larutan': 'Konsentrasi (Molaritas, Molalitas, Fraksi Mol) dan Gaya Antarmolekul',
  'Reaksi Redoks dan Penyetaraan': 'Aturan Bilangan Oksidasi (Biloks) dan Transfer Elektron Dasar',
  'Sel Volta, Elektrolisis, dan Korosi': 'Reaksi Redoks Spontan/Non-spontan, Aliran Elektron, dan Daya Hantar Elektrolit',
  'Kimia Unsur': 'Sifat Keperiodikan Unsur (Jari-jari Atom, Energi Ionisasi) dan Reaktivitas',
  'Senyawa Karbon': 'Struktur Hidrokarbon Alkana, Ikatan Kovalen Polar, dan Konsep Isomer',
  'Makromolekul': 'Gugus Fungsi Organik (Alkohol, Karboksilat, Amina) dan Reaksi Polimerisasi',

  // Kompatibilitas Alias Lama:
  'Pengukuran & Metode Ilmiah': 'Besaran & Satuan Standar SI, Konversi Satuan, dan Angka Penting',
  'Hukum Dasar Kimia': 'Sifat Materi, Perubahan Kimia, dan Partikel Materi',
  'Stoikiometri': 'Persamaan Reaksi dan Hukum Dasar Kimia',
  'Perubahan Energi': 'Kalor, Perubahan Suhu Lingkungan, dan Satuan Energi (Joule)',
  'Larutan Asam Basa': 'Konsep Mol dan Konsentrasi Larutan',
  'Hidrokarbon & Minyak Bumi': 'Ikatan Kovalen Karbon, Elektron Valensi C, dan Rumus Struktur Kimia',
  'Laju Reaksi': 'Stoikiometri, Konsentrasi Molaritas (M = n/V), dan Teori Tumbukan',
  'Titrasi Asam-Basa': 'Stoikiometri Larutan dan Konsep Titik Ekivalen Mol H⁺ = Mol OH⁻',
  'Redoks & Sel Elektrokimia': 'Aturan Bilangan Oksidasi (Biloks) dan Penyetaraan Reaksi Redoks Dasar',
  'Senyawa Karbon & Gugus Fungsi': 'Struktur Hidrokarbon Alkana, Ikatan Kovalen, dan Konsep Isomer',
  'Makromolekul & Biomolekul': 'Gugus Fungsi Organik (Alkohol, Karboksilat, Amina) dan Reaksi Polimerisasi',
};

// Daftar 24 Topik Lengkap Kurikulum Kimia SMA
export const DAFTAR_TOPIK_PRASYARAT: Array<{ topik: string; grade: 'X' | 'XI' | 'XII'; code: string }> = [
  // Kelas X (Fase E)
  { topik: 'Sifat Materi & Metode Ilmiah', grade: 'X', code: 'X.01' },
  { topik: 'Struktur Atom', grade: 'X', code: 'X.02' },
  { topik: 'Kimia Hijau', grade: 'X', code: 'X.03' },
  { topik: 'Pemanasan Global', grade: 'X', code: 'X.04' },
  { topik: 'Keselamatan Kerja di Laboratorium', grade: 'X', code: 'X.05' },
  { topik: 'Konfigurasi Elektron dan Bilangan Kuantum', grade: 'X', code: 'X.06' },
  { topik: 'Sistem Periodik Unsur', grade: 'X', code: 'X.07' },
  { topik: 'Ikatan Kimia', grade: 'X', code: 'X.08' },
  { topik: 'Hukum Dasar Kimia dan Konsep Mol', grade: 'X', code: 'X.09' },

  // Kelas XI (Fase F)
  { topik: 'Senyawa Hidrokarbon dan Minyak Bumi', grade: 'XI', code: 'XI.01' },
  { topik: 'Termokimia', grade: 'XI', code: 'XI.02' },
  { topik: 'Laju Reaksi dan Teori Tumbukan', grade: 'XI', code: 'XI.03' },
  { topik: 'Kesetimbangan Kimia', grade: 'XI', code: 'XI.04' },
  { topik: 'Asam Basa dan Derajat Keasaman (pH)', grade: 'XI', code: 'XI.05' },
  { topik: 'Titrasi Asam Basa', grade: 'XI', code: 'XI.06' },
  { topik: 'Hidrolisis Garam', grade: 'XI', code: 'XI.07' },
  { topik: 'Larutan Penyangga (Buffer)', grade: 'XI', code: 'XI.08' },
  { topik: 'Sistem Koloid', grade: 'XI', code: 'XI.09' },

  // Kelas XII (Fase F)
  { topik: 'Sifat Koligatif Larutan', grade: 'XII', code: 'XII.01' },
  { topik: 'Reaksi Redoks dan Penyetaraan', grade: 'XII', code: 'XII.02' },
  { topik: 'Sel Volta, Elektrolisis, dan Korosi', grade: 'XII', code: 'XII.03' },
  { topik: 'Kimia Unsur', grade: 'XII', code: 'XII.04' },
  { topik: 'Senyawa Karbon', grade: 'XII', code: 'XII.05' },
  { topik: 'Makromolekul', grade: 'XII', code: 'XII.06' },
];

/**
 * Mencari Materi Prasyarat dari Kamus berdasarkan nama, query, atau kode topik.
 */
export function cariPrasyaratTopik(input: string): PrasyaratMapping {
  if (!input) {
    return {
      topik: 'Struktur Atom',
      prasyarat: KAMUS_PRASYARAT['Struktur Atom'],
      grade: 'X',
    };
  }

  const raw = input.trim();
  const lower = raw.toLowerCase();

  // 1. Cek kecocokan langsung key kamus
  for (const [key, val] of Object.entries(KAMUS_PRASYARAT)) {
    if (key.toLowerCase() === lower) {
      const meta = DAFTAR_TOPIK_PRASYARAT.find((t) => t.topik === key);
      return { topik: key, prasyarat: val, grade: meta?.grade || 'X' };
    }
  }

  // 2. Prioritas spesifik 5 topik wajib utama sesuai prompt user
  if (lower.includes('hijau') || lower.includes('green')) {
    return {
      topik: 'Kimia Hijau',
      prasyarat: KAMUS_PRASYARAT['Kimia Hijau'],
      grade: 'X',
    };
  }
  if (lower.includes('atom') || lower.includes('x.02')) {
    return {
      topik: 'Struktur Atom',
      prasyarat: KAMUS_PRASYARAT['Struktur Atom'],
      grade: 'X',
    };
  }
  if (lower.includes('ikatan') || lower.includes('x.03')) {
    return {
      topik: 'Ikatan Kimia',
      prasyarat: KAMUS_PRASYARAT['Ikatan Kimia'],
      grade: 'X',
    };
  }
  if (lower.includes('stoikiometri') || lower.includes('perhitungan kimia') || lower.includes('x.05') || lower.includes('konsep-mol')) {
    return {
      topik: 'Stoikiometri',
      prasyarat: KAMUS_PRASYARAT['Stoikiometri'],
      grade: 'X',
    };
  }
  if (lower.includes('asam') || lower.includes('basa') || lower.includes('xi.05')) {
    return {
      topik: 'Larutan Asam Basa',
      prasyarat: KAMUS_PRASYARAT['Larutan Asam Basa'],
      grade: 'XI',
    };
  }

  // 3. Cek kode topik (X.01, XI.02, dsb)
  const byCode = DAFTAR_TOPIK_PRASYARAT.find(
    (item) => item.code.toLowerCase() === lower || item.code.toLowerCase().replace('.', '') === lower.replace('.', '')
  );
  if (byCode && KAMUS_PRASYARAT[byCode.topik]) {
    return {
      topik: byCode.topik,
      prasyarat: KAMUS_PRASYARAT[byCode.topik],
      grade: byCode.grade,
    };
  }

  // 4. Substring matching
  for (const [key, val] of Object.entries(KAMUS_PRASYARAT)) {
    const kLower = key.toLowerCase();
    if (lower.includes(kLower) || kLower.includes(lower)) {
      const meta = DAFTAR_TOPIK_PRASYARAT.find((t) => t.topik === key);
      return { topik: key, prasyarat: val, grade: meta?.grade || 'X' };
    }
  }

  // Fallback default
  return {
    topik: raw,
    prasyarat: KAMUS_PRASYARAT['Struktur Atom'],
    grade: 'X',
  };
}

/**
 * Membuat prompt Gemini resmi sesuai instruksi ketat dari pengguna:
 * "Siswa ingin mempelajari materi [Topik Pilihan]. Namun, buatkan 5 soal pilihan ganda (A-E) yang HANYA menguji materi prasyarat berikut: [Materi Prasyarat dari Kamus]. DILARANG membuat soal tentang [Topik Pilihan]."
 */
export function buildPrerequisiteCheckPrompt(
  topikPilihan: string,
  materiPrasyarat: string
): { systemInstruction: string; userPrompt: string } {
  const strictDirective = `Siswa ingin mempelajari materi "${topikPilihan}". Buatkan 5 soal pilihan ganda (A-E) yang HANYA menguji MATERI PRASYARAT: "${materiPrasyarat}". SANGAT DILARANG membuat soal tentang "${topikPilihan}".`;

  const systemInstruction = `Kamu adalah Asesmen Engine Kesiapan Belajar Kimia SMA (Prerequisite Check) berstandar kurikulum nasional.
${strictDirective}

ATURAN WAJIB & PANDUAN PEMBUATAN SOAL:
1. TINGKAT KESULITAN: SOAL HARUS MUDAH & MENDASAR (Tingkat Kognitif C1-C3 Bloom: definisi, pengenalan konsep dasar, perbandingan model, identifikasi sifat). JANGAN membuat soal yang terlalu sulit, rumit, atau perhitungan angka yang berbelit-belit.
2. FOKUS PRASYARAT: Soal HANYA boleh menguji MATERI PRASYARAT ("${materiPrasyarat}").
   Contoh: Jika topik pilihan siswa adalah "Struktur Atom", maka soal HARUS menguji materi prasyarat "Perkembangan Teori Atom (Model Dalton, Thomson, Rutherford, Bohr)" seperti konsep bola pejal, roti kismis, hamburan sinar alfa, dan lintasan stasioner Bohr. DILARANG membuat soal materi target.
3. FORMAT: Tepat 5 butir soal pilihan ganda (opsi A, B, C, D, E). Hanya ada 1 kunci jawaban benar per butir soal.
4. Gunakan notasi kimia subscript/superscript IUPAC yang rapi dan bahasa Indonesia baku yang ramah siswa SMA.
5. Sertakan pembahasan singkat dan jelas yang mudah dipahami siswa SMA.
6. Kembalikan HASIL HANYA dalam format JSON valid tanpa teks pengantar atau penutup.`;

  const userPrompt = `${strictDirective}

Format JSON WAJIB:
{
  "judul_tes": "Asesmen Kesiapan Belajar untuk: ${topikPilihan}",
  "topik_pilihan": "${topikPilihan}",
  "materi_prasyarat": "${materiPrasyarat}",
  "threshold": 70,
  "soal": [
    {
      "id": "q1",
      "nomor": 1,
      "soal": "Pertanyaan nomor 1 menguji konsep dasar materi prasyarat (${materiPrasyarat})",
      "opsi": {
        "A": "Pilihan A",
        "B": "Pilihan B",
        "C": "Pilihan C",
        "D": "Pilihan D",
        "E": "Pilihan E"
      },
      "kunci": "A",
      "pembahasan": "Penjelasan mengapa kunci jawaban benar...",
      "prasyaratTerkait": "${materiPrasyarat}"
    },
    {
      "id": "q2",
      "nomor": 2,
      "soal": "Pertanyaan nomor 2 menguji materi prasyarat...",
      "opsi": { "A": "...", "B": "...", "C": "...", "D": "...", "E": "..." },
      "kunci": "B",
      "pembahasan": "...",
      "prasyaratTerkait": "${materiPrasyarat}"
    },
    {
      "id": "q3",
      "nomor": 3,
      "soal": "Pertanyaan nomor 3 menguji penerapan materi prasyarat...",
      "opsi": { "A": "...", "B": "...", "C": "...", "D": "...", "E": "..." },
      "kunci": "C",
      "pembahasan": "...",
      "prasyaratTerkait": "${materiPrasyarat}"
    },
    {
      "id": "q4",
      "nomor": 4,
      "soal": "Pertanyaan nomor 4 menguji analisis materi prasyarat...",
      "opsi": { "A": "...", "B": "...", "C": "...", "D": "...", "E": "..." },
      "kunci": "D",
      "pembahasan": "...",
      "prasyaratTerkait": "${materiPrasyarat}"
    },
    {
      "id": "q5",
      "nomor": 5,
      "soal": "Pertanyaan nomor 5 menguji evaluasi materi prasyarat...",
      "opsi": { "A": "...", "B": "...", "C": "...", "D": "...", "E": "..." },
      "kunci": "E",
      "pembahasan": "...",
      "prasyaratTerkait": "${materiPrasyarat}"
    }
  ]
}`;

  return { systemInstruction, userPrompt };
}

/**
 * Format teks analisis kesiapan belajar sesuai aturan #4:
 * "Setelah siswa selesai, berikan analisis: 'Kesiapan Anda: [Persentase]%'.
 * Jika di bawah 70%, beri saran: 'Silakan pelajari kembali materi prasyarat [Materi Prasyarat] sebelum masuk ke [Topik Pilihan].'"
 */
export function formatKesiapanAnalysis(
  persentase: number,
  topikPilihan: string,
  materiPrasyarat: string
): { kesiapanText: string; saranText: string; isLulus: boolean } {
  const isLulus = persentase >= 70;
  const kesiapanText = `Kesiapan Anda: ${persentase}%`;
  const saranText = isLulus
    ? `Selamat! Kesiapan Anda sangat baik (${persentase}%). Anda siap untuk mempelajari materi ${topikPilihan}!`
    : `Silakan pelajari kembali materi prasyarat ${materiPrasyarat} sebelum masuk ke ${topikPilihan}.`;

  return { kesiapanText, saranText, isLulus };
}

// ----------------------------------------------------------------------
// VERIFIED PROCEDURAL 5-QUESTION MULTIPLE CHOICE SETS (A - E)
// Digunakan sebagai generator deterministik cepat & cadangan terverifikasi
// yang secara ketat HANYA menguji MATERI PRASYARAT.
// ----------------------------------------------------------------------
export const PROCEDURAL_PREREQUISITE_SETS: Record<string, DiagnosticQuestion[]> = {
  // 1. KIMIA HIJAU -> Prasyarat: Konsep Limbah, Perubahan Fisika/Kimia, dan Reaksi Pembakaran
  'Kimia Hijau': [
    {
      id: 'q1',
      nomor: 1,
      level: 1,
      levelLabel: 'Level 1: Konsep Dasar Prasyarat',
      tipe: 'PG',
      bloom: 'C2',
      indikator: 'Mengidentifikasi jenis dan karakteristik limbah materi kimia berbahaya (B3)',
      soal: 'Suatu zat sisa atau produk samping dari proses industri yang memiliki sifat mudah meledak, mudah menyala, beracun, dan bersifat korosif diklasifikasikan sebagai:',
      opsi: {
        A: 'Limbah Bahan Berbahaya dan Beracun (B3)',
        B: 'Limbah organik biodegradable mudah terurai',
        C: 'Limbah non-polutan ramah lingkungan',
        D: 'Residu inert tanah liat',
        E: 'Zat katalisator murni non-reaktif',
      },
      kunci: 'A',
      pembahasan: 'Limbah B3 adalah zat, energi, atau komponen lain yang karena sifat, konsentrasi, atau jumlahnya dapat mencemari lingkungan dan membahayakan kesehatan manusia. Sifat utamanya: mudah menyala, korosif, reaktif, dan beracun.',
      prasyaratTerkait: 'Konsep Limbah, Perubahan Fisika/Kimia, dan Reaksi Pembakaran',
    },
    {
      id: 'q2',
      nomor: 2,
      level: 1,
      levelLabel: 'Level 1: Pemahaman Konsep Prasyarat',
      tipe: 'PG',
      bloom: 'C2',
      indikator: 'Membedakan perubahan materi fisika dan kimia pada kehidupan sehari-hari',
      soal: 'Peristiwa di bawah ini yang merupakan contoh PERUBAHAN KIMIA (menghasilkan zat baru dengan komposisi berbeda) adalah:',
      opsi: {
        A: 'Peleburan lilin padat menjadi cairan saat dipanaskan',
        B: 'Pelarutan gula pasir di dalam air teh hangat',
        C: 'Pembakaran kertas yang menghasilkan abu dan gas karbon dioksida (CO₂)',
        D: 'Penguapan alkohol cair pada permukaan kulit',
        E: 'Penyubliman kapur barus padat menjadi uap',
      },
      kunci: 'C',
      pembahasan: 'Pembakaran kertas merupakan perubahan kimia karena ikatan kimia selulosa terputus dan bereaksi dengan O₂ membentuk zat baru berupa abu karbon, gas CO₂, dan H₂O. Opsi A, B, D, dan E adalah perubahan fisika karena tidak mengubah identitas zat.',
      prasyaratTerkait: 'Konsep Limbah, Perubahan Fisika/Kimia, dan Reaksi Pembakaran',
    },
    {
      id: 'q3',
      nomor: 3,
      level: 2,
      levelLabel: 'Level 2: Penerapan Prasyarat',
      tipe: 'PG',
      bloom: 'C3',
      indikator: 'Menjelaskan ciri dan produk dari reaksi pembakaran sempurna hidrokarbon',
      soal: 'Ketika gas metana (CH₄) mengalami reaksi pembakaran sempurna dengan gas oksigen (O₂) berlebih, zat apakah yang dihasilkan sebagai produk reaksi?',
      opsi: {
        A: 'Gas karbon monoksida (CO) dan gas hidrogen (H₂)',
        B: 'Gas karbon dioksida (CO₂) dan uap air (H₂O)',
        C: 'Arang karbon padat (C) dan asam format',
        D: 'Gas ozon (O₃) dan gas metana terionisasi',
        E: 'Asam karbonat cair (H₂CO₃) murni',
      },
      kunci: 'B',
      pembahasan: 'Reaksi pembakaran sempurna hidrokarbon: CH₄(g) + 2O₂(g) → CO₂(g) + 2H₂O(g) + energi kalor. Pembakaran sempurna selalu menghasilkan gas CO₂ dan H₂O.',
      prasyaratTerkait: 'Konsep Limbah, Perubahan Fisika/Kimia, dan Reaksi Pembakaran',
    },
    {
      id: 'q4',
      nomor: 4,
      level: 2,
      levelLabel: 'Level 2: Analisis Masalah Prasyarat',
      tipe: 'PG',
      bloom: 'C3',
      indikator: 'Menganalisis dampak bahaya pembakaran tidak sempurna bahan bakar',
      soal: 'Pembakaran tidak sempurna pada kendaraan bermotor terjadi jika pasokan gas oksigen tidak mencukupi. Gas sampingan beracun yang tidak berwarna dan tidak berbau namun dapat mengikat hemoglobin darah secara kuat adalah:',
      opsi: {
        A: 'Gas Karbon Monoksida (CO)',
        B: 'Gas Karbon Dioksida (CO₂)',
        C: 'Gas Nitrogen Oksida (NO₂)',
        D: 'Gas Belerang Dioksida (SO₂)',
        E: 'Gas Metana (CH₄)',
      },
      kunci: 'A',
      pembahasan: 'Pembakaran tak sempurna menghasilkan gas karbon monoksida (CO). Afinitas gas CO terhadap hemoglobin darah sekitar 200 kali lebih kuat dibandingkan O₂, sehingga membentuk HbCO dan menyebabkan asfiksia (kekurangan oksigen jaringan).',
      prasyaratTerkait: 'Konsep Limbah, Perubahan Fisika/Kimia, dan Reaksi Pembakaran',
    },
    {
      id: 'q5',
      nomor: 5,
      level: 3,
      levelLabel: 'Level 3: HOTS / Evaluasi Prasyarat',
      tipe: 'PG',
      bloom: 'C4',
      indikator: 'Menganalisis perubahan energi dan sifat termal pada reaksi pembakaran materi',
      soal: 'Semua reaksi pembakaran tergolong sebagai reaksi eksotermik. Manakah pernyataan berikut yang paling tepat menjelaskan kondisi energi pada reaksi tersebut?',
      opsi: {
        A: 'Sistem menyerap kalor dari lingkungan sehingga suhu lingkungan menjadi dingin (ΔH > 0)',
        B: 'Sistem melepaskan kalor ke lingkungan sehingga suhu lingkungan meningkat dan entalpi sistem berkurang (ΔH < 0)',
        C: 'Energi produk selalu lebih besar daripada energi pereaksi pada kondisi STP',
        D: 'Tidak terjadi perpindahan kalor antara sistem reaksi dengan lingkungan sekitarnya',
        E: 'Entalpi pembakaran bernilai nol karena massa zat kekal menurut hukum Lavoisier',
      },
      kunci: 'B',
      pembahasan: 'Reaksi pembakaran bersifat eksotermik: melepaskan kalor ke lingkungan sehingga suhu lingkungan naik. Entalpi produk lebih rendah daripada reaktan, sehingga nilai ΔH = H_produk - H_reaktan bernilai negatif (ΔH < 0).',
      prasyaratTerkait: 'Konsep Limbah, Perubahan Fisika/Kimia, dan Reaksi Pembakaran',
    },
  ],

  // 2. STRUKTUR ATOM -> Prasyarat: Perkembangan Teori Atom (Model Dalton, Thomson, Rutherford, Bohr)
  'Struktur Atom': [
    {
      id: 'q1',
      nomor: 1,
      level: 1,
      levelLabel: 'Level 1: Konsep Dasar Prasyarat',
      tipe: 'PG',
      bloom: 'C1',
      indikator: 'Mengidentifikasi postulat dasar model atom John Dalton',
      soal: 'Menurut teori atom John Dalton, atom digambarkan sebagai partikel terkecil materi yang memiliki karakteristik utama berupa:',
      opsi: {
        A: 'Bola pejal padat yang tidak dapat dibagi lagi menjadi bagian yang lebih kecil',
        B: 'Bola pejal bermuatan positif dengan elektron tersebar di permukaannya',
        C: 'Inti kecil bermuatan positif yang dikelilingi elektron pada jarak jauh',
        D: 'Awan elektron dengan probabilitas menemukan posisi elektron',
        E: 'Ruang hampa dengan elektron yang bergerak bebas tanpa lintasan',
      },
      kunci: 'A',
      pembahasan: 'John Dalton mengemukakan bahwa materi tersusun atas atom-atom yang berupa bola pejal padat, bersifat identik untuk unsur yang sama, serta tidak dapat dibagi, diciptakan, atau dimusnahkan.',
      prasyaratTerkait: 'Perkembangan Teori Atom (Model Dalton, Thomson, Rutherford, Bohr)',
    },
    {
      id: 'q2',
      nomor: 2,
      level: 1,
      levelLabel: 'Level 1: Pemahaman Konsep Prasyarat',
      tipe: 'PG',
      bloom: 'C2',
      indikator: 'Menjelaskan model atom Thomson dan analogi roti kismis',
      soal: 'Tokoh ilmuwan yang mengemukakan bahwa atom merupakan bola bermuatan positif yang di dalamnya tersebar elektron bermuatan negatif secara merata (dianalogikan seperti roti kismis) adalah:',
      opsi: {
        A: 'John Dalton',
        B: 'J.J. Thomson',
        C: 'Ernest Rutherford',
        D: 'Niels Bohr',
        E: 'James Chadwick',
      },
      kunci: 'B',
      pembahasan: 'J.J. Thomson menemukan elektron melalui percobaan tabung sinar katoda, lalu mengemukakan model atom roti kismis (plum pudding model), di mana elektron bermuatan negatif tersebar merata di dalam bola bermuatan positif.',
      prasyaratTerkait: 'Perkembangan Teori Atom (Model Dalton, Thomson, Rutherford, Bohr)',
    },
    {
      id: 'q3',
      nomor: 3,
      level: 2,
      levelLabel: 'Level 2: Penerapan Prasyarat',
      tipe: 'PG',
      bloom: 'C2',
      indikator: 'Menjelaskan kesimpulan dari percobaan hamburan sinar alfa Rutherford',
      soal: 'Pada percobaan penembakan lempeng tipis emas dengan partikel sinar alfa (α) oleh Ernest Rutherford, sebagian besar partikel alfa diteruskan lurus. Fakta eksperimen ini membuktikan bahwa:',
      opsi: {
        A: 'Sebagian besar volume atom merupakan ruang hampa/kosong',
        B: 'Semua muatan positif atom tersebar merata di seluruh bagian atom',
        C: 'Atom tidak memiliki inti dan tidak bermassa',
        D: 'Elektron menyerap partikel alfa sehingga tidak terjadi pembelokan',
        E: 'Atom adalah bola pejal yang sangat keras dan rapat',
      },
      kunci: 'A',
      pembahasan: 'Karena sebagian besar partikel sinar alfa diteruskan tanpa hambatan, Rutherford menyimpulkan bahwa sebagian besar atom terdiri dari ruang hampa. Hanya sedikit partikel yang dipantulkan atau dibelokkan karena menabrak inti atom yang bermuatan positif dan sangat padat.',
      prasyaratTerkait: 'Perkembangan Teori Atom (Model Dalton, Thomson, Rutherford, Bohr)',
    },
    {
      id: 'q4',
      nomor: 4,
      level: 2,
      levelLabel: 'Level 2: Analisis Prasyarat',
      tipe: 'PG',
      bloom: 'C2',
      indikator: 'Menjelaskan konsep lintasan stasioner pada model atom Niels Bohr',
      soal: 'Kelebihan utama model atom Niels Bohr dibandingkan model atom Ernest Rutherford adalah mampu menjelaskan:',
      opsi: {
        A: 'Bahwa elektron mengelilingi inti pada lintasan/orbit tertentu tanpa memancarkan energi (keadaan stasioner)',
        B: 'Keberadaan partikel neutron di dalam inti atom',
        C: 'Sifat dualisme gelombang-partikel dari elektron',
        D: 'Posisi elektron yang tidak dapat ditentukan secara pasti menurut asas ketidakpastian',
        E: 'Massa elektron yang jauh lebih berat daripada proton',
      },
      kunci: 'A',
      pembahasan: 'Bohr memperbaiki kelemahan model Rutherford dengan postulat bahwa elektron mengorbit inti pada tingkat energi (lintasan) tertentu yang bersifat stasioner, sehingga elektron tidak kehilangan energi dan tidak jatuh ke dalam inti atom.',
      prasyaratTerkait: 'Perkembangan Teori Atom (Model Dalton, Thomson, Rutherford, Bohr)',
    },
    {
      id: 'q5',
      nomor: 5,
      level: 3,
      levelLabel: 'Level 3: HOTS / Urutan Kronologis Prasyarat',
      tipe: 'PG',
      bloom: 'C3',
      indikator: 'Mengurutkan perkembangan model atom secara kronologis dan logis',
      soal: 'Urutan kronologis perkembangan teori atom dari yang paling awal hingga munculnya konsep tingkat energi elektron adalah:',
      opsi: {
        A: 'Dalton → Thomson → Rutherford → Bohr',
        B: 'Thomson → Dalton → Bohr → Rutherford',
        C: 'Rutherford → Dalton → Thomson → Bohr',
        D: 'Dalton → Rutherford → Thomson → Bohr',
        E: 'Bohr → Rutherford → Thomson → Dalton',
      },
      kunci: 'A',
      pembahasan: 'Urutan kronologis perkembangan teori atom klasik: 1. John Dalton (1803, bola pejal), 2. J.J. Thomson (1897, roti kismis), 3. Ernest Rutherford (1911, inti atom & ruang hampa), 4. Niels Bohr (1913, tingkat energi/lintasan stasioner).',
      prasyaratTerkait: 'Perkembangan Teori Atom (Model Dalton, Thomson, Rutherford, Bohr)',
    },
  ],

  // 3. IKATAN KIMIA -> Prasyarat: Konfigurasi Elektron dan Sistem Periodik Unsur
  'Ikatan Kimia': [
    {
      id: 'q1',
      nomor: 1,
      level: 1,
      levelLabel: 'Level 1: Konsep Dasar Prasyarat',
      tipe: 'PG',
      bloom: 'C2',
      indikator: 'Menentukan konfigurasi elektron dan elektron valensi atom logam',
      soal: 'Suatu atom natrium (Na) memiliki nomor atom 11. Bagaimanakah susunan konfigurasi elektron kulit Bohr dan jumlah elektron valensinya?',
      opsi: {
        A: '2, 8, 1 dengan elektron valensi 1',
        B: '2, 9 dengan elektron valensi 9',
        C: '2, 8, 8, 1 dengan elektron valensi 1',
        D: '2, 2, 7 dengan elektron valensi 7',
        E: '10, 1 dengan elektron valensi 1',
      },
      kunci: 'A',
      pembahasan: 'Nomor atom 11: Kulit K = 2, Kulit L = 8, Kulit M = 1. Jumlah elektron valensi (kulit terluar) adalah 1.',
      prasyaratTerkait: 'Konfigurasi Elektron dan Sistem Periodik Unsur',
    },
    {
      id: 'q2',
      nomor: 2,
      level: 1,
      levelLabel: 'Level 1: Pemahaman Konsep Prasyarat',
      tipe: 'PG',
      bloom: 'C2',
      indikator: 'Menghubungkan konfigurasi elektron gas mulia dengan kestabilan oktet/duplet',
      soal: 'Unsur gas mulia (golongan VIIIA seperti Neon dan Argon) bersifat sangat stabil dan sukar bereaksi karena memiliki konfigurasi elektron dengan:',
      opsi: {
        A: '8 elektron pada kulit terluar (oktet)',
        B: '1 elektron valensi yang mudah dilepaskan',
        C: 'Jumlah elektron ganjil pada orbital terluar',
        D: 'Jari-jari atom yang paling besar dalam satu periode',
        E: 'Energi ionisasi yang sangat rendah',
      },
      kunci: 'A',
      pembahasan: 'Kestabilan gas mulia disebabkan oleh susunan elektron valensi penuh (oktet: 8 elektron valensi, atau duplet: 2 elektron pada He), sehingga tidak memiliki kecenderungan melepas atau menarik elektron.',
      prasyaratTerkait: 'Konfigurasi Elektron dan Sistem Periodik Unsur',
    },
    {
      id: 'q3',
      nomor: 3,
      level: 2,
      levelLabel: 'Level 2: Penerapan Prasyarat',
      tipe: 'PG',
      bloom: 'C3',
      indikator: 'Menentukan letak golongan dan periode unsur dalam sistem periodik',
      soal: 'Unsur kalsium memiliki nomor atom 20 dengan konfigurasi elektron: 2, 8, 8, 2. Pada tabel periodik unsur, kalsium terletak pada:',
      opsi: {
        A: 'Golongan IIA, Periode 4',
        B: 'Golongan IVA, Periode 2',
        C: 'Golongan IIB, Periode 4',
        D: 'Golongan VIIIA, Periode 2',
        E: 'Golongan IA, Periode 3',
      },
      kunci: 'A',
      pembahasan: 'Jumlah kulit elektron terisi = 4 kulit (K, L, M, N) → Periode 4. Elektron valensi pada kulit terluar = 2 → Golongan IIA.',
      prasyaratTerkait: 'Konfigurasi Elektron dan Sistem Periodik Unsur',
    },
    {
      id: 'q4',
      nomor: 4,
      level: 2,
      levelLabel: 'Level 2: Analisis Prasyarat',
      tipe: 'PG',
      bloom: 'C3',
      indikator: 'Menganalisis kecenderungan atom mencapai kestabilan konfigurasi elektron',
      soal: 'Unsur klorin memiliki nomor atom 17 (konfigurasi: 2, 8, 7). Agar mencapai konfigurasi elektron yang stabil seperti gas mulia terdekat (Argon: 2, 8, 8), atom klorin cenderung:',
      opsi: {
        A: 'Menangkap 1 elektron membentuk anion Cl⁻',
        B: 'Melepaskan 7 elektron membentuk kation Cl⁷⁺',
        C: 'Melepaskan 1 elektron membentuk kation Cl⁺',
        D: 'Menangkap 7 elektron membentuk ion Cl⁷⁻',
        E: 'Tidak mengalami perubahan elektron karena sudah stabil',
      },
      kunci: 'A',
      pembahasan: 'Atom klorin memiliki 7 elektron valensi. Untuk mencapai aturan oktet (8 elektron), lebih mudah menangkap 1 elektron dari luar sehingga menjadi anion klorida Cl⁻ dengan konfigurasi 2, 8, 8.',
      prasyaratTerkait: 'Konfigurasi Elektron dan Sistem Periodik Unsur',
    },
    {
      id: 'q5',
      nomor: 5,
      level: 3,
      levelLabel: 'Level 3: HOTS / Evaluasi Prasyarat',
      tipe: 'PG',
      bloom: 'C4',
      indikator: 'Memprediksi rumus ionik senyawa berdasarkan konfigurasi elektron prasyarat',
      soal: 'Diketahui dua unsur dengan konfigurasi elektron:\nUnsur A: 2, 8, 3\nUnsur B: 2, 8, 6\nBerdasarkan kecenderungan pelepasan dan penangkapan elektron untuk mencapai kestabilan oktet, bagaimanakah rumus kimia senyawa yang terbentuk?',
      opsi: {
        A: 'AB',
        B: 'A₂B₃',
        C: 'A₃B₂',
        D: 'AB₂',
        E: 'A₂B',
      },
      kunci: 'B',
      pembahasan: 'Unsur A memiliki 3 elektron valensi → melepas 3e⁻ menjadi kation A³⁺. Unsur B memiliki 6 elektron valensi → menangkap 2e⁻ menjadi anion B²⁻. Penyetaraan muatan ion: 2(A³⁺) + 3(B²⁻) → rumus senyawa A₂B₃.',
      prasyaratTerkait: 'Konfigurasi Elektron dan Sistem Periodik Unsur',
    },
  ],

  // 4. STOIKIOMETRI -> Prasyarat: Persamaan Reaksi dan Hukum Dasar Kimia
  'Stoikiometri': [
    {
      id: 'q1',
      nomor: 1,
      level: 1,
      levelLabel: 'Level 1: Konsep Dasar Prasyarat',
      tipe: 'PG',
      bloom: 'C2',
      indikator: 'Menjelaskan bunyi dan penemu Hukum Kekekalan Massa',
      soal: 'Hukum dasar kimia yang menyatakan bahwa "dalam suatu sistem tertutup, massa total zat sebelum reaksi adalah sama dengan massa total zat sesudah reaksi" dikemukakan oleh:',
      opsi: {
        A: 'Antoine Lavoisier (Hukum Kekekalan Massa)',
        B: 'Joseph Proust (Hukum Perbandingan Tetap)',
        C: 'John Dalton (Hukum Kelipatan Perbandingan)',
        D: 'Gay-Lussac (Hukum Perbandingan Volume)',
        E: 'Amedeo Avogadro (Hipotesis Avogadro)',
      },
      kunci: 'A',
      pembahasan: 'Hukum Kekekalan Massa dirumuskan oleh Antoine Laurent Lavoisier setelah melakukan percobaan pembakaran merkuri dalam wadah tertutup kedap udara.',
      prasyaratTerkait: 'Persamaan Reaksi dan Hukum Dasar Kimia',
    },
    {
      id: 'q2',
      nomor: 2,
      level: 1,
      levelLabel: 'Level 1: Pemahaman Konsep Prasyarat',
      tipe: 'PG',
      bloom: 'C2',
      indikator: 'Mengidentifikasi kaidah penyetaraan persamaan reaksi kimia',
      soal: 'Manakah syarat mutlak yang WAJIB dipenuhi agar suatu persamaan reaksi kimia dikatakan telah SETARA?',
      opsi: {
        A: 'Jumlah atom setiap unsur di ruas kiri (reaktan) harus sama dengan ruas kanan (produk)',
        B: 'Jumlah molekul di ruas kiri harus sama persis dengan jumlah molekul di ruas kanan',
        C: 'Volume zat pereaksi selalu dua kali lipat volume zat hasil reaksi',
        D: 'Semua zat pereaksi dan produk harus berwujud gas (g)',
        E: 'Koefisien semua senyawa harus bernilai 1',
      },
      kunci: 'A',
      pembahasan: 'Persamaan reaksi setara berarti jumlah atom masing-masing unsur di ruas kiri sama dengan ruas kanan, sesuai pemenuhan Hukum Kekekalan Massa Lavoisier.',
      prasyaratTerkait: 'Persamaan Reaksi dan Hukum Dasar Kimia',
    },
    {
      id: 'q3',
      nomor: 3,
      level: 2,
      levelLabel: 'Level 2: Penerapan Prasyarat',
      tipe: 'PG',
      bloom: 'C3',
      indikator: 'Menyetarakan persamaan reaksi pembakaran hidrokarbon sederhana',
      soal: 'Perhatikan persamaan reaksi pembakaran gas metana berikut:\nCH₄(g) + b O₂(g) → c CO₂(g) + d H₂O(g)\nAgar persamaan reaksi tersebut setara, berapakah nilai koefisien b, c, dan d berturut-turut?',
      opsi: {
        A: 'b = 2, c = 1, d = 2',
        B: 'b = 1, c = 1, d = 2',
        C: 'b = 2, c = 2, d = 1',
        D: 'b = 3, c = 1, d = 2',
        E: 'b = 4, c = 2, d = 4',
      },
      kunci: 'A',
      pembahasan: 'CH₄ + 2O₂ → CO₂ + 2H₂O. Atom C: 1 = 1. Atom H: 4 = 2×2 = 4. Atom O: 2×2 = 4 di kiri, (1×2) + (2×1) = 4 di kanan. Maka b = 2, c = 1, d = 2.',
      prasyaratTerkait: 'Persamaan Reaksi dan Hukum Dasar Kimia',
    },
    {
      id: 'q4',
      nomor: 4,
      level: 2,
      levelLabel: 'Level 2: Analisis Prasyarat',
      tipe: 'PG',
      bloom: 'C3',
      indikator: 'Menganalisis penerapan Hukum Perbandingan Tetap (Proust)',
      soal: 'Perbandingan massa unsur hidrogen dan oksigen dalam senyawa air (H₂O) selalu tetap yaitu 1 : 8. Jika 3 gram hidrogen direaksikan dengan 16 gram oksigen, berapakah massa air yang terbentuk dan apakah ada zat yang tersisa?',
      opsi: {
        A: 'Terbentuk 18 gram air dan tersisa 1 gram gas hidrogen',
        B: 'Terbentuk 19 gram air tanpa ada zat yang tersisa',
        C: 'Terbentuk 16 gram air dan tersisa 3 gram hidrogen',
        D: 'Terbentuk 9 gram air dan tersisa 10 gram oksigen',
        E: 'Terbentuk 24 gram air dan tersisa 1 gram oksigen',
      },
      kunci: 'A',
      pembahasan: 'Perbandingan H : O = 1 : 8. Untuk 16 gram O, dibutuhkan H = (1/8) × 16 = 2 gram H. Massa H mula-mula 3 gram, maka H bereaksi 2 gram dan tersisa 3 - 2 = 1 gram H. Massa air terbentuk = 2 gram H + 16 gram O = 18 gram air.',
      prasyaratTerkait: 'Persamaan Reaksi dan Hukum Dasar Kimia',
    },
    {
      id: 'q5',
      nomor: 5,
      level: 3,
      levelLabel: 'Level 3: HOTS / Evaluasi Prasyarat',
      tipe: 'PG',
      bloom: 'C4',
      indikator: 'Menyetarakan koefisien reaksi pembakaran propana kompleks',
      soal: 'Perhatikan persamaan reaksi pembakaran gas propana:\na C₃H₈(g) + b O₂(g) → c CO₂(g) + d H₂O(g)\nNilai koefisien bulat paling sederhana a, b, c, dan d agar reaksi setara berturut-turut adalah:',
      opsi: {
        A: '1, 5, 3, 4',
        B: '1, 3, 3, 4',
        C: '2, 7, 6, 8',
        D: '1, 4, 3, 4',
        E: '2, 10, 6, 8',
      },
      kunci: 'A',
      pembahasan: 'Jika a = 1:\nAtom C: c = 3.\nAtom H: 2d = 8 → d = 4.\nAtom O di kanan = (3 × 2) + (4 × 1) = 6 + 4 = 10 atom O → 2b = 10 → b = 5.\nMaka a = 1, b = 5, c = 3, d = 4.',
      prasyaratTerkait: 'Persamaan Reaksi dan Hukum Dasar Kimia',
    },
  ],

  // 5. LARUTAN ASAM BASA -> Prasyarat: Konsep Mol dan Konsentrasi Larutan
  'Larutan Asam Basa': [
    {
      id: 'q1',
      nomor: 1,
      level: 1,
      levelLabel: 'Level 1: Konsep Dasar Prasyarat',
      tipe: 'PG',
      bloom: 'C2',
      indikator: 'Menghitung jumlah mol zat dari massa dan Mr zat',
      soal: 'Berapakah jumlah mol yang terkandung dalam 8 gram kristal padat NaOH (diketahui Mr NaOH = 40 g/mol)?',
      opsi: {
        A: '0,2 mol',
        B: '0,5 mol',
        C: '2,0 mol',
        D: '5,0 mol',
        E: '320 mol',
      },
      kunci: 'A',
      pembahasan: 'Rumus mol: n = massa / Mr = 8 gram / 40 g/mol = 0,2 mol.',
      prasyaratTerkait: 'Konsep Mol dan Konsentrasi Larutan',
    },
    {
      id: 'q2',
      nomor: 2,
      level: 1,
      levelLabel: 'Level 1: Pemahaman Konsep Prasyarat',
      tipe: 'PG',
      bloom: 'C2',
      indikator: 'Menjelaskan definisi molaritas (konsentrasi molar larutan)',
      soal: 'Molaritas (M) larutan didefinisikan sebagai jumlah mol zat terlarut dalam:',
      opsi: {
        A: '1 liter (1000 mL) larutan',
        B: '1 kilogram pelarut murni',
        C: '100 gram larutan',
        D: '1 mol zat pelarut',
        E: '1 mililiter larutan',
      },
      kunci: 'A',
      pembahasan: 'Molaritas (M) menyatakan jumlah mol zat terlarut dalam 1 liter (1 dm³) larutan. Rumusnya: M = n / V (V dalam Liter).',
      prasyaratTerkait: 'Konsep Mol dan Konsentrasi Larutan',
    },
    {
      id: 'q3',
      nomor: 3,
      level: 2,
      levelLabel: 'Level 2: Penerapan Prasyarat',
      tipe: 'PG',
      bloom: 'C3',
      indikator: 'Menghitung konsentrasi molaritas larutan',
      soal: 'Sebanyak 4 gram natrium hidroksida (NaOH, Mr = 40 g/mol) dilarutkan ke dalam air hingga volume larutan menjadi 500 mL (0,5 L). Berapakah konsentrasi molaritas larutan tersebut?',
      opsi: {
        A: '0,1 M',
        B: '0,2 M',
        C: '0,4 M',
        D: '0,8 M',
        E: '2,0 M',
      },
      kunci: 'B',
      pembahasan: 'Mol NaOH = 4 / 40 = 0,1 mol. Volume = 500 mL = 0,5 L. Molaritas M = n / V = 0,1 mol / 0,5 L = 0,2 M.',
      prasyaratTerkait: 'Konsep Mol dan Konsentrasi Larutan',
    },
    {
      id: 'q4',
      nomor: 4,
      level: 2,
      levelLabel: 'Level 2: Analisis Prasyarat',
      tipe: 'PG',
      bloom: 'C3',
      indikator: 'Menerapkan rumus pengenceran larutan (M₁·V₁ = M₂·V₂)',
      soal: 'Sebanyak 50 mL larutan HCl 2 M diencerkan dengan menambahkan air murni hingga volume larutannya menjadi 200 mL. Berapakah konsentrasi larutan setelah pengenceran?',
      opsi: {
        A: '0,5 M',
        B: '1,0 M',
        C: '0,25 M',
        D: '0,1 M',
        E: '0,75 M',
      },
      kunci: 'A',
      pembahasan: 'Rumus pengenceran: M₁ · V₁ = M₂ · V₂. Diketahui M₁ = 2 M, V₁ = 50 mL, V₂ = 200 mL. M₂ = (2 × 50) / 200 = 100 / 200 = 0,5 M.',
      prasyaratTerkait: 'Konsep Mol dan Konsentrasi Larutan',
    },
    {
      id: 'q5',
      nomor: 5,
      level: 3,
      levelLabel: 'Level 3: HOTS / Evaluasi Prasyarat',
      tipe: 'PG',
      bloom: 'C4',
      indikator: 'Menghitung konsentrasi ion dalam larutan elektrolit terlarut',
      soal: 'Larutan kalsium klorida (CaCl₂) dengan konsentrasi 0,15 M terdisosiasi sempurna di dalam air menurut persamaan:\nCaCl₂(aq) → Ca²⁺(aq) + 2 Cl⁻(aq)\nBerapakah konsentrasi ion klorida (Cl⁻) di dalam larutan tersebut?',
      opsi: {
        A: '0,15 M',
        B: '0,30 M',
        C: '0,45 M',
        D: '0,075 M',
        E: '0,60 M',
      },
      kunci: 'B',
      pembahasan: 'Berdasarkan perbandingan koefisien reaksi ionisasi: koefisien Cl⁻ adalah 2 kali koefisien CaCl₂. Maka [Cl⁻] = 2 × [CaCl₂] = 2 × 0,15 M = 0,30 M.',
      prasyaratTerkait: 'Konsep Mol dan Konsentrasi Larutan',
    },
  ],
};

/**
 * Mengambil atau membuat set 5 soal pilihan ganda prosedural untuk topik tertentu.
 */
export function getProceduralPrerequisiteSet(topikPilihan: string, setId: string): DiagnosticSet {
  const mapping = cariPrasyaratTopik(topikPilihan);
  const now = new Date();

  // Ambil set 5 soal terverifikasi dari katalog lengkap 24 materi atau kamus prosedural
  const baseQuestions =
    getDiagnosticQuestionsForTopic(mapping.topik) ||
    PROCEDURAL_PREREQUISITE_SETS[mapping.topik] ||
    PROCEDURAL_PREREQUISITE_SETS['Struktur Atom'];

  const clonedQuestions: DiagnosticQuestion[] = baseQuestions.map((q, idx) => ({
    ...q,
    id: `q${idx + 1}`,
    nomor: idx + 1,
    tipe: q.tipe || 'PG',
    prasyaratTerkait: q.prasyaratTerkait || mapping.prasyarat,
  }));

  return {
    materi_id: mapping.topik,
    materi_nama: mapping.topik,
    kelas: mapping.grade,
    prasyarat: [mapping.prasyarat],
    judul_tes: `Asesmen Kesiapan Belajar untuk: ${mapping.topik}`,
    set_id: setId,
    level_kesulitan: 'pilihan-ganda-prasyarat',
    threshold: 70,
    soal: clonedQuestions,
    metadata: {
      generated_at: now.toISOString(),
      model_used: 'procedural-kamus-prasyarat',
    },
  };
}
