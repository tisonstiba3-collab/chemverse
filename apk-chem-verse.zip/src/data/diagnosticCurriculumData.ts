import { PrerequisiteCurriculumItem } from '../types/chemistry';

export const DIAGNOSTIC_CURRICULUM_CATALOG: PrerequisiteCurriculumItem[] = [
  // ==========================================
  // KELAS X (Fase E)
  // ==========================================
  {
    code: 'X.01',
    name: 'Pengukuran & Metode Ilmiah',
    grade: 'X',
    prasyarat: ['Besaran & satuan SI', 'Angka penting', 'Konversi satuan'],
    aliases: ['hakikat-ilmu-kimia-x', 'pengukuran-metode-ilmiah', 'keselamatan-laboratorium-x'],
    remedialSummary:
      'Pengukuran ilmiah membutuhkan pemahaman satuan baku SI (kg, m, s, mol, K), aturan penulisan angka penting saat perkalian/pembagian, serta ketelitian konversi satuan volume (1 L = 1 dm³ = 1000 mL = 1000 cm³).',
    keyFormulas: [
      '\\text{Massa Jenis (}\\rho\\text{)} = \\frac{m}{V}',
      '1\\text{ L} = 1000\\text{ mL} = 1\\times 10^{-3}\\text{ m}^3',
    ],
  },
  {
    code: 'X.02',
    name: 'Struktur Atom',
    grade: 'X',
    prasyarat: ['Sifat Materi dan Partikel Penyusun Materi'],
    aliases: ['struktur-atom-x', 'struktur-atom', 'konfigurasi-elektron-x', 'sistem-periodik-x'],
    remedialSummary:
      'Materi tersusun dari partikel-partikel mikroskopis (atom, ion, molekul) dan mengalami perubahan fisik maupun kimia. Atom memiliki partikel dasar penyusun: proton bermuatan positif dan neutron netral di dalam inti, serta elektron bermuatan negatif yang mengelilingi inti.',
    keyFormulas: [
      'A = Z + n \\quad (\\text{Nomor Massa} = \\text{Proton} + \\text{Neutron})',
      '\\text{Muatan Inti} = +Z',
    ],
  },
  {
    code: 'X.03',
    name: 'Ikatan Kimia',
    grade: 'X',
    prasyarat: ['Konfigurasi Elektron dan Sistem Periodik Unsur'],
    aliases: ['ikatan-kimia-x', 'ikatan-kimia'],
    remedialSummary:
      'Konfigurasi elektron menentukan elektron valensi suatu unsur. Golongan dan periode dalam tabel periodik mencerminkan kecenderungan unsur untuk melepas elektron (logam) atau menarik elektron (nonlogam) demi mencapai konfigurasi stabil seperti gas mulia (kaidah duplet/oktet).',
    keyFormulas: [
      '\\text{Elektron Valensi} = \\text{Elektron Kulit Terluar}',
      '\\text{Kaidah Oktet: } 8\\text{ elektron terluar}',
    ],
  },
  {
    code: 'X.04',
    name: 'Hukum Dasar Kimia',
    grade: 'X',
    prasyarat: ['Sifat Zat, Perubahan Kimia, dan Partikel Materi'],
    aliases: ['hukum-dasar-kimia-x', 'hukum-dasar-kimia'],
    remedialSummary:
      'Hukum Lavoisier (Kekekalan Massa) menyatakan massa total zat sebelum dan sesudah reaksi selalu sama dalam sistem tertutup. Oleh sebab itu, persamaan reaksi wajib disetarakan jumlah atomnya pada ruas kiri dan kanan.',
    keyFormulas: [
      '\\sum m_{\\text{reaktan}} = \\sum m_{\\text{produk}} \\quad (\\text{Hukum Lavoisier})',
      'n = \\frac{m}{M_r}',
    ],
  },
  {
    code: 'X.05',
    name: 'Stoikiometri',
    grade: 'X',
    prasyarat: ['Persamaan Reaksi dan Hukum Dasar Kimia'],
    aliases: ['stoikiometri-x', 'stoikiometri', 'perhitungan-kimia-x'],
    remedialSummary:
      'Sebelum melakukan perhitungan stoikiometri, persamaan reaksi wajib disetarakan agar koefisien reaksinya menunjukkan perbandingan jumlah mol zat pereaksi dan produk, sesuai Hukum Kekekalan Massa dan Hukum Perbandingan Tetap.',
    keyFormulas: [
      'n = \\frac{m}{M_r}',
      'V_{\\text{STP}} = n \\times 22{,}4\\text{ L}',
      '\\text{Perbandingan Mol} = \\text{Perbandingan Koefisien Reaksi Setara}',
    ],
  },
  {
    code: 'X.06',
    name: 'Kimia Hijau',
    grade: 'X',
    prasyarat: ['Konsep Limbah, Perubahan Fisika/Kimia, dan Reaksi Pembakaran'],
    aliases: ['kimia-hijau-x', 'green-chemistry-x'],
    remedialSummary:
      'Kimia hijau mengedepankan pencegahan limbah daripada penanggulangan setelah terbentuk, penghematan energi, pemanfaatan bahan mentah terbarukan, dan perancangan sintesis dengan ekonomi atom tinggi.',
    keyFormulas: [
      '\\text{Ekonomi Atom (\\%)} = \\frac{M_r\\text{ produk target}}{\\sum M_r\\text{ semua reaktan}} \\times 100\\%',
    ],
  },
  {
    code: 'X.07',
    name: 'Perubahan Energi',
    grade: 'X',
    prasyarat: ['Reaksi eksoterm/endoterm', 'Kalor', 'Satuan energi'],
    aliases: ['pemanasan-global-x', 'perubahan-energi-x'],
    remedialSummary:
      'Reaksi eksoterm melepaskan kalor ke lingkungan (ΔH bernilai negatif, suhu lingkungan naik). Reaksi endoterm menyerap kalor dari lingkungan (ΔH bernilai positif, suhu lingkungan turun). 1 kalori = 4,184 Joule.',
    keyFormulas: [
      'q = m \\cdot c \\cdot \\Delta T',
      '\\Delta H < 0 \\text{ (Eksoterm)}, \\quad \\Delta H > 0 \\text{ (Endoterm)}',
    ],
  },

  // ==========================================
  // KELAS XI (Fase F)
  // ==========================================
  {
    code: 'XI.01',
    name: 'Hidrokarbon & Minyak Bumi',
    grade: 'XI',
    prasyarat: ['Ikatan kovalen C', 'Struktur senyawa karbon', 'Tata nama IUPAC dasar'],
    aliases: ['senyawa-hidrokarbon-xi', 'hidrokarbon-xi'],
    remedialSummary:
      'Atom karbon (C) memiliki 4 elektron valensi dan mampu membentuk 4 ikatan kovalen stabil serta rantai karbon bercabang maupun siklik. Deret homolog: Alkana (CnH2n+2), Alkena (CnH2n), dan Alkuna (CnH2n-2).',
    keyFormulas: [
      '\\text{Alkana: } C_n H_{2n+2}',
      '\\text{Alkena: } C_n H_{2n}',
      '\\text{Alkuna: } C_n H_{2n-2}',
    ],
  },
  {
    code: 'XI.02',
    name: 'Termokimia',
    grade: 'XI',
    prasyarat: ['Persamaan reaksi', 'Stoikiometri', 'Konsep mol', 'Satuan kJ·mol⁻¹'],
    aliases: ['termokimia-xi'],
    remedialSummary:
      'Perubahan entalpi standar (ΔH°) diukur pada kondisi 25°C dan 1 atm dalam satuan kJ·mol⁻¹. Menurut Hukum Hess, perubahan entalpi reaksi hanya bergantung pada keadaan awal dan akhir pereaksi, tidak bergantung pada jalannya reaksi.',
    keyFormulas: [
      '\\Delta H_r^\\circ = \\sum \\Delta H_f^\\circ(\\text{produk}) - \\sum \\Delta H_f^\\circ(\\text{reaktan})',
      '\\Delta H = -\\frac{q_{\\text{larutan}}}{n}',
    ],
  },
  {
    code: 'XI.03',
    name: 'Laju Reaksi',
    grade: 'XI',
    prasyarat: ['Stoikiometri', 'Konsentrasi (M)', 'Teori tumbukan dasar'],
    aliases: ['laju-reaksi-xi'],
    remedialSummary:
      'Konsentrasi molaritas (M) = mol / volume larutan (L). Laju reaksi dipengaruhi oleh luas permukaan sentuh, konsentrasi, suhu (meningkatkan energi kinetik partikel sehingga tumbukan efektif meningkat), dan katalis (menurunkan energi aktivasi Ea).',
    keyFormulas: [
      'M = \\frac{n}{V} = \\frac{m}{M_r} \\times \\frac{1000}{V(\\text{mL})}',
      'v = k[A]^m[B]^n',
    ],
  },
  {
    code: 'XI.04',
    name: 'Kesetimbangan Kimia',
    grade: 'XI',
    prasyarat: ['Laju reaksi', 'Reaksi reversible (⇌)', 'Kc dasar'],
    aliases: ['kesetimbangan-kimia-xi'],
    remedialSummary:
      'Kesetimbangan dinamis tercapai ketika laju reaksi maju sama dengan laju reaksi balik (v1 = v2). Berdasarkan Azas Le Chatelier, jika sistem kesetimbangan diberikan aksi luar (suhu, tekanan, volume, konsentrasi), sistem akan bergeser untuk meminimalkan aksi tersebut.',
    keyFormulas: [
      'K_c = \\frac{[C]^c [D]^d}{[A]^a [B]^b} \\quad (\\text{Hanya fase aq dan g})',
      'K_p = K_c(RT)^{\\Delta n}',
    ],
  },
  {
    code: 'XI.05',
    name: 'Larutan Asam Basa',
    grade: 'XI',
    prasyarat: ['Konsep Mol dan Konsentrasi Larutan'],
    aliases: ['asam-basa-xi', 'larutan-asam-basa', 'asam-basa'],
    remedialSummary:
      'Menurut Arrhenius, asam menghasilkan ion H⁺ (atau H₃O⁺) dalam air, sedangkan basa menghasilkan ion OH⁻. pH = -log[H⁺] dan pOH = -log[OH⁻]. Hubungan dalam air murni: pH + pOH = 14 pada 25°C.',
    keyFormulas: [
      '\\text{pH} = -\\log[H^+]',
      '[H^+]_{\\text{asam kuat}} = a \\times M',
      '[H^+]_{\\text{asam lemah}} = \\sqrt{K_a \\times M}',
    ],
  },
  {
    code: 'XI.06',
    name: 'Hidrolisis Garam',
    grade: 'XI',
    prasyarat: ['Asam-basa', 'Ka/Kb dasar', 'Reaksi ion'],
    aliases: ['hidrolisis-garam-xi'],
    remedialSummary:
      'Hidrolisis terjadi ketika kation/anion dari asam atau basa lemah bereaksi dengan air. Garam dari asam kuat dan basa kuat netral (tidak terhidrolisis). Garam dari asam lemah + basa kuat bersifat basa (hidrolisis parsial anion).',
    keyFormulas: [
      '[OH^-] = \\sqrt{\\frac{K_w}{K_a} \\times [\\text{garam}] \\times val}',
      '[H^+] = \\sqrt{\\frac{K_w}{K_b} \\times [\\text{garam}] \\times val}',
    ],
  },
  {
    code: 'XI.07',
    name: 'Larutan Penyangga',
    grade: 'XI',
    prasyarat: ['Asam-basa', 'Kesetimbangan', 'Perhitungan pH'],
    aliases: ['larutan-penyangga-xi'],
    remedialSummary:
      'Larutan penyangga (buffer) mempertahankan pH dari penambahan sedikit asam, sedikit basa, atau pengenceran. Terdiri atas asam lemah + basa konjugasinya (buffer asam) atau basa lemah + asam konjugasinya (buffer basa).',
    keyFormulas: [
      '[H^+] = K_a \\times \\frac{n_{\\text{asam lemah}}}{n_{\\text{basa konjugasi}}}',
      '[OH^-] = K_b \\times \\frac{n_{\\text{basa lemah}}}{n_{\\text{asam konjugasi}}}',
    ],
  },
  {
    code: 'XI.08',
    name: 'Titrasi Asam-Basa',
    grade: 'XI',
    prasyarat: ['Konsentrasi', 'Stoikiometri larutan', 'Indikator'],
    aliases: ['titrasi-asam-basa-xi'],
    remedialSummary:
      'Titrasi adalah analisis kuantitatif untuk menentukan konsentrasi larutan analit menggunakan larutan standar titran. Titik ekivalen tercapai saat mol ekuivalen asam tepat sama dengan mol ekuivalen basa: a · Va · Ma = b · Vb · Mb.',
    keyFormulas: [
      'a \\times V_a \\times M_a = b \\times V_b \\times M_b',
    ],
  },
  {
    code: 'XI.09',
    name: 'Koloid',
    grade: 'XI',
    prasyarat: ['Sifat larutan', 'Campuran homogen/heterogen'],
    aliases: ['sistem-koloid-xi', 'koloid-xi'],
    remedialSummary:
      'Koloid merupakan sistem dispersi heterogen antara larutan sejati dan suspensi kasar (ukuran partikel 1–100 nm). Sifat khas koloid: Efek Tyndall (penghamburan cahaya), Gerak Brown (gerak acak partikel), dan Adsorpsi muatan ion.',
    keyFormulas: [
      '\\text{Ukuran partikel koloid: } 1 - 100\\text{ nm}',
    ],
  },

  // ==========================================
  // KELAS XII (Fase F)
  // ==========================================
  {
    code: 'XII.01',
    name: 'Sifat Koligatif Larutan',
    grade: 'XII',
    prasyarat: ['Konsentrasi (M, m)', 'Konsep mol', 'Sifat larutan'],
    aliases: ['sifat-koligatif-xii'],
    remedialSummary:
      'Sifat koligatif larutan hanya bergantung pada jumlah partikel zat terlarut, bukan jenisnya. Meliputi: penurunan tekanan uap (ΔP), kenaikan titik didih (ΔTb), penurunan titik beku (ΔTf), dan tekanan osmotik (π).',
    keyFormulas: [
      'm = \\frac{m_{\\text{terlarut}}}{M_r} \\times \\frac{1000}{P(\\text{gram pelarut})}',
      '\\Delta T_b = m \\cdot K_b \\cdot i, \\quad \\Delta T_f = m \\cdot K_f \\cdot i',
      '\\pi = M \\cdot R \\cdot T \\cdot i',
    ],
  },
  {
    code: 'XII.02',
    name: 'Redoks & Biloks',
    grade: 'XII',
    prasyarat: ['Biloks', 'Konsep oksidasi-reduksi', 'Reaksi setara'],
    aliases: ['reaksi-redoks-xii', 'redoks-xii'],
    remedialSummary:
      'Oksidasi adalah kenaikan bilangan oksidasi (pelepasan elektron). Reduksi adalah penurunan bilangan oksidasi (penerimaan elektron). Oksidator mengalami reduksi, sedangkan reduktor mengalami oksidasi.',
    keyFormulas: [
      '\\text{Biloks atom bebas} = 0, \\quad \\text{Biloks ion tunggal} = \\text{muatannya}',
      '\\sum \\text{Biloks senyawa netral} = 0',
    ],
  },
  {
    code: 'XII.03',
    name: 'Sel Volta & Elektrolisis',
    grade: 'XII',
    prasyarat: ['Redoks', 'Potensial sel', 'Hukum Faraday dasar'],
    aliases: ['sel-volta-xii'],
    remedialSummary:
      'Sel Volta mengubah energi kimia menjadi listrik (spontan, E°sel > 0). Anoda = oksidasi (kutub negatif), Katoda = reduksi (kutub positif). E°sel = E°katoda - E°anoda.',
    keyFormulas: [
      'E^\\circ_{\\text{sel}} = E^\\circ_{\\text{katoda}} - E^\\circ_{\\text{anoda}}',
      'w = \\frac{e \\cdot I \\cdot t}{96500} \\quad (\\text{Hukum Faraday I})',
    ],
  },
  {
    code: 'XII.04',
    name: 'Korosi',
    grade: 'XII',
    prasyarat: ['Redoks', 'Elektrokimia dasar', 'Reaksi dengan oksigen'],
    aliases: ['korosi-xii'],
    remedialSummary:
      'Korosi besi adalah proses elektrokimia di mana besi (Fe) teroksidasi menjadi Fe²⁺ oleh air dan gas oksigen O₂. Pencegahan: pelapisan cat/minyak, galvanisasi (lapisan seng Zn), dan proteksi katodik (korban anoda Mg).',
    keyFormulas: [
      '\\text{Anoda: } \\text{Fe}(s) \\rightarrow \\text{Fe}^{2+}(aq) + 2e^-',
      '\\text{Katoda: } \\text{O}_2(g) + 2\\text{H}_2\\text{O}(l) + 4e^- \\rightarrow 4\\text{OH}^-(aq)',
    ],
  },
  {
    code: 'XII.05',
    name: 'Kimia Unsur',
    grade: 'XII',
    prasyarat: ['Sistem periodik', 'Sifat periodik', 'Kecenderungan unsur'],
    aliases: ['kimia-unsur-xii'],
    remedialSummary:
      'Sifat periodik: jari-jari atom dalam satu golongan makin ke bawah makin besar; dalam satu periode makin ke kanan makin kecil. Energi ionisasi dan keelektronegatifan makin ke kanan makin besar.',
    keyFormulas: [
      '\\text{Golongan Utama: IA, IIA, VIIA (Halogen), VIIIA (Gas Mulia)}',
      '\\text{Logam Transisi: Blok d, memiliki bilangan oksidasi bervariasi}',
    ],
  },
  {
    code: 'XII.06',
    name: 'Senyawa Karbon & Isomer',
    grade: 'XII',
    prasyarat: ['Ikatan kovalen', 'Struktur senyawa', 'Tata nama IUPAC organik'],
    aliases: ['senyawa-karbon-xii'],
    remedialSummary:
      'Gugus fungsi menentukan sifat kimia senyawa organik: Alkohol (-OH), Eter (-O-), Aldehid (-CHO), Keton (-CO-), Asam Karboksilat (-COOH), Ester (-COO-). Isomer meliputi isomer rangka, posisi, gugus fungsi, dan geometri (cis-trans).',
    keyFormulas: [
      'R-\\text{OH} \\quad (\\text{Alkohol/Alkanol})',
      'R-\\text{COOH} \\quad (\\text{Asam Alkanoat})',
      'R-\\text{COO}-R\' \\quad (\\text{Alkil Alkanoat/Ester})',
    ],
  },
  {
    code: 'XII.07',
    name: 'Biomolekul (Karbo, Protein, Lipid)',
    grade: 'XII',
    prasyarat: ['Gugus fungsi', 'Ikatan kimia', 'Reaksi organik dasar'],
    aliases: ['makromolekul-xii', 'biomolekul-xii'],
    remedialSummary:
      'Karbohidrat tersusun atas monosakarida yang terhubung ikatan glikosida. Protein tersusun atas asam amino yang terhubung ikatan peptida (-CO-NH-). Lipid (lemak) adalah ester dari gliserol dengan 3 asam lemak.',
    keyFormulas: [
      '\\text{Ikatan Peptida: } -\\text{CO}-\\text{NH}-',
      '\\text{Trigliserida: Gliserol} + 3\\text{ Asam Lemak} \\rightarrow \\text{Lemak} + 3\\text{H}_2\\text{O}',
    ],
  },
  {
    code: 'XII.08',
    name: 'Polimer',
    grade: 'XII',
    prasyarat: ['Gugus fungsi', 'Reaksi adisi/kondensasi'],
    aliases: ['polimer-xii'],
    remedialSummary:
      'Polimer adalah makromolekul yang terbentuk dari penggabungan monomer-monomer berulang. Polimerisasi adisi memutus ikatan rangkap monomer (contoh: etena -> polietilena). Polimerisasi kondensasi melepaskan molekul kecil seperti H₂O (contoh: nilon, poliester).',
    keyFormulas: [
      'n(CH_2=CH_2) \\xrightarrow{\\text{Adisi}} -[CH_2-CH_2]_n-',
    ],
  },
  {
    code: 'XII.09',
    name: 'Kimia Lingkungan',
    grade: 'XII',
    prasyarat: ['Stoikiometri', 'Redoks', 'Sifat gas'],
    aliases: ['kimia-lingkungan-xii'],
    remedialSummary:
      'Kimia lingkungan mempelajari siklus unsur biogeokimia dan dampak polutan kimia terhadap atmosfer, hidrosfer, dan litosfer. Hujan asam disebabkan oleh emisi gas SO₂ dan NOx yang bereaksi dengan uap air membentuk H₂SO₄ dan HNO₃.',
    keyFormulas: [
      '\\text{SO}_3(g) + \\text{H}_2\\text{O}(l) \\rightarrow \\text{H}_2\\text{SO}_4(aq)',
      '2\\text{NO}_2(g) + \\text{H}_2\\text{O}(l) \\rightarrow \\text{HNO}_3(aq) + \\text{HNO}_2(aq)',
    ],
  },
];

/**
 * Finds the matching prerequisite curriculum item by topic id or curriculum code
 */
export function findPrerequisiteItem(topicIdOrCode: string): PrerequisiteCurriculumItem {
  const normalized = topicIdOrCode.trim().toLowerCase();

  // Try direct code match (e.g. "X.01", "x.01", "x01")
  const codeMatch = DIAGNOSTIC_CURRICULUM_CATALOG.find(
    (item) =>
      item.code.toLowerCase() === normalized ||
      item.code.toLowerCase().replace('.', '') === normalized.replace('.', '')
  );
  if (codeMatch) return codeMatch;

  // Try alias match
  const aliasMatch = DIAGNOSTIC_CURRICULUM_CATALOG.find((item) =>
    item.aliases.some((alias) => normalized.includes(alias) || alias.includes(normalized))
  );
  if (aliasMatch) return aliasMatch;

  // Try name match
  const nameMatch = DIAGNOSTIC_CURRICULUM_CATALOG.find(
    (item) =>
      item.name.toLowerCase().includes(normalized) ||
      normalized.includes(item.name.toLowerCase())
  );
  if (nameMatch) return nameMatch;

  // Fallback default (X.05 Stoikiometri if not found)
  return DIAGNOSTIC_CURRICULUM_CATALOG[4];
}
