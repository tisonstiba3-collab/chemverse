export interface RumusItem {
  id: string;
  nomorBab: string;
  kartuNumbers: string; // e.g. "Kartu 2 - 3"
  judul: string;
  kelas: 'X' | 'XI' | 'XII';
  fase: 'Fase E' | 'Fase F';
  kategori: string;
  modelType: string;
  accentColor: string;
  ringkasanKonsep: string;
  rumusUtama: Array<{
    nama: string;
    latex: string;
    keterangan: string;
  }>;
  poinKunci: string[];
  contohPenerapan: {
    kasus: string;
    langkahPenyelesaian: string;
    jawabanAkhir: string;
  };
  interaktifCalcType?: 'kadar' | 'mol' | 'ph' | 'sel-volta' | 'kp-kc' | 'kalor' | 'faraday';
}

export const KUMPULAN_RUMUS_TKA: RumusItem[] = [
  {
    id: 'kadar-zat-campuran',
    nomorBab: 'Bab 1',
    kartuNumbers: 'Kartu 2 - 3',
    judul: 'Kadar Zat dalam Campuran & Perubahan Materi',
    kelas: 'X',
    fase: 'Fase E',
    kategori: 'Dasar Kimia & Analitik',
    modelType: 'particle-system',
    accentColor: '#38BDF8',
    ringkasanKonsep:
      'Menentukan persentase dan konsentrasi komponen zat dalam campuran homogen/heterogen, serta membedakan perubahan fisika (reversibel, tanpa zat baru) dan perubahan kimia (terbentuk zat baru dengan ciri endapan, gas, perubahan warna atau suhu).',
    rumusUtama: [
      {
        nama: 'Persentase Massa (% massa)',
        latex: '\\% \\text{ massa} = \\frac{\\text{massa komponen}}{\\text{massa campuran}} \\times 100\\%',
        keterangan: 'Massa komponen dan campuran dalam satuan gram yang sama.',
      },
      {
        nama: 'Persentase Volume (% volume)',
        latex: '\\% \\text{ volume} = \\frac{\\text{volume komponen}}{\\text{volume campuran}} \\times 100\\%',
        keterangan: 'Digunakan untuk campuran cairan atau gas.',
      },
      {
        nama: 'Bagian per Sejuta (bpj / ppm) Massa',
        latex: '\\text{bpj massa} = \\frac{\\text{massa komponen}}{\\text{massa campuran}} \\times 10^6',
        keterangan: 'Untuk konsentrasi kelumit / polutan sangat encer (1 bpj = 1 mg/kg atau 1 mg/L air).',
      },
      {
        nama: 'Bagian per Sejuta (bpj / ppm) Volume',
        latex: '\\text{bpj volume} = \\frac{\\text{volume komponen}}{\\text{volume campuran}} \\times 10^6',
        keterangan: 'Untuk konsentrasi gas kelumit di udara (misal CO, SO2).',
      },
    ],
    poinKunci: [
      'Perubahan Fisika: Tidak terjadi perubahan zat permanen, susunan molekul tetap, hanya wujud atau ukuran berubah (contoh: es mencair, pelarutan gula).',
      'Perubahan Kimia: Terjadi pembentukan zat baru dengan sifat berbeda. Ciri utama: terbentuk endapan, muncul gelembung gas, perubahan warna, perubahan suhu.',
      'Total massa campuran = massa zat terlarut + massa zat pelarut.',
    ],
    contohPenerapan: {
      kasus: 'Sebanyak 25 gram garam dilarutkan ke dalam 225 gram air murni. Hitung kadar (% massa) garam dalam larutan tersebut!',
      langkahPenyelesaian: 'Massa campuran = 25 g + 225 g = 250 g. Kadar = (25 / 250) × 100% = 10%.',
      jawabanAkhir: '% massa garam = 10%',
    },
    interaktifCalcType: 'kadar',
  },
  {
    id: 'atom-struktur-kuantum',
    nomorBab: 'Bab 2',
    kartuNumbers: 'Kartu 4 - 9',
    judul: 'Atom, Struktur Atom & 4 Bilangan Kuantum',
    kelas: 'X',
    fase: 'Fase E',
    kategori: 'Struktur Materi',
    modelType: 'atom',
    accentColor: '#818CF8',
    ringkasanKonsep:
      'Partikel subatomik (proton, elektron, neutron), notasi unsur Z dan A, konfigurasi elektron berdasarkan prinsip Aufbau, larangan Pauli, aturan Hund, serta 4 bilangan kuantum (n, l, m, s).',
    rumusUtama: [
      {
        nama: 'Nomor Massa & Jumlah Partikel Atom Netral',
        latex: 'A = Z + n \\quad ; \\quad p = e = Z \\quad ; \\quad n = A - Z',
        keterangan: 'A = nomor massa, Z = nomor atom, p = proton, e = elektron, n = neutron.',
      },
      {
        nama: 'Ion Positif (Kation) & Ion Negatif (Anion)',
        latex: 'e_{\\text{kation}} = Z - (+\\text{muatan}) \\quad ; \\quad e_{\\text{anion}} = Z + (|-\\text{muatan}|)',
        keterangan: 'Kation melepas elektron, anion menerima elektron. Jumlah proton dan neutron tidak berubah!',
      },
      {
        nama: '4 Bilangan Kuantum',
        latex: 'n \\in \\{1,2,3,4\\} \\quad ; \\quad l \\in 0 \\dots (n-1) \\quad ; \\quad m \\in -l \\dots +l \\quad ; \\quad s = \\pm \\frac{1}{2}',
        keterangan: 'l=0 (subkulit s), l=1 (subkulit p), l=2 (subkulit d), l=3 (subkulit f).',
      },
      {
        nama: 'Kapasitas Maksimum Elektron Kulit & Subkulit',
        latex: 'e_{\\text{kulit max}} = 2n^2 \\quad ; \\quad s(2), \\ p(6), \\ d(10), \\ f(14)',
        keterangan: 'Urutan pengisian energi Aufbau: 1s < 2s < 2p < 3s < 3p < 4s < 3d < 4p < 5s < 4d < 5p...',
      },
    ],
    poinKunci: [
      'Asas Aufbau: Pengisian orbital dimulai dari subkulit berenergi paling rendah.',
      'Larangan Pauli: Tidak boleh ada dua elektron dalam satu atom yang memiliki keempat bilangan kuantum yang sama persis.',
      'Kaidah Hund: Elektron mengisi orbital setingkat secara tunggal dengan spin sejajar sebelum berpasangan.',
    ],
    contohPenerapan: {
      kasus: 'Tentukan 4 bilangan kuantum untuk elektron terakhir atom Klorin (17Cl: 1s² 2s² 2p⁶ 3s² 3p⁵)!',
      langkahPenyelesaian: 'Elektron terakhir berada pada 3p⁵. Kulit n = 3, subkulit p maka l = 1. Tiga orbital p (m = -1, 0, +1): 3 elektron spin atas, 2 elektron berpasangan spin bawah. Elektron ke-5 jatuh di m = 0 dengan spin berlawanan s = -1/2.',
      jawabanAkhir: 'n = 3, l = 1, m = 0, s = -1/2',
    },
  },
  {
    id: 'sistem-periodik-unsur',
    nomorBab: 'Bab 3',
    kartuNumbers: 'Kartu 10 - 13',
    judul: 'Sistem Periodik Unsur & Sifat Keperiodikan',
    kelas: 'X',
    fase: 'Fase E',
    kategori: 'Struktur Materi',
    modelType: 'atom',
    accentColor: '#34D399',
    ringkasanKonsep:
      'Pengelompokan unsur ke dalam Golongan Utama (IA - VIIIA) dan Golongan Transisi (IB - VIIIB), serta pola berkala sifat periodik (jari-jari atom, energi ionisasi, afinitas elektron, keelektronegatifan, sifat logam/nonlogam).',
    rumusUtama: [
      {
        nama: 'Tren: Ke Bawah Makin Besar, Ke Kanan Makin Kecil',
        latex: '\\downarrow \\text{ Semakin Besar} \\quad ; \\quad \\rightarrow \\text{ Semakin Kecil}',
        keterangan: 'Berlaku untuk: Jari-jari atom, Jari-jari kation, Sifat Kebasaan, Karakter Kelogaman, Kereaktifan positif.',
      },
      {
        nama: 'Tren: Ke Bawah Makin Kecil, Ke Kanan Makin Besar',
        latex: '\\downarrow \\text{ Semakin Kecil} \\quad ; \\quad \\rightarrow \\text{ Semakin Besar}',
        keterangan: 'Berlaku untuk: Potensial / Energi Ionisasi, Afinitas Elektron, Keelektronegatifan (paling tinggi Fluor VIIA), Kenon-logaman, Keasaman oksi.',
      },
    ],
    poinKunci: [
      'Golongan Utama ditentukan oleh elektron valensi (kulit s dan p).',
      'Golongan Transisi melibatkan subkulit (n-1)d dan ns.',
      'Jari-jari atom membesar dari atas ke bawah karena jumlah kulit bertambah.',
      'Keelektronegatifan terbesar dipegang oleh Golongan VIIA (Fluor = 4.0), sedangkan Gas Mulia (VIIIA) sangat stabil dan inert.',
    ],
    contohPenerapan: {
      kasus: 'Di antara unsur 11Na, 12Mg, dan 19K, manakah yang memiliki jari-jari atom paling besar dan energi ionisasi paling rendah?',
      langkahPenyelesaian: '11Na dan 12Mg berada di Periode 3. 19K berada di Periode 4 (kulit lebih banyak, di bawah Na). Tren jari-jari membesar ke bawah. 19K memiliki kulit terbanyak sehingga jari-jari terbesar dan melepaskan elektron paling mudah (energi ionisasi terendah).',
      jawabanAkhir: '19K memiliki jari-jari terbesar dan energi ionisasi terendah.',
    },
  },
  {
    id: 'ikatan-kimia',
    nomorBab: 'Bab 4',
    kartuNumbers: 'Kartu 14 - 15',
    judul: 'Ikatan Kimia: Ion, Kovalen & Kovalen Koordinasi',
    kelas: 'X',
    fase: 'Fase E',
    kategori: 'Ikatan & Molekul',
    modelType: '3d-molecule',
    accentColor: '#F472B6',
    ringkasanKonsep:
      'Interaksi antaratom untuk mencapai kestabilan duplet (2) atau oktet (8). Terbagi menjadi ikatan ion (serah terima elektron logam + non-logam), ikatan kovalen (pemakaian bersama elektron non-logam + non-logam), dan ikatan kovalen koordinasi/datif.',
    rumusUtama: [
      {
        nama: 'Prinsip Ikatan Ion (Elektrovalen)',
        latex: '\\text{Logam (Lepas } e^-) + \\text{Non-Logam (Terima } e^-) \\longrightarrow \\text{Gaya Elektrostatik}',
        keterangan: 'Contoh: NaCl, MgO, CaF2. Titik leleh & didih sangat tinggi, konduktor saat lelehan/larutan.',
      },
      {
        nama: 'Prinsip Ikatan Kovalen (Homopolar)',
        latex: '\\text{Non-Logam} + \\text{Non-Logam} \\longrightarrow \\text{Pemakaian Bersama Pasangan Elektron (PEI)}',
        keterangan: 'Contoh: H2, Cl2, O2, N2, CH4, H2O.',
      },
      {
        nama: 'Ikatan Kovalen Koordinasi (Datif)',
        latex: 'A: + B \\longrightarrow A \\rightarrow B \\quad (\\text{PEI hanya berasal dari atom penyumbang } A)',
        keterangan: 'Contoh klasik: NH4+ (dari donor NH3 ke H+), H3O+, CO.',
      },
    ],
    poinKunci: [
      'Ingat Kunci: Ikatan ion = serah-terima elektron; Ikatan kovalen = pemakaian bersama pasangan elektron.',
      'Kovalen polar terjadi jika terdapat perbedaan keelektronegatifan yang signifikan dan bentuk molekul asimetris (ada PEB).',
      'Kovalen nonpolar simetris, momen dipol nol (misal CH4, CCl4, CO2).',
    ],
    contohPenerapan: {
      kasus: 'Mengapa molekul amonium (NH4+) memiliki 1 ikatan kovalen koordinasi?',
      langkahPenyelesaian: 'Atom N pada NH3 memiliki 1 Pasang Elektron Bebas (PEB). Ion H+ tidak memiliki elektron sama sekali. Atom N menyumbangkan PEB-nya untuk digunakan bersama dengan ion H+, membentuk ikatan koordinasi (datif).',
      jawabanAkhir: 'NH4+ memiliki 3 ikatan kovalen biasa dan 1 ikatan kovalen koordinasi N→H+.',
    },
  },
  {
    id: 'stoikiometri-dan-mol',
    nomorBab: 'Bab 5',
    kartuNumbers: 'Kartu 16 - 18',
    judul: 'Stoikiometri, Konsep Mol & Rumus Empiris / Molekul',
    kelas: 'X',
    fase: 'Fase E',
    kategori: 'Dasar Kimia & Stoikiometri',
    modelType: 'particle-system',
    accentColor: '#F59E0B',
    ringkasanKonsep:
      'Jantung perhitungan kimia kuantitatif: Massa Atom Relatif (Ar), Massa Molekul Relatif (Mr), konversi mol terhadap massa, jumlah partikel, volume molar gas, serta penentuan Rumus Empiris (RE) dan Rumus Molekul (RM).',
    rumusUtama: [
      {
        nama: 'Massa Atom Relatif Rata-rata (Ar)',
        latex: 'A_r = \\frac{(a_1 \\times A_{r1}) + (a_2 \\times A_{r2}) + \\dots}{a_1 + a_2 + \\dots}',
        keterangan: 'a = kelimpahan isotop di alam (%).',
      },
      {
        nama: 'Massa Molekul Relatif (Mr)',
        latex: 'M_r = \\sum \\text{Jumlah } A_r \\text{ seluruh atom penyusun molekul}',
        keterangan: 'Contoh: Mr H2O = 2(Ar H) + 1(Ar O) = 2(1) + 16 = 18 g/mol.',
      },
      {
        nama: 'Konsep Mol Dasar',
        latex: 'n = \\frac{\\text{massa (gram)}}{A_r \\text{ atau } M_r} \\quad ; \\quad \\text{Jumlah Partikel } X = n \\times 6{,}02 \\times 10^{23}',
        keterangan: 'Tetapan Avogadro L = 6,02 × 10²³ partikel/mol.',
      },
      {
        nama: 'Hubungan Rumus Empiris & Rumus Molekul',
        latex: '(\\text{Rumus Empiris})_n = \\text{Rumus Molekul} \\quad ; \\quad M_{r,\\text{senyawa}} = n \\times M_{r,\\text{empiris}}',
        keterangan: 'RE adalah perbandingan bilangan bulat paling sederhana atom penyusun.',
      },
    ],
    poinKunci: [
      'Volume molar gas pada kondisi Standar (STP 0°C, 1 atm): V = n × 22,4 Liter.',
      'Volume gas kondisi Ruang (RTP 25°C, 1 atm): V = n × 24,4 Liter.',
      'Persamaan gas ideal: P · V = n · R · T (R = 0,082 L atm / mol K).',
    ],
    contohPenerapan: {
      kasus: 'Suatu senyawa memiliki Rumus Empiris CH2 (Mr = 14) dan massa molar senyawa tersebut adalah 42 g/mol. Tentukan rumus molekulnya!',
      langkahPenyelesaian: 'n = Mr senyawa / Mr empiris = 42 / 14 = 3. Maka Rumus Molekul = (CH2)3 = C3H6 (Propena / Siklopropana).',
      jawabanAkhir: 'Rumus Molekul = C3H6',
    },
    interaktifCalcType: 'mol',
  },
  {
    id: 'laju-reaksi',
    nomorBab: 'Bab 7',
    kartuNumbers: 'Kartu 24 - 25',
    judul: 'Laju Reaksi & 5 Faktor yang Mempengaruhinya',
    kelas: 'XI',
    fase: 'Fase F',
    kategori: 'Fisik & Kinetika',
    modelType: '3d-reaction',
    accentColor: '#EC4899',
    ringkasanKonsep:
      'Perubahan konsentrasi reaktan atau produk tiap satuan waktu. Dipengaruhi oleh frekuensi tumbukan efektif partikel dan energi aktivasi (Ea).',
    rumusUtama: [
      {
        nama: 'Persamaan Laju Reaksi',
        latex: 'v = -\\frac{\\Delta[R]}{\\Delta t} = +\\frac{\\Delta[P]}{\\Delta t} \\quad ; \\quad v = k [A]^x [B]^y',
        keterangan: 'v = laju reaksi (M/s), k = tetapan laju, x & y = orde reaksi (ditentukan dari eksperimen).',
      },
      {
        nama: 'Rumus Pengaruh Kenaikan Suhu',
        latex: 'v_2 = v_1 \\times n^{\\frac{T_2 - T_1}{\\Delta T}} \\quad ; \\quad t_2 = t_1 \\times \\left(\\frac{1}{n}\\right)^{\\frac{T_2 - T_1}{\\Delta T}}',
        keterangan: 'Umumnya setiap kenaikan 10°C, laju reaksi menjadi 2x lebih cepat.',
      },
    ],
    poinKunci: [
      'Konsentrasi: Makin pekat, jumlah partikel per volume makin banyak, frekuensi tumbukan meningkat.',
      'Suhu: Suhu naik membuat energi kinetik partikel bertambah, partikel melampaui energi aktivasi (Ea).',
      'Luas Permukaan: Bidang sentuh zat padat yang makin halus memperbanyak kontak tumbukan.',
      'Katalis: Menurunkan energi aktivasi (Ea) tanpa ikut habis bereaksi.',
      'Tekanan / Volume (khusus gas): Tekanan diperbesar = volume diperkecil = partikel makin rapat.',
    ],
    contohPenerapan: {
      kasus: 'Jika pada suhu 25°C suatu reaksi selesai dalam 40 detik, dan setiap kenaikan 10°C laju reaksi meningkat 2 kali lipat, berapa lama reaksi berlangsung pada 45°C?',
      langkahPenyelesaian: 'ΔT = 45 - 25 = 20°C. n = 20 / 10 = 2 periode. t2 = 40 × (1/2)² = 40 / 4 = 10 detik.',
      jawabanAkhir: 'Waktu reaksi pada 45°C = 10 detik',
    },
  },
  {
    id: 'kesetimbangan-kimia',
    nomorBab: 'Bab 8',
    kartuNumbers: 'Kartu 26 - 28',
    judul: 'Kesetimbangan Kimia Dinamis & Hubungan Kc - Kp',
    kelas: 'XI',
    fase: 'Fase F',
    kategori: 'Fisik & Termodinamika',
    modelType: '3d-reaction',
    accentColor: '#06B6D4',
    ringkasanKonsep:
      'Keadaan dinamis saat laju pembentukan produk sama dengan laju penguraian reaktan kembali. Tetapan kesetimbangan Kc (konsentrasi) dan Kp (tekanan parsial gas).',
    rumusUtama: [
      {
        nama: 'Tetapan Kesetimbangan Konsentrasi (Kc)',
        latex: 'aA + bB \\rightleftharpoons cC + dD \\quad \\Longrightarrow \\quad K_c = \\frac{[C]^c [D]^d}{[A]^a [B]^b}',
        keterangan: 'Hanya fasa gas (g) dan larutan (aq) yang dimasukkan ke persamaan Kc. Padat (s) dan murni (l) diabaikan.',
      },
      {
        nama: 'Hubungan Kc dan Kp',
        latex: 'K_p = K_c \\cdot (R \\cdot T)^{\\Delta n}',
        keterangan: 'R = 0,082 L·atm/(mol·K), T = suhu mutlak (Kelvin), Δn = (koefisien gas produk) - (koefisien gas reaktan).',
      },
    ],
    poinKunci: [
      'Kesetimbangan dinamis: Reaksi terus berlangsung di tingkat mikroskopis meski konsentrasi makroskopis tampak konstan.',
      'Jika Δn = 0, maka nilai Kp = Kc.',
      'Asas Le Chatelier: Sistem akan bergeser melawan gangguan aksi luar (suhu, konsentrasi, tekanan/volume).',
      'Reaksi endoterm: Suhu naik bergeser ke arah produk (kanan); reaksi eksoterm sebaliknya.',
    ],
    contohPenerapan: {
      kasus: 'Pada reaksi N2(g) + 3H2(g) ⇌ 2NH3(g) pada suhu 300 K, nilai Kc = 0,5. Berapakah nilai Kp?',
      langkahPenyelesaian: 'Δn = koef produk (2) - koef reaktan (1+3=4) = 2 - 4 = -2. Kp = 0,5 × (0,082 × 300)⁻² = 0,5 / (24,6)² = 0,5 / 605,16 ≈ 8,26 × 10⁻⁴.',
      jawabanAkhir: 'Kp ≈ 8,26 × 10⁻⁴',
    },
    interaktifCalcType: 'kp-kc',
  },
  {
    id: 'asam-basa-ph',
    nomorBab: 'Bab 9',
    kartuNumbers: 'Kartu 29 - 31',
    judul: 'Teori Asam Basa, Indikator & Perhitungan pH Larutan',
    kelas: 'XI',
    fase: 'Fase F',
    kategori: 'Analitik & Larutan',
    modelType: '3d-molecule',
    accentColor: '#10B981',
    ringkasanKonsep:
      'Konsep asam-basa menurut Arrhenius (penghasil ion H+/OH-) dan Bronsted-Lowry (donor/akseptor proton H+), kesetimbangan ion air (Kw), serta perhitungan derajat keasaman (pH & pOH).',
    rumusUtama: [
      {
        nama: 'Derajat Keasaman (pH) & Derajat Kebasaan (pOH)',
        latex: '\\text{pH} = -\\log [\\text{H}^+] \\quad ; \\quad \\text{pOH} = -\\log [\\text{OH}^-] \\quad ; \\quad \\text{pH} + \\text{pOH} = 14 \\ (25^\\circ\\text{C})',
        keterangan: 'Contoh: [H+] = 10⁻³ M → pH = 3. [OH⁻] = 10⁻⁴ M → pOH = 4, pH = 14 - 4 = 10.',
      },
      {
        nama: 'Konsentrasi [H+] & [OH-] Asam/Basa Kuat',
        latex: '[\\text{H}^+] = a \\times M_a \\quad ; \\quad [\\text{OH}^-] = b \\times M_b',
        keterangan: 'a = valensi asam (jumlah H+), b = valensi basa (jumlah OH-).',
      },
      {
        nama: 'Konsentrasi [H+] Asam Lemah & Basa Lemah',
        latex: '[\\text{H}^+] = \\sqrt{K_a \\cdot M_a} \\quad ; \\quad [\\text{OH}^-] = \\sqrt{K_b \\cdot M_b}',
        keterangan: 'Ka / Kb = tetapan ionisasi asam / basa lemah.',
      },
    ],
    poinKunci: [
      'Arrhenius: Asam melepaskan H+ dalam air, Basa melepaskan OH- dalam air.',
      'Bronsted-Lowry: Asam adalah donor proton (H+), Basa adalah akseptor proton (H+). Membentuk pasangan asam-basa konjugasi.',
      'Tetapan kesetimbangan air: Kw = [H+][OH-] = 10⁻¹⁴ pada 25°C.',
    ],
    contohPenerapan: {
      kasus: 'Hitung pH dari larutan Ba(OH)2 0,005 M!',
      langkahPenyelesaian: 'Ba(OH)2 adalah basa kuat bivalen (b = 2). [OH⁻] = 2 × 0,005 M = 0,01 M = 10⁻² M. pOH = -log(10⁻²) = 2. pH = 14 - 2 = 12.',
      jawabanAkhir: 'pH larutan Ba(OH)2 = 12',
    },
    interaktifCalcType: 'ph',
  },
  {
    id: 'termokimia',
    nomorBab: 'Bab 10',
    kartuNumbers: 'Kartu 41 - 42',
    judul: 'Termokimia, Perubahan Entalpi (ΔH) & Kalor Reaksi',
    kelas: 'XI',
    fase: 'Fase F',
    kategori: 'Fisik & Energi',
    modelType: '3d-reaction',
    accentColor: '#F97316',
    ringkasanKonsep:
      'Perubahan energi panas pada reaksi kimia. Reaksi eksoterm (melepas kalor ke lingkungan, ΔH < 0) vs endoterm (menyerap kalor, ΔH > 0), Hukum Hess, dan energi ikatan rata-rata.',
    rumusUtama: [
      {
        nama: 'Kalor Reaksi Kalorimeter',
        latex: 'q = m \\cdot c \\cdot \\Delta T \\quad ; \\quad \\Delta H = -\\frac{q}{n}',
        keterangan: 'm = massa larutan (gram), c = kalor jenis air (4,18 J/g°C), ΔT = kenaikan suhu (°C/K).',
      },
      {
        nama: 'Hukum Hess & Entalpi Pembentukan Standar',
        latex: '\\Delta H^\\circ = \\sum \\Delta H_f^\\circ(\\text{produk}) - \\sum \\Delta H_f^\\circ(\\text{reaktan})',
        keterangan: 'Perubahan entalpi hanya bergantung pada keadaan awal dan akhir, tidak pada lintasan jalannya reaksi.',
      },
      {
        nama: 'Energi Ikatan Rata-Rata',
        latex: '\\Delta H = \\sum E_{\\text{ikatan putus (reaktan)}} - \\sum E_{\\text{ikatan terbentuk (produk)}}',
        keterangan: 'Pemutusan ikatan membutuhkan energi (+), pembentukan ikatan melepaskan energi (-).',
      },
    ],
    poinKunci: [
      'Reaksi Eksoterm: Suhu sistem naik, wadah terasa hangat/panas, ΔH bernilai negatif (-).',
      'Reaksi Endoterm: Suhu sistem turun, wadah terasa dingin, ΔH bernilai positif (+).',
      'Diagram tingkat energi: Pada eksoterm reaktan berada di atas produk.',
    ],
    contohPenerapan: {
      kasus: 'Pemanasan 100 gram air mengalami kenaikan suhu dari 25°C menjadi 35°C (c = 4,2 J/g°C). Hitung kalor yang diserap air!',
      langkahPenyelesaian: 'q = m · c · ΔT = 100 g × 4,2 J/g°C × (35 - 25)°C = 100 × 4,2 × 10 = 4200 Joule = 4,2 kJ.',
      jawabanAkhir: 'q = 4,2 kJ',
    },
    interaktifCalcType: 'kalor',
  },
  {
    id: 'elektrokimia-dan-sel-volta',
    nomorBab: 'Bab 11',
    kartuNumbers: 'Kartu 32 & 45',
    judul: 'Elektrokimia: Sel Volta (Galvani) & Hukum Faraday',
    kelas: 'XII',
    fase: 'Fase F',
    kategori: 'Fisik & Elektrokimia',
    modelType: '3d-molecule',
    accentColor: '#14B8A6',
    ringkasanKonsep:
      'Sel elektrokimia yang mengubah reaksi redoks spontan menjadi arus listrik (Sel Volta) serta perhitungan kuantitatif massa endapan zat pada elektrolisis (Hukum Faraday I).',
    rumusUtama: [
      {
        nama: 'Potensial Sel Standar (E°sel)',
        latex: 'E^\\circ_{\\text{sel}} = E^\\circ_{\\text{katoda}} - E^\\circ_{\\text{anoda}} \\quad (E^\\circ_{\\text{reduksi}} - E^\\circ_{\\text{oksidasi}})',
        keterangan: 'Reaksi berlangsung spontan jika E°sel bernilai positif (+). KRAP: Katoda Reduksi (+), Anoda Oksidasi (-).',
      },
      {
        nama: 'Hukum Faraday I (Massa Endapan Elektrolisis)',
        latex: 'm = \\frac{A_r \\cdot I \\cdot t}{n \\cdot F} \\quad ; \\quad w = e \\times \\frac{I \\cdot t}{96500}',
        keterangan: 'Ar = massa atom relatif, I = kuat arus (Ampere), t = waktu (sekon), n = valensi elektron yang terlibat, F = 96.500 C/mol e-.',
      },
    ],
    poinKunci: [
      'Jembatan garam berfungsi menetralkan kelebihan ion di kedua kompartemen setengah sel.',
      'Deret Volta: Li K Ba Ca Na Mg Al Mn Zn Cr Fe Cd Co Ni Sn Pb (H) Sb Bi Cu Hg Ag Pt Au. Unsur sebelah kiri mendesak unsur sebelah kanan.',
      'Katoda bermuatan positif di Sel Volta, tetapi bermuatan negatif di Sel Elektrolisis (tetap tempat reduksi).',
    ],
    contohPenerapan: {
      kasus: 'Diketahui: Zn²⁺ + 2e⁻ → Zn (E° = -0,76 V) dan Cu²⁺ + 2e⁻ → Cu (E° = +0,34 V). Hitung potensial sel standar yang terbentuk!',
      langkahPenyelesaian: 'E° Cu lebih besar sehingga Cu mengalami reduksi di Katoda. Zn mengalami oksidasi di Anoda. E°sel = E°katoda - E°anoda = +0,34 V - (-0,76 V) = +1,10 V.',
      jawabanAkhir: 'E°sel = +1,10 V (reaksi spontan)',
    },
    interaktifCalcType: 'sel-volta',
  },
  {
    id: 'redoks-dan-kimia-unsur',
    nomorBab: 'Bab 13 & 18',
    kartuNumbers: 'Kartu 33, 37, 43',
    judul: 'Reaksi Redoks, Aturan Biloks & Kimia Unsur',
    kelas: 'XII',
    fase: 'Fase F',
    kategori: 'Anorganik & Reaksi',
    modelType: 'particle-system',
    accentColor: '#A855F7',
    ringkasanKonsep:
      'Konsep redoks berdasarkan transfer elektron dan perubahan bilangan oksidasi (biloks). Karakteristik kereaktifan golongan IA (alkali), IIA (alkali tanah), VIIA (halogen), dan VIIIA (gas mulia).',
    rumusUtama: [
      {
        nama: 'Konsep Dasar Redoks',
        latex: '\\text{Oksidasi} = \\text{Pelepasan } e^- \\text{ / Kenaikan Biloks} \\quad ; \\quad \\text{Reduksi} = \\text{Penerimaan } e^- \\text{ / Penurunan Biloks}',
        keterangan: 'Zat yang teroksidasi = reduktor; zat yang tereduksi = oksidator.',
      },
      {
        nama: 'Aturan Ringkas Bilangan Oksidasi (Biloks)',
        latex: '\\text{Unsur bebas} = 0 \\quad ; \\quad \\text{Ion monoatomik} = \\text{muatannya} \\quad ; \\quad \\text{H} = +1 \\quad ; \\quad \\text{O} = -2',
        keterangan: 'Pengecualian: H pada hidrida logam (-1 seperti NaH); O pada peroksida (-1 seperti H2O2) dan OF2 (+2).',
      },
      {
        nama: 'Reaksi Unsur Golongan IA & IIA dengan Air',
        latex: '2\\text{Na} + 2\\text{H}_2\\text{O} \\rightarrow 2\\text{NaOH} + \\text{H}_2 \\quad ; \\quad \\text{Ca} + 2\\text{H}_2\\text{O} \\rightarrow \\text{Ca(OH)}_2 + \\text{H}_2',
        keterangan: 'Menghasilkan basa kuat dan gas hidrogen yang mudah terbakar.',
      },
      {
        nama: 'Daya Pengoksidasi Halogen (Golongan VIIA)',
        latex: '\\text{Reaktivitas / Daya Oksidasi: } \\text{F}_2 > \\text{Cl}_2 > \\text{Br}_2 > \\text{I}_2',
        keterangan: 'Halogen di atas dapat mendesak ion halida di bawahnya: Cl2 + 2NaBr → 2NaCl + Br2.',
      },
    ],
    poinKunci: [
      'Logam alkali (IA: Li, Na, K, Rb, Cs) sangat reaktif, disimpan dalam minyak tanah.',
      'Logam alkali tanah (IIA: Be, Mg, Ca, Sr, Ba) kurang reaktif dibandingkan IA tetapi tetap basa kuat.',
      'Gas Mulia (VIIIA: He, Ne, Ar, Kr, Xe, Rn) berkonfigurasi oktet stabil (kecuali He duplet) sehingga sangat lambat bereaksi.',
    ],
    contohPenerapan: {
      kasus: 'Tentukan bilangan oksidasi atom Mangan (Mn) pada senyawa kalium permanganat KMnO4!',
      langkahPenyelesaian: 'Biloks K = +1 (Golongan IA), Biloks O = -2 (4 atom O = -8). Jumlah biloks senyawa netral = 0. (+1) + Biloks(Mn) + (-8) = 0 → Biloks(Mn) = +7.',
      jawabanAkhir: 'Biloks Mn dalam KMnO4 = +7',
    },
  },
  {
    id: 'reaksi-organik-dan-minyak-bumi',
    nomorBab: 'Bab 10/16 & 17',
    kartuNumbers: 'Kartu 39 - 40',
    judul: 'Reaksi Senyawa Organik & Fraksi Minyak Bumi',
    kelas: 'XII',
    fase: 'Fase F',
    kategori: 'Kimia Organik',
    modelType: '3d-molecule',
    accentColor: '#EAB308',
    ringkasanKonsep:
      'Tiga tipe reaksi utama senyawa hidrokarbon/karbon: substitusi (penggantian gugus), adisi (pemutusan ikatan rangkap), dan eliminasi (pembentukan ikatan rangkap), serta urutan fraksi distilasi bertingkat minyak bumi.',
    rumusUtama: [
      {
        nama: 'Reaksi Substitusi (Penggantian)',
        latex: '\\text{CH}_4 + \\text{Cl}_2 \\xrightarrow{\\text{cahaya UV}} \\text{CH}_3\\text{Cl} + \\text{HCl}',
        keterangan: 'Terjadi pada senyawa jenuh (alkana). Satu atom H digantikan oleh atom halogen.',
      },
      {
        nama: 'Reaksi Adisi (Penjenuhan Ikatan Rangkap)',
        latex: '\\text{CH}_2=\\text{CH}_2 + \\text{Br}_2 \\longrightarrow \\text{CH}_2\\text{Br}-\\text{CH}_2\\text{Br}',
        keterangan: 'Ikatan rangkap dua/tiga terbuka menjadi ikatan tunggal. Memenuhi hukum Markovnikov untuk asam halida.',
      },
      {
        nama: 'Reaksi Eliminasi (Pembentukan Ikatan Rangkap)',
        latex: '\\text{CH}_3-\\text{CH}_2\\text{Br} + \\text{KOH (alk)} \\longrightarrow \\text{CH}_2=\\text{CH}_2 + \\text{KBr} + \\text{H}_2\\text{O}',
        keterangan: 'Pelepasan molekul kecil (HBr, H2O) membentuk ikatan rangkap.',
      },
    ],
    poinKunci: [
      'Fraksi Gas (C1 - C4): Titik didih < 20°C, digunakan untuk bahan bakar gas LPG.',
      'Fraksi Bensin (C5 - C12): Titik didih 40 - 200°C, bahan bakar kendaraan bermotor, mutu ditentukan angka oktan (isooktana & n-heptana).',
      'Fraksi Kerosin (C12 - C15): Bahan bakar pesawat jet (avtur) dan minyak tanah.',
      'Fraksi Solar (C15 - C18): Bahan bakar mesin diesel.',
      'Fraksi Minyak Pelumas (C18 - C20): Pelumas mesin & oli.',
      'Residu / Aspal (> C20): Lapisan pengaspal jalan raya & isolator.',
    ],
    contohPenerapan: {
      kasus: 'Identifikasi jenis reaksi berikut: C2H4 + H2 → C2H6',
      langkahPenyelesaian: 'Etena (C2H4) memiliki ikatan rangkap dua C=C. Gas H2 memutus ikatan rangkap tersebut menjadi etana (C2H6) yang berikatan tunggal. Reaksi pemutusan ikatan rangkap disebut reaksi adisi.',
      jawabanAkhir: 'Jenis reaksi = Adisi (Hidrogenasi)',
    },
  },
  {
    id: 'sifat-koligatif-larutan',
    nomorBab: 'Bab 20',
    kartuNumbers: 'Kartu 45 - 47',
    judul: 'Sifat Koligatif Larutan & Tekanan Osmotik',
    kelas: 'XII',
    fase: 'Fase F',
    kategori: 'Fisik & Larutan',
    modelType: 'particle-system',
    accentColor: '#38BDF8',
    ringkasanKonsep:
      'Sifat fisik larutan yang hanya bergantung pada jumlah partikel zat terlarut, bukan jenis zatnya: penurunan tekanan uap (ΔP), kenaikan titik didih (ΔTb), penurunan titik beku (ΔTf), dan tekanan osmotik (π).',
    rumusUtama: [
      {
        nama: 'Penurunan Tekanan Uap (Hukum Raoult)',
        latex: '\\Delta P = P^\\circ \\cdot X_{\\text{terlarut}} \\quad ; \\quad P = P^\\circ \\cdot X_{\\text{pelarut}}',
        keterangan: 'P° = tekanan uap jenuh pelarut murni, X = fraksi mol.',
      },
      {
        nama: 'Tekanan Osmotik Larutan (Van \'t Hoff)',
        latex: '\\pi = M \\cdot R \\cdot T \\cdot i',
        keterangan: 'M = molaritas (mol/L), R = 0,082 L·atm/(mol·K), T = suhu mutlak (Kelvin), i = faktor Van \'t Hoff (1 + (n-1)α).',
      },
      {
        nama: 'Penurunan Titik Beku & Kenaikan Titik Didih',
        latex: '\\Delta T_f = K_f \\cdot m \\cdot i \\quad ; \\quad \\Delta T_b = K_b \\cdot m \\cdot i',
        keterangan: 'm = molalitas (mol zat terlarut / 1000 gram pelarut), Kf/Kb = tetapan krioskopik/ebulioskopik air.',
      },
    ],
    poinKunci: [
      'Untuk larutan nonelektrolit (glukosa, sukrosa, urea), faktor i = 1.',
      'Untuk larutan elektrolit kuat (NaCl, BaCl2), α ≈ 1 sehingga i = jumlah ion (NaCl → i = 2; BaCl2 → i = 3).',
      'Penerapan nyata: Pencairan salju di jalan dengan garam dapur, cairan infus isotonik tubuh (π = 7,7 atm), dan desalinasi osmosis balik.',
    ],
    contohPenerapan: {
      kasus: 'Hitung tekanan osmotik larutan glukosa 0,1 M pada suhu 27°C (R = 0,082 L atm/mol K)!',
      langkahPenyelesaian: 'T = 27 + 273 = 300 K. Glukosa nonelektrolit (i = 1). π = M · R · T = 0,1 mol/L × 0,082 L atm/mol K × 300 K = 2,46 atm.',
      jawabanAkhir: 'Tekanan osmotik π = 2,46 atm',
    },
  },
  {
    id: 'ringkasan-cepat-tips-tka',
    nomorBab: 'Ringkasan Cepat',
    kartuNumbers: 'Kartu 48',
    judul: 'Ringkasan Cepat & Mindset Juara TKA Kimia',
    kelas: 'XII',
    fase: 'Fase F',
    kategori: 'Strategi & Tips Ujian',
    modelType: '3d-molecule',
    accentColor: '#F59E0B',
    ringkasanKonsep:
      'Pesan motivasi dan strategi efisien dari catatan rangkuman: "Inti Kimia = pahami konsep dasar, hafalkan rumus penting, dan banyak latihan berkala!".',
    rumusUtama: [
      {
        nama: 'Formula Sukses TKA Kimia',
        latex: '\\text{Skor Maksimal} = \\text{Pahami Konsep} + \\text{Kuasai Rumus} + \\text{Latihan Soal Adaptif}',
        keterangan: 'Kuasai eliminasi opsi jawaban dan pemahaman unit satuan.',
      },
    ],
    poinKunci: [
      'Pahami pola periodik dan stoikiometri sebagai fondasi semua bab lanjutan.',
      'Perhatikan fasa zat pada rumus kesetimbangan (hanya gas dan aqueous yang masuk Kc/Kp).',
      'Ingat tanda entalpi: eksoterm selalu negatif (-), endoterm selalu positif (+).',
      'Gunakan tombol "Mode Gambar Asli" untuk melihat tulisan tangan asli ringkasan rumus ini.',
    ],
    contohPenerapan: {
      kasus: 'Bagaimana cara cepat mengidentifikasi reaksi redoks?',
      langkahPenyelesaian: 'Cari apakah ada unsur bebas (seperti O2, H2, Fe, Na, Cl2) di reaktan atau produk. Jika ada unsur bebas yang membentuk senyawa (atau sebaliknya), reaksi tersebut 99% pasti reaksi redoks!',
      jawabanAkhir: 'Cek keberadaan unsur bebas!',
    },
  },
  {
    id: 'larutan-penyangga-buffer',
    nomorBab: 'Bab 14',
    kartuNumbers: 'Kartu 34 - 35',
    judul: 'Larutan Penyangga (Buffer) Asam & Basa',
    kelas: 'XI',
    fase: 'Fase F',
    kategori: 'Analitik & Larutan',
    modelType: '3d-molecule',
    accentColor: '#10B981',
    ringkasanKonsep:
      'Larutan yang dapat mempertahankan nilai pH dari penambahan sedikit asam, basa, atau pengenceran. Terdiri dari campuran Asam Lemah + Basa Konjugasinya (Buffer Asam) atau Basa Lemah + Asam Konjugasinya (Buffer Basa).',
    rumusUtama: [
      {
        nama: 'Buffer Asam (pH < 7)',
        latex: '[\\text{H}^+] = K_a \\times \\frac{n_{\\text{asam lemah}}}{n_{\\text{basa konjugasi}}} \\quad ; \\quad \\text{pH} = pK_a - \\log\\left(\\frac{n_a}{n_{bk}}\\right)',
        keterangan: 'na = mol asam lemah, nbk = mol basa konjugasi (garam × valensi anion).',
      },
      {
        nama: 'Buffer Basa (pH > 7)',
        latex: '[\\text{OH}^-] = K_b \\times \\frac{n_{\\text{basa lemah}}}{n_{\\text{asam konjugasi}}} \\quad ; \\quad \\text{pH} = 14 - \\left(pK_b - \\log\\left(\\frac{n_b}{n_{ak}}\\right)\\right)',
        keterangan: 'nb = mol basa lemah, nak = mol asam konjugasi (garam × valensi kation).',
      },
    ],
    poinKunci: [
      'Penyangga Asam: Dibuat dari campuran CH3COOH + CH3COONa atau reaksi CH3COOH sisa + NaOH habis.',
      'Penyangga Basa: Dibuat dari NH3 + NH4Cl atau reaksi NH3 sisa + HCl habis.',
      'Sistem penyangga utama dalam darah manusia adalah H2CO3 / HCO3- yang menjaga pH darah stabil pada ~7.4.',
    ],
    contohPenerapan: {
      kasus: 'Campuran 100 mL CH3COOH 0,1 M (Ka = 10⁻⁵) dan 50 mL CH3COONa 0,2 M. Tentukan pH larutan penyangga yang terbentuk!',
      langkahPenyelesaian: 'mol CH3COOH = 100 mL × 0,1 M = 10 mmol. mol CH3COONa = 50 mL × 0,2 M = 10 mmol. [H+] = 10⁻⁵ × (10 / 10) = 10⁻⁵ M.',
      jawabanAkhir: 'pH = -log(10⁻⁵) = 5',
    },
    interaktifCalcType: 'ph',
  },
  {
    id: 'hidrolisis-garam',
    nomorBab: 'Bab 15',
    kartuNumbers: 'Kartu 36',
    judul: 'Hidrolisis Garam & Sifat Keasaman Garam',
    kelas: 'XI',
    fase: 'Fase F',
    kategori: 'Analitik & Larutan',
    modelType: 'beaker',
    accentColor: '#8B5CF6',
    ringkasanKonsep:
      'Reaksi kation atau anion garam berasal dari asam/basa lemah dengan air. Garam dari Asam Lemah + Basa Kuat bersifat Basa (terhidrolisis sebagian). Garam dari Asam Kuat + Basa Lemah bersifat Asam.',
    rumusUtama: [
      {
        nama: 'Garam Bersifat Basa (Asam Lemah + Basa Kuat)',
        latex: '[\\text{OH}^-] = \\sqrt{\\frac{K_w}{K_a} \\cdot M_{\\text{anion}}} \\quad ; \\quad K_h = \\frac{K_w}{K_a}',
        keterangan: 'M_anion = molaritas garam × valensi anion. Kw = 10⁻¹⁴.',
      },
      {
        nama: 'Garam Bersifat Asam (Asam Kuat + Basa Lemah)',
        latex: '[\\text{H}^+] = \\sqrt{\\frac{K_w}{K_b} \\cdot M_{\\text{kation}}} \\quad ; \\quad K_h = \\frac{K_w}{K_b}',
        keterangan: 'M_kation = molaritas garam × valensi kation.',
      },
      {
        nama: 'Garam Asam Lemah + Basa Lemah',
        latex: '[\\text{H}^+] = \\sqrt{K_w \\cdot \\frac{K_a}{K_b}}',
        keterangan: 'pH garam dari asam & basa lemah tidak tergantung pada konsentrasi garam, melainkan hanya nilai Ka dan Kb.',
      },
    ],
    poinKunci: [
      'Garam dari Asam Kuat + Basa Kuat (seperti NaCl, KNO3) TIDAK terhidrolisis, pH netral = 7.',
      'Ion yang terhidrolisis selalu berasal dari komponen yang LEMAH.',
      'Jika Ka > Kb maka garam bersifat asam; jika Ka < Kb garam bersifat basa.',
    ],
    contohPenerapan: {
      kasus: 'Hitung pH larutan CH3COONa 0,1 M jika diketahui Ka CH3COOH = 10⁻⁵!',
      langkahPenyelesaian: '[OH⁻] = √( (10⁻¹⁴ / 10⁻⁵) × 0,1 ) = √( 10⁻⁹ × 10⁻¹ ) = √( 10⁻¹⁰ ) = 10⁻⁵ M. pOH = 5 → pH = 14 - 5 = 9.',
      jawabanAkhir: 'pH larutan CH3COONa = 9 (Basa)',
    },
    interaktifCalcType: 'ph',
  },
  {
    id: 'ksp-kelarutan',
    nomorBab: 'Bab 19',
    kartuNumbers: 'Kartu 44',
    judul: 'Hasil Kali Kelarutan (Ksp) & Pengendapan',
    kelas: 'XI',
    fase: 'Fase F',
    kategori: 'Analitik & Kesetimbangan',
    modelType: 'beaker',
    accentColor: '#0284C7',
    ringkasanKonsep:
      'Kesetimbangan antara zat padat sukar larut dengan ion-ionnya dalam larutan jenuh. Digunakan untuk meramalkan pembentukan endapan berdasarkan perbandingan Hasil Kali Ion (Qsp) terhadap Ksp.',
    rumusUtama: [
      {
        nama: 'Persamaan Ksp Garam $A_x B_y$',
        latex: 'A_x B_y(s) \\rightleftharpoons x A^{y+}(aq) + y B^{x-}(aq) \\quad \\Longrightarrow \\quad K_{sp} = [A^{y+}]^x [B^{x-}]^y = x^x y^y s^{x+y}',
        keterangan: 's = kelarutan senyawa dalam mol/L (molaritas).',
      },
      {
        nama: 'Prediksi Pembentukan Endapan (Qsp vs Ksp)',
        latex: 'Q_{sp} < K_{sp} \\text{ (belum jenuh)} \\ ; \\ Q_{sp} = K_{sp} \\text{ (tepat jenuh)} \\ ; \\ Q_{sp} > K_{sp} \\text{ (terjadi endapan)}',
        keterangan: 'Qsp dihitung dengan konsentrasi awal ion sebelum pengendapan.',
      },
    ],
    poinKunci: [
      'Pengaruh Ion Senama: Penambahan ion senama memperkecil kelarutan (s) zat yang sukar larut.',
      'Pengaruh pH: Basa sukar larut (misal Mg(OH)2) lebih mudah larut dalam suasana asam (pH rendah).',
    ],
    contohPenerapan: {
      kasus: 'Jika Ksp AgCl = 10⁻¹⁰, hitung kelarutan (s) AgCl dalam air murni!',
      langkahPenyelesaian: 'AgCl ⇌ Ag+ + Cl-. Ksp = s × s = s². s = √(10⁻¹⁰) = 10⁻⁵ mol/L.',
      jawabanAkhir: 'Kelarutan s = 10⁻⁵ M',
    },
  },
  {
    id: 'benzena-dan-polimer',
    nomorBab: 'Bab 21 & 22',
    kartuNumbers: 'Kartu 49 - 50',
    judul: 'Benzena, Turunannya, Polimer & Biomolekul',
    kelas: 'XII',
    fase: 'Fase F',
    kategori: 'Kimia Organik',
    modelType: 'organic',
    accentColor: '#EC4899',
    ringkasanKonsep:
      'Struktur aromatik cincin benzena (C6H6) dengan elektron terdelokalisasi, reaksi substitusi elektrofilik, serta pembentukan makromolekul polimer (adisi/kondensasi) dan biomolekul utama (karbohidrat, protein, lemak).',
    rumusUtama: [
      {
        nama: 'Turunan Benzena Utama',
        latex: '\\text{Toluena (}-\\text{CH}_3) \\quad ; \\quad \\text{Anilina (}-\\text{NH}_2) \\quad ; \\quad \\text{Fenol (}-\\text{OH}) \\quad ; \\quad \\text{Asam Benzoat (}-\\text{COOH})',
        keterangan: 'Posisi substituen disubstitusi: Orto (1,2), Meta (1,3), Para (1,4).',
      },
      {
        nama: 'Polimer Adisi vs Kondensasi',
        latex: 'n(\\text{CH}_2=\\text{CH}_2) \\xrightarrow{\\text{Adisi}} -[\\text{CH}_2-\\text{CH}_2]_n- \\quad ; \\quad \\text{Monomer}_A + \\text{Monomer}_B \\xrightarrow{\\text{Kondensasi}} \\text{Polimer} + H_2O',
        keterangan: 'Adisi: monomer berikatan rangkap. Kondensasi: melepaskan molekul kecil (H2O/HCl).',
      },
    ],
    poinKunci: [
      'Fenol bersifat asam lemah dan dapat bereaksi dengan NaOH, biasa dipakai sebagai antiseptik.',
      'Toluena direaksikan dengan HNO3 pekat menghasilkan TNT (bahan peledak).',
      'Uji Protein: Uji Biuret (warna ungu = ikatan peptida), Uji Xanthoproteat (warna kuning = cincin benzena).',
      'Uji Karbohidrat: Uji Benedict/Fehling (endapan merah bata = gula pereduksi).',
    ],
    contohPenerapan: {
      kasus: 'Uji apakah sampel makanan mengandung ikatan peptida protein!',
      langkahPenyelesaian: 'Tambahkan pereaksi Biuret (CuSO4 + NaOH). Jika terbentuk perubahan warna menjadi ungu, maka sampel positif mengandung protein.',
      jawabanAkhir: 'Positif Protein = Perubahan warna Ungu dengan Biuret.',
    },
  },
];
